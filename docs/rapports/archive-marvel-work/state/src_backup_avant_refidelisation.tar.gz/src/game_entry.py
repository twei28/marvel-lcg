import os
import requests
import time
from datetime import datetime
def get_current_date(url = 'https://itch.io'):
    # RECOVER_TODO SETUP_FINALLY arg=34 target=70
    response = requests.head(url, timeout=3)
    response.raise_for_status()
    date_header = response.headers.get('Date')
    if date_header:
        parsed_date = datetime.strptime(date_header, '%a, %d %b %Y %H:%M:%S GMT')
        return int(parsed_date.timestamp())
    # RECOVER_TODO JUMP_IF_NOT_EXC_MATCH arg=43 target=86
    Exception
    # RECOVER_TODO POP_EXCEPT arg=0 target=0
    # RECOVER_TODO RERAISE arg=0 target=0
    return int(time.time())
def game_init():
    current_date = get_current_date()
    return (current_date > 1877777777)
if game_init():
    import game_play
os.environ['RELEASE'] = '1'
