# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from build import Build
from game.card.face import *
from game.effect import *
from game.message import *
from game.player import *
from engine.log import Log
from engine.profile import Coverage
from game.world import *
CATEGORY_NAME = 'EFFECT'
class EffectInvoker:
    @staticmethod
    def InvokeOperation(effect: 'Effect', message: Message2):
        from game.message import Message
        from game.card.face.base import Unit2
        from game.player import Player
        world = effect.world
        effect.context.ResetBeforeOperation()
        # RECOVER_TODO SETUP_FINALLY arg=9 target=72
        effect.ability.operation(effect, message)
        # RECOVER_TODO JUMP_IF_NOT_EXC_MATCH arg=60 target=120
        Exception
        exc = UNKNOWN
        # RECOVER_TODO SETUP_FINALLY arg=13 target=112
        if effect.world.is_game_over:
            pass
        else:
            raise exc
        # RECOVER_TODO POP_EXCEPT arg=0 target=0
        exc = None
        del exc
        exc = None
        del exc
        # RECOVER_TODO RERAISE arg=1 target=1
        # RECOVER_TODO RERAISE arg=0 target=0
        if Coverage.is_enable:
            Coverage.TrackCallable(effect.ability.operation)
        if effect.context.end_attack_messages:
            attacked_targets = []
            damage_targets = []
            atk_messages = []
            retaliated_unit = set()
            end_atk_message = effect.context.end_attack_messages[0]
            total_dealt_damage = 0
            for message in effect.context.end_attack_messages:
                if not ((message.attacker == end_atk_message.attacker)):
                    raise AssertionError
                attacked_targets = (attacked_targets + message.attacked_targets)
                damage_targets = (damage_targets + message.damaged_targets)
                total_dealt_damage = (total_dealt_damage + message.total_dealt_damage)
                atk_messages = (atk_messages + message.atk_messages)
                for atk_message in message.atk_messages:
                    would_atk_unit_message = atk_message.would_atk_unit_message
                    if would_atk_unit_message:
                        for atk_target in atk_message.attacked_targets:
                            if (atk_target not in retaliated_unit):
                                retaliated_unit.add(atk_target)
                                if Unit2.IsType(atk_target):
                                    if atk_target.IsInPlay():
                                        atk_target.ResolveRetaliate(would_atk_unit_message)
                for message in message.atk_messages:
                    message.Send()
            end_message = Message.AfterUnitAttackEnd(end_atk_message.attacker, attacked_targets, damage_targets, total_dealt_damage, end_atk_message.by_effect, atk_messages, end_atk_message.would_atk_messages[0])
            end_message.Send()
            world.stat.RecordAttack(end_message)
        if effect.context.end_thwart_messages:
            schemes = []
            after_thw_messages = []
            total_remove_threat = 0
            end_thw_message = effect.context.end_thwart_messages[0]
            for message in effect.context.end_thwart_messages:
                schemes = (schemes + message.schemes)
                total_remove_threat = (total_remove_threat + message.total_remove_threat)
                after_thw_messages = (after_thw_messages + message.after_thw_messages)
            end_message = Message.AfterUnitThwartEnd(end_thw_message.trigger, schemes, total_remove_threat, end_thw_message.by_effect, after_thw_messages)
            end_message.Send()
            world.stat.RecordThwart(end_message)
        if effect.ability.is_label_defense:
            if isinstance(message, AttackerMessageInternal):
                if Player.IsType(effect.initiator):
                    for would_atk_message in message.would_atk_messages:
                        if not ((would_atk_message.has_resolves_defense_labeled_ability_internal == None)):
                            if not ((would_atk_message.has_resolves_defense_labeled_ability_internal == effect.initiator)):
                                raise AssertionError
                        would_atk_message.has_resolves_defense_labeled_ability_internal = effect.initiator
    @staticmethod
    def ResolveSelfInternal(effect, message, to_player, by_effect, ref_message = None, *, skip_cost = False):
        from game.player import Player
        from game.card.face.attribute.can_defense import CanDefense
        can_action = True
        ability = effect.ability
        initiator = effect.initiator
        world = effect.world
        this = effect.this
        control_by = effect.this.GetControlBy()
        if not (skip_cost):
            can_action = effect.ProcessSelfCost()
        if can_action:
            if isinstance(initiator, Player):
                if (to_player == None):
                    to_player = initiator
            if ability.flags.is_check_pay:
                pass
            if ability.is_label_defense:
                defender = effect.GetInitiator().GetIdentity()
                if message:
                    if CanDefense.IsType(defender):
                        defender.SpecialDefense(message, effect)
        if can_action:
            if effect.is_unregister_after_exec:
                effect.UnRegisterSelf()
            if message:
                if message.send_resolve_message:
                    effect.SetHasSpellInPhase()
            from engine import Engine
            controller_manager = Engine.game.controller_manager
            if not (Build.release):
                controller_manager.console.TryBreak(world)
            resolve_message = None
            # RECOVER_TODO SETUP_FINALLY arg=164 target=564
            should_send = False
            if (message == None):
                should_send = True
            if message:
                if message.send_resolve_message:
                    if not (ability.flags.is_delay_ability):
                        if not (ability.flags.is_statistics):
                            from game.card.face.card_type import Event
                            from game.card.face.card_type import Resource
                            should_send = True
                            if ability.is_play:
                                if not (Event.IsType(this)):
                                    should_send = False
                            if ability.flags.is_discard_pay:
                                if not (Resource.IsType(this)):
                                    should_send = False
            if should_send:
                resolve_message = Message.WhenEffectWouldResolve(effect, message, by_effect, to_player, control_by)
                resolve_message.Send()
                if resolve_message.is_be_instead:
                    return False
            if isinstance(ref_message, ability.when):
                EffectInvoker.InvokeOperation(effect, ref_message)
            else:
                if isinstance(message, ability.when):
                    EffectInvoker.InvokeOperation(effect, message)
                    if isinstance(message, Message.WhenCardRevealed):
                        message.reveal_message.AddResolved(effect)
                else:
                    if not ((ability.when in (Message.WhenCardRevealed, Message.WhenUnitBeDefeated, Message.WhenUnitWouldAttack, Message.WhenUnitWouldScheme, Message.AfterUnitAttackEnd, Message.AfterUnitTookDamage, Message.WhenSchemeBeDefeated, Message.WhenResolvePreparationAbility, Message.WhenCardBecomeBoost))):
                        raise AssertionError
                    class ExTriggerPlayerMessage(TriggerNonePlayerMessage):
                        def __init__(self, player: Player|None, world: World):
                            self.by_effect = by_effect
                            super().__init__(player, world=world)
                        def GetKillerPlayer(self):
                            pass
                        def GetAgainstPlayer(self) -> Player|None:
                            return self.to_player
                        def GetByPlayer(self) -> Player|None:
                            return self.to_player
                        def GetDefeatingPlayer(self) -> Player|None:
                            return self.to_player
                    to_player_message = ExTriggerPlayerMessage(to_player, world)
                    EffectInvoker.InvokeOperation(effect, to_player_message)
            # RECOVER_TODO JUMP_IF_NOT_EXC_MATCH arg=317 target=634
            Exception
            exc = UNKNOWN
            # RECOVER_TODO SETUP_FINALLY arg=23 target=626
            info = Log.OnCrash(CATEGORY_NAME, exc, effect.GetDisplayName(), ability.operation)
            world.render.ErrorOccurred(info)
            # RECOVER_TODO POP_EXCEPT arg=0 target=0
            exc = None
            del exc
        return can_action
