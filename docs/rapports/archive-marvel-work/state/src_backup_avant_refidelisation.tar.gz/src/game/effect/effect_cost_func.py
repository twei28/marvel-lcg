# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.ability import *
from game.effect import *
class EffectCostFunction:
    TF = TypeVar('TF', bound='CostFunc.Base')
    def __init__(self, effect: Effect):
        self.effect = effect
        self.additional_cost_func_list = []
        self.Reset()
    def Get(self, cost_fn_type, *, index = 0):
        fn = self.Has(cost_fn_type, index=index)
        if (fn == None):
            raise AssertionError
        return fn
    def Has(self, cost_fn_type, *, index = 0):
        check_index = 0
        for cost_fn in self.GetAll():
            if isinstance(cost_fn, cost_fn_type):
                if (check_index == index):
                    cost_fn
                    return
                check_index = (check_index + 1)
    def Reset(self):
        self.cost_func_list = []
        if not (self.effect.ability.flags.is_delay_ability):
            self.cost_func_list = self.effect.ability.cost_funcs[:]
            return
    def Add(self, cost_func: CostFunc.Base):
        self.additional_cost_func_list.append(cost_func)
    def Del(self, cost_func: CostFunc.Base):
        self.additional_cost_func_list.remove(cost_func)
    def GetAll(self):
        return (self.cost_func_list + self.additional_cost_func_list)
