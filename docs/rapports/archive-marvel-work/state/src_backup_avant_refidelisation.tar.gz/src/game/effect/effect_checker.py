# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.message import *
from game.player import *
from engine.log import Log
from game.effect.effect_failure import EffectFailure
CATEGORY_NAME = 'EFFECT'
class EffectChecker:
    def __init__(self, effect: Effect):
        from game.effect.effect_failure import FailureReason
        from game.effect.effect_target_cost import TargetCost
        self.effect = effect
        self.ability = effect.ability
        self.failures = FailureReason(effect)
        self.cost_for_different_target = TargetCost()
    def HasCostTargets(self):
        for cost_func in self.effect.cost_func.GetAll():
            if not (cost_func.HasTargets(self.effect)):
                return False
        return True
    def UpdateLegalTargets(self, referential_effect = None):
        from game.operate.faces_counter import FacesCounter
        from game.selector.selector import Selector
        effect = self.effect
        ability = self.ability
        if isinstance(effect.bind_message, Message.WhenPlayerChooseAbility):
            for_second_target = effect.bind_message.for_second_target
        else:
            for_second_target = False
        if ability.flags.is_statistics:
            return True
        if ability.flags.is_delay_ability:
            return True
        if not (ability.selectors):
            return True
        if effect.world.rule.v16_confuse_stun:
            if ability.is_label_attack:
                if effect.initiator.GetRoleCharacter().IsStunned():
                    if not (for_second_target):
                        effect.context.target_range = (0, 0)
                        return True
            if ability.is_label_thwart:
                if effect.initiator.GetRoleCharacter().IsConfused():
                    if not (for_second_target):
                        effect.context.target_range = (0, 0)
                        return True
        def get_all_legal_targets(selector, index, dont_update_target):
            all_legal_targets = list(selector.GetAllLegalTargets(effect, referential_effect))
            if (index == 0):
                effect.context.all_legal_targets = all_legal_targets
            target_range = selector.GetTargetRange(effect, all_legal_targets)
            if (target_range == None):
                return False
            if (selector.selector_rule.select_rule == 'DifferentType'):
                if (FacesCounter.GetDifferentTypesCount(all_legal_targets) < target_range[0]):
                    self.failures.Set(effect.initiator, EffectFailure.TypeCountNotEnough)
                    return False
            if (selector.selector_rule.select_rule == 'MustIncludeTraits'):
                left_must_include_traits = selector.selector_rule.target_must_include_traits[:]
                for target in all_legal_targets:
                    traits = target.FindHasTrait(*left_must_include_traits)
                    left_must_include_traits = [x for x in left_must_include_traits if (x not in traits)]
                    if not (left_must_include_traits):
                        pass
                    else:
                        pass
            if dont_update_target:
                return True
            if (index == 0):
                effect.context.all_legal_targets = all_legal_targets
                effect.context.target_range = target_range
                return True
            effect.context.all_legal_targets = []
            effect.context.target_range = (0, 0)
            return True
        has_target = False
        is_teamup = False
        for _item in enumerate(ability.selectors):
            index = UNKNOWN[0]
            selector = UNKNOWN[1]
            if selector:
                if not ((selector.condition == None)):
                    if selector.condition(effect):
                        has_this_target = False
                        if has_target:
                            if not ((index == 0)):
                                if not (selector.is_optional):
                                    # RECOVER_TODO SETUP_FINALLY arg=18 target=326
                                    dont_update_target = (is_teamup or ((not selector.is_optional) and (index != 0)))
                                    has_this_target = get_all_legal_targets(selector, index, dont_update_target)
                        # RECOVER_TODO SETUP_FINALLY arg=18 target=326
                        dont_update_target = (is_teamup or ((not selector.is_optional) and (index != 0)))
                        has_this_target = get_all_legal_targets(selector, index, dont_update_target)
                has_this_target = False
                if has_target:
                    if not ((index == 0)):
                        if not (selector.is_optional):
                            # RECOVER_TODO SETUP_FINALLY arg=18 target=326
                            dont_update_target = (is_teamup or ((not selector.is_optional) and (index != 0)))
                            has_this_target = get_all_legal_targets(selector, index, dont_update_target)
                # RECOVER_TODO SETUP_FINALLY arg=18 target=326
                dont_update_target = (is_teamup or ((not selector.is_optional) and (index != 0)))
                has_this_target = get_all_legal_targets(selector, index, dont_update_target)
        return has_target
    def UpdatePayResources(self, player):
        from game.message import Message
        from game.effect.effect_target_cost import TargetCost
        effect = self.effect
        ability = self.ability
        if not (ability.NeedCost()):
            raise AssertionError
        if player.world.rule.disable_pay:
            effect.context.ignore_resource_cost = True
        else:
            effect.context.ignore_resource_cost = False
        self.effect.this.card.ui.cost.Reset('All')
        self.cost_for_different_target = TargetCost()
        if not (effect.context.ignore_resource_cost):
            def process_target(target: CardFace|None):
                if target:
                    targets = [target]
                else:
                    targets = []
                calc_message = Message.WhenCalculateEffectCost(player, effect, targets)
                calc_message.Send()
                self.cost_for_different_target.AddTarget(target, calc_message.cost)
                paying_message = Message.CheckPlayerCanPayCost(player, effect, calc_message.cost, targets)
                paying_message.Send()
                for the_effects in paying_message.can_pay_effects:
                    cost_effect = the_effects[0]
                    res = the_effects[1]
                    check_effect = the_effects[2]
                    self.cost_for_different_target.AddPayment(target, cost_effect, res, check_effect)
            if ('09039' in [x.paper.card_id for x in effect.context.all_legal_targets]):
                for target in effect.context.all_legal_targets:
                    process_target(target)
                return True
            self.cost_for_different_target.SetNoneTargetOnly()
            process_target(None)
        return True
    def CheckBeforeActive(self, player):
        from game.element.resources import Resources
        effect = self.effect
        def check_target():
            if (self.ability.selectors != []):
                if not (self.ability.selectors[0]):
                    return True
                if not (self.ability.selectors[0].AfterSelectTargets(effect, effect.targets, effect.context.target_range)):
                    return False
            return True
        def check_pay():
            res_text = ''
            need_cost = ''
            if not (self.cost_for_different_target.IsEmpty()):
                if not (effect.context.ignore_resource_cost):
                    pass
            effect.context.paid_this_resources = Resources('0')
            return True
        if not (check_target()):
            self.failures.Set(player, EffectFailure.CheckTarget)
            return False
        if not (check_pay()):
            self.failures.Set(player, EffectFailure.CheckPay)
            return False
        return True
    def CheckNotOutOfPlay(self):
        from game.card.face.card_type import Obligation
        from game.card.face.base import Villain
        this = self.effect.this
        if Obligation.IsType(this):
            if this.card.area.flags.is_processing:
                return False
        if Villain.IsType(this):
            if this.IsInPlay():
                if this.IsThisFaceUp():
                    return True
        if this.card.area.flags.is_status_area:
            if this.IsFaceUp():
                return True
        if self.ability.is_ignore_out_of_play:
            return True
        if self.ability.can_work_also_in_hand:
            if this.IsLikeInHand():
                return True
        if self.ability.can_work_only_in_hand:
            if not (this.IsLikeInHand()):
                return False
            return True
        if this.IsInPlay(is_same_face=True):
            if this.IsFaceUp():
                return True
        if this.card.area.flags.is_processing:
            if this.IsFaceUp():
                return True
        if self.ability.is_play:
            return True
        if self.ability.flags.is_when_reveal:
            if this.CanResolveWhenRevealed():
                return True
        if self.ability.flags.is_boost:
            if this.card.area.flags.is_boost_area:
                if this.IsFaceUp():
                    return True
        return False
    def CheckCondition(self, message, asked_player):
        this = self.effect.this
        if not (self.effect.world.is_game_started):
            if not (isinstance(message, Message.WhenPlayerChooseAbility)):
                if not (self.effect.is_forced):
                    if not (self.ability.flags.is_setup):
                        if PlayerCard.IsType(this):
                            return False
        if not (self.CheckNotOutOfPlay()):
            self.failures.Set(asked_player, EffectFailure.OutOfPlay)
            return False
        if this.card.area.flags.is_revealing:
            if self.effect.ability.flags.is_nonkeyword:
                if not (self.effect.ability.IsFunction('AttachToWhenEnterPlay')):
                    if not (self.effect.ability.IsFunction('CheckAllyLimit')):
                        return False
        if self.ability.is_play:
            if asked_player:
                if (this.card.area == asked_player.hand_cards):
                    pass
                else:
                    if (this.GetOwner() != asked_player):
                        self.failures.SetText(asked_player, f"{asked_player} doesn't have this card")
                        return False
        if message.send_resolve_message:
            if not (self.ability.flags.is_statistics):
                check_message = Message.CheckEffectCondition(self.effect, this)
                check_message.Send()
                if not (check_message.effect_valid):
                    self.failures.SetText(asked_player, str([x.this for x in check_message.cause_by]))
                    return False
        for condition in self.ability.conditions:
            if not (self.effect.is_forced):
                if (self.effect.initiator != asked_player):
                    self.failures.SetText(asked_player, f'asking {asked_player}, but initiator is {self.effect.initiator}')
                    return False
            # RECOVER_TODO SETUP_FINALLY arg=21 target=400
            if not (condition(self.effect, message)):
                self.failures.SetText(asked_player, GetFuncName(condition))
                return False
        if isinstance(message, Message.WhenPlayerChooseAbility):
            by_effect = message.by_effect
        else:
            by_effect = self.effect
        if not (self.UpdateLegalTargets(by_effect)):
            self.failures.Set(asked_player, EffectFailure.UpdateLegalTargets)
            return False
        if not (self.HasCostTargets()):
            self.failures.Set(asked_player, EffectFailure.NoCostTarget)
            return False
        if self.ability.NeedCost():
            if not (asked_player):
                self.failures.Set(asked_player, EffectFailure.HasCostButNoAskPlayer)
                raise AssertionError(f'self={self!r}')
            self.UpdatePayResources(asked_player)
        if self.ability.is_label_defense:
            if isinstance(message, AttackerMessageInternal):
                if (message.has_resolves_defense_labeled_ability != None):
                    if (message.has_resolves_defense_labeled_ability != asked_player):
                        self.failures.Set(asked_player, EffectFailure.AlreadyResolvesDefense)
                        return False
        self.failures.Set(asked_player, EffectFailure.OK)
        return True
