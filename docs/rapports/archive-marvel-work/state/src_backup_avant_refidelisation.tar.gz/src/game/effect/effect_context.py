# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.effect import *
from game.message import *
from game.player import *
from game.world import *
from game.element.resources import Resources
from game.element.cost import Cost
@final
class EffectContext:
    def __init__(self, effect: Effect):
        self.effect = effect
        self.end_attack_messages = []
        self.end_thwart_messages = []
        self.initialized_targets = []
        self.paid_this_cost = Cost('0')
        self.paid_this_resources = Resources('0')
        self.targets_internal = []
        self.bind_message = None
        self.is_must_choose = False
        self.only_work_when_no_other_options = False
        self.target_range = (0, 0)
        self.all_legal_targets = []
        self.ignore_resource_cost = False
        self.ask_player = None
        self.this_effect_need_cost = None
        self.paid_this_res_effects = []
        self.initiator = self.effect.this.GetControlByOrOwner()
    def AddAtkMessage(self, end_message: Message.AfterUnitAttackEnd):
        self.end_attack_messages.append(end_message)
    def AddThwMessage(self, end_message: Message.AfterUnitThwartEnd):
        self.end_thwart_messages.append(end_message)
    def ResetBeforeOperation(self):
        self.end_attack_messages = []
        self.end_thwart_messages = []
        self.initialized_targets = [*(False, False, False)]
    def GetTargetsInternal(self, index):
        if not ((index != 0)):
            raise AssertionError
        if not ((self.initialized_targets[index] == False)):
            raise AssertionError
        effect = self.effect
        initiator = effect.GetInitiator()
        labels = [x for x in effect.ability.labels if (x != 'defense')]
        selector = effect.ability.selectors[index]
        self.initialized_targets[index] = True
        if (selector != None):
            return initiator.AskChooseSelect(selector, effect, labels=labels, for_second_target=True)
        return []
    def ResetBeforeCondition(self):
        self.is_must_choose = False
        self.only_work_when_no_other_options = False
    def ResetAfterOperation(self):
        self.target_range = (0, 0)
        self.all_legal_targets = []
        self.ignore_resource_cost = False
        self.ask_player = None
        self.this_effect_need_cost = None
        self.paid_this_res_effects = []
        self.initiator = self.effect.this.GetControlByOrOwner()
        self
