# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.face import *
from game.effect import *
from game.player import *
from game.message import *
from game.world import *
class GameRule(Effect):
    def __init__(self, face, bind_message = None, *, display_name = '', initiator = None):
        from game.effect.effect_context import EffectContext
        self.this = face
        self.context = EffectContext(self)
        if (initiator == None):
            initiator = face.GetControlByOrOwner()
        self.context.initiator = initiator
        self.display_name = display_name
        self.context.bind_message = bind_message
        self.world = face.card.world
    @property
    @override
    def is_rule(self):
        return True
    def __repr__(self):
        return 'Game Rule'
    @override
    def GetDisplayName(self, *, remove_space = False):
        if self.display_name:
            return self.display_name
        return str(self)
class Ties(GameRule):
    def __init__(self, name = 'Ties', *, world):
        first_player = world.GetFirstPlayer()
        face = first_player.GetIdentity()
        super().__init__(face, display_name=name)
    def __repr__(self):
        return 'Ties'
class MainSchemePhasePlaceThreat(GameRule):
    def __repr__(self):
        return 'Main Scheme Phase Place Threat'
class UniqueMinionRevealed(GameRule):
    def __repr__(self):
        return 'Unique Minion Revealed'
class Activate(GameRule):
    def __repr__(self):
        return 'Activate'
class Retaliate(GameRule):
    def __repr__(self):
        return 'Retaliate'
class Consequential(GameRule):
    def __repr__(self):
        return 'Consequential'
class Quickstrike(GameRule):
    def __repr__(self):
        return 'Quickstrike'
class Teamwork(GameRule):
    def __repr__(self):
        return 'Teamwork'
class Modifier(GameRule):
    def __repr__(self):
        return 'Modifier'
class SchemeActive(GameRule):
    def __init__(self, face: CardFace):
        super().__init__(face)
        self.this = face
        self.context.initiator = face.GetControlByOrOwner()
        self.world = face.card.world
    def __repr__(self):
        return 'Scheme'
class DebugRule(GameRule):
    def __init__(self, face, *, display_name = ''):
        super().__init__(face, display_name=display_name)
        self.context.initiator = face.GetOwner()
    def __repr__(self):
        return 'Debug Rule'
class Incite(GameRule):
    def __repr__(self):
        return 'Incite'
class Toughness(GameRule):
    def __repr__(self):
        return 'Toughness'
class ResetKeyword(GameRule):
    def __repr__(self):
        return 'Reset'
class Surge(GameRule):
    def __repr__(self):
        return 'Surge'
class Advance(GameRule):
    def __repr__(self):
        return 'Advance'
class EndPhase(GameRule):
    def __init__(self, initiator: Player):
        face = initiator.world.insert
        super().__init__(face, initiator=initiator)
    def __repr__(self):
        return 'End Phase'
