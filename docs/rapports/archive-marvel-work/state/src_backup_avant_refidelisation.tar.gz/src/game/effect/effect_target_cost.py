# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.effect import *
from game.element.resources import Resources
from game.element.cost import Cost
class TargetCost:
    @dataclass
    class Payment:
        __annotations__ = {}
        cost: 'Cost'
        payments: List[Dict[('Effect', str)]]
        cost_check: Dict[('Effect', 'Effect')]
    def __init__(self):
        self.target_cost = {}
        self.only_none_target = False
    def SetNoneTargetOnly(self):
        self.only_none_target = True
    def IsEmpty(self):
        return (self.target_cost == {})
    def HasTarget(self, face):
        return (face in self.target_cost)
    def GetCost(self, face: 'CardFace|None') -> Cost:
        if self.only_none_target:
            return self.target_cost[None].cost
        return self.target_cost[face].cost
    def GetPayment(self, face: 'CardFace|None') -> 'TargetCost.Payment':
        if self.only_none_target:
            return self.target_cost[None]
        return self.target_cost[face]
    def UpdateCost(self, face: 'CardFace|None', diff: int):
        self.target_cost[face].cost = (self.target_cost[face].cost + diff)
    def AddTarget(self, face: 'CardFace|None', cost: Cost):
        self.target_cost[face] = TargetCost.Payment(cost, [], {})
    def AddPayment(self, face: 'CardFace|None', cost_effect: Effect, cost: Resources, check_effect: Effect):
        self.target_cost[face].payments.append({cost_effect: cost.text_legacy})
        self.target_cost[face].cost_check[cost_effect] = check_effect
    def GetAllPayEffects(self):
        effects = []
        for face in self.target_cost:
            for effect_str in self.target_cost[face].payments:
                for effect in effect_str:
                    if (effect not in effects):
                        effects.append(effect)
        return effects
    def FindPayEffect(self, target, effect_id):
        for effect_res in self.GetPayment(target).payments:
            for effect in effect_res:
                if (effect.object_id == effect_id):
                    effect
                    return
