# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.face import *
from game.effect import *
from game.message import *
from game.player import *
from game.element.resources import Resources
from game.render.descriptor.effect import EffectDescriptor
from game.object import Object
from engine.log import Log
from engine.profile import Coverage
from game.message.message_type import HasPreEventMessage
from game.message.message_type import HasEndEventMessage
from game.world import *
from game.effect.effect_failure import EffectFailure
from game.effect.effect_invoke import EffectInvoker
Unused(EffectFailure)
CATEGORY_NAME = 'EFFECT'
class Effect(Object):
    def __init__(self, face, ability, *, is_temp = False, is_local = False, world):
        from game.card.face.card_type import Event
        from game.message import Message
        from game.effect.effect_checker import EffectChecker
        from game.effect.effect_context import EffectContext
        from game.effect.effect_cost_func import EffectCostFunction
        self.this = face
        ability.Initialize(self.this)
        self.ability = ability
        self.delay_ability = None
        self.checker = EffectChecker(self)
        self.failures = self.checker.failures
        self.cost_func = EffectCostFunction(self)
        self.context = EffectContext(self)
        if Coverage.is_enable:
            Coverage.RegisterFunction(self.ability.operation)
        self.is_unregister_after_exec = False
        self.is_temp = (is_temp or self.ability.flags.is_temp)
        self.is_nonkeyword = self.ability.flags.is_nonkeyword
        self.is_unregister = False
        self.is_local = is_local
        if not (self.is_forced):
            if not (Event.IsType(self.this)):
                if not ((self.ability.when != Message.WhenCardRevealed)):
                    raise AssertionError(f'self.this={self.this!r} self.ability={self.ability!r}')
        if ability.is_choose:
            super().__init__('choose_effect', world)
            return
        if self.is_forced:
            super().__init__('forced_effect', world)
            return
        if ability.is_paying:
            super().__init__('paying_effect', world)
            return
        super().__init__('effect', world)
    @property
    def is_rule(self):
        return self.ability.flags.is_rule
    @property
    def initiator(self) -> User:
        return self.context.initiator
    @property
    def bind_message(self) -> Message2|None:
        return self.context.bind_message
    @property
    def targets(self):
        return self.context.targets_internal
    @property
    def targets2(self):
        return self.context.GetTargetsInternal(1)
    @property
    def targets3(self):
        return self.context.GetTargetsInternal(2)
    def IsPaidForWithCardType(self, card_type):
        for effect in self.context.paid_this_res_effects:
            if card_type.IsType(effect.this):
                return True
        return False
    @property
    def is_forced(self):
        return self.ability.flags.is_forced
    @property
    def is_action(self):
        return self.ability.flags.is_action
    @property
    def must_choose(self):
        return (self.context.is_must_choose or self.ability.default_choose)
    def SetMustChoose(self):
        self.context.is_must_choose = True
    def __repr__(self):
        before = ''
        if self.is_local:
            before = (before + '^')
        if self.is_forced:
            before = (before + '!')
        if self.ability.flags.is_delay_ability:
            before = (before + '_')
        auto_unregister = ('Auto ' if self.is_unregister_after_exec else '')
        return f'({before}{self.object_id}) {self.this} {auto_unregister}{self.ability}'
    def GetBindMessage(self, event):
        if not ((self.bind_message != None)):
            raise AssertionError
        return self.bind_message.CastTo(event)
    def GetReplayText(self):
        ability_name = self.GetDisplayName(remove_space=True)
        if not ((ability_name != '')):
            raise AssertionError
        return (f'e{self.object_id} {ability_name} ' + self.this.GetReplayText())
    def ProcessSelfCost(self):
        for cost_func in self.cost_func.GetAll():
            # RECOVER_TODO SETUP_FINALLY arg=13 target=42
            if not (cost_func.PayCost(self, self.initiator)):
                return False
        return True
    def ResolveToPlayer(self, to_player, by_effect, ref_message):
        result = EffectInvoker.ResolveSelfInternal(self, None, to_player, by_effect, ref_message, skip_cost=True)
        return result
    def ResolveSelf(self, message, by_effect, *, to_player = None, skip_cost = False):
        result = EffectInvoker.ResolveSelfInternal(self, message, to_player, by_effect, skip_cost=skip_cost)
        return result
    def SetHasSpellInPhase(self):
        world = self.world
        if not (self.ability.flags.is_rule):
            if self.ability.flags.is_statistics:
                return
        return
        if not (world.rule.disable_limit_once):
            if not (self.ability.flags.is_interrupt):
                if not (self.ability.flags.is_response):
                    if not (self.ability.flags.is_resource):
                        if not (self.ability.flags.is_when_completed):
                            if not (self.ability.flags.is_when_reveal):
                                if not (self.ability.flags.is_when_defeated):
                                    if not (self.ability.flags.is_setup):
                                        if not (self.ability.flags.is_boost):
                                            if not (self.ability.flags.is_special):
                                                if not (self.ability.flags.is_action):
                                                    if self.ability.flags.is_nonkeyword:
                                                        if isinstance(self.bind_message, TriggerNonePlayerMessage):
                                                            if (self.bind_message.to_player != None):
                                                                player = self.bind_message.GetToPlayer()
                                                                effect = self
                                                                world.stat.RecordEffectWithPlayer(effect, player)
                                                        if isinstance(self.bind_message, Message.WhenPlayerPayingResources):
                                                            effect = self.bind_message.cost_check_effect
                                                            world.stat.RecordEffect(effect)
                                                        world.stat.RecordEffect(self)
                                                        self.GetBindMessage(self.ability.when).once_per_event_effects.append(self)
                                                        return
                                                        return
            if isinstance(self.bind_message, TriggerNonePlayerMessage):
                if (self.bind_message.to_player != None):
                    player = self.bind_message.GetToPlayer()
                    effect = self
                    world.stat.RecordEffectWithPlayer(effect, player)
            if isinstance(self.bind_message, Message.WhenPlayerPayingResources):
                effect = self.bind_message.cost_check_effect
                world.stat.RecordEffect(effect)
            world.stat.RecordEffect(self)
            self.GetBindMessage(self.ability.when).once_per_event_effects.append(self)
            return
    def UnRegisterSelf(self):
        if not (self.is_temp):
            if not (self.ability.flags.is_statistics):
                raise AssertionError(f'self={self!r}')
        if (self in self.this.effect.local_effects):
            self.is_unregister = True
            self.this.effect.local_effects.remove(self)
            return
        if (self in self.this.effect.given_effects):
            self.is_unregister = True
            self.this.effect.given_effects.remove(self)
            return
        self.this.effect.global_effects.remove(self)
        self.world.event_manager.UnRegisterEffect(self)
    def SetDestroyedAfter(self, unregister_after_exec, until_turn_end = False, until_next_turn_end = False, until_phase_end = False, until_round_end = False, until_this_leave_play = False, until_after_event = None, until_after_resolve_effect = None):
        if not (self.is_temp):
            raise AssertionError(f'self.ability.flags={self.ability.flags!r}')
        from game.ability.factory import AbilityFactory
        from game.ability import AbilityType
        from game.operate.effects import Effects
        from game.ability import Ability
        self.is_unregister_after_exec = unregister_after_exec
        temp_effects = []
        def try_unregister(effect: 'Effect'):
            if not (effect.is_unregister):
                effect.UnRegisterSelf()
            Effects.UnRegister([x for x in temp_effects if not (x.is_unregister)])
        if until_turn_end:
            if not ((until_phase_end == False)):
                raise AssertionError
            if not ((until_round_end == False)):
                raise AssertionError
            temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.WhenPlayerTurnEnd(AbilityType.Temp0, 'This', lambda effect, message: try_unregister(self)), unregister_after_exec=True))
        if until_next_turn_end:
            temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.WhenPlayerTurnEnd(AbilityType.Temp0, 'This', lambda effect, message: try_unregister(self), round_id=(self.world.round_id + 1)), unregister_after_exec=True))
        if until_phase_end:
            if not ((until_turn_end == False)):
                raise AssertionError
            if not ((until_round_end == False)):
                raise AssertionError
            temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.AfterPhaseEnd(AbilityType.Temp0, None, lambda effect, message: try_unregister(self)), unregister_after_exec=True))
        if until_round_end:
            if not ((until_turn_end == False)):
                raise AssertionError
            if not ((until_phase_end == False)):
                raise AssertionError
            temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.AfterRoundEnd(AbilityType.Temp0, lambda effect, message: try_unregister(self)), unregister_after_exec=True))
        if until_this_leave_play:
            temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.AfterCardLeavePlay(AbilityType.Temp0, self.this, lambda effect, message: try_unregister(self)), unregister_after_exec=True))
        if isinstance(until_after_event, Message.WhenUnitWouldDefend):
            temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.AfterUnitAttackEnd(AbilityType.Temp0, None, lambda effect, message: try_unregister(self), conditions=[lambda effect, message: (until_after_event.would_atk_message in message.would_atk_messages)]), unregister_after_exec=True))
        else:
            if isinstance(until_after_event, Message.WhenUnitWouldAttackUnit):
                temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.AfterUnitAttackEnd(AbilityType.Temp0, None, lambda effect, message: try_unregister(self), conditions=[lambda effect, message: (until_after_event.would_atk_message in message.would_atk_messages)]), unregister_after_exec=True))
            else:
                if isinstance(until_after_event, Message.WhenUnitWouldAttack):
                    temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.AfterUnitAttackEnd(AbilityType.Temp0, None, lambda effect, message: try_unregister(self), conditions=[lambda effect, message: (until_after_event in message.would_atk_messages)]), unregister_after_exec=True))
                else:
                    if isinstance(until_after_event, Message.WhenUnitWouldThwart):
                        temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.AfterUnitThwartEnd(AbilityType.Temp0, None, lambda effect, message: try_unregister(self), conditions=[lambda effect, message: (until_after_event in message.would_thw_messages)]), unregister_after_exec=True))
                    else:
                        if isinstance(until_after_event, Message.WhenUnitWouldScheme):
                            temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.AfterUnitSchemeEnd(AbilityType.Temp0, None, lambda effect, message: try_unregister(self), conditions=[lambda effect, message: (until_after_event in message.would_sch_messages)]), unregister_after_exec=True))
                        else:
                            if isinstance(until_after_event, Message.WhenCardWouldLeavePlay):
                                temp_effects = (temp_effects + self.this.effect.RegisterTemp(AbilityFactory.AfterCardLeavePlay(AbilityType.Temp2, None, lambda effect, message: try_unregister(self), conditions=[lambda effect, message: (until_after_event == message.would_leave_play_message)]), unregister_after_exec=True))
                            else:
                                if (until_after_event != None):
                                    temp_effects = (temp_effects + self.this.effect.RegisterTemp(Ability(AbilityType.Temp2, until_after_event.end_event, [lambda effect, message: (until_after_event == message.CastTo(HasPreEventMessage).pre_message)], lambda effect, message: try_unregister(self)), unregister_after_exec=True))
        if isinstance(until_after_event, CanBeInstead):
            temp_effects = (temp_effects + self.this.effect.RegisterTemp(Ability(AbilityType.Temp2, Message.WhenMessageBeInstead, [lambda effect, message: (until_after_event == message.message)], lambda effect, message: try_unregister(self)), unregister_after_exec=True))
        if until_after_resolve_effect:
            from cards.pack import RunAt
            def action():
                try_unregister(self)
            RunAt.AfterResolveEffect(until_after_resolve_effect, until_after_resolve_effect, action)
        return self
    def Copy(self) -> 'Effect':
        from copy import copy
        return copy(self)
    def IsName(self, name):
        return (self.ability.name == name)
    def IsType(self, type):
        return self.ability.flags.IsType(type)
    def GetInitiator(self) -> 'Player':
        from game.player import Player
        if not (isinstance(self.initiator, Player)):
            raise AssertionError(f'self.initiator={self.initiator!r}')
        return self.initiator
    def IsPlayerInitiator(self) -> bool:
        return self.initiator.IsPlayer()
    def GetDisplayName(self, *, remove_space = False):
        from game.card.face.card_type import Upgrade
        from game.card.face.card_type import Event
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Identity
        def get_name():
            if not (Identity.IsType(self.this)):
                if Ally.IsType(self.this):
                    if self.ability.IsFunction('ATK'):
                        return 'Attack'
                    if self.ability.IsFunction('DEF'):
                        return 'Defense'
                    if self.ability.IsFunction('THW'):
                        return 'Thwart'
                    if self.ability.IsFunction('REC'):
                        return 'Recover'
                    if self.ability.IsFunction('Change Form'):
                        if not (self.ability.name):
                            return 'Change Form'
                    if self.ability.IsFunction('Ask'):
                        return 'Ask'
            if self.ability.IsFunction('ATK'):
                return 'Attack'
            if self.ability.IsFunction('DEF'):
                return 'Defense'
            if self.ability.IsFunction('THW'):
                return 'Thwart'
            if self.ability.IsFunction('REC'):
                return 'Recover'
            if self.ability.IsFunction('Change Form'):
                if not (self.ability.name):
                    return 'Change Form'
            if self.ability.IsFunction('Ask'):
                return 'Ask'
            if self.ability.flags.is_temp:
                return 'Temp'
            if self.ability.name:
                return self.ability.name
            if self.ability.flags.is_resource:
                return 'Resource'
            if self.ability.is_play:
                return 'Play'
            if self.ability.flags.is_choose_ability:
                return 'Choose'
            if self.ability.flags.ui_display_name:
                return self.ability.flags.ability_type.value
            if self.this.card.IsInHand():
                return ''
            if Event.IsType(self.this):
                return ''
            if not (Upgrade.IsType(self.this)):
                if self.ability.labels:
                    return ' '.join(self.ability.labels)
            return ''
        name = get_name()
        if self.ability.flags.is_action:
            effects = self.this.effect.Find(type=self.ability.type)
            index = effects.index(self)
            if (index != 0):
                name = f'{name}_{index}'
        if remove_space:
            return name.replace(' ', '_')
        return name
    def IsIgnoreKeyword(self, keyword, effect):
        if effect.is_rule:
            return True
        if effect.world.rule.encounter_cards_ignore_crisis:
            if (keyword == 'Crisis'):
                if effect.this.GetControlByOrOwner().IsScenario():
                    return True
        if self.ability.ignore.keyword[keyword](effect):
            return True
        if (keyword == 'Guard'):
            if not (effect.ability.is_like_attack):
                return False
        if (keyword == 'Patrol'):
            if not (effect.ability.is_like_thwart):
                return False
        message = Message.CheckIfEffectIsIgnoreKeyWord(self, keyword)
        message.Send()
        if message.is_ignore_this_keyword:
            return True
        return False
    def GetPaidResources(self, ask_specify_green = False):
        res = self.context.paid_this_resources.Copy()
        if ask_specify_green:
            initiator = self.GetInitiator()
            res = initiator.AskSpecifyResources(res)
        return res
    def GetCostX(self) -> int:
        return (self.context.paid_this_resources.val - self.context.paid_this_cost.true_val)
    def Render(self, by_effect, bind_player_id):
        def get_pay_info(effect):
            def get_cost_str_rule(effect, target):
                if effect.failures.GetText(bind_player_id):
                    return ('0', [])
                if effect.context.ignore_resource_cost:
                    return ('*', [])
                if effect.checker.cost_for_different_target.HasTarget(target):
                    cost = effect.checker.cost_for_different_target.GetCost(target)
                    if (cost.rule.or_res != None):
                        return ('1', [])
                    return (cost.text_legacy, cost.GetRuleText())
                return ('', [])
            payinfo_dict = {}
            for target in effect.checker.cost_for_different_target.target_cost:
                if (target == None):
                    target_id = 0
                else:
                    target_id = target.card.object_id
                cost_text = get_cost_str_rule(effect, target)[0]
                cost_rule = get_cost_str_rule(effect, target)[1]
                payinfo_dict[target_id] = EffectDescriptor.Payment(cost=cost_text, payment=[], rule=cost_rule)
                if effect.context.ignore_resource_cost:
                    pass
                for effect_res in effect.checker.cost_for_different_target.target_cost[target].payments:
                    for pay_effect in effect_res:
                        payinfo_dict[target_id].payment.append({pay_effect.object_id: effect_res[pay_effect]})
            return payinfo_dict
        the_effect = self
        if by_effect:
            the_effect = by_effect
        if (by_effect != None):
            if (self.ability.name == ''):
                name = by_effect.GetDisplayName(remove_space=True)
            else:
                name = self.GetDisplayName(remove_space=True)
        else:
            name = self.GetDisplayName(remove_space=True)
        bind_id = the_effect.this.card.object_id
        selector = (self.ability.selectors[0] if self.ability.selectors else None)
        if selector:
            select_rule = selector.selector_rule.GetRuleAndParam()[0]
            select_rule_param = selector.selector_rule.GetRuleAndParam()[1]
            target_must_include_traits = selector.selector_rule.target_must_include_traits
        else:
            select_rule = ''
            select_rule_param = (0, 0)
            target_must_include_traits = []
        if selector:
            is_search = selector.is_search
        else:
            is_search = False
        failure_reason = self.failures.GetText(bind_player_id)
        if self.failures.IsNoProcess(bind_player_id):
            failure_reason = ''
        return EffectDescriptor(id=self.object_id, name=name, bind_id=bind_id, bind_player_id=bind_player_id, all_legal_targets=[face.card.object_id for face in self.context.all_legal_targets], target_num_range=list(self.context.target_range), target_payment=get_pay_info(self), select_rule=select_rule, select_rule_param=select_rule_param, target_must_include_traits=[f't_{x}' for x in target_must_include_traits], failure_reason=failure_reason, is_search=is_search)
