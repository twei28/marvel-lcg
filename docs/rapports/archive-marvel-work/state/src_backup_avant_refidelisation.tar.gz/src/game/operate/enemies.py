# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
@final
class Enemies:
    class ActivatedResult:
        def __init__(self, has_enemy = False, activated_cnt = 0):
            self.has_enemy = has_enemy
            self.activated_cnt = activated_cnt
        def __add__(self, other: 'Enemies.ActivatedResult') -> 'Enemies.ActivatedResult':
            return Enemies.ActivatedResult((self.has_enemy | other.has_enemy), (self.activated_cnt + other.activated_cnt))
        def __bool__(self):
            raise TypeError('This class cannot be converted to a boolean.')
    @staticmethod
    def DoActivateAgainstYouInternal(effect, activate_against_player, *, activate, finder = None, include_minion, include_villain, if_no_activate = None):
        from game.operate.worlds import Worlds
        engaged_minions = (include_minion == 'Engaged')
        all_minions = (include_minion == 'All')
        active_cnt = 0
        has_enemy = False
        if include_villain:
            game_area = activate_against_player.GetIdentity().card.GetGameArea()
            if Worlds.GetScenario(effect).IsVillainReady():
                active_villain = Worlds.FindVillainByGameArea(game_area)
                if active_villain:
                    has_enemy = True
                    if finder:
                        if finder.Check(active_villain):
                            if (activate == 'Attack'):
                                do_active = active_villain.DoAttackYou(activate_against_player, effect)
                            else:
                                if (activate == 'Scheme'):
                                    do_active = active_villain.DoSchemes(activate_against_player, effect)
                                else:
                                    do_active = active_villain.DoActivate(activate_against_player, effect)
                    if (activate == 'Attack'):
                        do_active = active_villain.DoAttackYou(activate_against_player, effect)
                    else:
                        if (activate == 'Scheme'):
                            do_active = active_villain.DoSchemes(activate_against_player, effect)
                        else:
                            do_active = active_villain.DoActivate(activate_against_player, effect)
        activated_minions = []
        if not (engaged_minions):
            if all_minions:
                if engaged_minions:
                    minions = activate_against_player.GetEngagedMinions(finder)
                else:
                    if all_minions:
                        minions = Worlds.GetOnFieldMinions(effect, finder)
                    else:
                        raise AssertionError
                minions = [x for x in minions if (x not in activated_minions)]
                if not (minions):
                    pass
                else:
                    for minion in activate_against_player.ChooseOrder(minions, prompt='Minion Activates Order'):
                        if minion.IsInPlay():
                            has_enemy = True
                            if (activate == 'Attack'):
                                do_active = minion.DoAttackYou(activate_against_player, effect)
                            else:
                                if (activate == 'Scheme'):
                                    do_active = minion.DoSchemes(activate_against_player, effect)
                                else:
                                    do_active = minion.DoActivate(activate_against_player, effect)
                        if Worlds.IsGameOver(effect):
                            Enemies.ActivatedResult(has_enemy, active_cnt)
                            return
                        new_minions = activate_against_player.GetEngagedMinions(finder)
                        if [x for x in new_minions if (x not in minions) if (x not in activated_minions)]:
                            pass
                        else:
                            if [x for x in minions if (x not in new_minions) if (x not in activated_minions)]:
                                pass
                            else:
                                pass
                    # backward conditional jump to 202: engaged_minions
                    # backward conditional jump to 202: all_minions
        if engaged_minions:
            minions = activate_against_player.GetEngagedMinions(finder)
        else:
            if all_minions:
                minions = Worlds.GetOnFieldMinions(effect, finder)
            else:
                raise AssertionError
        minions = [x for x in minions if (x not in activated_minions)]
        if not (minions):
            pass
        else:
            for minion in activate_against_player.ChooseOrder(minions, prompt='Minion Activates Order'):
                if minion.IsInPlay():
                    has_enemy = True
                    if (activate == 'Attack'):
                        do_active = minion.DoAttackYou(activate_against_player, effect)
                    else:
                        if (activate == 'Scheme'):
                            do_active = minion.DoSchemes(activate_against_player, effect)
                        else:
                            do_active = minion.DoActivate(activate_against_player, effect)
                if Worlds.IsGameOver(effect):
                    Enemies.ActivatedResult(has_enemy, active_cnt)
                    return
                new_minions = activate_against_player.GetEngagedMinions(finder)
                if [x for x in new_minions if (x not in minions) if (x not in activated_minions)]:
                    pass
                else:
                    if [x for x in minions if (x not in new_minions) if (x not in activated_minions)]:
                        pass
                    else:
                        pass
            # backward conditional jump to 202: engaged_minions
            # backward conditional jump to 202: all_minions
        if if_no_activate:
            if (active_cnt == 0):
                if_no_activate()
        return Enemies.ActivatedResult(has_enemy, active_cnt)
    @staticmethod
    def AllMinionActivateAgainstYou(effect, player, *, trait = None, finder = None, if_no_activate = None):
        if trait:
            if not (finder):
                finder = CardFinder2(trait)
        return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Activate', finder=finder, include_minion='All', include_villain=False, if_no_activate=if_no_activate)
    @staticmethod
    def AllMinionActivateAgainstEngagedPlayer(effect, *, trait = None, finder = None, if_no_activate = None):
        from game.operate.players import Players
        if trait:
            if not (finder):
                finder = CardFinder2(trait)
        def action(player: Player):
            return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Activate', finder=finder, include_minion='Engaged', include_villain=False)
        activated_result = Players.ForEachPlayer(effect, action, Enemies.ActivatedResult())
        if (activated_result.activated_cnt == 0):
            if if_no_activate:
                if_no_activate()
        return activated_result
    @staticmethod
    def AllMinionAttackTheHeroItEngagedWith(effect, *, trait = None, finder = None, if_no_attack = None):
        from game.operate.players import Players
        if trait:
            if not (finder):
                finder = CardFinder2(trait)
        def action(player: Player):
            if not (player.IsHero()):
                return Enemies.ActivatedResult()
            return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Attack', finder=finder, include_minion='Engaged', include_villain=False)
        activated_result = Players.ForEachPlayer(effect, action, Enemies.ActivatedResult())
        if (activated_result.activated_cnt == 0):
            if if_no_attack:
                if_no_attack()
        return activated_result
    @staticmethod
    def EngagedMinionActivateAgainstYou(effect: Effect, player: Player, *, trait: CardFace.TRAITS|None = None, finder: CardFinder|None = None):
        if trait:
            if not (finder):
                finder = CardFinder2(trait)
        return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Activate', finder=finder, include_minion='Engaged', include_villain=False)
    @staticmethod
    def EngagedMinionAttackYou(effect: Effect, player: Player, *, trait: CardFace.TRAITS|None = None, finder: CardFinder|None = None):
        if trait:
            if not (finder):
                finder = CardFinder2(trait)
        return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Attack', finder=finder, include_minion='Engaged', include_villain=False)
    @staticmethod
    def EngagedMinionSchemes(effect: Effect, player: Player):
        return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Scheme', include_minion='Engaged', include_villain=False)
    @staticmethod
    def VillainAndEngagedMinionsActivateAgainstYou(effect: Effect, player: Player):
        return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Activate', include_minion='Engaged', include_villain=True)
    @staticmethod
    def VillainAndEngagedMinionsAttackYou(effect: Effect, player: Player):
        return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Attack', finder=None, include_minion='Engaged', include_villain=True)
    @staticmethod
    def AllEnemyAttackYou(effect: Effect, player: Player, finder: CardFinder|None = None):
        return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Attack', finder=finder, include_minion='All', include_villain=True)
    @staticmethod
    def AllEnemySchemeAgainstYou(effect, player, finder = None, if_no_activate = None):
        return Enemies.DoActivateAgainstYouInternal(effect, player, activate='Scheme', finder=finder, include_minion='All', include_villain=True, if_no_activate=if_no_activate)
    @staticmethod
    def PutYouDeckTopCardAsFacedownMinion(player, name, by_effect, size = 1):
        from game.card.factory import CardFactory
        world = player.world
        def process(face: CardFace):
            paper = CardFactory.FindCardPapers(name)[0]
            ultron_facedown_drone = CardFactory.CreateFace(paper, world)
            face.card.SetAsCard(ultron_facedown_drone)
            minion = face.card.face.CastTo(Minion)
            minion.PutIntoPlay(player, by_effect)
        player.PopPlayerDeckCards(size, process, by_effect)
