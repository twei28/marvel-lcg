# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Rand:
    @staticmethod
    def IsDisableShuffle(effect: Effect|World) -> bool:
        from game.world import World
        if isinstance(effect, World):
            world = effect
            return world.rule.disable_shuffle
        world = effect.world
        return world.rule.disable_shuffle
    T = TypeVar('T')
    @staticmethod
    def RandomChoice(input_list, effect):
        if not ((input_list != [])):
            raise AssertionError
        if Rand.IsDisableShuffle(effect):
            return input_list[0]
        return Random.RandomChoice(input_list)
    @staticmethod
    def RandomChoice2(input_list, x, effect):
        if Rand.IsDisableShuffle(effect):
            return [input_list[0]]
        return Random.RandomChoice2(input_list, x)
    @staticmethod
    def Shuffle(list, effect):
        if Rand.IsDisableShuffle(effect):
            return
        return Random.Shuffle(list)
