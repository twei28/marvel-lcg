# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
@final
class FacesHelper:
    @staticmethod
    def ListToDict(targets):
        faces = {}
        for target in targets:
            if (target in faces):
                pass
            faces[target] = targets.count(target)
        return faces
    @staticmethod
    def AssertCardsAreDifferent(faces):
        names = []
        for face in faces:
            if (face.name in names):
                raise AssertionError
        return True
