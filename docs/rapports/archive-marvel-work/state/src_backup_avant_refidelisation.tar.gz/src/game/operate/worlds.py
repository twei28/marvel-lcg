# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from . import *
class Worlds:
    __annotations__ = {}
    Character = ((((AlterEgo | Hero) | Ally) | Villain) | Minion)
    Character: TypeAlias
    @staticmethod
    def CastGameArea(x: Effect|GameArea) -> GameArea:
        if isinstance(x, Effect):
            from game.message.message_type import TriggerPlayerMessage
            if isinstance(x, TriggerPlayerMessage):
                return x.GetToPlayer().GetIdentity().card.game_area
            return x.this.card.game_area
        return x
    @staticmethod
    def CastWorld(x: Effect|World) -> World:
        if isinstance(x, Effect):
            return x.world
        return x
    @staticmethod
    def PopEncounterCards(size, process, continue_after_shuffle, by_effect):
        encounter_deck = Worlds.GetEncounterDeck(by_effect)
        encounter_discard_pile = Worlds.GetEncounterDiscardPile(by_effect)
        if not (encounter_discard_pile):
            raise AssertionError
        world = by_effect.world
        if ((encounter_deck.GetSize() + encounter_discard_pile.GetSize()) < size):
            world.game_over.SetGameOverByRule('There were no cards in either the encounter deck or the encounter discard pile')
            return []
        return encounter_deck.PopInternal(size, process, by_effect, continue_after_shuffle=continue_after_shuffle)
    @staticmethod
    def PopEncounterCard(by_effect: Effect) -> CardFace:
        encounter_deck = Worlds.GetEncounterDeck(by_effect)
        return encounter_deck.PopInternal(1, lambda face: None, by_effect, continue_after_shuffle=False)[0]
    @staticmethod
    def GetEncounterDeck(by_effect: Effect) -> Deck:
        villain = Worlds.FindVillainByGameArea(by_effect.this.card.game_area)
        if villain:
            return villain.encounter_deck
        world = by_effect.world
        return world.GetScenario().encounter_deck
    @staticmethod
    def GetEncounterDecks(by_effect):
        villains = Worlds.GetVillains(by_effect)
        decks = []
        for villain in villains:
            from game.player.scenario import Scenario
            controller = villain.GetControlBy()
            if Scenario.IsType(controller):
                deck = controller.encounter_deck
                decks.append(deck)
        if not (villains):
            world = by_effect.world
            decks.append(world.GetScenario().encounter_deck)
        return decks
    @staticmethod
    def GetEncounterDiscardPile(by_effect: Effect) -> Deck:
        deck = Worlds.GetEncounterDeck(by_effect)
        discard_pile = deck.bind_discard_pile
        if not (discard_pile):
            raise AssertionError
        return discard_pile
    @staticmethod
    def FindMainScheme(face: CardFace|Effect) -> MainScheme|None:
        from game.message import Message
        from game.card.face.card_type import MainScheme
        from game.effect.rule import Ties
        if isinstance(face, Effect):
            face = face.this
        game_area = face.card.game_area
        schemes = Worlds.GetMainSchemes(game_area)
        if (schemes == []):
            return
        if (len(schemes) == 1):
            return schemes[0]
        ret_main_scheme = None
        if not (ret_main_scheme):
            message = Message.GettingMainScheme(game_area, face)
            message.Send()
            main_scheme = message.return_value
            if main_scheme:
                ret_main_scheme = main_scheme
        if not (ret_main_scheme):
            player = face.GetOwner()
            if isinstance(player, Player):
                schemes = Worlds.GetMainSchemes(game_area)
                ret_main_scheme = player.AskChooseFace(schemes, Ties('Select Main Scheme', world=face.card.world))
        if not (ret_main_scheme):
            for scheme in Worlds.GetMainSchemes(game_area):
                ret_main_scheme = scheme
        if MainScheme.IsType(ret_main_scheme):
            return ret_main_scheme
    @staticmethod
    def GetMainSchemes(game_area_effect):
        world = game_area_effect.world
        game_area = Worlds.CastGameArea(game_area_effect)
        return [x for x in world.area_schemes_main.Get() if (x.card.GetGameArea() == game_area)]
    @staticmethod
    def GetOnFieldSchemes(game_area_effect, finder = None):
        faces = (Worlds.GetMainSchemes(game_area_effect) + Worlds.GetSideSchemes(game_area_effect))
        if finder:
            faces = finder.Checks(faces)
        return faces
    @staticmethod
    def GetSideSchemes(game_area_effect):
        world = game_area_effect.world
        game_area = Worlds.CastGameArea(game_area_effect)
        return [x for x in world.area_schemes_side.Get() if (x.card.GetGameArea() == game_area) if True]
    @staticmethod
    def FilterSideScheme(by_effect, least_threat = False, most_threat = False):
        from game.operate.filter import Filter
        targets_faces = Worlds.GetAllSideSchemes(by_effect)
        return Filter.One(targets_faces, by_effect, least_threat=least_threat, most_threat=most_threat)
    @staticmethod
    def GetVillainStage(by_effect):
        villain = Worlds.FindVillainByGameArea(by_effect.this.card.game_area)
        if villain:
            return villain.printed_stage
        return 0
    @staticmethod
    def FindVillainByGameArea(game_area: GameArea) -> Villain|None:
        world = game_area.world
        return world.GetScenario().GetVillain(game_area)
    @staticmethod
    def FindVillain(by_effect, name = None):
        if (name == None):
            this = by_effect.this
            if CanAttach.IsType(this):
                if this.refers_to_the_villain_refers_to_attached:
                    return this.GetBindFace()
            world = by_effect.world
            return world.GetScenario().GetVillain(by_effect.this.card.game_area)
        return Worlds.FindCardOnField(by_effect, name=name, card_type=Villain)
    @staticmethod
    def GetVillains(game_area_effect, finder = None):
        game_area = Worlds.CastGameArea(game_area_effect)
        world = game_area.world
        if finder:
            villains = finder.Checks(Worlds.GetAllVillains(world))
        else:
            villains = Worlds.GetAllVillains(world)
        return [x for x in villains if (x.card.GetGameArea() == game_area)]
    @staticmethod
    def GetOnFieldLeaders(game_area_effect):
        game_area = Worlds.CastGameArea(game_area_effect)
        world = game_area.world
        villains = Worlds.GetAllLeaders(world)
        return [x for x in villains if (x.card.GetGameArea() == game_area)]
    @staticmethod
    def GetPlayersIdentities(game_area_effect, finder = None):
        units = []
        for player in Worlds.GetPlayers(game_area_effect):
            units.append(player.GetIdentity())
        if finder:
            return finder.Checks(units)
        return units
    @staticmethod
    def GetOnFieldAlterEgos(game_area_effect):
        from game.card.face.card_type import AlterEgo
        return [x for x in Worlds.GetPlayersIdentities(game_area_effect) if AlterEgo.IsType(x)]
    @staticmethod
    def GetOnFieldHeroes(game_area_effect):
        from game.card.face.card_type import Hero
        return [x for x in Worlds.GetPlayersIdentities(game_area_effect) if Hero.IsType(x)]
    @staticmethod
    def GetOnFieldAllies(game_area_effect, finder = None):
        units = []
        for player in Worlds.GetPlayers(game_area_effect):
            units = (units + player.allies.Get())
        if finder:
            return finder.Checks(units)
        return units
    @staticmethod
    def GetOnFieldSupports(game_area_effect):
        supports = []
        for player in Worlds.GetPlayers(game_area_effect):
            supports = (supports + player.supports.Get())
        return supports
    @staticmethod
    def GetOnFieldEnemies(game_area_effect, finder = None):
        return (Worlds.GetVillains(game_area_effect, finder) + Worlds.GetOnFieldMinions(game_area_effect, finder))
    @staticmethod
    def GetOnFieldMinions(game_area_effect, finder = None):
        faces = Worlds.GetOnFieldCards(game_area_effect)
        units = [x for x in faces if Minion.IsType(x)]
        if finder:
            return finder.Checks(units)
        return units
    @staticmethod
    def GetOnFieldEnvironment(game_area_effect):
        faces = []
        for unit in Worlds.GetPlayersIdentities(game_area_effect):
            player = unit.GetControlByPlayer()
            faces = (faces + player.area_environment.Get())
        game_area = Worlds.CastGameArea(game_area_effect)
        faces = (faces + [x for x in game_area_effect.world.area_environment.Get() if (x.card.game_area == game_area)])
        return faces
    @staticmethod
    def GetOnFieldCharacters(game_area_effect, finder = None):
        units = []
        faces = Worlds.GetOnFieldCards(game_area_effect)
        units = [x for x in faces if Unit2.IsType(x)]
        if finder:
            return finder.Checks(units)
        return units
    @staticmethod
    def GetOnFieldFriendlyCharacters(game_area_effect, finder = None):
        units = []
        for player in Worlds.GetPlayers(game_area_effect):
            units = (units + ([player.GetIdentity()] + player.allies.Get()))
        if finder:
            return finder.Checks(units)
        return units
    @staticmethod
    def GetCrisisFaces(game_area_effect):
        faces = Worlds.GetOnFieldCards(game_area_effect)
        return CardFinder(crisis=True).Checks2(faces, CanCrisis)
    @staticmethod
    def GetCrisisIcons(game_area_effect):
        return len(Worlds.GetCrisisFaces(game_area_effect))
    @staticmethod
    def GetAccelerationIconFaces(game_area_effect):
        faces = Worlds.GetOnFieldCards(game_area_effect)
        return CardFinder(acceleration_icon=True).Checks2(faces, HasAccelerationIcon)
    @staticmethod
    def GetAccelerationTokenFaces(game_area_effect):
        faces = Worlds.GetOnFieldCards(game_area_effect)
        return CardFinder(acceleration_token=True).Checks2(faces, CanAccelerationToken)
    @staticmethod
    def GetAccelerationIcons(game_area_effect):
        value = 0
        for face in Worlds.GetAccelerationIconFaces(game_area_effect):
            value = (value + face.acceleration_icon)
        return value
    @staticmethod
    def GetHazardFaces(game_area_effect):
        faces = Worlds.GetOnFieldCards(game_area_effect)
        return CardFinder(hazard=True).Checks2(faces, HasHazard)
    @staticmethod
    def GetHazardIcons(game_area_effect):
        value = 0
        for face in Worlds.GetHazardFaces(game_area_effect):
            value = (value + face.hazard)
        return value
    @staticmethod
    def GetAmplifyFaces(game_area_effect):
        faces = Worlds.GetOnFieldCards(game_area_effect)
        return CardFinder(amplify=True).Checks2(faces, HasAmplify)
    @staticmethod
    def GetAmplifyIcons(game_area_effect):
        value = 0
        for face in Worlds.GetAmplifyFaces(game_area_effect):
            value = (value + face.amplify)
        return value
    @staticmethod
    def GetIconsNum(game_area_effect, names):
        value = 0
        for name in names:
            if (name == 'Hazard'):
                value = (value + Worlds.GetHazardIcons(game_area_effect))
            if (name == 'Amplify'):
                value = (value + Worlds.GetAmplifyIcons(game_area_effect))
            if (name == 'Acceleration'):
                value = (value + Worlds.GetAccelerationIcons(game_area_effect))
            if (name == 'Crisis'):
                value = (value + Worlds.GetCrisisIcons(game_area_effect))
        return value
    @staticmethod
    def GetEncounterDeckCards(by_effect):
        world = Worlds.CastWorld(by_effect)
        faces = []
        villains = Worlds.GetAllVillains(by_effect)
        for villain in villains:
            faces = (faces + villain.encounter_deck.Get(True))
        if (villains == []):
            return world.scenario.encounter_deck.Get()
        return faces
    @staticmethod
    def GetEncounterDiscardPileCards(by_effect, finder = None):
        world = Worlds.CastWorld(by_effect)
        faces = []
        villains = Worlds.GetAllVillains(by_effect)
        for villain in villains:
            faces = villain.encounter_discard_pile.Get(True)
        if (villains == []):
            faces = world.scenario.encounter_discard_pile.Get()
        if finder:
            return finder.Checks(faces)
        return faces
    @staticmethod
    def GetSetAsideAreaCards(by_effect, finder = None):
        world = by_effect.world
        faces = ((world.aside_deck.Get(True) + [p for p in world.const_players]) + [p for p in world.const_players])
        if finder:
            return finder.Checks(faces)
        return faces
    @staticmethod
    def GetOnFieldCards(game_area_effect):
        world = game_area_effect.world
        game_area = Worlds.CastGameArea(game_area_effect)
        faces = []
        areas = []
        for player in Worlds.GetPlayers(game_area):
            areas = (areas + [player.area_hero, player.area_environment, player.allies, player.supports, player.engaged_minions, player.obligations_area])
        for area in ([world.area_schemes_main, world.area_schemes_side, world.area_environment, world.scenario.area_villain] + areas):
            for face in area.GetAll():
                if (face.card.game_area == game_area):
                    def get_faces(*check_faces: CardFace):
                        found = []
                        for x in check_faces:
                            found.append(x)
                            found.extend(get_faces(*x.GetInventoryDeck().GetAll()))
                            found.extend(get_faces(*x.GetPlacedCardArea().GetAll()))
                        return found
                    found = get_faces(face)
                    faces.extend(found)
        faces = [x for x in faces if x.IsFaceUp()]
        return faces
    @staticmethod
    def GetAllMainSchemes(by_effect):
        world = Worlds.CastWorld(by_effect)
        return world.area_schemes_main.Get()
    @staticmethod
    def GetAllSideSchemes(by_effect):
        world = Worlds.CastWorld(by_effect)
        return world.area_schemes_side.Get()
    @staticmethod
    def GetOnAllFieldScheme(by_effect):
        return (Worlds.GetAllMainSchemes(by_effect) + Worlds.GetAllSideSchemes(by_effect))
    @staticmethod
    def GetAllVillains(by_effect):
        world = Worlds.CastWorld(by_effect)
        scenario = world.GetScenario()
        return scenario.area_villain.Get()
    @staticmethod
    def GetAllLeaders(by_effect):
        world = Worlds.CastWorld(by_effect)
        scenario = world.GetScenario()
        return [x for x in scenario.area_villain.Get() if Leader.IsType(x)]
    @staticmethod
    def FindCardOnField(by_effect, finder = None, *, name = None, trait = None, card_type = CardFace, game_area = None, **kwargs):
        faces = Worlds.FindCardsOnField(*(by_effect, finder), **{'max': 1, 'name': name, 'trait': trait, 'card_type': card_type, 'game_area': game_area, **kwargs})
        if (faces != []):
            return faces[0]
    @staticmethod
    def FindCardSizeOnField(by_effect, finder = None, *, name = None, trait = None, card_type = CardFace):
        return len(Worlds.FindCardsOnField(by_effect, finder, name=name, trait=trait, card_type=card_type))
    @staticmethod
    def FindCardsOnField(by_effect, finder = None, *, max = Math.INT_INF, name = None, trait = None, card_type = CardFace, game_area = None, **kwargs):
        from game.operate.filter import Filter
        if (game_area == None):
            game_area = by_effect.this.card.game_area
        faces = Worlds.GetOnFieldCards(by_effect)
        if finder:
            faces = finder.Checks(faces)
        return Filter.ByFinder(faces, CardFinder(*(), **{'name': name, 'trait': trait, 'card_type': card_type, 'game_area': game_area, **kwargs}), max=max)
    @staticmethod
    def DiscardEachOther(by_effect, this, trait = None, card_type = CardFace, name = None):
        from game.operate.faces import Faces
        faces = Worlds.FindCardsOnField(by_effect, card_type=card_type, trait=trait, name=name)
        if (this in faces):
            faces.remove(this)
        Faces.DiscardAll(faces, by_effect)
    @staticmethod
    def DiscardEncounterCardsUntil(by_effect, *, name = None, trait = None, card_type = CardFace, return_other_faces = None, **kwargs):
        encounter_deck = Worlds.GetEncounterDeck(by_effect)
        face = encounter_deck.DiscardUntil(*(by_effect,), **{'name': name, 'trait': trait, 'card_type': card_type, **kwargs})[0]
        other = encounter_deck.DiscardUntil(*(by_effect,), **{'name': name, 'trait': trait, 'card_type': card_type, **kwargs})[1]
        if (return_other_faces != None):
            return_other_faces.clear()
            return_other_faces.extend(other)
        return face
    @staticmethod
    def RevealEncounterDeckTopCard(to_player: Player, by_effect: Effect) -> CardFace|None:
        encounter_deck = Worlds.GetEncounterDeck(by_effect)
        return encounter_deck.RevealTopCard(to_player, by_effect)
    @staticmethod
    def DiscardEncounterCards(num, by_effect, *, each_time = None):
        deck = Worlds.GetEncounterDeck(by_effect)
        num = Worlds.ConvertPerPlayerIconToInt(num, by_effect)
        faces = deck.DiscardCardsInternal(num, by_effect, continue_after_shuffle=False, each_time=each_time)
        return faces
    @staticmethod
    def DiscardEncounterTopCard(by_effect: Effect) -> CardFace|None:
        faces = Worlds.DiscardEncounterCards(1, by_effect)
        if faces:
            return faces[0]
    @staticmethod
    def SetGameOver(player_won, by_effect):
        return by_effect.world.game_over.SetPlayersWon(player_won, by_effect)
    @staticmethod
    def GetFirstPlayer(by_effect: Effect) -> Player:
        world = by_effect.world
        for player in world.players:
            if not (player.is_eliminated):
                player
                return
        if not (world.is_game_over):
            raise AssertionError
        return world.players[0]
    @staticmethod
    def GetCurrentPlayer(by_effect: Effect) -> Player:
        world = by_effect.world
        return world.GetCurrentPlayer()
    @staticmethod
    def GetNextPlayer(player: Player, by_effect: Effect) -> Player|None:
        world = by_effect.world
        if not ((player in world.const_players)):
            raise AssertionError(f'player={player!r} world.const_players={world.const_players!r}')
        index = world.const_players.index(player)
        new_list = Types.Rotate(world.players, index)
        if (len(new_list) >= 2):
            return new_list[1]
    @staticmethod
    def GetPlayers(game_area_effect):
        from game.operate.worlds import Worlds
        game_area = Worlds.CastGameArea(game_area_effect)
        world = game_area.world
        return [x for x in world.const_players if (x.area_hero.GetSize() > 0) if (x.GetIdentity().card.GetGameArea() == game_area)]
    @staticmethod
    def FindPlayerByName(name: str, by_effect: Effect) -> Player|None:
        players = Worlds.GetPlayers(by_effect)
        for player in players:
            if player.IsName(name):
                player
                return
    @staticmethod
    def FindPlayer(finder, by_effect, *, engaged_with_fewest_minions = False):
        from game.operate.filter import Filter
        players = Worlds.GetPlayers(by_effect)
        if (finder == None):
            pass
        else:
            players = [x for x in players if finder.Check(x)]
        identity = Filter.One([x.GetIdentity() for x in players], by_effect, engaged_with_fewest_minions=engaged_with_fewest_minions)
        if identity:
            return identity.GetOwnerPlayer()
    @staticmethod
    def GetPlayerById(id, by_effect):
        world = by_effect.world
        for player in world.const_players:
            if (player.player_id == id):
                player
                return
        raise AssertionError
    @staticmethod
    def ConvertPerPlayerIconToInt(value, by_effect):
        if isinstance(value, str):
            return (int(value[:-1]) * Worlds.GetPlayerNumIcon(by_effect))
        return value
    @staticmethod
    def GetPlayerNumIcon(by_effect):
        world = by_effect.world
        return world.GetPlayerNumIcon()
    @staticmethod
    def GetPlayerNum(game_area_effect):
        world = game_area_effect.world
        return world.GetPlayerNum()
    @staticmethod
    def IsExpert(by_effect):
        return by_effect.world.scene.campaign.expert
    @staticmethod
    def IsStandard(by_effect):
        return (not Worlds.IsExpert(by_effect))
    @staticmethod
    def IsGameOver(by_effect):
        return by_effect.world.is_game_over
    @staticmethod
    def IsCampaign(by_effect):
        return by_effect.world.rule.mode_campaign.val
    @staticmethod
    def AsideDeck(by_effect: Effect) -> Deck:
        world = by_effect.world
        return world.aside_deck
    ASIDE_DECK_NAME = Literal[('TheCollection', 'ShipCommand', 'ShowDeck', 'InfinityStone', 'ExperimentalWeapons', 'SideSchemeDeck', 'BulldozerEncounter', 'PiledriverEncounter', 'ThunderballEncounter', 'HoldingCell', 'A.I.M.Envelope', 'S.H.I.E.L.D.Envelope')]
    ASIDE_DECK_NAME: TypeAlias
    SCENARIO_AREA_NAME = Literal['MissionArea']
    SCENARIO_AREA_NAME: TypeAlias
    @staticmethod
    def ScenarioDeck(by_effect: Effect, deck_name: ASIDE_DECK_NAME) -> SetAsideDeck:
        world = by_effect.world
        return world.scenario_decks[deck_name]
    @staticmethod
    def ScenarioArea(by_effect: Effect, deck_name: SCENARIO_AREA_NAME) -> Deck:
        raise NotImplemented
    @staticmethod
    def GetScenario(by_effect: Effect) -> Scenario:
        world = by_effect.world
        return world.GetScenario()
    @staticmethod
    def MainSchemesDeck(by_effect: Effect) -> Deck:
        world = by_effect.world
        return world.main_schemes_deck
    @staticmethod
    def AsideModular(by_effect: Effect) -> Deck:
        world = by_effect.world
        return world.aside_modular
    @staticmethod
    def VictoryDisplay(by_effect: Effect) -> Deck:
        world = by_effect.world
        return world.victory_display
    @staticmethod
    def Phase(by_effect: Effect):
        world = by_effect.world
        return world.phase
    @staticmethod
    def GetDefeatedVillain(by_effect: Effect):
        world = by_effect.world
        return world.area_removed.FindCards(card_type=Villain)
    @staticmethod
    def GetStandardEncounterSets(by_effect):
        standard_encounter_sets = []
        world = by_effect.world
        for encounter_set in world.scene.campaign.encounter_sets:
            if not (encounter_set.startswith('standard')):
                if encounter_set.startswith('expert'):
                    standard_encounter_sets.append(encounter_set)
            standard_encounter_sets.append(encounter_set)
        return standard_encounter_sets
    @staticmethod
    def GetModularSets(by_effect):
        encounter_sets = []
        world = by_effect.world
        for encounter_set in world.scene.campaign.encounter_sets:
            if not (encounter_set.startswith('standard')):
                if encounter_set.startswith('expert'):
                    pass
            encounter_sets.append(encounter_set)
        return encounter_sets
    @staticmethod
    def UpdateNextCardPlayCost(player, update_rule, by_effect, *, update_to = False, finder = None, in_this):
        from game.message import Message
        from game.ability import Ability
        from game.ability import AbilityType
        from game.ability.factory import AbilityFactory
        from game.operate.effects import Effects
        def check_card_type(effect, message):
            if (finder == None):
                return True
            return finder.Check(message.check_effect.this)
        def check_card_type2(effect, message):
            if (finder == None):
                return True
            return finder.Check(message.play_face)
        def set_update_fixed_cost(effect: Effect, message: Message.WhenCalculateEffectCost):
            if update_to:
                if not ((update_rule == 0)):
                    raise AssertionError
                message.UpdateToCost('0', effect)
                return
            message.UpdateCost(update_rule, effect)
        phase_end = (in_this == 'Phase')
        turn_end = (in_this == 'Turn')
        def check_is_player(effect: Effect, message: TriggerNonePlayerMessage):
            return ((player == 'Any') or (player == message.to_player))
        this = by_effect.this
        modify_cost_effects = this.effect.RegisterTemp(AbilityFactory.WhenCalculateEffectCost(AbilityType.Temp0, set_update_fixed_cost, conditions=[check_card_type, check_is_player, lambda effect, message: message.check_effect.ability.is_play]), unregister_after_exec=False, until_phase_end=phase_end, until_turn_end=turn_end)
        def unregister_modify_cost_effect(effect: Effect, message: Message2):
            Effects.UnRegister(modify_cost_effects)
        by_effect.this.effect.RegisterTemp(Ability(AbilityType.Temp0, Message.WhenPlayerWouldPlayCard, [check_card_type2, check_is_player], unregister_modify_cost_effect), unregister_after_exec=True, until_phase_end=phase_end, until_turn_end=turn_end)
    @staticmethod
    def GetEnemyTeam(by_effect: Effect) -> Player:
        return Worlds.GetFirstPlayer(by_effect)
    @staticmethod
    def GetEnemyLeader(by_effect: Effect) -> Leader|None:
        leader = Worlds.FindCardOnField(by_effect, card_type=Leader)
        return leader
    @staticmethod
    def GetYourTeam(by_effect: Effect) -> Player:
        return Worlds.GetFirstPlayer(by_effect)
    @staticmethod
    def GetYourTeamLeader(by_effect: Effect) -> Leader|None:
        pass
    @staticmethod
    def GetYourTeamSize(by_effect):
        return Worlds.GetPlayerNumIcon(by_effect)
    @staticmethod
    def IsCompetitiveMode(by_effect):
        return False
    @staticmethod
    def IsCooperativeMode(by_effect):
        return True
    Enemies = Enemies
