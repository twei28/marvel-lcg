# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class SetupCards:
    @staticmethod
    def PutIntoPlay(by_effect, for_player = 'FirstPlayer', under_control = False, *, flip_to_trait = None, flip_to_name = None, finder = None, name = None, trait = None, card_type = CardFace, from_where = [], **kwargs):
        faces = SearchInternal.FindCards(*(by_effect,), **{'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, 'include_in_play': False, **kwargs})
        put_faces = []
        for face in faces:
            if not (flip_to_trait):
                if flip_to_name:
                    face.FlipTo(by_effect, trait=flip_to_trait, name=flip_to_name)
            face.FlipTo(by_effect, trait=flip_to_trait, name=flip_to_name)
            this = face.card.face
            if this.PutIntoPlay(for_player, by_effect, under_control=under_control):
                put_faces.append(this)
        if put_faces:
            return put_faces[0]
    @staticmethod
    def Reveal(by_effect, reveal = True, *, range = (1, 1), finder = None, name = None, trait = None, card_type = CardFace, only_set_aside = False, **kwargs):
        from game.operate.worlds import Worlds
        if only_set_aside:
            faces = Worlds.GetSetAsideAreaCards(by_effect, (CardFinder(*(), **{'card_type': card_type, 'name': name, 'trait': trait, **kwargs}) & finder))
        else:
            faces = SearchInternal.FindCards(*(by_effect,), **{'range': range, 'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, **kwargs})
        for face in faces:
            if isinstance(reveal, Player):
                face.Reveal(reveal, by_effect)
            face.Reveal(None, by_effect)
        if faces:
            return faces[0]
    @staticmethod
    def ShuffleIntoEncounterDeck(by_effect, finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        faces = SearchInternal.FindCards(*(by_effect,), **{'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, **kwargs})
        for face in faces:
            Faces.ShuffleAllTo([face], 'EncounterDeck', by_effect)
    @staticmethod
    def AttachTo(by_effect, attach_to, *, flip_to_trait = None, flip_to_name = None, finder = None, name = None, trait = None, card_type = CardFace, choose = 'First', include_in_play = True, **kwargs):
        range = ((1, 1) if (choose == 'First') else 'All')
        faces = SearchInternal.FindCards(*(by_effect,), **{'range': range, 'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, 'include_in_play': include_in_play, **kwargs})
        if (choose == 'Random'):
            face = Random.RandomChoice(faces)
        else:
            if (choose == 'Ask'):
                face = by_effect.world.GetFirstPlayer().AskChooseFace(faces, by_effect)
            else:
                face = (faces[0] if faces else None)
        if CanAttach.IsType(face):
            if not (flip_to_trait):
                if flip_to_name:
                    face.FlipTo(by_effect, trait=flip_to_trait, name=flip_to_name)
            face.FlipTo(by_effect, trait=flip_to_trait, name=flip_to_name)
            face.AttachTo2(attach_to, by_effect)
            return
    @staticmethod
    def DealAsFacedownEncounterCard(by_effect, to_player, finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        faces = SearchInternal.FindCards(*(by_effect,), **{'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, **kwargs})
        for face in faces:
            to_player.DealEncounterCard(face, by_effect)
    @staticmethod
    def SetAsideCards(by_effect, *, finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        from game.operate.worlds import Worlds
        deck = Worlds.GetEncounterDeck(by_effect)
        faces = []
        faces = (faces + Worlds.FindCardsOnField(*(by_effect, finder), **{'name': name, 'trait': trait, 'card_type': card_type, **kwargs}))
        faces = (faces + deck.FindCards(*(), **{'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, **kwargs}))
        Faces.SetAside(faces, by_effect)
        return faces
