# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from cards.paper import Paper
@final
class Search:
    @staticmethod
    def EncounterCards(by_effect, who_perform = None, *, include_discard_pile, include_set_aside = False, most_top = None, finder = None, name = None, trait = None, card_type = CardFace, total = 1, **kwargs):
        from game.operate.worlds import Worlds
        if (who_perform == None):
            who_perform = by_effect.world.GetCurrentPlayer()
        else:
            if (who_perform == 'FirstPlayer'):
                who_perform = by_effect.world.GetFirstPlayer()
        total = Worlds.ConvertPerPlayerIconToInt(total, by_effect)
        return Search.SearchForCards(*(by_effect, who_perform), **{'include_encounter_deck': True, 'include_encounter_discard_pile': include_discard_pile, 'include_set_aside': include_set_aside, 'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, 'most_top': most_top, 'range': (total, total), **kwargs})
    @staticmethod
    def EncounterCard(by_effect, who_perform = None, *, include_discard_pile, include_set_aside = False, most_top = None, finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        if (who_perform == None):
            who_perform = by_effect.world.GetCurrentPlayer()
        else:
            if (who_perform == 'FirstPlayer'):
                who_perform = by_effect.world.GetFirstPlayer()
        return Search.SearchForCard(*(by_effect, who_perform), **{'include_encounter_deck': True, 'include_encounter_discard_pile': include_discard_pile, 'include_set_aside': include_set_aside, 'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, 'most_top': most_top, **kwargs})
    @staticmethod
    def EncounterCardTop(by_effect, who_perform, most_top, *, finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        return Search.EncounterCard(*(by_effect, who_perform), **{'include_discard_pile': False, 'include_set_aside': False, 'most_top': most_top, 'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, **kwargs})
    @staticmethod
    def EncounterCardsTop(by_effect, who_perform, most_top, *, finder = None, name = None, trait = None, card_type = CardFace, total = 1, **kwargs):
        return Search.EncounterCards(*(by_effect, who_perform), **{'include_discard_pile': False, 'include_set_aside': False, 'most_top': most_top, 'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, 'total': total, **kwargs})
    @staticmethod
    def PlayerCard(by_effect, player, *, include_player_deck, include_discard_pile = False, include_player_hand_cards = False, include_player_area = False, may = False, not_move = False, finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        return Search.SearchForCard(*(by_effect, player), **{'include_player_deck': include_player_deck, 'include_player_discard_pile': include_discard_pile, 'include_player_hand_cards': include_player_hand_cards, 'include_player_area': include_player_area, 'may': may, 'not_move': not_move, 'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, **kwargs})
    @staticmethod
    def PlayerDeckTop(by_effect, player, most_top, *, finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        return Search.SearchForCard(*(by_effect, player), **{'include_player_deck': True, 'most_top': most_top, 'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, **kwargs})
    @staticmethod
    def SearchForCard(by_effect, who_perform, *, process_choose = None, process_other = None, include_encounter_deck = False, include_encounter_discard_pile = False, include_set_aside = False, include_removed_area = False, include_in_play = False, include_player_deck = False, include_player_discard_pile = False, include_player_hand_cards = False, include_player_area = False, include_victory_display = False, faces = None, most_top = None, may = False, not_move = False, finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        found_faces = Search.SearchForCards(*(by_effect, who_perform), **{'process_choose': process_choose, 'process_other': process_other, 'include_encounter_deck': include_encounter_deck, 'include_encounter_discard_pile': include_encounter_discard_pile, 'include_set_aside': include_set_aside, 'include_removed_area': include_removed_area, 'include_in_play': include_in_play, 'include_player_deck': include_player_deck, 'include_player_discard_pile': include_player_discard_pile, 'include_player_hand_cards': include_player_hand_cards, 'include_player_area': include_player_area, 'include_victory_display': include_victory_display, 'faces': faces, 'most_top': most_top, 'may': may, 'not_move': not_move, 'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, **kwargs})
        if found_faces:
            return found_faces[0]
    @staticmethod
    def SearchForCards(by_effect, who_perform, *, process_choose = None, process_other = None, include_encounter_deck = False, include_encounter_discard_pile = False, include_set_aside = False, include_removed_area = False, include_in_play = False, include_player_deck = False, include_player_discard_pile = False, include_player_hand_cards = False, include_player_area = False, include_victory_display = False, faces = None, most_top = None, may = False, not_move = False, range = (1, 1), finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        from game.operate.worlds import Worlds
        from game.message import Message
        if (faces == None):
            faces = []
        if include_encounter_deck:
            decks = []
            villains = Worlds.GetAllVillains(by_effect)
            for villain in villains:
                decks.append(villain.encounter_deck)
            if (villains == []):
                decks.append(by_effect.world.scenario.encounter_deck)
            for deck in Types.RemoveDuplicates(decks):
                searched_faces = deck.Get(True)[:most_top]
                faces = (faces + searched_faces)
                Message.WhenPlayerSearchingDeckCards_Text(who_perform, deck, most_top, searched_faces)
        if include_encounter_discard_pile:
            faces = (faces + Worlds.GetEncounterDiscardPileCards(by_effect)[:most_top])
        if include_set_aside:
            faces = (faces + Worlds.GetSetAsideAreaCards(by_effect))
        if include_in_play:
            faces = (faces + Worlds.GetOnFieldCards(by_effect))
        if include_removed_area:
            faces = (faces + by_effect.world.area_removed.Get(True))
        if (include_player_deck == True):
            deck = who_perform.player_deck
            searched_faces = deck.Get(True)[:most_top]
            faces = (faces + searched_faces)
            Message.WhenPlayerSearchingDeckCards_Text(who_perform, deck, most_top, searched_faces)
        else:
            if (include_player_deck == 'All'):
                for check_player in Worlds.GetPlayers(by_effect):
                    deck = check_player.player_deck
                    searched_faces = deck.Get(True)[:most_top]
                    faces = (faces + searched_faces)
                    Message.WhenPlayerSearchingDeckCards_Text(who_perform, deck, most_top, searched_faces)
        if (include_player_discard_pile == True):
            faces = (faces + who_perform.discard_pile.Get(True)[:most_top])
        else:
            if (include_player_discard_pile == 'All'):
                for check_player in Worlds.GetPlayers(by_effect):
                    deck = check_player.discard_pile
                    faces = (faces + deck.Get(True)[:most_top])
        if (include_player_hand_cards == True):
            faces = (faces + who_perform.hand_cards.Get(True))
        else:
            if (include_player_hand_cards == 'All'):
                for check_player in Worlds.GetPlayers(by_effect):
                    faces = (faces + check_player.hand_cards.Get(True))
        if (include_player_area == True):
            faces = (faces + who_perform.GetPlayerAreaCards())
        else:
            if (include_player_area == 'All'):
                for check_player in Worlds.GetPlayers(by_effect):
                    faces = (faces + check_player.GetPlayerAreaCards())
        if include_victory_display:
            faces = (faces + by_effect.world.victory_display.Get(True))
        finder = (CardFinder(*(), **{'name': name, 'trait': trait, 'card_type': card_type, **kwargs}) & finder)
        from game.operate.search_internal import SearchInternal
        return SearchInternal.SearchForCardsInternal(by_effect, who_perform, faces, process_choose=process_choose, process_other=process_other, finder=finder, may=may, not_move=not_move, range=range)
    @staticmethod
    def Collection(by_effect, player, *, name = None, trait = None, card_type = None, card_classes = None, set_name = None, check_fn = None):
        from cards.database import CardsDB
        from game.card.factory import CardFactory
        if (card_type != None):
            check_card_type = str(card_type)
        else:
            check_card_type = None
        if (card_classes == 'Any'):
            card_classes = [*('Aggression', 'Justice', 'Leadership', 'Protection', "'Pool")]
        paper_ids = CardsDB.GetPapers(card_type=check_card_type, trait=trait, card_classes=card_classes, set_name=set_name, check_fn=check_fn)
        name = player.AskChoosePaper(paper_ids)
        card = CardFactory.GenerateCard(name, player.discard_pile, by_effect.world)
        return card.face
