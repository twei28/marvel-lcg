# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
@final
class Filter:
    @staticmethod
    def One(original_faces, by_effect, *, highest_cost = False, lowest_cost = False, fewest_remaining_hp = False, most_damage = False, least_damage = False, engaged_with_fewest_minions = False, most_remaining_hp = False, highest_atk = False, lowest_thw = False, fewest_counter = False, least_threat = False, most_threat = False):
        if not (original_faces):
            return
        targets_faces = original_faces
        faces = Filter.All(targets_faces, type(targets_faces[0]), highest_cost=highest_cost, lowest_cost=lowest_cost, fewest_remaining_hp=fewest_remaining_hp, most_damage=most_damage, least_damage=least_damage, engaged_with_fewest_minions=engaged_with_fewest_minions, most_remaining_hp=most_remaining_hp, highest_atk=highest_atk, lowest_thw=lowest_thw, least_threat=least_threat, most_threat=most_threat, fewest_counter=fewest_counter)
        if (faces == []):
            return
        if (len(faces) == 1):
            return faces[0]
        from game.effect.rule import Ties
        first_player = by_effect.world.GetFirstPlayer()
        return first_player.AskChooseFace(faces, Ties(world=by_effect.world), peek=True)
    @staticmethod
    def All(original_faces, card_type = CardFace, *, most_traits = False, highest_cost = False, lowest_cost = False, most_printed_res = False, engaged_with_fewest_minions = False, most_remaining_hp = False, fewest_remaining_hp = False, most_damage = False, least_damage = False, highest_printed_hp = False, highest_atk = False, lowest_atk = False, highest_printed_atk = False, lowest_printed_atk = False, highest_thw = False, lowest_thw = False, highest_sch = False, lowest_sch = False, least_threat = False, most_threat = False, lowest_order = False, highest_order = False, fewest_counter = False, max_size = None):
        from cards.pack.sm.sinister_six import GetLowestOrder
        from cards.pack.sm.sinister_six import GetHighestOrder
        from game.card.face.attribute.has_cost import HasCost
        faces = list(original_faces)
        def all_max(the_faces, card_type, key, *, max):
            type_faces = [x for x in the_faces if isinstance(x, card_type)]
            if max:
                x = Math.AllMax(type_faces, key)
                return x
            x = Math.AllMin(type_faces, key)
            return x
        if not (highest_cost):
            if lowest_cost:
                faces = [x for x in faces if HasCost.IsType(x) if x.has_printed_cost]
                faces = all_max(faces, HasCost, key=lambda x: x.printed_cost.val, max=highest_cost)
        faces = [x for x in faces if HasCost.IsType(x) if x.has_printed_cost]
        faces = all_max(faces, HasCost, key=lambda x: x.printed_cost.val, max=highest_cost)
        if most_printed_res:
            faces = all_max(faces, ClassCard, lambda face: face.printed_resource.val, max=most_printed_res)
        if engaged_with_fewest_minions:
            faces = all_max(faces, CardFace, lambda face: face.GetControlByPlayer().engaged_minions.GetSize(), max=False)
        if not (most_remaining_hp):
            if fewest_remaining_hp:
                faces = all_max(faces, CanHealth, lambda face: face.health, max=most_remaining_hp)
        faces = all_max(faces, CanHealth, lambda face: face.health, max=most_remaining_hp)
        if not (most_damage):
            if least_damage:
                faces = all_max(faces, CanHealth, lambda face: face.sustained, max=most_damage)
        faces = all_max(faces, CanHealth, lambda face: face.sustained, max=most_damage)
        if not (highest_atk):
            if lowest_atk:
                faces = all_max(faces, HasAttack, lambda face: face.attack, max=highest_atk)
        faces = all_max(faces, HasAttack, lambda face: face.attack, max=highest_atk)
        if not (highest_thw):
            if lowest_thw:
                faces = all_max(faces, HasThwart, lambda face: face.thwart, max=highest_thw)
        faces = all_max(faces, HasThwart, lambda face: face.thwart, max=highest_thw)
        if not (highest_sch):
            if lowest_sch:
                faces = all_max(faces, HasScheme, lambda face: face.scheme, max=highest_sch)
        faces = all_max(faces, HasScheme, lambda face: face.scheme, max=highest_sch)
        if highest_printed_hp:
            faces = all_max(faces, CanHealth, lambda face: face.printed_health, max=highest_printed_hp)
        if not (highest_printed_atk):
            if lowest_printed_atk:
                faces = all_max(faces, HasAttack, lambda face: face.printed_attack, max=highest_printed_atk)
        faces = all_max(faces, HasAttack, lambda face: face.printed_attack, max=highest_printed_atk)
        if fewest_counter:
            faces = all_max(faces, CanPlaceCounter, key=lambda x: x.GetCounters(fewest_counter), max=False)
        if lowest_order:
            faces = list(GetLowestOrder(faces))
        else:
            if highest_order:
                faces = list(GetHighestOrder(faces))
        if most_traits:
            faces = all_max(faces, CardFace, lambda face: len(face.traits), max=most_traits)
        if not (most_threat):
            if least_threat:
                faces = all_max(faces, Scheme2, lambda face: face.threat, max=most_threat)
        faces = all_max(faces, Scheme2, lambda face: face.threat, max=most_threat)
        if (max_size == None):
            return faces
        return faces[:max_size]
    @staticmethod
    def ByFinder(faces, finder = None, max = Math.INT_INF):
        if not (finder):
            return list(faces)[:max]
        face_list = []
        for face in faces:
            if finder.Check(face):
                face_list.append(face)
            if (len(face_list) >= max):
                return face_list
        return face_list
    @staticmethod
    def ByType(faces, card_type, *finders, return_rest_faces = None):
        face_list = []
        rest_faces = []
        for face in faces:
            do_append = False
            if card_type.IsType(face):
                if finders:
                    for finder in finders:
                        if finder.Check(face):
                            do_append = True
                        else:
                            pass
                else:
                    do_append = True
            if not (do_append):
                rest_faces.append(face)
        if return_rest_faces:
            return_rest_faces.clear()
            return_rest_faces.extend(rest_faces)
        return face_list
