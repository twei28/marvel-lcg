# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from game.message.message_type import HasEndEventMessage
class RunAt:
    @staticmethod
    def TheEndOfThePhase(by_effect, operation):
        by_effect.this.effect.RegisterTemp(AbilityFactory.WhenPhaseEnd(AbilityType.Temp2, None, lambda effect, message: operation()), unregister_after_exec=True)
    @staticmethod
    def RoundEnd(by_effect, operation):
        by_effect.this.effect.RegisterTemp(AbilityFactory.WhenRoundEnd(AbilityType.Temp2, None, lambda effect, message: operation()), unregister_after_exec=True)
    @staticmethod
    def TurnEnd(by_effect, operation):
        by_effect.this.effect.RegisterTemp(AbilityFactory.WhenPlayerTurnEnd(AbilityType.Temp2, 'AnyPlayer', lambda effect, message: operation()), unregister_after_exec=True)
    @staticmethod
    def AfterEventEnd(by_effect, would_message, operation):
        this = by_effect.this
        def create_effect_interal(ability, *, is_ally = False):
            this.effect.RegisterTemp(ability, unregister_after_exec=True)
        def create_effect(end_event, condition):
            create_effect_interal(Ability(AbilityType.Temp2, end_event, [condition], lambda effect, message: operation()))
        if isinstance(would_message, Message.AfterUnitAttackEnd):
            create_effect(Message.AfterUnitAttackEnd, lambda effect, message: (would_message == message))
            return
        if isinstance(would_message, Message.AfterUnitDefendEnd):
            create_effect(Message.AfterUnitDefendEnd, lambda effect, message: (would_message == message))
            return
        if isinstance(would_message, Message.WhenUnitWouldAttack):
            create_effect(Message.AfterUnitAttackEnd, lambda effect, message: (would_message in message.would_atk_messages))
            return
        if isinstance(would_message, Message.WhenUnitWouldScheme):
            create_effect(Message.AfterUnitSchemeEnd, lambda effect, message: (would_message in message.would_sch_messages))
            return
        if isinstance(would_message, Message.WhenUnitWouldThwart):
            create_effect(Message.AfterUnitThwartScheme, lambda effect, message: (would_message == message.would_thw_message))
            return
        if isinstance(would_message, Message.WhenUnitWouldAttackUnit):
            create_effect(Message.AfterUnitAttackEnd, lambda effect, message: (would_message.would_atk_message in message.would_atk_messages))
            return
        if isinstance(would_message, Message.WhenSchemeBeingThwart):
            create_effect(Message.AfterUnitThwartEnd, lambda effect, message: (would_message.would_thw_message in message.would_thw_messages))
            return
        if isinstance(would_message, Message.WhenUnitBeingAttack):
            create_effect(Message.AfterUnitAttackEnd, lambda effect, message: (would_message.would_atk_message in message.would_atk_messages))
            return
        if isinstance(would_message, Message.WhenSchemeBeingScheme):
            create_effect(Message.AfterUnitSchemeEnd, lambda effect, message: (would_message.would_sch_message in message.would_sch_messages))
            return
        if isinstance(would_message, Message.WhenUnitWouldDefend):
            create_effect(Message.AfterUnitDefendEnd, lambda effect, message: (would_message in message.would_def_messages))
            return
        if isinstance(would_message, Message.WhenUnitUseBasicPower):
            create_effect(Message.AfterUnitUseBasicPower, lambda effect, message: (would_message == message.pre_message))
            return
        if isinstance(would_message, Message.WhenEffectWouldResolve):
            create_effect(Message.AfterEffectResolved, lambda effect, message: (would_message == message.pre_message))
            return
        if isinstance(would_message, Message.WhenCardFlip):
            create_effect(Message.AfterCardFlip, lambda effect, message: (would_message == message.pre_message))
            return
        if isinstance(would_message, Message.WhenCardWouldMoveToArea):
            create_effect(Message.AfterCardsMoved, lambda effect, message: (would_message.trigger in message.faces))
            return
        if isinstance(would_message, Message.WhenMinionWouldEngagePlayer):
            create_effect(Message.AfterMinionEngagePlayer, lambda effect, message: (would_message.trigger == message.trigger))
            return
        raise AssertionError
    @staticmethod
    def AfterEnemyActivationEnd(by_effect, would_message, operation):
        if isinstance(would_message, (Message.WhenUnitBeingAttack | Message.WhenSchemeBeingScheme)):
            would_message = would_message.would_message
        def is_this_message(effect: Effect, message: Message.AfterEnemyActivationEnd):
            if message.atk_message:
                if (would_message in message.atk_message.would_atk_messages):
                    return True
            if message.sch_message:
                if (would_message in message.sch_message.would_sch_messages):
                    return True
            return False
        def operation_fn():
            operation()
        by_effect.this.effect.RegisterTemp(AbilityFactory.AfterEnemyActivationEnd(AbilityType.Temp2, None, lambda effect, message: operation_fn(), conditions=[is_this_message]), unregister_after_exec=True)
    @staticmethod
    def AfterResolveEffect(by_effect, check_effect, operation):
        by_effect.this.effect.RegisterTemp(AbilityFactory.AfterCardResolveAbility(AbilityType.Temp2, None, None, lambda effect, message: operation(), which_effect=check_effect), unregister_after_exec=True)
    @staticmethod
    def AfterResolveMessage(by_effect, check_message, operation):
        if isinstance(check_message, Message.WhenUnitWouldAttack):
            by_effect.this.effect.RegisterTemp(AbilityFactory.AfterUnitAttackEnd(AbilityType.Temp2, None, lambda effect, message: operation(), would_atk_message=check_message), unregister_after_exec=True)
            return
        by_effect.this.effect.RegisterTemp(Ability(AbilityType.Temp2, check_message.end_event, [lambda effect, message: (message.pre_message == check_message)], lambda effect, message: operation()), unregister_after_exec=True)
    @staticmethod
    def AfterFaceEnterPlay(by_effect, face, operation):
        by_effect.this.effect.RegisterTemp(AbilityFactory.AfterCardEnterPlay(AbilityType.Temp2, face, lambda effect, message: operation()), unregister_after_exec=True)
    @staticmethod
    def AfterPowerUsed(by_effect, message, operation):
        by_effect.this.effect.RegisterTemp(AbilityFactory.AfterUnitUseBasicPower(AbilityType.Temp2, None, lambda effect, message: operation(), use_message=message), unregister_after_exec=True, until_event_end=message)
    @staticmethod
    def WhenCardSetup(face, operation):
        face.effect.RegisterTemp(AbilityFactory.WhenCardSetup(face, lambda effect, message: operation()), unregister_after_exec=True)
    @staticmethod
    def WhenGameBeginSetup(face, operation):
        face.effect.RegisterTemp(AbilityFactory.WhenGameBeginSetup(lambda effect, message: operation()), unregister_after_exec=True)
    @staticmethod
    def AfterRevealed(face, operation):
        face.effect.RegisterTemp(AbilityFactory.AfterPlayerRevealCard(AbilityType.Temp2, 'AnyPlayer', face, lambda effect, message: operation()), unregister_after_exec=True)
