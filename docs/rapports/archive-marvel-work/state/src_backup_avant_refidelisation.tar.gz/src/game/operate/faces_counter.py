# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
@final
class FacesCounter:
    @staticmethod
    def GetDifferentTypesCount(faces):
        types = {}
        count = 0
        for face in faces:
            the_type = type(face)
            if (the_type in types):
                pass
            types[the_type] = 1
            count = (count + 1)
        return count
    @staticmethod
    def GetAspectCount(faces):
        from game.card.face.base import ClassCard
        classes = {}
        count = 0
        for face in faces:
            if ClassCard.IsType(face):
                if ('Aspect' in face.card_classes):
                    for check_class in face.card_classes:
                        if (check_class == 'Aspect'):
                            pass
                        if (check_class in classes):
                            pass
                        classes[check_class] = 1
                        count = (count + 1)
        return count
    @staticmethod
    def GetPrintedResources(faces):
        from game.element.resources import Resources
        from game.card.face.base import ClassCard
        res = Resources('0')
        for face in faces:
            if ClassCard.IsType(face):
                res = (res + face.printed_resource)
        return res
    @staticmethod
    def GetPrintedResourcesTypes(faces):
        return FacesCounter.GetPrintedResources(faces).GetResourceIconTypes()
    @staticmethod
    def GetPrintedResourcesCountInternal(faces, check_from_deck = 'Auto'):
        from game.card.face.base import ClassCard
        from game.message import Message
        return_res = {'R': 0, 'B': 0, 'Y': 0, 'G': 0}
        for face in faces:
            if ClassCard.IsType(face):
                if (check_from_deck == 'Auto'):
                    from_deck = face.card.area
                else:
                    from_deck = check_from_deck
        return return_res
    @staticmethod
    def GetPrintedResourcesCount(faces, colors, from_deck = 'Auto'):
        if not (isinstance(colors, list)):
            colors = [colors]
        res_dict = FacesCounter.GetPrintedResourcesCountInternal(faces, from_deck)
        value = 0
        for color in colors:
            value = (value + res_dict[color])
        return value
    @staticmethod
    def GetPrintedResourcesIcon(faces, from_deck):
        return FacesCounter.GetPrintedResourcesCount(faces, Resources.RBYG_LIST, from_deck)
    @staticmethod
    def GetPrintedResourceCost(faces):
        return FacesCounter.GetPrintedCost(faces)
    @staticmethod
    def GetTotalCost(faces):
        return FacesCounter.GetPrintedCost(faces)
    @staticmethod
    def GetPrintedCost(faces):
        from game.card.face.attribute.has_cost import HasCost
        total_res = 0
        for face in faces:
            if HasCost.IsType(face):
                total_res = (total_res + face.printed_cost.val)
        return total_res
    @staticmethod
    def GetMostCommonType(faces):
        return FacesCounter.GetMaxSameTypeCount(faces)
    @staticmethod
    def GetMaxSameTypeCount(faces):
        type_counts = collections.Counter((type(item) for item in faces))
        return max(type_counts.values(), default=0)
    @staticmethod
    def GetSetupPermanentFaces(faces):
        return [x for x in faces if HasPermanent.IsType(x) if x.printed_permanent]
    @staticmethod
    def CountTotalBoostIcons(faces):
        from game.card.face.attribute.has_boost_icon import HasBoostIcon
        value = 0
        for face in faces:
            if HasBoostIcon.IsType(face):
                value = (value + face.CountBoostIconsInternal())
        return value
    @staticmethod
    def CountTotalBoostStar(faces):
        from game.card.face.attribute.has_boost_icon import HasBoostIcon
        value = 0
        for face in faces:
            if HasBoostIcon.IsType(face):
                value = (value + face.boost_star)
        return value
    @staticmethod
    def CountTotalBoostStarAndBoost(faces):
        from game.card.face.attribute.has_boost_icon import HasBoostIcon
        value = 0
        for face in faces:
            if HasBoostIcon.IsType(face):
                value = (value + face.boost_star)
                value = (value + face.CountBoostIconsInternal())
        return value
