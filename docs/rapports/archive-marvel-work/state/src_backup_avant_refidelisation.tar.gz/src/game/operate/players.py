# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Players:
    @staticmethod
    def CannotChangeFormDuringNextTurn(player: Player, effect: Effect):
        from game.operate.effects import Effects
        identity = player.GetIdentity()
        def action():
            player.has_change_form = True
            cannot_effects = identity.effect.Registers(AbilityFactory.PlayersCannotChangeForms(AbilityType.Temp0, 'You'))
            identity.effect.RegisterTemp(AbilityFactory.WhenPlayerTurnEnd(AbilityType.Temp0, 'This', lambda effect, message: Effects.UnRegister(cannot_effects)), unregister_after_exec=True)
        identity.effect.RegisterTemp(AbilityFactory.WhenPlayerTurnBegin(AbilityType.Temp0, 'This', lambda effect, message: action()), unregister_after_exec=True)
    @staticmethod
    def DiscardResourceIconFromHand(player, size, effect, *, color = Resources.RBYG_LIST):
        from game.card.face.base import ClassCard
        from game.operate.faces import Faces
        from game.operate.faces_counter import FacesCounter
        from game.operate.filter import Filter
        icons = FacesCounter.GetPrintedResourcesCount(player.hand_cards.Get(), color, from_deck=player.hand_cards)
        if (icons == 0):
            return
        if (icons < size):
            faces = Filter.ByType(player.hand_cards.Get(), ClassCard, CardFinder(has_printed_res=True))
            Faces.DiscardAll(faces, effect)
            return
        discard_effect = player.ChooseAbilities(effect, AbilityFactory.ForChoiceAbility('', lambda targets: Faces.DiscardAll(targets, effect)).SetTarget(ClassCard, from_where=['YourHandCards'], combined_resource_icons=(size, size), canbe_discard=True))
        if discard_effect:
            return
    @staticmethod
    def DrawUp(targets, size, by_effect):
        Players.ForEachTargets(targets, lambda player: player.DrawUp(size, by_effect))
    T = TypeVar('T')
    @staticmethod
    def ForEachPlayer(by_effect, action, result = None):
        from game.operate.worlds import Worlds
        return_result = result
        for player in Worlds.GetPlayers(by_effect):
            action_result = action(player)
            if (return_result != None):
                if (action_result != None):
                    return_result = (return_result + action_result)
            if by_effect.world.is_game_over:
                return return_result
        return return_result
    @staticmethod
    def ForEachTargets(targets, action):
        for target in targets:
            player = target.GetControlBy()
            if Player.IsType(player):
                action(player)
                if player.world.is_game_over:
                    return
    @staticmethod
    def DiscardHeroActionAttachment(player, enemies, effect, *, may):
        from game.operate.faces import Faces
        if enemies:
            attachments = [x for x in enemies]
            ability = AbilityFactory.ForChoiceAbility('', lambda targets: Faces.DiscardAll(targets, effect)).SetTarget(attachments, with_texts=['Hero Action', 'Hero Response'], canbe_discard=True)
        else:
            ability = AbilityFactory.ForChoiceAbility('', lambda targets: Faces.DiscardAll(targets, effect)).SetTarget(Attachment, with_texts=['Hero Action', 'Hero Response'], canbe_discard=True)
        if may:
            player.MayChooseOneAbility(effect, ability)
            return
        player.ChooseAbilities(effect, ability)
    @staticmethod
    def EachCharacterGetsUntilPhaseEnd(player, by_effect, finder = None, *, attack = None, defense = None, thwart = None):
        from game.operate.worlds import Worlds
        from game.operate.run_at import RunAt
        if player:
            characters = player.GetControlCharacters(finder)
        else:
            characters = Worlds.GetOnFieldCharacters(by_effect, finder)
        units = {}
        def process_fn(face, diff):
            if (face in units):
                if (units[face] == diff):
                    return False
                units[face] = (units[face] + diff)
            else:
                units[face] = diff
            if face.Gain(by_effect, diff, attack=attack, defense=defense, thwart=thwart):
                Message.AfterCardApply_Text([face], by_effect, diff)
                return
        for unit in characters:
            process_fn(unit, 1)
        def action(effect: Effect, message: Message.AfterCardGainTrait|Message.AfterCardLoseTrait|Message.AfterCardLeavePlay|Message.AfterCardEnterPlay):
            if finder:
                if finder.Check(message.trigger):
                    diff = 1
                else:
                    diff = -1
            diff = 1
            diff = -1
            process_fn(message.trigger, diff)
        def check(effect, message):
            if (player != None):
                if (message.trigger.GetControlBy() != player):
                    if isinstance(message, Message.AfterCardLeavePlay):
                        found_units = [unit for unit in units if (unit.card == message.trigger.card)]
                        for unit in found_units:
                            units.pop(unit, None)
                    return False
            if isinstance(message, Message.AfterCardLeavePlay):
                units.pop(message.trigger, None)
            else:
                if isinstance(message, Message.AfterCardEnterPlay):
                    found_units = [unit for unit in units if (unit.card == message.trigger.card) if (unit != message.trigger)]
                    for unit in found_units:
                        units.pop(unit, None)
            if finder:
                if finder.Check(message.trigger):
                    diff = 1
                else:
                    diff = -1
            diff = 1
            diff = -1
            if (message.trigger not in units):
                if (diff == 1):
                    return True
                return False
            if (units[message.trigger] != diff):
                return True
            return False
        by_effect.this.effect.RegisterTemp(Ability(AbilityType.Temp0, (((Message.AfterCardGainTrait | Message.AfterCardLoseTrait) | Message.AfterCardLeavePlay) | Message.AfterCardEnterPlay), [check], action), unregister_after_exec=False, until_phase_end=True)
        def action2():
            for unit in units:
                process_fn(unit, (-1 * units[unit]))
        RunAt.TheEndOfThePhase(by_effect, action2)
