# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Find:
    @staticmethod
    def FindAndPutIntoPlay(by_effect, to_player, *, finder = None, name = None, trait = None, card_type = CardFace, if_not_enter_play = None):
        face = Find.Find(by_effect, finder=finder, name=name, trait=trait, card_type=card_type)
        not_enter = True
        if face:
            not_enter = False
            if face.IsInPlay():
                not_enter = True
            else:
                if face.PutIntoPlay(to_player, by_effect):
                    return face
                not_enter = True
        if not_enter:
            if if_not_enter_play:
                if_not_enter_play()
        return face
    @staticmethod
    def FindAndReveal(by_effect, to_player, *, finder = None, name = None, trait = None, card_type = CardFace, if_no_entered_play = None):
        face = Find.Find(by_effect, finder=finder, name=name, trait=trait, card_type=card_type)
        if face:
            if face.Reveal(to_player, by_effect, if_no_entered_play=if_no_entered_play):
                return face
    @staticmethod
    def FindAndAttachTo(by_effect, to_face, *, who_perform, finder = None, name = None, trait = None, card_type = CardFace):
        face = Find.Find(by_effect, who_perform=who_perform, finder=finder, name=name, trait=trait, card_type=card_type)
        if face:
            if CanAttach.IsType(face):
                if face.AttachTo2(to_face, by_effect):
                    return face
    @staticmethod
    def Find(by_effect, *, who_perform = None, finder = None, name = None, trait = None, card_type = CardFace, **kwargs):
        from game.operate.search import Search
        if (who_perform == None):
            who_perform = by_effect.world.GetFirstPlayer()
        face = Search.SearchForCard(by_effect, who_perform, include_encounter_deck=True, include_encounter_discard_pile=True, include_set_aside=True, include_removed_area=False, include_in_play=True, include_player_deck='All', include_player_discard_pile='All', include_player_hand_cards='All', include_player_area='All', include_victory_display=False, finder=(CardFinder(*(), **{'name': name, 'trait': trait, 'card_type': card_type, **kwargs}) & finder))
        return face
