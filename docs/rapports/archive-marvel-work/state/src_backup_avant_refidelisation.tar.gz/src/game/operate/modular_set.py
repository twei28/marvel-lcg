# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AsideModularSet:
    @staticmethod
    def ChooseRandom(effect, do_shuffle = False):
        from game.operate.faces import Faces
        from game.operate.faces_counter import FacesCounter
        from game.operate.worlds import Worlds
        from game.operate.rand import Rand
        modular_sets = {}
        for face in Worlds.AsideModular(effect).Get():
            set_name = face.paper.set_name
            if (set_name not in modular_sets):
                modular_sets[set_name] = []
            modular_sets[set_name].append(face)
        names = [x for x in modular_sets]
        select = Rand.RandomChoice(names, effect)
        if do_shuffle:
            setup_faces = FacesCounter.GetSetupPermanentFaces(modular_sets[select])
            faces = [x for x in modular_sets[select] if (x not in setup_faces)]
            Faces.ShuffleAllTo(faces, 'EncounterDeck', effect)
            for face in setup_faces:
                face.PutIntoPlay('CurrentPlayer', effect)
        return modular_sets[select]
    @staticmethod
    def GetSize(effect):
        from game.operate.worlds import Worlds
        modular_sets = []
        for face in Worlds.AsideModular(effect).Get():
            set_name = face.paper.set_name
            if (set_name not in modular_sets):
                modular_sets.append(set_name)
        return len(modular_sets)
