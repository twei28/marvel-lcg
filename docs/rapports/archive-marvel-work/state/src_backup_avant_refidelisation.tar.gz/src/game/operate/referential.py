# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from cards.database import CardsDB
from . import *
@final
class Referential:
    @staticmethod
    def BelongToSameIdentityEncounterSet(find_names, face, legal_faces):
        face.card.IsAsOtherCard()
        check_faces = []
        set_name = face.paper.set_name
        set_name_nemesis = (set_name[:-8] if set_name.endswith(' Nemesis') else None)
        set_id = face.paper.card_id[:2]
        if (set_name == 'Iceman'):
            if (set_name_nemesis == None):
                set_name_nemesis = 'Frostbite'
        has_this_name_in_set = False
        for card_id in CardsDB.sets_cards[set_name]:
            if (CardsDB.papers[card_id].name in find_names):
                has_this_name_in_set = True
            else:
                pass
        if not (has_this_name_in_set):
            return legal_faces
        for target in legal_faces:
            if not ((target.paper.set_name == set_name)):
                if (target.paper.set_name == set_name_nemesis):
                    if not ((set_name == 'Magneto')):
                        if (set_name == 'Venom'):
                            if (target.paper.card_id[:2] != set_id):
                                pass
                    if (target.paper.card_id[:2] != set_id):
                        pass
                    check_faces.append(target)
            if not ((set_name == 'Magneto')):
                if (set_name == 'Venom'):
                    if (target.paper.card_id[:2] != set_id):
                        pass
            if (target.paper.card_id[:2] != set_id):
                pass
            check_faces.append(target)
        if check_faces:
            return check_faces
        return []
    @staticmethod
    def Filter(finder, legal_faces, by_effect):
        if by_effect.world.rule.v16_referential_ability:
            if (len(legal_faces) == 1):
                return legal_faces
            if not (finder):
                return legal_faces
            check_by_name = finder.check_by_name
            if not (check_by_name):
                return legal_faces
            this = by_effect.this
            if (this in legal_faces):
                if finder.Check(this):
                    return [this]
            check_faces = Referential.BelongToSameIdentityEncounterSet(check_by_name, this, legal_faces)
            if check_faces:
                return check_faces
            if PlayerCard.IsType(this):
                return [x for x in legal_faces if PlayerCard.IsType(x)]
            if EncounterCard.IsType(this):
                return [x for x in legal_faces if EncounterCard.IsType(x)]
            return legal_faces
        return legal_faces
    @staticmethod
    def Check(finder, face, from_effect):
        from game.operate.worlds import Worlds
        if not (finder.Check(face, from_effect)):
            return False
        check_by_name = finder.check_by_name
        if not (check_by_name):
            return True
        if not (from_effect.world.rule.v16_referential_ability):
            return True
        if (from_effect.this.name == face.name):
            if (from_effect.this != face):
                return False
        if not (face.IsInPlay()):
            return True
        if face.card.IsAsOtherCard():
            return True
        all_faces = (Worlds.GetOnFieldCards(from_effect) + [x for x in Worlds.GetPlayers(from_effect)])
        same_name_faces = [x for x in all_faces if x.IsFaceUp() if (x.name == face.name)]
        if (len(same_name_faces) == 1):
            if (face.card == same_name_faces[0].card):
                return True
        found_faces = Referential.BelongToSameIdentityEncounterSet(check_by_name, from_effect.this, same_name_faces)
        return (face in found_faces)
