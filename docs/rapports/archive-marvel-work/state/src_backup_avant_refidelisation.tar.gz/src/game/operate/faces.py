# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
@final
class Faces:
    @staticmethod
    def DiscardAll(faces, by_effect, *, into_area = None, ignore_identity = False, simultaneous = False):
        from game.message import Message
        moved_faces = []
        from_decks = Faces.GetDecksInDeck(faces)
        if simultaneous:
            if faces:
                faces = by_effect.world.GetFirstPlayer().ChooseOrder(faces, prompt='Simultaneous Discard')
        for face in faces:
            if face.DiscardInternal(by_effect, into_area=into_area, ui_group=True, ignore_identity=ignore_identity):
                moved_faces.append(face)
        if moved_faces:
            Message.AfterCardsDiscard_Text({x: from_decks[x] for x in from_decks if (x in moved_faces)})
        return moved_faces
    @staticmethod
    def ExhaustAll(faces, by_effect):
        from game.message import Message
        processed_faces = []
        for face in faces:
            if face.ExhaustInternal(by_effect, ui_group=True):
                processed_faces.append(face)
        if processed_faces:
            Message.AfterCardsExhaust_Text(processed_faces, by_effect)
        return processed_faces
    @staticmethod
    def ReadyAll(faces, by_effect):
        from game.message import Message
        processed_faces = []
        for face in faces:
            if face.ReadyInternal(by_effect, ui_group=True):
                processed_faces.append(face)
        if processed_faces:
            Message.AfterCardsReadied_Text(processed_faces, by_effect)
        return processed_faces
    @staticmethod
    def ShuffleAllTo(faces, deck, by_effect, ui_group = True):
        from game.message import Message
        from game.operate.worlds import Worlds
        if (deck == 'EncounterDeck'):
            deck = Worlds.GetEncounterDeck(by_effect)
        Message.CardsShuffleToDeck_Text(faces, deck)
        moved_faces = Faces.MoveAllTo(faces, deck, by_effect, by_shuffle=True)
        if moved_faces:
            deck.Shuffle(by_effect)
        return moved_faces
    @staticmethod
    def MoveAllToDeck(faces, deck, position, by_effect):
        from game.message import Message
        moved_faces = []
        from_decks = Faces.GetDecksInDeck(faces)
        for face in faces:
            if (position == 'Top'):
                if face.card.MoveToTop(deck, by_effect, ui_group=True):
                    moved_faces.append(face)
            if (position == 'Bottom'):
                if face.card.MoveToBottom(deck, by_effect, ui_group=True):
                    moved_faces.append(face)
        if moved_faces:
            message = Message.AfterCardsMoved({x: from_decks[x] for x in from_decks if (x in moved_faces)}, move_by_position=True)
            message.Send()
        return moved_faces
    @staticmethod
    def MoveAllTo(faces, area, by_effect, *, by_shuffle = False, target_game_area = None):
        from game.message import Message
        moved_faces = []
        from_areas = Faces.GetDecksInDeck(faces)
        for face in faces:
            if face.card.MoveToArea(area, by_effect, ui_group=True, target_game_area=target_game_area):
                moved_faces.append(face)
        if moved_faces:
            message = Message.AfterCardsMoved({x: from_areas[x] for x in from_areas if (x in moved_faces)}, by_shuffle=by_shuffle, by_discard=area.flags.is_discards, by_put_into_play=area.flags.is_in_play, by_place_on_table=area.flags.is_processing, by_return_to_hand=area.flags.is_in_hand, by_setaside=area.flags.is_set_aside, by_draw_up=area.flags.is_in_hand, by_resources=area.flags.is_resources_area, by_deal_encounter_card=area.flags.is_dealt_encounter, by_boost=area.flags.is_boost_area, by_remove=area.flags.is_removed)
            message.Send()
        return moved_faces
    @staticmethod
    def MoveAllToProcessingArea(faces, by_effect):
        from game.message import Message
        if not (faces):
            return []
        moved_faces = []
        face = faces[0]
        player = face.card.area.GetOwner()
        world = by_effect.world
        if isinstance(player, Player):
            area = player.area_processing
        else:
            area = world.area_processing
        moved_faces = Faces.MoveAllTo(faces, area, by_effect)
        Message.AfterCardsPlaceOnTable_Text(moved_faces)
        return moved_faces
    @staticmethod
    def RemoveAllFromGame(faces, by_effect):
        from game.message import Message
        moved_faces = Faces.MoveAllTo(faces, by_effect.world.area_removed, by_effect)
        Message.AfterCardsRemove_Text(moved_faces)
        return moved_faces
    @staticmethod
    def FlipAllTo(faces, face_up, by_effect):
        from game.message import Message
        flipped_faces = []
        for face in faces:
            if (face_up == None):
                face.card.Flip(by_effect, ui_group=True)
                flipped_faces.append(face)
            if face.FlipTo(by_effect, face_up=face_up, ui_group=True):
                flipped_faces.append(face)
        Message.AfterCardsFlipAll_Text(flipped_faces)
        return flipped_faces
    @staticmethod
    def SetAside(faces, by_effect):
        from game.message import Message
        moved_faces = []
        from_decks = Faces.GetDecksInDeck(faces)
        for face in faces:
            if face.SetAsideInternal(by_effect, ui_group=True):
                moved_faces.append(face)
        Message.AfterCardsSetAside_Text({x: from_decks[x] for x in from_decks if (x in moved_faces)})
        return moved_faces
    @staticmethod
    def GiveStatus(units, status, by_effect):
        from game.card.face.base import Unit2
        from game.operate.worlds import Worlds
        if (units == 'YourLeader'):
            return 0
        if (units == 'EnemyLeader'):
            leader = Worlds.GetEnemyLeader(by_effect)
            if leader:
                units = [leader]
            else:
                return 0
        value = 0
        for unit in units:
            if unit.card.IsOnField():
                unit = unit.card.CastTo(Unit2)
                if unit.GainStatus(status, by_effect):
                    value = (value + 1)
        return value
    @staticmethod
    def HasStatus(units, status):
        from game.card.face.base import Unit2
        value = 0
        for unit in units:
            if unit.card.IsOnField():
                unit = unit.card.CastTo(Unit2)
                if unit.HasStatus(status):
                    value = (value + 1)
        return value
    @staticmethod
    def DefeatUnits(units, killer, by_effect, *, ignore_when_defeated = False):
        for unit in units:
            if Unit2.IsType(unit):
                unit.Death(killer, by_effect, ignore_when_defeated=ignore_when_defeated)
    @staticmethod
    def PlaceCountersOn(targets, value, name, by_effect, *, maximum = None, by_player = None):
        from game.card.face import CanPlaceCounter
        total = 0
        for target in targets:
            target = target.card.CastTo(CanPlaceCounter)
            total = (total + target.PlaceCountersInternal(value, name, by_effect, maximum=maximum))
        return total
    @staticmethod
    def RemoveCountersOn(targets, value, name, by_effect, *, by_player = None):
        from game.card.face import CanPlaceCounter
        total = 0
        for target in targets:
            target = target.card.CastTo(CanPlaceCounter)
            message = target.RemoveCountersInternal(value, name, by_effect, forced=True)
            if message:
                total = (total + message.removed_counters)
        return total
    @staticmethod
    def PlaceTokensOn(targets, value, name, by_effect):
        from game.card.face import CanPlaceToken
        total = 0
        for target in targets:
            target = target.card.CastTo(CanPlaceToken)
            token_name = name
            size = target.PlaceTokensInternal(value, token_name, by_effect)
            if size:
                total = (total + size)
        return total
    @staticmethod
    def RemoveTokensOn(targets, value, name, by_effect):
        from game.card.face import CanPlaceToken
        total = 0
        for target in targets:
            target = target.card.CastTo(CanPlaceToken)
            token_name = name
            size = target.RemoveTokensInternal(value, token_name, by_effect, forced=True)
            if size:
                total = (total + size)
        return total
    @staticmethod
    def FindCardSize(faces, finder = None):
        if finder:
            return len(finder.Checks(faces))
        return len(faces)
    @staticmethod
    def FindCardSizeOld(faces, finder):
        return len(finder.Checks(faces))
    @staticmethod
    def IsAll(faces, finder):
        for face in faces:
            if not (finder.Check(face)):
                return False
        return True
    @staticmethod
    def EachOfAre(faces, finder):
        for face in faces:
            if not (finder.Check(face)):
                return False
        return True
    @staticmethod
    def GetDecksInDeck(faces):
        return {x: x.card.area for x in faces}
    @staticmethod
    def ReturnToHand(faces, owner, by_effect):
        from game.message import Message
        returned_faces = []
        player_cards = {None: []}
        for face in faces:
            if (owner == 'Owner'):
                player = None
                if face.GetOwner().IsPlayer():
                    player = face.GetOwnerPlayer()
            else:
                player = owner
            if (player == None):
                player_cards[None].append(face)
            if (player not in player_cards):
                player_cards[player] = []
            player_cards[player].append(face)
        Faces.DiscardAll(player_cards[None], by_effect)
        for player in player_cards:
            if (player != None):
                player.GainCard(player_cards[player], by_effect)
                returned_faces = (returned_faces + player_cards[player])
        Message.AfterCardsReturnToHand_Text(returned_faces, by_effect)
        return returned_faces
    @staticmethod
    def AddToHand(faces, player, by_effect):
        return Faces.ReturnToHand(faces, player, by_effect)
    @staticmethod
    def TreatAsAlly(minion, as_card_name, player, effect):
        from game.ability.factory import AbilityFactory
        from game.card.factory import CardFactory
        from game.operate.effects import Effects
        this = effect.this
        minion = minion.card.CastTo(Minion)
        paper = CardFactory.FindCardPapers(as_card_name)[0]
        face = CardFactory.CreateFace(paper, effect.world)
        if face:
            if Ally.IsType(face):
                face.pic_id = minion.pic_id
                face.SetName(minion.printed_name)
                face.SetSubtitle(minion.printed_subtitle)
                face.printed_attack = minion.printed_attack
                face.printed_thwart = minion.printed_scheme
                minion.card.SwapCardFace(face, effect)
                CardFactory.FaceRegisterEffects(face)
                minion.ResetKeywords()
                effects = []
                def action(action_effect: Effect, action_message: Message2):
                    Effects.UnRegister(effects)
                    face.card.SwapCardFace(minion, action_effect)
                    if minion.IsInPlay():
                        if not (minion.IsDefeated()):
                            minion.PutIntoPlay(player, effect)
                    minion.card.SetOwner(None)
                effects = [*face.effect.RegisterTemp(AbilityFactory.AfterCardLeavePlay(AbilityType.Temp2, 'This', action), unregister_after_exec=False), *face.effect.RegisterTemp(AbilityFactory.WhenCardLeavePlay(AbilityType.Temp2, this, action, conditions=[lambda effect, message: (not face.IsDefeated())]), unregister_after_exec=False)]
                face.PutIntoPlay(player, effect, under_control=True)
                return True
        return False
    @staticmethod
    def SwapWithDeckTop(faces, deck, by_effect):
        if faces:
            size = len(faces)
            top_faces = deck.GetTops(size)
            if top_faces:
                original_decks = [x.card.area for x in faces]
                Faces.MoveAllTo(faces, deck, by_effect)
                for _item in enumerate(top_faces):
                    i = UNKNOWN[0]
                    face = UNKNOWN[1]
                    Faces.MoveAllTo([face], original_decks[i], by_effect)
    @staticmethod
    def GetRest(all_faces, checked_faces):
        faces = list(all_faces)
        for face in checked_faces:
            faces.remove(face)
        return faces
    @staticmethod
    def BindDiscardPile(faces, discard_pile):
        for face in faces:
            face.card.bind_discard_pile = discard_pile
    @staticmethod
    def LookAt(faces, player, by_effect):
        from game.message import Message
        Message.LookAt_Text(player, faces)
        return faces
    @staticmethod
    def AddToVictoryDisplay(faces, by_effect):
        return Faces.MoveAllTo(faces, by_effect.world.victory_display, by_effect)
    @staticmethod
    def GiveFacedownBoostCards(faces, num, by_effect):
        from game.card.face.attribute.can_boost import CanBoost
        for face in faces:
            if CanBoost.IsType(face):
                face.GiveFacedownBoostCardsInternal(num, by_effect, None)
    @staticmethod
    def GetTotalCounters(faces, counter):
        size = 0
        for face in faces:
            if CanPlaceCounter.IsType(face):
                size = (size + face.GetCounters(counter))
        return size
    @staticmethod
    def SwapTwoCards(targets, by_effect):
        def do_move(face, into_area, index, from_area):
            if into_area.flags.is_in_play:
                face.card.MoveToArea(into_area, by_effect)
                return
            if (into_area != from_area):
                face.card.area.Remove(face.card)
            into_area.Insert(index, face.card)
        from game.message import Message
        face0 = targets[0]
        area0 = face0.card.area
        index0 = area0.GetIndex(face0)
        face1 = targets[1]
        area1 = face1.card.area
        index1 = area1.GetIndex(face1)
        do_move(face1, area0, index0, area1)
        do_move(face0, area1, index1, area0)
        message = Message.AfterCardsSwapDeck_Text(face0, face1)
        message.Send()
    @staticmethod
    def CountTraitNum(faces):
        traits = set()
        for face in faces:
            for trait in face.traits:
                traits.add(trait)
        return len(traits)
    @staticmethod
    def ResolveAbility(faces, player, ability_type, by_effect, ref_message = None):
        ret_value = 0
        for face in faces:
            if face.ResolveAbility(player, ability_type, by_effect, ref_message):
                ret_value = (ret_value + 1)
        return ret_value
