# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from . import *
PLAYER_LIST_KEY = Literal[('Obligations', 'Rescued Allies', 'Aspect Advantage: Reputation Track Reward')]
PLAYER_LIST_KEY: TypeAlias
PLAYER_STR_KEY = Literal[('Tech Upgrade', 'Basic Upgrade', 'S.H.I.E.L.D. Tech: Reputation Track Reward', 'Planning Ahead: Reputation Track Reward')]
PLAYER_STR_KEY: TypeAlias
PLAYER_INT_KEY = Literal[('Remaining hit points',)]
PLAYER_INT_KEY: TypeAlias
LOG_LIST_KEY = Literal[('Experimental Weapons added to encounter deck', 'Players engaged with minions', 'Allies removed from the campaign', 'Community Service: Victory for Scenarios #1-4', 'Osborn Tech: Reputation Track Penalty', 'Last Ones Standing: Victory for Scenario #4 - The Sinister Six')]
LOG_LIST_KEY: TypeAlias
LOG_INT_KEY = Literal[('Number of delay counters on main scheme', 'Reputation Track', 'Waking Nightmare: Victory for Scenario #3 - Mysterio')]
LOG_INT_KEY: TypeAlias
LOG_STR_KEY = Literal['']
LOG_STR_KEY: TypeAlias
class CampaignLog:
    @staticmethod
    def GetStrInternal(key, by_effect):
        if Stores.HasKey(key, by_effect):
            return Stores.GetStr(key, by_effect)
        return ''
    @staticmethod
    def GetIntInternal(key, by_effect):
        value = CampaignLog.GetStrInternal(key, by_effect)
        if value:
            return int(value)
        return 0
    @staticmethod
    def GetListInternal(key, by_effect):
        value = CampaignLog.GetStrInternal(key, by_effect)
        if value:
            return value.split(';')
        return []
    @staticmethod
    def GetStr(key, by_effect):
        return CampaignLog.GetStrInternal(key, by_effect)
    @staticmethod
    def GetInt(key, by_effect):
        return CampaignLog.GetIntInternal(key, by_effect)
    @staticmethod
    def GetList(key, by_effect):
        return CampaignLog.GetListInternal(key, by_effect)
    @staticmethod
    def GetStrByPlayer(key, player_id, by_effect):
        player_keys = [f'Player {(player_id + 1)} {key}', f'{key} P{(player_id + 1)}']
        for player_key in player_keys:
            value = CampaignLog.GetStrInternal(player_key, by_effect)
            if value:
                value
                return
        return ''
    @staticmethod
    def GetListByPlayer(key, player_id, by_effect):
        player_keys = [f'Player {(player_id + 1)} {key}', f'{key} P{(player_id + 1)}']
        for player_key in player_keys:
            value = CampaignLog.GetListInternal(player_key, by_effect)
            if value:
                value
                return
        return []
    @staticmethod
    def GetIntByPlayer(key, player_id, by_effect):
        player_keys = [f'Player {(player_id + 1)} {key}', f'{key} P{(player_id + 1)}']
        for player_key in player_keys:
            value = CampaignLog.GetIntInternal(player_key, by_effect)
            if value:
                value
                return
        return 0
    @staticmethod
    def SetStr(key, value, world):
        world.store.SetStr(key, value)
