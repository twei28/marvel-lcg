# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
@final
class Effects:
    @staticmethod
    def UnRegister(*effects):
        def unregister(effects):
            if (effects == None):
                return
            if isinstance(effects, list):
                for effect in effects:
                    effect.UnRegisterSelf()
                return
            effects.UnRegisterSelf()
        for effect in effects:
            unregister(effect)
