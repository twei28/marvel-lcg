# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Stores:
    @staticmethod
    def SetStr(name, value, by_effect):
        world = by_effect.world
        world.store.SetStr(name, value)
    @staticmethod
    def GetStr(name, by_effect):
        world = by_effect.world
        return world.store.GetStr(name)
    @staticmethod
    def HasKey(name, by_effect):
        world = by_effect.world
        return world.store.HasKey(name)
    @staticmethod
    def SetFace(name, value, by_effect):
        world = by_effect.world
        world.store.SetFace(name, value)
    @staticmethod
    def GetFace(name, by_effect):
        world = by_effect.world
        return world.store.GetFace(name)
    @staticmethod
    def AddFace(name, value, by_effect):
        world = by_effect.world
        world.store.AddFace(name, value)
    @staticmethod
    def GetFaces(name, by_effect):
        world = by_effect.world
        return world.store.GetFaces(name)
