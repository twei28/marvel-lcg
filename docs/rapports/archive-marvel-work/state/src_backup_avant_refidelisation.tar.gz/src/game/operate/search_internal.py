# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
@final
class SearchInternal:
    @staticmethod
    def SearchForCardsInternal(by_effect, player, all_faces, process_choose, process_other, finder, may, not_move = False, range = (1, 1)):
        from game.card.face.card_face import CardFace
        legal_faces = []
        if finder:
            legal_faces = finder.Checks(all_faces)
        else:
            legal_faces = list(all_faces)
        skip_choose = True
        if (range == 'All'):
            skip_choose = True
        else:
            check_faces_deck = {}
            for face in legal_faces:
                face_name = face.name
                if (face_name in check_faces_deck):
                    if (check_faces_deck[face_name] != face.card.area):
                        skip_choose = False
                    else:
                        check_faces_deck[face_name] = face.card.area
                        if (len(check_faces_deck.keys()) > 1):
                            skip_choose = False
                        else:
                            pass
                else:
                    check_faces_deck[face_name] = face.card.area
                    if (len(check_faces_deck.keys()) > 1):
                        skip_choose = False
                    else:
                        pass
        if skip_choose:
            if (legal_faces != []):
                select_face = legal_faces
            else:
                select_face = all_faces
        else:
            select_face = all_faces
        return_face = []
        if may:
            if not (isinstance(range, Tuple)):
                raise AssertionError
            x = range[1]
            if isinstance(x, str):
                raise AssertionError
            range = (0, x)
        selector = Select.From(faces=select_face, finder=finder, not_move=not_move, not_shuffle=False, by_search=True, range=range)
        if skip_choose:
            if not (may):
                faces = selector.GetAllLegalTargets(by_effect)
                min = selector.selector_range.GetTargetMin(by_effect, faces)
                max = selector.selector_range.GetTargetMax(by_effect, faces)
                faces = faces[:max]
                if not (selector.AfterSelectTargets(by_effect, faces, (min, max))):
                    selector.IfSelectTargetFailure(by_effect)
                    faces = []
            else:
                faces = player.AskChooseSelect(selector, by_effect)
        else:
            faces = player.AskChooseSelect(selector, by_effect)
        def process(targets):
            for face in targets:
                if process_choose:
                    process_choose(face)
                return_face.append(face)
            if process_other:
                for face in all_faces:
                    if (face not in targets):
                        process_other(face)
        if faces:
            process(faces)
        return return_face
    @staticmethod
    def FindCards(by_effect, *, range = (1, 1), finder = None, name = None, trait = None, card_type = CardFace, include_in_play = True, **kwargs):
        from game.operate.search import Search
        player = by_effect.world.GetFirstPlayer()
        faces = Search.SearchForCards(by_effect, player, include_encounter_deck=True, include_encounter_discard_pile=True, include_set_aside=True, include_in_play=include_in_play, finder=(CardFinder(*(), **{'name': name, 'trait': trait, 'card_type': card_type, **kwargs}) & finder), range=range)
        return faces
