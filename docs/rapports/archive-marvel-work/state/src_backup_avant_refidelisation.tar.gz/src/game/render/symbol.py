# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from colorama import Fore
from colorama import Back
from colorama import Style
import re
@dataclass
class Symbol:
    health = f'{Fore.LIGHTRED_EX}♡{Fore.RESET}'
    threat = f'{Fore.YELLOW}⚠{Fore.RESET}'
    number = {Back.LIGHTRED_EX}
    func_name = {Back.LIGHTBLUE_EX}
    reset = {Style.RESET_ALL}
    environment = f'{Fore.GREEN}⌼ {Fore.RESET}'
    ready_ally = f'{Fore.RED}🃢{Fore.RESET}'
    exhauste_ally = f'{Fore.LIGHTBLACK_EX}🃱{Fore.RESET}'
    ready_upgrade = f'{Fore.RED}🃪{Fore.RESET}'
    exhauste_upgrade = f'{Fore.LIGHTBLACK_EX}🃪{Fore.RESET}'
    exhauste = f'{Fore.LIGHTBLACK_EX}🃱{Fore.RESET}'
    hand_card = f'{Fore.LIGHTBLUE_EX}🂠{Fore.RESET}'
    scheme = f'{Fore.CYAN}🃧{Fore.RESET}'
    villain = f'{Fore.BLACK}🂿{Fore.RESET}'
    minion = f'{Fore.BLACK}🃟{Fore.RESET}'
    r_b_mental = f'{Fore.BLUE}B{Fore.RESET}'
    r_r_physical = f'{Fore.RED}R{Fore.RESET}'
    r_y_energy = f'{Fore.YELLOW}Y{Fore.RESET}'
    r_g_wild = f'{Fore.GREEN}G{Fore.RESET}'
    stunned = f'{Fore.GREEN}Stunned{Fore.RESET}'
    confused = f'{Fore.CYAN}Confused{Fore.RESET}'
    tough = f'{Fore.LIGHTYELLOW_EX}Tough{Fore.RESET}'
    boost = f'{Fore.RED}✶{Fore.RESET}'
    consequential_damage = '☆'
    hazard = 'Hazard'
    crisis = 'Crisis'
    acceleration = 'Acceleration'
    _Symbol__ansi_escape = re.compile('\n        \\x1B  # ESC\n        (?:   # 7-bit C1 Fe (except CSI)\n            [@-Z\\\\-_]\n        |     # or [ for CSI, followed by a control sequence\n            \\[\n            [0-?]*  # Parameter bytes\n            [ -/]*  # Intermediate bytes\n            [@-~]   # Final byte\n        )\n    ', re.VERBOSE)
    @staticmethod
    def Clean(text):
        return Symbol._Symbol__ansi_escape.sub('', text)
    @staticmethod
    def CleanPrompt(text):
        text = text.replace(Symbol.r_b_mental, '[[mental]]')
        text = text.replace(Symbol.r_r_physical, '[[physical]]')
        text = text.replace(Symbol.r_y_energy, '[[energy]]')
        text = text.replace(Symbol.r_g_wild, '[[wild]]')
        text = text.replace(Symbol.boost, '[[boost]]')
        return Symbol.Clean(text)
    @staticmethod
    def AddColor(text):
        text = re.sub('c(\\d+)', ((('c' + Fore.GREEN) + '\\1') + Fore.RESET), text)
        return text
