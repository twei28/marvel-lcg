# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.render import *
from game.render.descriptor.card import CardDescriptor
@dataclass
class WorldDescriptor:
    __annotations__ = {}
    render_id = field(default=0)
    render_id: int
    round_id = field(default=0)
    round_id: int
    phase = field(default='')
    phase: str
    prompt = field(default='')
    prompt: str
    event_name = field(default='')
    event_name: str
    prompt_last_text = field(default='')
    prompt_last_text: str
    sound_name = field(default='')
    sound_name: str
    max_card_object_id = field(default=0)
    max_card_object_id: int
    area_schemes_main = field(default_factory=lambda : [])
    area_schemes_main: List[CardDescriptor]
    main_schemes_deck = field(default_factory=lambda : [])
    main_schemes_deck: List[CardDescriptor]
    area_schemes_side = field(default_factory=lambda : [])
    area_schemes_side: List[CardDescriptor]
    additional_decks = field(default_factory=lambda : [])
    additional_decks: List[Sequence[CardDescriptor]]
    additional_discard_piles = field(default_factory=lambda : [])
    additional_discard_piles: List[Sequence[CardDescriptor]]
    area_villain = field(default_factory=lambda : [])
    area_villain: List[CardDescriptor]
    villain_deck = field(default_factory=lambda : [])
    villain_deck: List[CardDescriptor]
    encounter_deck = field(default_factory=lambda : [])
    encounter_deck: List[CardDescriptor]
    encounter_discard_pile = field(default_factory=lambda : [])
    encounter_discard_pile: List[CardDescriptor]
    area_boost = field(default_factory=lambda : [])
    area_boost: List[CardDescriptor]
    area_environment = field(default_factory=lambda : [])
    area_environment: List[CardDescriptor]
    area_evidence = field(default_factory=lambda : [])
    area_evidence: List[CardDescriptor]
    area_rule = field(default_factory=lambda : [])
    area_rule: List[CardDescriptor]
    area_processing = field(default_factory=lambda : [])
    area_processing: List[CardDescriptor]
    area_revealing = field(default_factory=lambda : [])
    area_revealing: List[CardDescriptor]
    area_resources = field(default_factory=lambda : [])
    area_resources: List[CardDescriptor]
    area_removed = field(default_factory=lambda : [])
    area_removed: List[CardDescriptor]
    area_insert = field(default_factory=lambda : [])
    area_insert: List[CardDescriptor]
    area_set_aside = field(default_factory=lambda : [])
    area_set_aside: List[CardDescriptor]
    victory_display = field(default_factory=lambda : [])
    victory_display: List[CardDescriptor]
    area_status_cards = field(default_factory=lambda : [])
    area_status_cards: List[CardDescriptor]
    @dataclass
    class PlayerDescriptor:
        __annotations__ = {}
        area_hero = field(default_factory=lambda : [])
        area_hero: List[CardDescriptor]
        allies = field(default_factory=lambda : [])
        allies: List[CardDescriptor]
        supports = field(default_factory=lambda : [])
        supports: List[CardDescriptor]
        player_deck = field(default_factory=lambda : [])
        player_deck: List[CardDescriptor]
        player_discard_pile = field(default_factory=lambda : [])
        player_discard_pile: List[CardDescriptor]
        dealt_encounter_cards = field(default_factory=lambda : [])
        dealt_encounter_cards: List[CardDescriptor]
        hand_cards = field(default_factory=lambda : [])
        hand_cards: List[CardDescriptor]
        engaged_enemies = field(default_factory=lambda : [])
        engaged_enemies: List[CardDescriptor]
        set_aside_nemesis_sets = field(default_factory=lambda : [])
        set_aside_nemesis_sets: List[CardDescriptor]
        set_aside_deck = field(default_factory=lambda : [])
        set_aside_deck: List[CardDescriptor]
        additional_deck = field(default_factory=lambda : [])
        additional_deck: List[CardDescriptor]
        additional_discard_pile = field(default_factory=lambda : [])
        additional_discard_pile: List[CardDescriptor]
        obligations_area = field(default_factory=lambda : [])
        obligations_area: List[CardDescriptor]
        environment_area = field(default_factory=lambda : [])
        environment_area: List[CardDescriptor]
        resources = field(default='')
        resources: str
        is_eliminated = field(default=False)
        is_eliminated: bool
    players = field(default_factory=lambda : [])
    players: List[PlayerDescriptor]
    active_card_ids = field(default_factory=lambda : [])
    active_card_ids: List[int]
