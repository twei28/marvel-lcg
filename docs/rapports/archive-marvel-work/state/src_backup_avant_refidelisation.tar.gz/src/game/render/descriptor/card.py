# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
@dataclass
class CardDescriptor:
    __annotations__ = {}
    id: int
    is_ready: bool
    is_face_up: bool
    visible_for_players: List[int]
    bind_object_id: int
    effect_by_cards: List[int]
    effect_to_cards: List[int]
    game_area: int
    name: str
    info: Dict[(str, int)]
    traits: Dict[(str, int)]
    buffs: Dict[(str, str)]
    card_id: str
    pic_id: str
    down_card_ids: List[str]
    effects: List[int]
    resources: List[int]
    card_type: str
    cost: int
    crc: int
    is_new: bool
    is_action: bool
