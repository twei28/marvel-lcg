# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.render.symbol import Symbol
Unused(Symbol)
from game.render.descriptor.world import WorldDescriptor
from game.render.descriptor.card import CardDescriptor
from game.render.descriptor.effect import EffectDescriptor
Unused(WorldDescriptor)
Unused(CardDescriptor)
Unused(EffectDescriptor)
