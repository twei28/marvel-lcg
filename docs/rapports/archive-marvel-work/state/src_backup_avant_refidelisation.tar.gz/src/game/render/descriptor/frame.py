# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
@dataclass
class FrameDescriptor:
    __annotations__ = {}
    render_id: int
    game_id: int
    ask_players: List[int]
    remaining_time: float
    max_timeout: float
    notify_texts: List[str]
    debug_message: str
    current_step_id: int
    max_replay_step_id: int
    player_id: int
    total_players: int
