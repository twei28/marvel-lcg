# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
@dataclass
class EffectDescriptor:
    __annotations__ = {}
    @dataclass
    class Payment:
        __annotations__ = {}
        cost: str
        payment: List[Dict[(int, str)]]
        rule: List[str]
    id: int
    name: str
    bind_id: int
    bind_player_id: int
    all_legal_targets: List[int]
    target_num_range: List[int]
    target_payment: Dict[(int, Payment)]
    select_rule: str
    select_rule_param: Tuple[(int, int)]
    target_must_include_traits: List[str]
    failure_reason: str
    is_search: bool
