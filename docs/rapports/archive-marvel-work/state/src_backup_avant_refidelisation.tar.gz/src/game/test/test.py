# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game import *
from engine.log import Log
from engine.file import FileManager
from engine.config import ConfigVariables
REPLAY_FOLDERS = ConfigVariables.Folders('replay_folders')
class Test:
    __annotations__ = {}
    is_in_test = False
    test_cases = []
    test_cases: List[str]
    @staticmethod
    def GetTestCases(category = None):
        all_cases = []
        def not_start_with(f):
            return (not f.startswith('_'))
        for replays_folder in REPLAY_FOLDERS.value:
            all_cases = (all_cases + FileManager.ListFiles(replays_folder, ext='.json', check_file_name=not_start_with))
        def extract_version(s):
            import re
            match = re.search('\\[(.*?)\\]', s)
            if match:
                return tuple(map(int, match.group(1).split('.')))
            return ()
        all_cases = sorted(all_cases, key=extract_version)
        test_cases = all_cases
        if category:
            test_cases = [x for x in test_cases if (category in x)]
        return test_cases
    @staticmethod
    def SetStart(start_id, test_category):
        Test.test_cases = Test.GetTestCases(test_category)[start_id:]
    @staticmethod
    def Exit():
        Test.is_in_test = False
        Test.test_cases = []
    @staticmethod
    def Run(game):
        if not (game.state.start_state.is_in_testing):
            return False
        from game.test.test_run import TestRun
        if Test.test_cases:
            Test.is_in_test = True
            success = TestRun.Run(game, Test.test_cases, do_save=True)
            exit_test = success
        else:
            success = False
            Log.Print('No cases for testing')
            game.state.SetStartState('')
            exit_test = True
        TestRun.RunEnd(game, success, exit_test)
        return True
    @staticmethod
    def IsInTesting():
        return Test.is_in_test
