# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.face import *
from game.effect import *
from game.deck import *
class SelectorEnd:
    def __init__(self, peek = False, not_move = False, not_shuffle = False):
        self.peek = peek
        self.not_move = not_move
        self.not_shuffle = not_shuffle
    def Process(self, effect, targets):
        do_move = True
        if self.not_move:
            do_move = False
        if not (self.not_shuffle):
            SelectorEnd.DoShuffle(effect, targets, do_move, False)
            return True
        if do_move:
            SelectorEnd.DoMove(effect, targets, do_move)
        return True
    def OnSelectTargetFailure(self, effect, peeked_faces):
        if self.peek:
            if peeked_faces:
                SelectorEnd.DoShuffle(effect, peeked_faces, False, True)
                return
                return
    @staticmethod
    def DoMove(effect, faces, need_move):
        from game.operate.faces import Faces
        places = []
        moved_faces = []
        for face in faces:
            deck = face.card.area
            if deck.flags.is_deck:
                if not (face.card.IsFaceUp()):
                    moved_faces.append(face)
                    places.append(face.card.area)
        if need_move:
            if moved_faces:
                Faces.MoveAllToProcessingArea(moved_faces, effect)
            return places
        return places
    @staticmethod
    def DoShuffle(effect, faces, need_move, is_failure):
        from game.deck.deck import Deck
        places = SelectorEnd.DoMove(effect, faces, need_move)
        if not (need_move):
            if is_failure:
                for deck in Types.RemoveDuplicates(places):
                    if not ((deck.GetSize() != 0)):
                        raise AssertionError
                    if (deck.GetSize() == 0):
                        pass
                    deck.Shuffle(effect)
        for deck in Types.RemoveDuplicates(places):
            if not ((deck.GetSize() != 0)):
                raise AssertionError
            if (deck.GetSize() == 0):
                pass
            deck.Shuffle(effect)
