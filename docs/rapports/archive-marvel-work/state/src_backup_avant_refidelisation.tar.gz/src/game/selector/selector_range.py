# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.face import *
from game.effect import *
from game.selector.selector_rule import *
class SelectorRange:
    RANGE_MIN = ((int | Callable[(['Effect'], int)]) | Literal['Zero'])
    RANGE_MAX = ((int | Callable[(['Effect'], int)]) | Literal['All'])
    RANGE_INT_TYPE = Tuple[(int, int)]
    RANGE_TYPE = (((RANGE_INT_TYPE | Tuple[(RANGE_MIN, RANGE_MAX)]) | Literal[('All', 'Default')]) | Callable[(['Effect'], int)])
    def __init__(self, range: 'RANGE_TYPE', selector_rule: 'SelectorRule'):
        self
        self
        self.has_combined_rules = selector_rule.has_combined_rules
        self.has_repeat_rules = (selector_rule.repeat_rules != [])
        self.select_rule = selector_rule.select_rule
        self.SetRange(range)
    def SetRange(self, range: 'RANGE_TYPE'):
        self.raw_range = range
        if self.has_combined_rules:
            if not ((range == 'Default')):
                raise AssertionError
            max_fn = 'All'
            min_fn = 1
            select_all = False
        else:
            if (range == 'Default'):
                min_fn = 1
                max_fn = 1
                select_all = False
            else:
                if (range == 'All'):
                    min_fn = 0
                    max_fn = 0
                    select_all = True
                else:
                    if isinstance(range, Tuple):
                        min_fn = range[0]
                        max_fn = range[1]
                        select_all = False
                    else:
                        min_fn = range
                        max_fn = min_fn
                        select_all = False
        if (self.select_rule != '') and (not select_all):
            if not ((isinstance(max_fn, int) and (max_fn > 1)) or (max_fn == 'All')):
                raise AssertionError
        self.max_fn = max_fn
        self.min_fn = min_fn
        self.select_all = select_all
        self.can_be_zero = (self.min_fn == 'Zero')
    def GetTargetMax(self, effect, targets):
        if self.select_all or (self.max_fn == 'All'):
            if self.has_repeat_rules:
                return Math.INT_INF
            return len(targets)
        if isinstance(self.max_fn, int):
            return self.max_fn
        return self.max_fn(effect)
    def GetTargetMin(self, effect, targets):
        if self.select_all:
            return max(1, len(targets))
        if (self.min_fn == 'Zero'):
            return len(targets)
        if isinstance(self.min_fn, int):
            return self.min_fn
        return self.min_fn(effect)
