# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.selector.factory import Select
from game.selector.selector import Selector
Unused(Select)
Unused(Selector)
from game.selector.factory import SELECT
Unused(SELECT)
