# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.ability import *
from game.card.face import *
from game.selector import *
from game.message import *
from game.operate.worlds import Worlds
from game.card.face.base import Asset2
from game.card.face.card_type import Event
from game.message.message_type import TargetsMessage
from game.selector import Select
def get_TeamUp(effect):
    if not (Event.IsType(effect.this)):
        raise AssertionError
    return effect.this.GetTeamUpUnits()
def get_VillainAndEngagedSamePlayerMinion(effect):
    faces = []
    for player in effect.world.const_seat_order_players:
        faces = (faces + player.engaged_minions.Get())
    return (Worlds.GetVillains(effect) + faces)
def get_VillainAndYouEngagedMinion(effect):
    player = Select.GetYou(effect)
    return (Worlds.GetVillains(effect) + player.engaged_minions.Get())
def get_Attached(effect):
    if effect.ability.flags.is_choose_ability:
        if isinstance(effect.bind_message, Message.WhenPlayerChooseAbility):
            effect = effect.bind_message.by_effect
    if not (Asset2.IsType(effect.this)):
        raise AssertionError(f'effect.this={effect.this!r}')
    return [effect.this.GetBindFace()]
def get_Initiator(effect):
    return [effect.GetInitiator().GetIdentity()]
def get_This(effect):
    if effect.ability.flags.is_choose_ability:
        if isinstance(effect.bind_message, Message.WhenPlayerChooseAbility):
            effect = effect.bind_message.by_effect
    return [effect.this]
def get_DefendingCharacter(effect):
    found_faces = []
    if isinstance(effect.bind_message, DefenderNoneMessage):
        if effect.bind_message.defender:
            found_faces = [effect.bind_message.defender]
        return found_faces
    if not (isinstance(effect.bind_message, Message.WhenCardBecomeBoost)):
        raise AssertionError(f'effect.bind_message={effect.bind_message!r}')
    if isinstance(effect.bind_message.being_message, Message.WhenUnitBeingAttack):
        defender = effect.bind_message.being_message.would_atk_message.GetDefender()
        if defender:
            found_faces = [defender]
    return found_faces
def get_Attacker(effect):
    def get_attacker(message):
        attackers = []
        if isinstance(message, AttackerMessageInternal):
            if (message.attacker != None):
                attackers = [message.attacker]
        if isinstance(message, Message.WhenBoostCardTurnedFaceUp):
            if isinstance(message.being_message, Message.WhenUnitBeingAttack):
                attackers = [message.would_atk_message.attacker]
        attackers = [x for x in attackers if x.IsInPlay()]
        return attackers
    message = effect.GetBindMessage(Message2)
    if isinstance(message, Message.AfterPlayerPlayedCard):
        found_faces = get_attacker(message.on_message)
        return found_faces
    if isinstance(message, CanBeInstead):
        if message.is_be_instead:
            found_faces = []
            return found_faces
    found_faces = get_attacker(message)
    return found_faces
def get_Attacked(effect):
    def get_attacked(message):
        if isinstance(message, AttackerMessageInternal):
            if (message.attacker != None):
                return message.attacked_targets
        return []
    message = effect.GetBindMessage(Message2)
    if isinstance(message, Message.AfterPlayerPlayedCard):
        found_faces = get_attacked(message.on_message)
        return found_faces
    if isinstance(message, CanBeInstead):
        if message.is_be_instead:
            found_faces = []
            return found_faces
    found_faces = get_attacked(message)
    return found_faces
def get_DamageTarget(effect):
    message = effect.GetBindMessage(Message2)
    if isinstance(message, Message.AfterUnitAttackEnd):
        return message.damaged_targets
    return []
def get_BoostForCard(effect):
    if not (isinstance(effect.bind_message, (Message.WhenCardBecomeBoost | Message.WhenBoostCardTurnedFaceUp))):
        raise AssertionError
    return [effect.bind_message.being_message.by_face]
def get_Trigger(effect):
    if isinstance(effect.bind_message, Message.WhenPlayerChooseAbility):
        message = effect.bind_message.by_effect.bind_message
    else:
        message = effect.bind_message
    if isinstance(message, Message.WhenPlayerInTurn):
        return [message.GetToPlayer().GetIdentity()]
    if isinstance(message, ((TriggerUnitMessage | TriggerSchemeMessage) | TriggerFaceMessage)):
        return [message.trigger]
    if isinstance(message, TriggerPlayerMessage):
        if message.to_player:
            return [message.to_player.GetIdentity()]
    raise AssertionError(f'effect={effect!r}')
def get_Targets(effect):
    if not (isinstance(effect.bind_message, TargetsMessage)):
        raise AssertionError
    return effect.bind_message.targets
def get_to_player(effect):
    if not (isinstance(effect.bind_message, TriggerPlayerMessage)):
        raise AssertionError
    return [effect.bind_message.GetToPlayer().GetIdentity()]
def get_played_card(effect):
    if not (isinstance(effect.bind_message, Message.AfterPlayerPlayedCard)):
        raise AssertionError
    return [effect.bind_message.played_face]
def get_UsedToPayForThis(effect):
    if not (isinstance(effect.bind_message, Message.AfterPlayerPlayedCard)):
        raise AssertionError
    return [x.this for x in effect.bind_message.paid_res_effects]
def get_ThisAttachedHereCard(effect):
    return effect.this.GetPlacedCardArea().Get()
def get_Players(effect):
    return Worlds.GetPlayersIdentities(effect)
def get_OtherPlayers(effect):
    return [x for x in Worlds.GetPlayersIdentities(effect) if (x.GetControlBy() != Select.GetYou(effect))]
def get_FirstPlayer(effect):
    return [Worlds.GetFirstPlayer(effect).GetIdentity()]
def get_YourHero(effect):
    you = Select.GetYou(effect)
    if you.IsHero():
        return [you.GetIdentity()]
    return []
def get_YourIdentity(effect):
    you = Select.GetYou(effect)
    return [you.GetIdentity()]
def get_YourAlterEgo(effect):
    you = Select.GetYou(effect)
    if you.IsAlterEgo():
        return [you.GetIdentity()]
    return []
def get_YourSidekick(effect):
    you = Select.GetYou(effect)
    return [face for face in you.allies.Get() if (face.GetInventoryDeck().FindCard(name='Sidekick', card_type=Upgrade) != None)]
def get_YouControlUnit(effect):
    you = Select.GetYou(effect)
    return you.GetControlCharacters()
def get_YouControlCards(effect):
    you = Select.GetYou(effect)
    return you.GetControlCards()
def get_YourAlly(effect):
    you = Select.GetYou(effect)
    return you.allies.Get()
def get_YourEngagedMinions(effect):
    you = Select.GetYou(effect)
    return you.engaged_minions.Get()
def get_Hero_Ally(effect):
    return (Worlds.GetOnFieldAllies(effect) + Worlds.GetOnFieldHeroes(effect))
def get_Hero_Villain(effect):
    return (Worlds.GetAllVillains(effect) + Worlds.GetOnFieldHeroes(effect))
def get_Ally_Minion(effect):
    return (Worlds.GetOnFieldAllies(effect) + Worlds.GetOnFieldMinions(effect))
def get_Ally_Support(effect):
    return (Worlds.GetOnFieldAllies(effect) + Worlds.GetOnFieldSupports(effect))
def get_EnemyOrScheme(effect):
    return (Worlds.GetOnFieldEnemies(effect) + Worlds.GetOnFieldSchemes(effect))
def get_Upgrade_Support(effect):
    return [x for x in Worlds.GetOnFieldCards(effect) if True]
def get_LeaderMinion(effect):
    return (Worlds.GetOnFieldLeaders(effect) + Worlds.GetOnFieldMinions(effect))
def get_MainScheme(effect):
    return Worlds.GetMainSchemes(effect)
def get_Villain(effect):
    return Worlds.GetVillains(effect)
def get_Minion(effect):
    return Worlds.GetOnFieldMinions(effect)
def get_SideScheme(effect):
    return Worlds.GetSideSchemes(effect)
def get_PlayerSideScheme(effect):
    return [x for x in Worlds.GetSideSchemes(effect) if PlayerSideScheme.IsType(x)]
def get_Upgrade(effect):
    return [x for x in Worlds.GetOnFieldCards(effect) if Upgrade.IsType(x)]
def get_Support(effect):
    return Worlds.GetOnFieldSupports(effect)
def get_Attachment(effect):
    return [x for x in Worlds.GetOnFieldCards(effect) if Attachment.IsType(x)]
def get_Environment(effect):
    return Worlds.GetOnFieldEnvironment(effect)
def get_Obligation(effect):
    return [identity for identity in Worlds.GetPlayersIdentities(effect)]
def get_Ally(effect):
    return Worlds.GetOnFieldAllies(effect)
def get_Hero(effect):
    return Worlds.GetOnFieldHeroes(effect)
def get_AlterEgo(effect):
    return Worlds.GetOnFieldAlterEgos(effect)
def get_StatusCard(effect):
    return [unit for unit in Worlds.GetOnFieldCharacters(effect)]
def get_Friend(effect):
    return Worlds.GetOnFieldFriendlyCharacters(effect)
def get_Scheme2(effect):
    return Worlds.GetOnFieldSchemes(effect)
def get_Identity(effect):
    return Worlds.GetPlayersIdentities(effect)
def get_EnemyLeader(effect):
    leader = Worlds.GetEnemyLeader(effect)
    if leader:
        return [leader]
    return []
def get_YourLeader(effect):
    leader = Worlds.GetYourTeamLeader(effect)
    if leader:
        return [leader]
    return []
def get_YourSuitFormUpgrade(effect):
    you = Select.GetYou(effect)
    return you.GetControlUpgrade(CardFinder(card_type=Upgrade, form='Suit'))
def get_TuckHereCard(effect):
    return effect.this.GetPlacedCardArea().GetAll()
def get_TuckUnderYourIdentityCard(effect):
    you = Select.GetYou(effect)
    return you.GetIdentity().GetPlacedCardArea().GetAll()
def get_YourHeroTough(effect):
    you = Select.GetYou(effect)
    if you.IsHero():
        return you.GetIdentity().components.status.GetDeck().FindCards(name='Tough')
    return []
def get_YourHandCards(effect):
    you = Select.GetYou(effect)
    return you.hand_cards.Get()
def get_YourLikeHandCards(effect):
    you = Select.GetYou(effect)
    faces = you.hand_cards.Get()
    for face in you.discard_pile.GetAll():
        if face.IsLikeInHand():
            faces.append(face)
    for face in you.player_deck.GetAll():
        if face.IsLikeInHand():
            faces.append(face)
    return faces
TARGET_MAP_FUNC = {'TeamUp': get_TeamUp, 'VillainAndEngagedSamePlayerMinion': get_VillainAndEngagedSamePlayerMinion, 'VillainAndYouEngagedMinion': get_VillainAndYouEngagedMinion, 'Attached': get_Attached, 'Initiator': get_Initiator, 'This': get_This, 'DefendingCharacter': get_DefendingCharacter, 'Attacker': get_Attacker, 'Attacked': get_Attacked, 'DamageTarget': get_DamageTarget, 'BoostForCard': get_BoostForCard, 'Trigger': get_Trigger, 'Targets': get_Targets, 'ToPlayer': get_to_player, 'PlayedCard': get_played_card, 'UsedToPayForThis': get_UsedToPayForThis, 'ThisAttachedHereCard': get_ThisAttachedHereCard, **{'Players': get_Players, 'OtherPlayers': get_OtherPlayers, 'FirstPlayer': get_FirstPlayer, 'YourHero': get_YourHero, 'YourIdentity': get_YourIdentity, 'YourAlterEgo': get_YourAlterEgo, 'YourSidekick': get_YourSidekick, 'YouControlUnit': get_YouControlUnit, 'YouControlCards': get_YouControlCards, 'YourAlly': get_YourAlly, 'YourEngagedMinions': get_YourEngagedMinions, 'Hero|Ally': get_Hero_Ally, 'Hero|Villain': get_Hero_Villain, 'Ally|Minion': get_Ally_Minion, 'Ally|Support': get_Ally_Support, 'Enemy|Scheme': get_EnemyOrScheme, 'Upgrade|Support': get_Upgrade_Support}, **{'Leader|Minion': get_LeaderMinion, 'YourSuitFormUpgrade': get_YourSuitFormUpgrade, 'TuckHereCard': get_TuckHereCard, 'TuckUnderYourIdentityCard': get_TuckUnderYourIdentityCard, 'YourHeroTough': get_YourHeroTough, 'YourHandCards': get_YourHandCards, 'YourLikeHandCards': get_YourLikeHandCards, 'Minion': get_Minion, 'Villain': get_Villain, 'EncounterSideScheme': get_SideScheme, 'MainScheme': get_MainScheme, 'PlayerSideScheme': get_PlayerSideScheme, 'Upgrade': get_Upgrade, 'Support': get_Support, 'Attachment': get_Attachment, 'Environment': get_Environment, 'Obligation': get_Obligation}, **{'Ally': get_Ally, 'Hero': get_Hero, 'AlterEgo': get_AlterEgo, 'StatusCard': get_StatusCard, 'Friend': get_Friend, 'Scheme2': get_Scheme2, 'Identity': get_Identity, 'EnemyLeader': get_EnemyLeader, 'YourLeader': get_YourLeader}}
TARGET_MAP_FUNC: Dict[('SELECT.TARGET_TYPE|CardFinderHelper.FINDER_TARGET|SELECT.TARGET_TYPE_HELPER', Callable[(['Effect'], Sequence['CardFace'])])]
