# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.face import *
from game.effect import *
from game.selector import *
from game.selector.selector_target import SelectorTarget
from game.selector.selector_filter import SelectorFilter
from game.selector.selector_range import SelectorRange
from game.selector.selector_end import SelectorEnd
from game.selector.selector_rule import SelectorRule
CATEGORY_NAME = 'SELECTOR'
class Selector(metaclass=Tracker.Meta):
    def __init__(self, selector_target, selector_rule, selector_filter, selector_range, selector_end, *, after_select_fn = None, check_again_fn = None, target_text = None):
        self.selector_target = selector_target
        self.selector_rule = selector_rule
        self.selector_filter = selector_filter
        self.selector_range = selector_range
        self.selector_end = selector_end
        self.after_select_fn = after_select_fn
        self.check_again_fn = check_again_fn
        self.target_text = target_text
        self.peeked_faces = []
        self.is_optional = True
        self.condition = None
    @property
    def is_search(self):
        return self.selector_end.peek
    def GetRandomTarget(self, legal_faces, effect):
        from game.operate.rand import Rand
        return Rand.RandomChoice2(legal_faces, self.selector_range.GetTargetMax(effect, legal_faces), effect)
    def GetAllLegalTargets(self, effect, referential_effect = None, *, just_check = False):
        from game.operate.referential import Referential
        legal_faces = self.selector_target.GetAllTarget(effect, self.selector_range)
        self.peeked_faces = legal_faces
        if (referential_effect == None):
            referential_effect = effect
        legal_faces = Referential.Filter(self.selector_filter.finder, legal_faces, referential_effect)
        legal_faces = self.selector_filter.FilterLegalTargets(legal_faces, effect)
        legal_faces = self.selector_rule.Process(legal_faces, effect, self.selector_range)
        if not (legal_faces):
            return []
        if self.selector_rule.random:
            if not (just_check):
                return self.GetRandomTarget(legal_faces, effect)
        return legal_faces
    def GetTargetRange(self, effect, faces):
        from game.effect.effect import EffectFailure
        target_range = [self.selector_range.GetTargetMin(effect, faces), self.selector_range.GetTargetMax(effect, faces)]
        if (len(faces) < target_range[0]):
            return
        target_range[1] = min(len(faces), target_range[1])
        if (target_range[1] == 0):
            if (target_range[0] > target_range[1]):
                effect.failures.Set(effect.initiator, EffectFailure.MaxTargetsIsZero)
                return
        if (target_range[0] > target_range[1]):
            if (UNKNOWN > 0):
                pass
        else:
            pass
        target_range[0] = target_range[1]
        if (faces == []):
            if (target_range[0] > 0):
                effect.failures.Set(effect.initiator, EffectFailure.NoFilterTargets)
                return
        return (target_range[0], target_range[1])
    def HasLegalTargets(self, effect):
        faces = self.GetAllLegalTargets(effect, just_check=True)
        return (len(faces) >= self.selector_range.GetTargetMin(effect, faces))
    def AfterSelectTargets(self, effect, targets, range):
        if not (self.selector_rule.AfterSelectTargets(effect, targets, range)):
            return False
        if self.check_again_fn:
            if not (self.check_again_fn(effect, targets)):
                return False
        if self.after_select_fn:
            self.after_select_fn(effect)
        if self.selector_end:
            self.selector_end.Process(effect, targets)
        return True
    def IfSelectTargetFailure(self, effect: Effect):
        if self.selector_end:
            self.selector_end.OnSelectTargetFailure(effect, self.peeked_faces)
            return
