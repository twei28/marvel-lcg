# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.face import *
from game.effect import *
from game.selector import *
from game.selector.selector_range import SelectorRange
CATEGORY_NAME = 'SELECTOR'
class SelectorRule:
    RULE_BASE = Literal[('', 'DifferentCards', 'DifferentType', 'MustIncludeTraits')]
    RULE_WITH_PARAM = Literal[('CombinedResourceCost', 'CombinedPrintedCost', 'CombinedResourceIcons')]
    RULE_FOR_UI = Literal[('VillainAndMinionsEngagedSamePlayer', 'VillainAndMinionsEngagedWithYou')]
    RULE_ALL = ((RULE_BASE | RULE_WITH_PARAM) | RULE_FOR_UI)
    REPEAT_RULE = Literal[('Sustained', 'Threat', 'Health', 'CanHasConfused', 'Any')]
    def __init__(self, random = False, select_rule = '', repeat_rules = [], combined_resource_cost = None, combined_printed_cost = None, combined_resource_icons = None, top_bottom_most = False, target_must_include_traits = []):
        self.random = random
        self.raw_select_rule = select_rule
        self.repeat_rules = repeat_rules
        self.combined_resource_cost = combined_resource_cost
        self.combined_printed_cost = combined_printed_cost
        self.combined_resource_icons = combined_resource_icons
        self.top_bottom_most = top_bottom_most
        if (select_rule != 'MustIncludeTraits'):
            target_must_include_traits = []
        self.target_must_include_traits = target_must_include_traits
        if combined_resource_cost:
            new_rule_all = 'CombinedResourceCost'
            rule_param = combined_resource_cost
        else:
            if combined_printed_cost:
                new_rule_all = 'CombinedPrintedCost'
                rule_param = combined_printed_cost
            else:
                if combined_resource_icons:
                    new_rule_all = 'CombinedResourceIcons'
                    rule_param = combined_resource_icons
                else:
                    new_rule_all = select_rule
                    rule_param = (0, 0)
        self.select_rule = new_rule_all
        self.rule_param = rule_param
    def GetRuleAndParam(self):
        return (self.select_rule, self.rule_param)
    @property
    def has_combined_rules(self):
        return bool((self.combined_resource_cost or (self.combined_printed_cost or self.combined_resource_icons)))
    def Process(self, legal_faces, effect, selector_range):
        from game.operate.faces_counter import FacesCounter
        if self.top_bottom_most:
            max = selector_range.GetTargetMax(effect, legal_faces)
            legal_faces = legal_faces[:max]
        if self.repeat_rules:
            from game.card.face.base import Scheme2
            from game.card.face.base import Unit2
            max_value = selector_range.GetTargetMax(effect, legal_faces)
            face_list = []
            for face in Types.RemoveDuplicates(legal_faces):
                for allow_repeat in self.repeat_rules:
                    if (allow_repeat == 'Threat'):
                        if Scheme2.IsType(face):
                            face_list = (face_list + ([face] * min(face.threat, max_value)))
                    if (allow_repeat == 'Sustained'):
                        if Unit2.IsType(face):
                            face_list = (face_list + ([face] * min(face.sustained, max_value)))
                    if (allow_repeat == 'Health'):
                        if Unit2.IsType(face):
                            face_list = (face_list + ([face] * min(face.health, max_value)))
                    if (allow_repeat == 'CanHasConfused'):
                        if Unit2.IsType(face):
                            if face.IsConfused():
                                pass
                            if face.IsSteady():
                                if face.confused:
                                    face_list = (face_list + [face])
                                face_list = (face_list + ([face] * 2))
                            face_list = (face_list + [face])
                    if (allow_repeat == 'Any'):
                        face_list = (face_list + ([face] * max_value))
            legal_faces = face_list
        if self.combined_resource_cost:
            cost = FacesCounter.GetPrintedCost(legal_faces)
            if (cost < self.combined_resource_cost[0]):
                return []
        if self.combined_printed_cost:
            cost = FacesCounter.GetPrintedCost(legal_faces)
            if (cost < self.combined_printed_cost[0]):
                return []
        if self.combined_resource_icons:
            icon = FacesCounter.GetPrintedResourcesIcon(legal_faces, 'Auto')
            if (icon < self.combined_resource_icons[0]):
                return []
        return legal_faces
    def AfterSelectTargets(self, effect, targets, range):
        from game.operate.faces_counter import FacesCounter
        from game.card.face.card_type import Minion
        from game.effect.effect_failure import EffectFailure
        if not (self.select_rule.startswith('VillainAndMinions')):
            if (range[0] <= len(targets)):
                if not ((UNKNOWN <= range[1])):
                    pass
            else:
                pass
            effect.failures.Set(None, EffectFailure.TargetNum)
            return False
        else:
            player = None
            for face in targets:
                if Minion.IsType(face):
                    player = face.GetEngagedPlayer()
                else:
                    pass
            for face in targets:
                if Minion.IsType(face):
                    if (player != face.GetEngagedPlayer()):
                        effect.failures.Set(player, EffectFailure.EngagedDifferentPlayer)
                        return False
        if self.combined_resource_cost:
            cost = FacesCounter.GetPrintedCost(targets)
            if (cost < self.combined_resource_cost[0]):
                return False
            if (cost > self.combined_resource_cost[1]):
                return False
        if self.combined_printed_cost:
            cost = FacesCounter.GetPrintedCost(targets)
            if (cost < self.combined_printed_cost[0]):
                return False
            if (cost > self.combined_printed_cost[1]):
                return False
        if self.combined_resource_icons:
            icon = FacesCounter.GetPrintedResourcesIcon(targets, 'Auto')
            if (icon < self.combined_resource_icons[0]):
                return False
            if (icon > self.combined_resource_icons[0]):
                return False
        return True
