# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from typing import TypeAlias
from core import *
from game.effect import *
from game.card.face import *
from game.selector import *
from game.message import *
from game.selector.selector_rule import SelectorRule
from game.selector.selector_where import SelectorWhere
from game.selector.selector_range import SelectorRange
CATEGORY_NAME = 'SELECTOR'
class SelectorTarget:
    __annotations__ = {}
    TARGET_TYPE = Literal[('This', 'DefendingCharacter', 'BoostForCard', 'DamageTarget', 'Attacker', 'Attacked', 'Attached', 'Initiator', 'Trigger', 'Targets', 'ToPlayer', 'PlayedCard', 'TeamUp', 'ThisAttachedHereCard', 'VillainAndEngagedSamePlayerMinion', 'VillainAndYouEngagedMinion', 'UsedToPayForThis')]
    TARGET_TYPE: TypeAlias
    TARGET_TYPE_HELPER = Literal[('Hero|Ally', 'Hero|Villain', 'Ally|Minion', 'Upgrade|Support', 'Ally|Support', 'Enemy|Scheme', 'Leader|Minion', 'Minion', 'Villain', 'EncounterSideScheme', 'MainScheme', 'PlayerSideScheme', 'Upgrade', 'Support', 'Attachment', 'Environment', 'Obligation', 'Identity', 'Ally', 'Hero', 'AlterEgo', 'StatusCard', 'Friend', 'Scheme2', 'YourSuitFormUpgrade', 'YourHeroTough', 'YourHandCards', 'YourLikeHandCards', 'TuckHereCard', 'TuckUnderYourIdentityCard', 'EnemyLeader', 'YourLeader')]
    TARGET_TYPE_HELPER: TypeAlias
    TARGET_TYPE_HELPER_LIST = Types.LiteralToList(TARGET_TYPE_HELPER)
    TARGET_TYPE_HELPER_LIST: List[TARGET_TYPE_HELPER]
    @staticmethod
    def IsHelpType(target):
        return (target in SelectorTarget.TARGET_TYPE_HELPER_LIST)
    def __init__(self, target, faces, get_targets_fn, from_where):
        from game.selector.selector_target_helper import TARGET_MAP_FUNC
        self.faces = faces
        self.get_targets_fn = get_targets_fn
        self.selector_where = SelectorWhere(from_where)
        self.raw_target = target
        if (target in TARGET_MAP_FUNC):
            if not ((self.get_targets_fn == None)):
                raise AssertionError
            self.get_targets_fn = TARGET_MAP_FUNC[target]
            return
    def GetForcedRangeRule(self):
        TARGET_MAP_RANGE = {'TeamUp': ((2, 2), 'DifferentCards'), 'VillainAndEngagedSamePlayerMinion': ('All', 'VillainAndMinionsEngagedSamePlayer'), 'VillainAndYouEngagedMinion': ('All', 'VillainAndMinionsEngagedWithYou')}
        if (self.raw_target in TARGET_MAP_RANGE):
            return TARGET_MAP_RANGE[self.raw_target]
    def GetAllTarget(self, effect, selector_range):
        found_faces = []
        if self.faces:
            found_faces = (found_faces + self.faces)
        from_where = self.selector_where.Get(effect, selector_range)
        if self.get_targets_fn:
            if self.selector_where.is_not_set:
                found_faces = (found_faces + self.get_targets_fn(effect))
            else:
                found_faces = (found_faces + [x for x in self.get_targets_fn(effect) if (x in from_where)])
        if (self.faces == None):
            if (self.get_targets_fn == None):
                found_faces = (found_faces + from_where)
        return found_faces
