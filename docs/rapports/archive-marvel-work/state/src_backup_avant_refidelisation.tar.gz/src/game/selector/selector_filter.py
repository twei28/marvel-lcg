# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.effect import *
from game.message import *
CATEGORY_NAME = 'SELECTOR'
class FilterArgs(TypedDict, total=False):
    __annotations__ = {}
    most_traits: bool
    highest_cost: bool
    lowest_cost: bool
    most_printed_res: bool
    engaged_with_fewest_minions: bool
    most_remaining_hp: bool
    fewest_remaining_hp: bool
    highest_printed_hp: bool
    highest_atk: bool
    lowest_atk: bool
    highest_printed_atk: bool
    lowest_printed_atk: bool
    highest_thw: bool
    lowest_thw: bool
    highest_sch: bool
    lowest_sch: bool
    least_threat: bool
    most_threat: bool
    lowest_order: bool
    highest_order: bool
class SelectorFilter:
    def __init__(self, finder, *, exclude = [], another = None, share_trait_with_your_hero = False, share_trait_with_your_identity = False, corresponding = None, **kwargs):
        from game.card.face.card_face import CardFace
        from game.operate.worlds import Worlds
        from game.operate.filter import Filter
        self.finder = finder
        self.check_effect_fns = []
        def filter_legal_targets(legal_faces, effect):
            from game.player import Player
            initiator = effect.initiator
            corresponding_face = None
            if (corresponding == 'ActiveVillain'):
                villain = Worlds.FindVillain(effect)
                if not (villain):
                    return []
                corresponding_face = villain.FindCorrespondingScheme()
            if not (share_trait_with_your_hero):
                if share_trait_with_your_identity:
                    if initiator.IsScenario():
                        return []
                    if share_trait_with_your_hero:
                        if isinstance(initiator, Player):
                            if not (initiator.IsHero()):
                                return []
            if initiator.IsScenario():
                return []
            if share_trait_with_your_hero:
                if isinstance(initiator, Player):
                    if not (initiator.IsHero()):
                        return []
            excludes = []
            if (exclude == 'This'):
                excludes = [effect.this]
            else:
                if (exclude == 'Trigger'):
                    if isinstance(effect.bind_message, TriggerMessage):
                        excludes = [effect.bind_message.trigger]
                else:
                    if (exclude == 'Attacker'):
                        if isinstance(effect.bind_message, AttackerMessageInternal):
                            attacker = effect.bind_message.attacker
                            if attacker:
                                excludes = [attacker]
                    else:
                        if (exclude == 'Targets'):
                            if isinstance(effect.bind_message, TargetsMessage):
                                excludes = list(effect.bind_message.targets)
                        else:
                            excludes = exclude
            exclude_cards = [face.card for face in excludes]
            legal_faces = [face for face in legal_faces if (face.card not in exclude_cards)]
            if not (share_trait_with_your_hero):
                if share_trait_with_your_identity:
                    if isinstance(initiator, Player):
                        identity = initiator.GetIdentity()
            if isinstance(initiator, Player):
                identity = initiator.GetIdentity()
            def filter_fn(face):
                if another:
                    if (face == effect.this):
                        return False
                if not (self.CheckFinder(face, effect)):
                    return False
                if not (share_trait_with_your_hero):
                    if share_trait_with_your_identity:
                        if not (face.ShareTrait(identity)):
                            return False
                if not (face.ShareTrait(identity)):
                    return False
                if (corresponding_face != None):
                    if (corresponding_face != face):
                        return False
                return True
            filter_faces = [face for face in legal_faces if filter_fn(face)]
            if not (filter_faces):
                return []
            filter_faces = Filter.All(*(filter_faces, CardFace), **{**kwargs})
            return filter_faces
        self.FilterLegalTargets = filter_legal_targets
    def CheckFinder(self, face, effect):
        if effect:
            for fn in self.check_effect_fns:
                if not (fn(effect, face)):
                    return False
        return ((not self.finder) or self.finder.Check(face, effect))
    @property
    def target_must_include_traits(self):
        if self.finder:
            return self.finder.traits
        return []
    @property
    def check_by_name(self):
        if self.finder:
            return (self.finder.check_by_name != [])
        return False
    def AddParameter(self, *, canbe_exhaust = None, canbe_ready = None, has_non_health = None, canbe_heal = None, check_effect_fn = None):
        from game.card.face.base import Unit2
        if not ((canbe_exhaust != None)):
            if not ((canbe_ready != None)):
                if not ((has_non_health != None)):
                    if not ((canbe_heal != None)):
                        if not ((check_effect_fn != None)):
                            raise AssertionError
        if (canbe_exhaust != None):
            self.check_effect_fns.append(lambda effect, face: (canbe_exhaust == face.CanExhaust()))
        if (canbe_ready != None):
            self.check_effect_fns.append(lambda effect, face: (canbe_ready == face.IsCanReadyBy(effect)))
        if (has_non_health != None):
            self.check_effect_fns.append(lambda effect, face: (Unit2.IsType(face) and (has_non_health == bool((face.health <= 0)))))
        if (canbe_heal != None):
            self.check_effect_fns.append(lambda effect, face: (Unit2.IsType(face) and (face.CanHeath() and (face.sustained >= canbe_heal))))
        if (check_effect_fn != None):
            self.check_effect_fns.append(check_effect_fn)
            return
