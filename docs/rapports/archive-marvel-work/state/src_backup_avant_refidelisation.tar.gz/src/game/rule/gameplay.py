# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.message import *
from game.deck import *
from cards.pack import *
from game.ability.factory import AbilityFactory
from engine.config import ConfigVariables
ALLOW_CUSTOM_SCRIPT = ConfigVariables.Bool('allow_custom_script', False)
def GetGamePlayRules():
    def try_shuffle_deck(effect: Effect, deck: Deck):
        if effect.world.is_game_started:
            if (deck.bind_discard_pile != None):
                if (deck.bind_discard_pile.GetSize() > 0):
                    if deck.flags.is_player_deck:
                        if not (deck.GetOwnerPlayer().is_eliminated):
                            deck.ShuffleWithDiscardPile(True, effect)
                    deck.ShuffleWithDiscardPile(True, effect)
            return
    def increase_kill_count(effect: Effect, message: Message.AfterUnitBeDefeated):
        if not ((message.killer != None)):
            raise AssertionError
        player = message.killer.GetControlByPlayer()
        player.stat.UpdateKillCounter(message.trigger.CastTo(Unit2))
    def custom_script(effect: Effect, message: Message.WhenGameWouldBegin):
        if not (ALLOW_CUSTOM_SCRIPT.value):
            return
    return [Ability(AbilityType.Rule, Message.WhenGameWouldBegin, [], custom_script), Ability(AbilityType.Rule, Message.AfterDeckRunOut, [], lambda effect, message: try_shuffle_deck(effect, message.deck)), AbilityFactory.AfterUnitBeDefeated(AbilityType.Rule, None, increase_kill_count, conditions=[lambda effect, message: ((message.killer != None) and (Player.IsType(message.killer.GetControlBy()) and (not message.IsByConsequential())))])]
