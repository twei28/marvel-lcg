# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.face import *
from game.ability import *
from game.message import *
class Buff:
    def __init__(self):
        self.name = type(self).__name__
        self.Reset()
    @final
    def Reset(self):
        self.by_effects = []
        self.text = ''
    def OnRoundEnd(self):
        pass
    def OnRecordPlayedFace(self, face: 'CardFace'):
        pass
    def SetUIText(self, text):
        self.text = text
    @final
    def GetText(self):
        if self.text:
            return self.text
        return str(len(self.by_effects))
    @final
    def OnGain(self, by_effect: 'Effect'):
        self.by_effects.append(by_effect)
    @final
    def OnLost(self, which_effect: 'Effect'):
        self.by_effects.remove(which_effect)
    def __bool__(self):
        return (self.by_effects != [])
class BuffIsTreatAsIfBlank(Buff):
    __doc__ = 'Except for traits'
class BuffCannotTakeDamage(Buff):
    pass
class BuffCannotBeConfused(Buff):
    pass
class BuffCannotBeStunned(Buff):
    pass
