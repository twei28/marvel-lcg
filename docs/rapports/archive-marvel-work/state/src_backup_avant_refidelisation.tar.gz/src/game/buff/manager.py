# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.world import *
from game.buff import *
class BuffManager:
    def __init__(self, world: World):
        self.buffers = []
    TB = TypeVar('TB', bound=Buff)
    def RegisterBuffer(self, type):
        buff = type()
        self.buffers.append(buff)
        return buff
    def OnRoundEnd(self):
        for buff in self.buffers:
            buff.OnRoundEnd()
    def OnRecordPlayedFace(self, face: CardFace):
        for buff in self.buffers:
            buff.OnRecordPlayedFace(face)
