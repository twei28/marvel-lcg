# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.world import *
from game.object import *
class Object:
    def __init__(self, category: 'ObjectManager.OBJECT_CATEGORY', world: 'World'):
        object_id = world.object_manager.AddObject(category, self)
        self.object_id = object_id
        self.object_category = category
        self.world = world
