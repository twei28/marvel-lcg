# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.object import Object
class ObjectManager:
    __annotations__ = {}
    OBJECT_CATEGORY = Literal[('card', 'effect', 'player', 'scenario', 'forced_effect', 'paying_effect', 'message', 'check_message', 'choose_effect', 'game_area', 'deck')]
    INIT_DICT = {'card': -1, 'effect': 0, 'message': 0, 'check_message': 0, 'player': 0, 'scenario': 0, 'forced_effect': 0, 'paying_effect': 0, 'choose_effect': 0, 'game_area': 0, 'deck': 0}
    INIT_DICT: Dict[(OBJECT_CATEGORY, int)]
    def __init__(self):
        from game.card import Card
        from game.effect import Effect
        from game.message import Message2
        self
        self.card_dict = {}
        self.effect_dict = {}
        self.paying_effect_dict = {}
        self.message_dict = {}
        self.ResetObjects()
    def AddObject(self, category, object):
        from game.card import Card
        from game.effect import Effect
        from game.message import Message2
        self.index_dict[category] = (self.index_dict[category] + 1)
        object_id = self.index_dict[category]
        if (category == 'card'):
            self.card_dict[object_id] = Cast(Card, object)
        if (category == 'effect'):
            self.effect_dict[object_id] = Cast(Effect, object)
        if (category == 'paying_effect'):
            self.paying_effect_dict[object_id] = Cast(Effect, object)
        if (category == 'message'):
            self.message_dict[object_id] = Cast(Message2, object)
        return object_id
    def ResetObjects(self):
        self.index_dict = ObjectManager.INIT_DICT.copy()
        self.card_dict = {}
        self.effect_dict = {}
        self.paying_effect_dict = {}
        self.message_dict = {}
    def ResetChooseEffect(self):
        self.index_dict['choose_effect'] = ObjectManager.INIT_DICT['choose_effect']
