# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from game.card.face import *
KEY_NAME = Literal[('damage_dealt', 'damage_taken', 'thwarted_threat', 'entered_play')]
KEY_NAME: TypeAlias
class SessionStatistics:
    def __init__(self):
        self.dic = {}
        self.DEFAULT_STATS = dict.fromkeys(get_args(KEY_NAME), 0)
    def Add(self, face, value, name):
        if not (PlayerCard.IsType(face)):
            return
        id = face.card.object_id
        stats = self.dic.setdefault(id, self.DEFAULT_STATS.copy())
        stats[name] = (stats[name] + value)
