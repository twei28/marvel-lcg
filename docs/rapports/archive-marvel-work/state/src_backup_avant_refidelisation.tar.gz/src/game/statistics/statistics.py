# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
@dataclass
class Statistics:
    __annotations__ = {}
    version = field(default='')
    version: str
    operation = field(default=0)
    operation: int
    crc = field(default='')
    crc: str
    took_damage = field(default=0)
    took_damage: int
    dealt_damage = field(default=0)
    dealt_damage: int
    healed_damage = field(default=0)
    healed_damage: int
    drawn_cards = field(default=0)
    drawn_cards: int
    removed_threats = field(default=0)
    removed_threats: int
    maximum_single_damage = field(default=0)
    maximum_single_damage: int
    maximum_single_took_damage = field(default=0)
    maximum_single_took_damage: int
    maximum_single_healing = field(default=0)
    maximum_single_healing: int
    maximum_single_draw = field(default=0)
    maximum_single_draw: int
    game_won = field(default=0)
    game_won: int
    game_lost = field(default=0)
    game_lost: int
    total_damage_taken = field(default=0)
    total_damage_taken: int
    total_damage_dealt = field(default=0)
    total_damage_dealt: int
    total_damage_healed = field(default=0)
    total_damage_healed: int
    total_cards_drawn = field(default=0)
    total_cards_drawn: int
    total_threats_removed = field(default=0)
    total_threats_removed: int
    max_single_damage_dealt = field(default=0)
    max_single_damage_dealt: int
    max_single_damage_taken = field(default=0)
    max_single_damage_taken: int
    max_single_damage_healed = field(default=0)
    max_single_damage_healed: int
    max_single_cards_drawn = field(default=0)
    max_single_cards_drawn: int
    max_phase_kill = field(default=0)
    max_phase_kill: int
    generate_resources_r = field(default=0)
    generate_resources_r: int
    generate_resources_b = field(default=0)
    generate_resources_b: int
    generate_resources_y = field(default=0)
    generate_resources_y: int
    generate_resources_g = field(default=0)
    generate_resources_g: int
    play_aspect_aggression = field(default=0)
    play_aspect_aggression: int
    play_aspect_justice = field(default=0)
    play_aspect_justice: int
    play_aspect_leadership = field(default=0)
    play_aspect_leadership: int
    play_aspect_protection = field(default=0)
    play_aspect_protection: int
    play_aspect_pool = field(default=0)
    play_aspect_pool: int
    play_basic_cards = field(default=0)
    play_basic_cards: int
    play_identity_specific = field(default=0)
    play_identity_specific: int
    engaged_minions = field(default=0)
    engaged_minions: int
    max_engaged_minions = field(default=0)
    max_engaged_minions: int
    run_out_of_deck = field(default=0)
    run_out_of_deck: int
    games_new = field(default=0)
    games_new: int
    games_won = field(default=0)
    games_won: int
    games_lost = field(default=0)
    games_lost: int
    achievement_first_blood = field(default=0)
    achievement_first_blood: int
    achievement_double_kill = field(default=0)
    achievement_double_kill: int
    achievement_triple_kill = field(default=0)
    achievement_triple_kill: int
    achievement_ultra_kill = field(default=0)
    achievement_ultra_kill: int
    achievement_rampage = field(default=0)
    achievement_rampage: int
    data = field(default_factory=lambda : {})
    data: Dict[(str, Tuple[(int, int, int)])]
    def UpdateVersion(self):
        attributes = [*(('game_won', 'games_won'), ('game_lost', 'games_lost'), ('took_damage', 'total_damage_taken'), ('dealt_damage', 'total_damage_dealt'), ('healed_damage', 'total_damage_healed'), ('drawn_cards', 'total_cards_drawn'), ('removed_threats', 'total_threats_removed'), ('maximum_single_damage', 'max_single_damage_dealt'), ('maximum_single_took_damage', 'max_single_damage_taken'), ('maximum_single_healing', 'max_single_damage_healed'), ('maximum_single_draw', 'max_single_cards_drawn'))]
        for attr, target in attributes:
            old_value = getattr(self, attr)
            if hasattr(self, attr):
                if (old_value > 0):
                    setattr(self, target, old_value)
            delattr(self, attr)
        crc = ''
        attr = 'crc'
        if hasattr(self, attr):
            crc = getattr(self, attr)
            delattr(self, attr)
        return crc
