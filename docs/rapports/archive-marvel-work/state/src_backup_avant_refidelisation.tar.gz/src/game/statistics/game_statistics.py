# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.face.card_face import CardFace
from game.player import *
from game.statistics.statistics import Statistics
from engine.lib import Json
from engine.lib import Ver
from engine.log import Log
from engine.log import Notify
from engine.file import FileManager
from engine.config import ConfigVariables
CATEGORY_NAME = 'STATISTICS'
GAME_STATISTICS_FILE = ConfigVariables.File('game_statistics_file', 'statistics.json')
STATISTICS = ConfigVariables.Bool('statistics', True)
class GameStatistics:
    __annotations__ = {}
    DATA_INFO = '<card_id>: [<resolve>, <play>, <reveal>, <defeated>]'
    DATA_INFO: Final
    def __init__(self):
        self
        self
        self
        self
        self.pause_internal = False
        self.file_broken = False
        if not (STATISTICS.value):
            self.pause_internal = True
            def DoNothing(*args, **kwargs):
                pass
            def ReturnFalse(*args, **kwargs):
                return False
            self.Copy = DoNothing
            self.Reset = DoNothing
            self.Save = DoNothing
            self.Load = DoNothing
            self.IsNew = ReturnFalse
            self.SetPause = DoNothing
            self.IsPause = ReturnFalse
            self.CanRegisterAbility = ReturnFalse
            self.content = Statistics()
            self.completion_rate = 0
            return
    def Copy(self):
        import copy
        self.content_copy = copy.deepcopy(self.content)
    def Reset(self):
        import copy
        self.content = copy.deepcopy(self.content_copy)
        Log.Debug(CATEGORY_NAME, 'GameStatistics reset')
    def Save(self):
        if (self.pause_internal == True):
            return
        if self.file_path:
            if not (self.file_broken):
                self.Copy()
                Json.Save(self.content, self.file_path, ignore_check_sum=False)
                Log.Info(CATEGORY_NAME, f'Saved: {self.file_path}')
                return
                return
    def Load(self):
        self.file_path = GAME_STATISTICS_FILE.value
        need_created = True
        if FileManager.Exists(self.file_path):
            # RECOVER_TODO SETUP_FINALLY arg=52 target=130
            statistics = Json.LoadAs(self.file_path, Statistics, check_sum='Restrict')
            crc = statistics.UpdateVersion()
            def check_version(crc):
                def crc_random(total_sum):
                    import hashlib
                    if (total_sum == 0):
                        return ''
                    def custom_random(seed, a, b):
                        return (a + (seed % ((b - a) + 1)))
                    total_sum = custom_random(total_sum, 0, 4294967296)
                    hash_object = hashlib.sha256(str(total_sum).encode())
                    return hash_object.hexdigest()
                def get_hash_v155(content):
                    flat_list = [sublist for sublist in content.data.values()]
                    total_sum = 0
                    total_sum = (total_sum + sum(flat_list))
                    total_sum = (total_sum + sum((getattr(content, f.name) for f in fields(Statistics) if (f.type == int))))
                    return crc_random(total_sum)
                def get_hash_v139(content, hack = False):
                    flat_list = [sublist for sublist in content.data.values()]
                    keys_list = [sublist for sublist in content.data.keys()]
                    total_sum = 0
                    total_sum = (total_sum + sum(flat_list))
                    total_sum = (total_sum + sum((int(key) for key in keys_list if key.isdigit())))
                    total_sum = (total_sum + sum((getattr(content, f.name) for f in fields(Statistics) if (f.type == int))))
                    return crc_random(total_sum)
                if not ((crc == get_hash_v155(statistics))):
                    if not ((crc == get_hash_v139(statistics))):
                        raise AssertionError
                        return
            if not (Ver(statistics.version).IsChecksum()):
                if crc:
                    check_version(crc)
            self.content = statistics
            need_created = False
            Log.Info(CATEGORY_NAME, f'{self.file_path} loaded')
        if need_created:
            if not (self.file_broken):
                Log.Info(CATEGORY_NAME, f'{self.file_path} created')
            self.content = Statistics()
            self.content.UpdateVersion()
        self.Copy()
        from cards.database import CardsDB
        self.completion_rate = (len(self.content.data) / len(CardsDB.papers))
    def RecordAchievement(self, player, name):
        if self.IsPause():
            return
        setattr(self.content, name, (getattr(self.content, name) + 1))
        text = f"Achievement: {name.lstrip('achievement_').upper()}"
        Notify.Statistics(text)
    def RecordValue(self, name, value):
        if self.IsPause():
            return
        setattr(self.content, name, (getattr(self.content, name) + value))
        text = f'{name} -> {getattr(self.content, name)} (+{value})'
        if (name != 'operation'):
            Notify.Statistics(text)
            return
    def RecordMaximum(self, name, value):
        if self.IsPause():
            return
        original_value = getattr(self.content, name)
        if (original_value < value):
            setattr(self.content, name, value)
            text = f'{name} -> {value}'
            Notify.Statistics(text)
            return
    def RecordCard(self, face, method):
        if self.IsPause():
            return
        card_id = face.paper.card_id
        if (card_id not in self.content.data):
            self.content.data[card_id] = (0, 0, 0)
            self.content.data = dict(sorted(self.content.data.items()))
        index = -1
        if (method == 'Resolve'):
            index = 0
        else:
            if (method in ('Play', 'Resource', 'Reveal', 'PutIntoPlay', 'Hero', 'Attached')):
                index = 1
            else:
                if (method in ('Defeated', 'Discard', 'Cancel', 'GameOver')):
                    index = 2
        if (index != -1):
            data = list(self.content.data[card_id])
            data[index] = (data[index] + 1)
            self.content.data[card_id] = tuple(data)
            Notify.Statistics(f'{card_id} {method} x{data[index]}')
            return
    def GetData(self, card_id):
        if (card_id in self.content.data):
            return self.content.data[card_id]
        return (0, 0, 0)
    def IsNew(self, card_id):
        if (self.pause_internal == True):
            return False
        return (card_id not in self.content.data)
    def SetPause(self, pause):
        if (self.pause_internal != pause):
            old_pause = self.pause_internal
            self.pause_internal = pause
            Log.Debug(CATEGORY_NAME, f'Pause: {old_pause} -> {pause}')
            return
    def IsPause(self):
        if isinstance(self.pause_internal, bool):
            return self.pause_internal
        from engine import Engine
        game = Engine.game
        if (self.pause_internal == 'WhenSkipping'):
            return game.controller_manager.skip.is_skipping
        return self.pause_internal
    def CanRegisterAbility(self):
        return (self.pause_internal != True)
