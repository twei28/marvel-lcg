# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face.base import *
from game.card.face import *
from game.message import *
from game.ability import *
from cards.paper import Paper
class Friend(Unit2):
    @override
    def __init__(self, paper: Paper):
        super().__init__(paper)
    def GetBasicPowerEffects(self, powers):
        powers_set = set(powers)
        return [x for x in self.effects if (x.ability.func_names & powers_set)]
