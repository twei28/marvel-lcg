# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasQuickstrike(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_quickstrike = 0
        super().__init__(paper)
        self.RegisterAttribute('Quickstrike', 'printed_quickstrike')
        self.RegisterInfoDict('quickstrike')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainQuickstrike(self.printed_quickstrike, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsQuickstrike(self):
        return (self.quickstrike > 0)
    @final
    @property
    def quickstrike(self):
        return self.GetKeyword('Quickstrike')
    @final
    def GainQuickstrike(self, diff, by_effect):
        self.GainKeyword(diff, 'Quickstrike', by_effect)
class CanQuickstrike(HasQuickstrike):
    @final
    def ResolveQuickstrike(self, player: Player):
        from game.effect.rule import Quickstrike
        from game.card.face.base import Enemy
        if self.IsInPlay():
            if self.IsQuickstrike():
                if player.IsHero():
                    effect = Quickstrike(self)
                    if Enemy.IsType(self):
                        self.DoAttackYou(player, effect)
                        return
                    if CanAttack.IsType(self):
                        self.BasicAttack([player.GetIdentity()], effect)
                        return
                        return
                        return
                        return
