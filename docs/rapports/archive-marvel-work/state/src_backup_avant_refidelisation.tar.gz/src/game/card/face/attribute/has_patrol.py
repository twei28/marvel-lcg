# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasPatrol(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_patrol = 0
        super().__init__(paper)
        self.RegisterAttribute('Patrol', 'printed_patrol')
        self.RegisterInfoDict('patrol')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainPatrol(self.printed_patrol, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsPatrol(self):
        return (self.patrol > 0)
    @final
    @property
    def patrol(self):
        return self.GetKeyword('Patrol')
    @final
    def GainPatrol(self, diff, by_effect):
        from game.card.face.card_type import Minion
        if not (Minion.IsType(self)):
            raise AssertionError
        self.ClearGuardPatrolEffectTargets()
        self.GainKeyword(diff, 'Patrol', by_effect)
        self.SetGuardPatrolEffectedBy(self.IsGuard(), self.IsPatrol())
