# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class CanAttach(CardFace):
    @override
    def __init__(self, paper: Paper):
        self.refers_to_the_villain_refers_to_attached = None
        super().__init__(paper)
    @override
    def OnBeforeFlip(self, by_effect, no_detach = False):
        super().OnBeforeFlip(by_effect, no_detach=no_detach)
        if self.bind_face:
            if self.IsInPlay():
                self.DetachFrom2(self.GetBindFace(), by_effect)
                return
                return
    @override
    def OnAfterFlip(self, by_effect, call_reveal = False):
        super().OnAfterFlip(by_effect, call_reveal=call_reveal)
        if self.IsFaceUp():
            if self.IsInPlay():
                if self.card.area.flags.is_upgrades:
                    if not (self.card.area.bind_card):
                        raise AssertionError
                    self.AttachTo2(self.card.area.bind_card.face, by_effect)
                    return
                    return
                    return
    @override
    def OnLeavedPlayEnd(self, by_effect: Effect):
        face = self.bind_face
        if face:
            self.DetachFrom2(face, by_effect)
        return super().OnLeavedPlayEnd(by_effect)
    def OnAttachTo(self, face, cause_by_flip):
        from game.message import Message
        self.card.state.is_attached = True
        message = Message.AfterCardGainUpgradeAbility(face, self)
        message.Send()
    def OnDetachFrom(self, face, by_flip):
        from game.message import Message
        message = Message.AfterCardLostUpgradeAbility(face, self, by_flip)
        message.Send()
        self.card.state.is_attached = False
    def AttachTo2(self, face, by_effect):
        from game.message import Message
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        if not (face.card.IsOnField()):
            return False
        self.refers_to_the_villain_refers_to_attached = None
        message = Message.WhenCardWouldAttachTo(self, face, by_effect)
        message.Send()
        if message.is_be_instead:
            return False
        if (self.bind_face == face):
            self.card.area.Remove(self.card)
            self.card.area.Append(self.card)
            return True
        if self.bind_face:
            self.DetachFrom2(self.bind_face, by_effect)
        if not (Faces.MoveAllTo([self], face.GetInventoryDeck(), GameRule(self))):
            if (self in face.GetInventoryDeck().GetAll()):
                if (self.bind_face == None):
                    self.card.area.UnMarkAsRemoved(self.card)
                    self.OnAttachTo(face, False)
                    gain_message = Message.AfterCardAttachTo(face, self, message)
                    gain_message.Send()
                    return True
        self.card.area.UnMarkAsRemoved(self.card)
        self.OnAttachTo(face, False)
        gain_message = Message.AfterCardAttachTo(face, self, message)
        gain_message.Send()
        return True
        Faces.DiscardAll([self], by_effect)
        return False
    @final
    def DetachFrom2(self, face, by_effect):
        from game.message import Message
        self.refers_to_the_villain_refers_to_attached = None
        if not (face.card.IsOnField()):
            return False
        if (self.card in self.card.area.removed_cards):
            return False
        if (self.bind_face == face):
            self.OnDetachFrom(face, False)
            self.card.area.MarkAsRemoved(self.card)
            lost_message = Message.AfterCardDetachFrom(face, self)
            lost_message.Send()
            return True
        return False
    @property
    def attached_face(self) -> CardFace|None:
        if not (self.card.state.is_attached):
            return
        return self.bind_face
    @property
    @override
    def bind_face(self) -> CardFace|None:
        if self.card.area.flags.is_encounter_deck:
            return
        if self.card.area.flags.is_encounter_discard_pile:
            return
        if (self.card.area.bind_card == None):
            return
        return self.card.area.bind_card.face
    @property
    def is_refers_to_the_villain_refers_to_attached(self):
        if (self.refers_to_the_villain_refers_to_attached == None):
            from game.message import Message
            message = Message.CheckIfRefersToTheVillainRefersToAttached(self)
            message.Send()
            self.refers_to_the_villain_refers_to_attached = message.refers_to
        return self.refers_to_the_villain_refers_to_attached
