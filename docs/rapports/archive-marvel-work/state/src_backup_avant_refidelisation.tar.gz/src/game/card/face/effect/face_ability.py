# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.message import *
class FaceAbility:
    def __init__(self, this: CardFace):
        self.face = this
        self.abilities = []
    @final
    def Add(self, *abilities: Ability):
        for ability in abilities:
            ability.paper = self.face.paper
            self.abilities.append(ability)
    @final
    def Find(self, *, func_name = None, name = None, type = None, label = None):
        abilities = []
        for ability in self.abilities:
            if (func_name != None):
                if not (ability.IsFunction(func_name)):
                    pass
            if (name != None):
                if (ability.name != name):
                    pass
            if (type != None):
                if not (ability.flags.IsType(type)):
                    pass
            if (label != None):
                if not (ability.IsLabel(label)):
                    pass
            abilities.append(ability)
        return abilities
