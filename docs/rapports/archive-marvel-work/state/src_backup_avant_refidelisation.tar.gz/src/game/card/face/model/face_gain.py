# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.buff import *
from game.effect import *
from game.player import *
from game.card.face.model.base import ModelBase
from game.element.resources import Resources
class ModelGain(ModelBase):
    @final
    def Gain(self, effect, diff, trait = None, teamwork = None, attack = None, defense = None, thwart = None, scheme = None, retaliate = None, restricted = None, hand_size = None, stalwart = None, health = None, considered_at_least_hp = None, recover = None, guard = None, steady = None, treat_as_blank = None, target_threat = None, quickstrike = None, patrol = None, amplify = None, crisis = None, ally_limit = None, flag = None, surge = None, hinder = None, control_additional_restricted = None, attack_consequential_damage = None, thwart_consequential_damage = None, consider_as = None, toughness = None, incite = None, acceleration_icon = None, hazard = None, peril = None, temporary = None, assault = None, have_res_icon = None, permanent = None, villainous = None, ignore_acceleration_icon = None, ignore_amplify = None, ignore_crisis = None, ignore_hazard = None, additional_cost_for_basic_attack = None, additional_cost_for_basic_thwart = None, additional_cost_for_basic_defend = None, base_sch = None, base_atk = None, base_health = None, abilities = None, buffs = None, apply = None):
        from game.card.face.attribute.has_hazard import HasHazard
        from game.card.face.attribute.has_amplify import HasAmplify
        from game.card.face.attribute.has_crisis import CanCrisis
        from game.card.face.attribute.can_attack import HasAttack
        from game.card.face.attribute.can_health import CanHealth
        from game.card.face.attribute.can_recover import HasRecover
        from game.card.face.attribute.can_retaliate import CanRetaliate
        from game.card.face.attribute.can_scheme import HasScheme
        from game.card.face.attribute.can_thwart import HasThwart
        from game.card.face.attribute.has_hand_size import HasHandSize
        from game.card.face.attribute.can_surge import CanSurge
        from game.card.face.attribute.can_hinder import CanHinder
        from game.card.face.attribute.has_acceleration_icon import HasAccelerationIcon
        from game.card.face.attribute.can_teamwork import CanTeamwork
        from game.card.face.attribute.can_incite import CanIncite
        from game.card.face.attribute.can_health import CanHealth
        from game.card.face.attribute.has_temporary import HasTemporary
        from game.card.face.attribute.has_permanent import HasPermanent
        from game.card.face.attribute.has_villainous import HasVillainous
        from game.card.face.attribute.has_restricted import HasRestricted
        from game.card.face.base import Unit2
        from game.card.face.base import EncounterNonVillainCard
        from game.card.face.base import Scheme2
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Minion
        from game.card.face.card_type import Hero
        from game.card.face.card_type import MainScheme
        from game.operate.worlds import Worlds
        unit = self.GetThis()
        if unit.card.state.is_advancing:
            return 0
        return_val = 0
        if (trait != None):
            unit.GainTraits(diff, trait, effect)
            return_val = (return_val + 1)
        if (teamwork != None):
            if CanTeamwork.IsType(unit):
                unit.GainTeamwork(diff, teamwork, effect)
                return_val = (return_val + 1)
        if (thwart != None):
            if HasThwart.IsType(unit):
                unit.GainThwart((thwart * diff), effect)
                return_val = (return_val + thwart)
        if (scheme != None):
            if HasScheme.IsType(unit):
                unit.GainScheme((scheme * diff), effect)
                return_val = (return_val + scheme)
        if (attack != None):
            if HasAttack.IsType(unit):
                unit.GainAttack((attack * diff), effect)
                return_val = (return_val + attack)
        if (defense != None):
            if Hero.IsType(unit):
                unit.GainDefense((defense * diff), effect)
                return_val = (return_val + defense)
        if (retaliate != None):
            if CanRetaliate.IsType(unit):
                unit.GainRetaliate((retaliate * diff), effect)
                return_val = (return_val + retaliate)
        if (restricted != None):
            if HasRestricted.IsType(unit):
                unit.GainRestricted((restricted * diff), effect)
                return_val = (return_val + restricted)
        if (hand_size != None):
            if HasHandSize.IsType(unit):
                unit.GainHandSize((hand_size * diff), effect)
                return_val = (return_val + hand_size)
        if (stalwart != None):
            if Unit2.IsType(unit):
                unit.GainStalwart((stalwart * diff), effect)
                return_val = (return_val + stalwart)
        if (health != None):
            if CanHealth.IsType(unit):
                if not (Unit2.IsType(unit)):
                    raise AssertionError
                if isinstance(health, int):
                    value = (health * diff)
                else:
                    if isinstance(health, str):
                        value = Worlds.ConvertPerPlayerIconToInt(health, effect)
                        health = value
                        value = (value * diff)
                    else:
                        health = health(effect)
                        value = (health * diff)
                if not (unit.card.state.is_leaving_play):
                    if (unit.health <= 0):
                        if effect.this.card.state.is_leaving_play:
                            pass
                        else:
                            if unit.card.state.is_defeating:
                                if not (unit.card.state.is_swapping_end):
                                    if (value <= 0):
                                        pass
                                    else:
                                        if unit.card.state.is_flipping:
                                            unit.GainOnlyMaxHealth(value, effect)
                                        else:
                                            unit.GainHealthAndMaxHealth(value, effect)
                                else:
                                    if unit.card.state.is_flipping:
                                        unit.GainOnlyMaxHealth(value, effect)
                                    else:
                                        unit.GainHealthAndMaxHealth(value, effect)
                            else:
                                if unit.card.state.is_flipping:
                                    unit.GainOnlyMaxHealth(value, effect)
                                else:
                                    unit.GainHealthAndMaxHealth(value, effect)
                    else:
                        if unit.card.state.is_defeating:
                            if not (unit.card.state.is_swapping_end):
                                if (value <= 0):
                                    pass
                                else:
                                    if unit.card.state.is_flipping:
                                        unit.GainOnlyMaxHealth(value, effect)
                                    else:
                                        unit.GainHealthAndMaxHealth(value, effect)
                            else:
                                if unit.card.state.is_flipping:
                                    unit.GainOnlyMaxHealth(value, effect)
                                else:
                                    unit.GainHealthAndMaxHealth(value, effect)
                        else:
                            if unit.card.state.is_flipping:
                                unit.GainOnlyMaxHealth(value, effect)
                            else:
                                unit.GainHealthAndMaxHealth(value, effect)
                if unit.card.state.is_defeating:
                    if not (unit.card.state.is_swapping_end):
                        if (value <= 0):
                            pass
                        else:
                            if unit.card.state.is_flipping:
                                unit.GainOnlyMaxHealth(value, effect)
                            else:
                                unit.GainHealthAndMaxHealth(value, effect)
                    else:
                        if unit.card.state.is_flipping:
                            unit.GainOnlyMaxHealth(value, effect)
                        else:
                            unit.GainHealthAndMaxHealth(value, effect)
                else:
                    if unit.card.state.is_flipping:
                        unit.GainOnlyMaxHealth(value, effect)
                    else:
                        unit.GainHealthAndMaxHealth(value, effect)
        if (considered_at_least_hp != None):
            if CanHealth.IsType(unit):
                unit.GainConsideredAtLeastHP((considered_at_least_hp * diff), effect)
                return_val = (return_val + considered_at_least_hp)
        if (recover != None):
            if HasRecover.IsType(unit):
                unit.GainRecover((recover * diff), effect)
                return_val = (return_val + recover)
        if (guard != None):
            if Minion.IsType(unit):
                unit.GainGuard((guard * diff), effect)
                return_val = (return_val + guard)
        if (steady != None):
            if Unit2.IsType(unit):
                unit.GainSteady((steady * diff), effect)
                return_val = (return_val + steady)
        if (treat_as_blank != None):
            unit.TreatAsIfBlankInternal(diff, effect)
            return_val = (return_val + treat_as_blank)
        if (target_threat != None):
            if MainScheme.IsType(unit):
                unit.GainTargetThreatValue((target_threat * diff), effect)
                return_val = (return_val + target_threat)
        if (quickstrike != None):
            if Minion.IsType(unit):
                unit.GainQuickstrike((quickstrike * diff), effect)
                return_val = (return_val + quickstrike)
        if (patrol != None):
            if Minion.IsType(unit):
                unit.GainPatrol((patrol * diff), effect)
                return_val = (return_val + patrol)
        if (amplify != None):
            if HasAmplify.IsType(unit):
                unit.GainAmplify((amplify * diff), effect)
                return_val = (return_val + amplify)
        if (crisis != None):
            if CanCrisis.IsType(unit):
                unit.GainCrisis((crisis * diff), effect)
                return_val = (return_val + crisis)
        if (surge != None):
            if CanSurge.IsType(unit):
                unit.GainSurge((surge * diff), effect)
                return_val = (return_val + surge)
        if (hinder != None):
            if CanHinder.IsType(unit):
                hinder = Worlds.ConvertPerPlayerIconToInt(hinder, effect)
                unit.GainHinder((hinder * diff), effect)
                return_val = (return_val + hinder)
        if (toughness != None):
            if Unit2.IsType(unit):
                unit.GainToughness((toughness * diff), effect)
                return_val = (return_val + toughness)
        if (incite != None):
            if CanIncite.IsType(unit):
                unit.GainIncite((incite * diff), effect)
                return_val = (return_val + incite)
        if (acceleration_icon != None):
            if HasAccelerationIcon.IsType(unit):
                unit.GainAccelerationIcon((acceleration_icon * diff), effect)
                return_val = (return_val + acceleration_icon)
        if (hazard != None):
            if HasHazard.IsType(unit):
                unit.GainHazard((hazard * diff), effect)
                return_val = (return_val + hazard)
        if (ally_limit != None):
            player = unit.GetControlByPlayer()
            player.limit_ally.Increase((ally_limit * diff), effect)
            return_val = (return_val + ally_limit)
        if (control_additional_restricted != None):
            player = unit.GetControlByPlayer()
            player.limit_restricted.Increase(diff, effect, control_additional_restricted)
            return_val = (return_val + 1)
        if (flag != None):
            player = unit.GetControlByPlayer()
            player.flag.Update(flag, diff)
        if (attack_consequential_damage != None):
            if Ally.IsType(unit):
                unit.GainAttackConsequentialDamage((attack_consequential_damage * diff), effect)
                return_val = (return_val + attack_consequential_damage)
        if (thwart_consequential_damage != None):
            if Ally.IsType(unit):
                unit.GainThwartConsequentialDamage((thwart_consequential_damage * diff), effect)
                return_val = (return_val + thwart_consequential_damage)
        if (peril != None):
            if EncounterNonVillainCard.IsType(unit):
                unit.GainPeril((peril * diff), effect)
                return_val = (return_val + peril)
        if (temporary != None):
            if HasTemporary.IsType(unit):
                unit.GainTemporary((temporary * diff), effect)
                return_val = (return_val + temporary)
        if (assault != None):
            if Scheme2.IsType(unit):
                unit.GainAssault((assault * diff), effect)
                return_val = (return_val + assault)
        if (have_res_icon != None):
            if HasResourceIcon.IsType(unit):
                unit.printed_resource_internal = (unit.printed_resource_internal + (Resources(have_res_icon) * diff))
                return_val = (return_val + 1)
        if (permanent != None):
            if HasPermanent.IsType(unit):
                unit.GainPermanent((permanent * diff), effect)
        if (villainous != None):
            if HasVillainous.IsType(unit):
                unit.GainVillainous((villainous * diff), effect)
        if (ignore_acceleration_icon != None):
            if HasAccelerationIcon.IsType(unit):
                unit.SetIgnoreAccelerationIcon((ignore_acceleration_icon * diff), effect)
                return_val = (return_val + ignore_acceleration_icon)
        if (ignore_amplify != None):
            if HasAmplify.IsType(unit):
                unit.SetIgnoreAmplify((ignore_amplify * diff), effect)
                return_val = (return_val + ignore_amplify)
        if (ignore_crisis != None):
            if CanCrisis.IsType(unit):
                unit.SetIgnoreCrisis((ignore_crisis * diff), effect)
                return_val = (return_val + ignore_crisis)
        if (ignore_hazard != None):
            if HasHazard.IsType(unit):
                unit.SetIgnoreHazard((ignore_hazard * diff), effect)
                return_val = (return_val + ignore_hazard)
        if (abilities != None):
            if (diff > 0):
                for ability in abilities:
                    unit.effect.RegisterGiven(ability)
            else:
                for ability in abilities:
                    unit.effect.UnRegisterGiven(ability)
        if (buffs != None):
            if (diff > 0):
                for buff in buffs:
                    unit.GetBuff(buff).OnGain(effect)
            else:
                for buff in buffs:
                    unit.GetBuff(buff).OnLost(effect)
        if (apply != None):
            apply(effect, unit, diff)
            return_val = (return_val + 1)
        if (consider_as != None):
            unit.SetConsiderAs(unit, diff, name=None, trait=consider_as[0], card_type=consider_as[1])
            return_val = (return_val + 1)
        if additional_cost_for_basic_attack:
            attack_effects = unit.effect.Find(func_name='ATK')
            for check_effect in attack_effects:
                if (diff > 0):
                    check_effect.cost_func.Add(additional_cost_for_basic_attack)
                if (diff < 0):
                    check_effect.cost_func.Del(additional_cost_for_basic_attack)
            return_val = (return_val + 1)
        if additional_cost_for_basic_thwart:
            thwart_effects = unit.effect.Find(func_name='THW')
            for check_effect in thwart_effects:
                if (diff > 0):
                    check_effect.cost_func.Add(additional_cost_for_basic_thwart)
                if (diff < 0):
                    check_effect.cost_func.Del(additional_cost_for_basic_thwart)
            return_val = (return_val + 1)
        if additional_cost_for_basic_defend:
            defend_effects = unit.effect.Find(func_name='DEF')
            for check_effect in defend_effects:
                if (diff > 0):
                    check_effect.cost_func.Add(additional_cost_for_basic_defend)
                if (diff < 0):
                    check_effect.cost_func.Del(additional_cost_for_basic_defend)
            return_val = (return_val + 1)
        if base_sch:
            if HasScheme.IsType(unit):
                unit.SetBaseScheme((base_sch * diff), effect)
                return_val = (return_val + base_sch)
        if base_atk:
            if HasAttack.IsType(unit):
                unit.SetBaseAttack((base_atk * diff), effect)
                return_val = (return_val + base_atk)
        if base_health:
            if CanHealth.IsType(unit):
                unit.SetBaseHealth((base_health * diff), effect)
                return_val = (return_val + base_health)
        return (return_val * diff)
    @final
    def FaceSet(self, effect, value, attack = None, scheme = None):
        from game.card.face.attribute.can_scheme import HasScheme
        from game.card.face.attribute.can_attack import HasAttack
        unit = self.GetThis()
        return_val = 0
        if (scheme != None):
            if HasScheme.IsType(unit):
                unit.GainScheme(((scheme * value) - unit.scheme), effect)
                return_val = (return_val + scheme)
        if (attack != None):
            if HasAttack.IsType(unit):
                unit.GainAttack(((attack * value) - unit.attack), effect)
                return_val = (return_val + attack)
        return (return_val * value)
