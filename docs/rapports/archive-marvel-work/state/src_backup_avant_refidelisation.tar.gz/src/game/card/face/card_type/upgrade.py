# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.message import *
from game.ability.factory import *
from game.player import *
from game.element.damage_property import DamageProperty
@final
class Upgrade(Asset2, HasModify, HasForm, HasRestricted, HasUses, HasHazard, CanCrisis, HasPermanent, HasTemporary, HasSetup, HasVictory, ClassCard, FinalType):
    @override
    def GetAbilities(self):
        abilities = []
        play_ability = None
        if not (self.ability.Find(func_name='Play')):
            play_ability = AbilityFactory.CanPlayThisUpgradeCard()
            abilities.append(play_ability)
        else:
            play_abilities = self.ability.Find(func_name='Play')
            if play_abilities:
                play_ability = play_abilities[0]
        if play_ability:
            if play_ability.selectors:
                if play_ability.selectors[0]:
                    def check_condition(effect, message):
                        for condition in play_ability.const_condition:
                            if not (condition(effect, message)):
                                return False
                        return True
                    abilities.append(AbilityFactory.AttachToFaceWhenPutIntoPlayInternal(play_ability.selectors[0], conditions=[check_condition]))
        return (abilities + super().GetAbilities())
    def GetControlByOrOwnerFace(self) -> CardFace:
        bind_card = self.card.area.bind_card
        if (bind_card == None):
            bind_card = self.card.area.GetOwner().GetRoleCharacter().card
        controller = bind_card.GetController()
        if controller:
            if not (controller.IsPlayer()):
                return self.GetOwnerPlayer().GetIdentity()
        return self.GetOwnerPlayer().GetIdentity()
        return bind_card.face
    @override
    def OnDealDamage(self, units, damage, by_effect, *, property = None, attack_in_event):
        if not ((by_effect != None)):
            raise AssertionError(f'self={self!r}')
        if not ((self == by_effect.this)):
            raise AssertionError(f'self={self!r} by_effect.this={by_effect.this!r}')
        identity = self.GetControlByOrOwnerFace()
        if identity.IsDefeated():
            return
        return identity.OnDealDamage(units, damage, by_effect, property=property, attack_in_event=attack_in_event)
    @override
    def OnRemoveSchemeThreat(self, schemes, value, by_effect):
        if not ((by_effect != None)):
            raise AssertionError(f'self={self!r}')
        if not ((self == by_effect.this)):
            raise AssertionError(f'self={self!r} by_effect.this={by_effect.this!r}')
        hero = self.GetControlByOrOwnerFace()
        return hero.OnRemoveSchemeThreat(schemes, value, by_effect)
    @override
    def CanAttachTo(self, face):
        if not (super().CanAttachTo(face)):
            return False
        play_abilities = self.ability.Find(func_name='Play')
        for ability in play_abilities:
            if not (ability.selectors):
                raise AssertionError
            if ability.selectors[0]:
                if ability.selectors[0].target_text:
                    if (ability.selectors[0].target_text != 'TeamUp'):
                        if not (isinstance(face, CardFinderHelper.GetTargetType(ability.selectors[0].target_text))):
                            return False
            if ability.selectors[0]:
                ability.selectors[0].selector_filter.CheckFinder(face, None)
                return
            return True
        return False
