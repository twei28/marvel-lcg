# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.message import *
from game.player import *
from game.deck import *
@final
class Leader(Villain, FinalType):
    pass
