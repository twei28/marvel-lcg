# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.effect import *
from game.card.face.model.base import ModelBase
class ModelTrait(ModelBase):
    def GetInfoTraits(self):
        info = {}
        for trait in self.traits_internal:
            if self.HasTrait(trait):
                text = trait.replace(' ', '_').replace('!', '')
                info = (info | {f't_{text}': len(self.traits_internal[trait])})
        return info
    def OnInitModel(self):
        self.ResetTrait()
        return super().OnInitModel()
    def OnResetModel(self):
        self.ResetTrait()
        return super().OnResetModel()
    @final
    def ResetTrait(self):
        this = self.GetThis()
        self.traits_internal = {}
        for trait in this.paper.traits:
            self.traits_internal[trait] = [this]
    @property
    def traits(self):
        return [x for x in self.traits_internal if (len(self.traits_internal[x]) > 0)]
    @property
    def traits_str(self):
        name = ''
        for trait in self.traits_internal:
            name = (name + (trait + ' '))
        return name
    @final
    def FindHasTrait(self, *traits):
        has_traits = []
        for trait in traits:
            if self.HasTrait(trait):
                has_traits.append(trait)
        return has_traits
    @final
    def HasTrait(self, *traits):
        this = self.GetThis()
        for trait in traits:
            if (trait in self.traits_internal):
                if not ((self.traits_internal[trait] != [])):
                    if this.IsConsiderAs(trait=trait):
                        return True
            if this.IsConsiderAs(trait=trait):
                return True
        return False
    @final
    def ShareTrait(self, face):
        return self.HasTrait(*list(face.traits_internal.keys()))
    @final
    def GetShareTraitNum(self, face):
        return len(self.GetShareTrait(face))
    @final
    def GetShareTrait(self, face):
        traits = []
        for trait in face.traits_internal:
            if self.HasTrait(trait):
                traits.append(trait)
        return traits
    @final
    def GainTraitInternal(self, diff, trait, by_effect):
        face = by_effect.this
        if (diff == 1):
            if (trait in self.traits_internal):
                self.traits_internal[trait].append(face)
                return
            self.traits_internal[trait] = [face]
            return
        if (diff == -1):
            self.traits_internal[trait].remove(face)
            if (self.traits_internal[trait] == []):
                del self.traits_internal[trait]
                return
            return
        raise AssertionError
    @final
    def GainTraits(self, diff, traits, by_effect):
        from game.message import Message
        this = self.GetThis()
        the_traits = []
        if isinstance(traits, list):
            the_traits = traits
        else:
            the_traits = [traits]
        for trait in the_traits:
            this.GainTraitInternal(diff, trait, by_effect)
        Message.WhenCardUpdateTrait_Text(this, diff, the_traits, by_effect)
    @final
    def CopyTrait(self, face: 'CardFace', by_effect: Effect):
        self.GainTraits(1, face.traits, by_effect)
    def GetTraitsTotalCount(self):
        value = 0
        for trait in self.traits:
            value = (value + len(self.traits_internal[trait]))
        return value
    def GetTraitsTotalCount2(self):
        return len(self.traits)
