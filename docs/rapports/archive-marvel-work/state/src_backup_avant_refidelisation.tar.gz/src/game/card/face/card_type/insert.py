# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.message import *
from game.player import *
@final
class Insert(FinalType):
    pass
@final
class Challenge(FinalType):
    @override
    def OnPutIntoPlay(self, message: Message.WhenCardPutIntoPlay) -> bool:
        from game.operate.faces import Faces
        world = self.card.world
        if Faces.MoveAllTo([self], world.area_rule, message.by_effect):
            return super().OnPutIntoPlay(message)
        return False
