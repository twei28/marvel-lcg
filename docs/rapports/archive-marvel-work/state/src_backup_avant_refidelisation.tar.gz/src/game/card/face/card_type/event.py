# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.deck import *
from game.ability import *
from game.message import *
from game.player import *
from cards.paper import Paper
from game.element.damage_property import DamageProperty
@final
class Event(HasTeamUp, HasAlliance, ClassCard, FinalType):
    @override
    def __init__(self, paper: Paper):
        super().__init__(paper)
    @override
    def OnAfterPlay(self, player: Player, by_effect: 'Effect', play_message: Message.WhenPlayerPlayCard, message: Message2, from_area: Deck):
        from game.operate.faces import Faces
        if self.IsInProcessingArea():
            Faces.DiscardAll([self], by_effect)
        super().OnAfterPlay(player, by_effect, play_message, message, from_area)
    @override
    def OnDealDamage(self, units, damage, by_effect, *, property = None, attack_in_event):
        if not ((self == by_effect.this)):
            raise AssertionError(f'self={self!r} by_effect.this={by_effect.this!r}')
        identity = by_effect.GetInitiator().GetIdentity()
        if identity.IsDefeated():
            return
        return identity.OnDealDamage(units, damage, by_effect, property=property, attack_in_event=attack_in_event)
    @override
    def OnRemoveSchemeThreat(self, schemes, value, by_effect):
        if not ((by_effect != None)):
            raise AssertionError(f'self={self!r}')
        if not ((self == by_effect.this)):
            raise AssertionError(f'self={self!r} by_effect.this={by_effect.this!r}')
        identity = by_effect.GetInitiator().GetIdentity()
        return identity.OnRemoveSchemeThreat(schemes, value, by_effect)
