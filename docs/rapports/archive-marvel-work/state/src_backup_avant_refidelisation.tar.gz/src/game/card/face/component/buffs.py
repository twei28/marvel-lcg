# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Buffs(Component):
    TB = TypeVar('TB', bound=Buff)
    @override
    def __init__(self, card: Card):
        super().__init__(card)
        self.buffers = {}
    def GetBuff(self, type):
        if (type not in self.buffers):
            self.buffers[type] = self.parent.world.buff_manager.RegisterBuffer(type)
        return Cast(type, self.buffers[type])
    def GetBuffs(self):
        return [self.buffers[x] for x in self.buffers]
