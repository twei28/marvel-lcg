# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class CanAttacked(CardFace):
    def TakeDamageWithOverkillTarget(self, source, property, by_effect, would_attack_unit_message = None, overkill_target = None, *, from_atk_message = None, operation = None):
        self.TakeDamage(source, property, by_effect, would_attack_unit_message, operation=operation)
        return []
    def TakeDamage(self, source, property, by_effect, would_attack_unit_message = None, *, operation = None):
        if isinstance(property, int):
            damage = property
        else:
            damage = property.damage
        if CanPlaceCounter.IsType(self):
            self.PlaceCountersInternal(damage, 'damage', by_effect)
            return
    def ResolveRetaliate(self, atk_message: Message.WhenUnitWouldAttackUnit):
        pass
    def DoAttackYou(self, against_player, by_effect, *, property = None, operation = None, if_no_character_takes_damage = None, you_cannot_play_event = False):
        pass
