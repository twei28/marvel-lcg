# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasIncite(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_incite = 0
        super().__init__(paper)
        self.RegisterAttribute('Incite', 'printed_incite')
        self.RegisterInfoDict('incite')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainIncite(self.printed_incite, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def GainIncite(self, diff, by_effect):
        self.GainKeyword(diff, 'Incite', by_effect)
    @final
    @property
    def incite(self):
        return self.GetKeyword('Incite')
class CanIncite(HasIncite):
    @final
    def ResolveIncite(self) -> Effect|None:
        from game.operate.worlds import Worlds
        if not (self.incite):
            return
        from game.effect.rule import Incite
        scheme = Worlds.FindMainScheme(self)
        if scheme:
            effect = Incite(self)
            scheme.PlaceThreatInternal(self.incite, effect)
            return effect
