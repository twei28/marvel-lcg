# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from game.card.face import *
from game.message import *
from cards.paper import Paper
@final
class Evidence(CanAttach, HasAttribute, FinalType):
    __annotations__ = {}
    SUBTYPE = Literal[('Opportunity', 'Motive', 'Means')]
    SUBTYPE: TypeAlias
    @override
    def __init__(self, paper: Paper):
        self
        super().__init__(paper)
        self.RegisterAttribute('Subtype', 'subtype', str)
    @override
    def CheckPrintedValue(self):
        if not ((self.subtype != None)):
            raise AssertionError
        return super().CheckPrintedValue()
    @override
    def OnWhenCardSetup(self, message: Message.WhenCardSetup):
        from game.effect.rule import GameRule
        if self.IsInDeck():
            self.PutIntoPlay('FirstPlayer', GameRule(self))
        return super().OnWhenCardSetup(message)
    @override
    def OnPutIntoPlay(self, message):
        from game.operate.faces import Faces
        world = self.card.world
        if not ((self.card.area == world.area_evidence)):
            if Faces.MoveAllTo([self], world.area_evidence, message.by_effect):
                return super().OnPutIntoPlay(message)
        return super().OnPutIntoPlay(message)
        return False
