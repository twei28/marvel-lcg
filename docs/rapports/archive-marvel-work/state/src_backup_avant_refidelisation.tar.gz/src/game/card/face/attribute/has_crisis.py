# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class CanCrisis(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_crisis = 0
        super().__init__(paper)
        self.RegisterAttribute('Crisis', 'printed_crisis')
        self.RegisterInfoDict('crisis')
    @override
    def OnWhenCardEnterPlay(self, message):
        if super().OnWhenCardEnterPlay(message):
            self.SetCrisisEffectedBy(self.IsCrisis())
            return True
        return False
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainCrisis(self.printed_crisis, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsCrisis(self):
        return (self.crisis > 0)
    @final
    @property
    def crisis(self):
        return self.GetKeyword('Crisis')
    @final
    def SetCrisisEffectedBy(self, diff, forced = False):
        from game.effect.rule import GameRule
        from game.operate.worlds import Worlds
        if (diff != 0):
            if not (self.IsInPlay()):
                if forced:
                    for scheme in Worlds.GetMainSchemes(self.card.game_area):
                        scheme.card.ui.SetEffectedBy(diff, GameRule(self))
            for scheme in Worlds.GetMainSchemes(self.card.game_area):
                scheme.card.ui.SetEffectedBy(diff, GameRule(self))
    @final
    def GainCrisis(self, diff, by_effect):
        self.GainKeyword(diff, 'Crisis', by_effect)
        self.SetCrisisEffectedBy(diff)
    @final
    def SetIgnoreCrisis(self, diff, by_effect):
        self.SetIgnoreKeyword(diff, 'Crisis', by_effect)
    @final
    def ClearCrisisEffectTargets(self):
        self.SetCrisisEffectedBy((-1 * self.IsCrisis()), forced=True)
    @override
    def OnLeaveGameArea(self, game_area: GameArea):
        self.ClearCrisisEffectTargets()
        return super().OnLeaveGameArea(game_area)
    @override
    def OnEnterGameArea(self, game_area: GameArea):
        self.ClearCrisisEffectTargets()
        return super().OnEnterGameArea(game_area)
    @override
    def OnAfterCardLeavePlay(self, message: Message.AfterCardLeavePlay):
        self.ClearCrisisEffectTargets()
        return super().OnAfterCardLeavePlay(message)
