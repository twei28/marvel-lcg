# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasAmplify(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_amplify = 0
        super().__init__(paper)
        self.RegisterAttribute('Amplify', 'printed_amplify')
        self.RegisterInfoDict('amplify')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainAmplify(self.printed_amplify, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    @property
    def amplify(self):
        return self.GetKeyword('Amplify')
    @final
    def GainAmplify(self, diff, by_effect):
        self.GainKeyword(diff, 'Amplify', by_effect)
    @final
    def SetIgnoreAmplify(self, diff, by_effect):
        self.SetIgnoreKeyword(diff, 'Amplify', by_effect)
    @final
    def ResolveAmplify(self, face: 'EncounterNonVillainCard'):
        from game.effect.rule import GameRule
        if self.amplify:
            face.GainBoostIcons(self.amplify, GameRule(self))
            return
