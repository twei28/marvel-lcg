# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasAttribute(CardFace):
    def __init__(self, paper: Paper):
        self.attributes = {}
        self.player_num = 0
        self.info_dict = []
        super().__init__(paper)
    def RegisterAttribute(self, key, attr, t = int):
        self.attributes = (self.attributes | {key: (attr, t)})
    def RegisterInfoDict(self, key):
        self.info_dict.append(key)
    def FormatPlayerNumValue(self, text):
        text = text.replace('*', f'*{self.player_num}')
        local_vars = {'val': 0}
        exec(f'val = int({text})', {}, local_vars)
        return local_vars['val']
    def SetPlayerNum(self, player_num):
        self.player_num = player_num
        self.info_dict.reverse()
    @final
    def InitPrintedValue(self, key, value):
        if (key == 'Linked'):
            return
        attr = self.attributes[key]
        name = attr[0]
        t = attr[1]
        if (name == None):
            return
        if isinstance(name, str):
            if (t is int):
                format_value = self.FormatPlayerNumValue(value)
                setattr(self, name, format_value)
                return
            if (t is bool):
                setattr(self, name, bool(int(value)))
                return
            if (t is str):
                setattr(self, name, value)
                return
            if (t is None):
                return
            raise AssertionError(f'{self.paper.card_id}, {attr}')
        name(value)
    def CheckPrintedValue(self):
        pass
    @override
    def GetInfoDict(self):
        dic = {}
        for key in self.info_dict:
            value = getattr(self, key)
            if isinstance(value, str):
                pass
            if isinstance(value, list):
                value = len(value)
            if (value == None):
                value = 0
            dic = (dic | {key: int(value)})
        return (dic | super().GetInfoDict())
