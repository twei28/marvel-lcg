# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.effect import *
from game.message import *
from game.message.message_type import HasEndEventMessage
class FaceEffect:
    def __init__(self, this: CardFace):
        self.face = this
        self.global_effects = []
        self.local_effects = []
        self.given_effects = []
    def GetAll(self):
        return ((self.global_effects + self.local_effects) + self.given_effects)
    @final
    def FindAbility(self, ability: Ability) -> Effect|None:
        effects = self.Find(name=ability.name, when=ability.when)
        if effects:
            return effects[0]
    @final
    def Find(self, *, name = None, func_name = None, label = None, type = None, when = None):
        effects = []
        for effect in self.GetAll():
            if (label != None):
                if not (effect.ability.IsLabel(label)):
                    pass
            if (func_name != None):
                if not (effect.ability.IsFunction(func_name)):
                    pass
            if (name != None):
                if not (effect.IsName(name)):
                    pass
            if (type != None):
                if not (effect.IsType(type)):
                    pass
            # RECOVER_TODO SETUP_FINALLY arg=15 target=132
            if (when != None):
                if not (issubclass(effect.ability.when, when)):
                    pass
            # RECOVER_TODO POP_EXCEPT arg=0 target=0
            effects.append(effect)
        return effects
    @final
    def UnRegisterGiven(self, ability: Ability):
        for effect in self.given_effects:
            if (effect.ability == ability):
                effect.UnRegisterSelf()
                return
        raise AssertionError
    @final
    def RegisterGiven(self, ability: Ability) -> Effect:
        effect = self.face.card.RegisterEffect(ability, self.face, world=self.face.card.world, is_temp=True)
        self.given_effects.append(effect)
        return effect
    @final
    def Registers(self, *abilities):
        effects = []
        for ability in abilities:
            effects.append(self.RegisterInternal(ability))
        return effects
    @final
    def RegisterInternal(self, ability: Ability) -> Effect:
        if ability.is_local:
            return self.RegisterLocalInternal(ability)
        effect = self.face.card.RegisterEffect(ability, self.face, world=self.face.card.world)
        self.global_effects.append(effect)
        return effect
    @final
    def RegisterLocalInternal(self, ability: Ability) -> Effect:
        effect = self.face.card.RegisterEffect(ability, self.face, is_local=True, world=self.face.card.world)
        self.local_effects.append(effect)
        return effect
    @final
    def RegisterTemp(self, *abilities, unregister_after_exec, until_turn_end = False, until_next_turn_end = False, until_phase_end = False, until_round_end = False, until_this_leave_play = False, until_event_end = None, until_resolve_effect = None):
        effects = []
        for ability in abilities:
            if ability.flags.is_delay_ability:
                if not ((unregister_after_exec == False)):
                    raise AssertionError
            effect = self.face.card.RegisterEffect(ability, self.face, is_temp=True, world=self.face.card.world)
            effect.SetDestroyedAfter(unregister_after_exec, until_turn_end=until_turn_end, until_next_turn_end=until_next_turn_end, until_phase_end=until_phase_end, until_round_end=until_round_end, until_this_leave_play=until_this_leave_play, until_after_event=until_event_end, until_after_resolve_effect=until_resolve_effect)
            effects.append(effect)
        self.global_effects = (self.global_effects + effects)
        return effects
