# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.ability.factory import *
from game.message import *
from game.player import *
from game.deck import *
from game.card.face.model.base import ModelBase
from game.element.damage_property import DamageProperty
from game.world.game_area import *
class ModelOnEvent(ModelBase):
    def OnWouldEnterPlay(self, into_area):
        return True
    def OnWhenCardWouldMoveToArea(self, message):
        message.Send()
        return (not message.cannot)
    def OnWhenCardWouldLeavePlay(self, message):
        message.Send()
        return (not message.is_be_instead)
    def OnWhenCardLeavePlay(self, message):
        message.Send()
        return True
    def OnLeavedPlayEnd(self, by_effect: Effect):
        pass
    def OnAfterCardLeavePlay(self, message: Message.AfterCardLeavePlay):
        from game.effect.rule import GameRule
        this = self.GetThis()
        rule = GameRule(this)
        this.card.components.OnAfterLeavePlay(rule)
        message.Send()
    def OnWhenCardWouldDiscard(self, message):
        message.Send()
        return True
    def OnAfterDestroy(self):
        pass
    def OnBeforeFlip(self, by_effect, no_detach = False):
        this = self.GetThis()
        this.card.components.OnBeforeFlip(by_effect, no_detach)
    def OnFlip(self, by_effect: Effect, origin_face: 'CardFace|None'):
        this = self.GetThis()
        this.card.ui.ResetEffectedBy()
        this.ResetKeywords()
        this.OnResetModel()
    def OnAfterFlip(self, by_effect, call_reveal = False):
        from game.effect.rule import GameRule
        from game.card.face.base import EncounterCard
        from game.card.face.card_type import MainScheme
        from game.card.face.base import Villain
        this = self.GetThis()
        this.card.components.OnAfterFlip(by_effect)
        if this.IsInPlay():
            this.ApplyAfterEnterPlay(this.card.area, this.card.area, GameRule(this), is_flip=True)
            this.card.state.is_swapping_end = False
            if this.IsFaceUp():
                if not (EncounterCard.IsType(this)):
                    if not (MainScheme.IsType(this)):
                        if Villain.IsType(this):
                            if call_reveal:
                                this.Reveal(None, GameRule(this), is_by_flipping=True)
                if call_reveal:
                    this.Reveal(None, GameRule(this), is_by_flipping=True)
    def OnWhenCardFlip(self, message: Message.WhenCardFlip):
        message.Send()
    def OnAfterCardFlip(self, message: Message.AfterCardFlip):
        message.Send()
    def OnDealDamage(self, units, damage, by_effect, *, property = None, attack_in_event):
        if not ((property == None)):
            raise AssertionError
        if not ((attack_in_event == False)):
            raise AssertionError
        this = self.GetThis()
        return this.DefaultDealDamageTo(this, units, damage, by_effect)
    def OnRemoveSchemeThreat(self, schemes, value, by_effect):
        this = self.GetThis()
        return this.DefaultRemoveSchemeThreat(this, schemes, value, by_effect)
    def OnResetKeywords(self, by_effect: Effect):
        this = self.GetThis()
        message = Message.WhenCardResetKeyword(this)
        message.Send()
    def OnLeaveGameArea(self, game_area: GameArea):
        pass
    def OnEnterGameArea(self, game_area: GameArea):
        this = self.GetThis()
        message = Message.GameAreaAddCard(this)
        message.Send()
    def OnWhenCardSetup(self, message: Message.WhenCardSetup):
        message.Send()
    @final
    def Setup(self, before_put_setup_cards):
        from game.message import Message
        this = self.GetThis()
        message = Message.WhenCardSetup(this, before_put_setup_cards)
        self.OnWhenCardSetup(message)
        return True
    def OnReset(self, message: Message.WhenCardReset_Text):
        message.Send()
    @final
    def Reset(self, is_flip):
        from game.message import Message
        this = self.GetThis()
        message = Message.WhenCardReset_Text(this, is_flip)
        this.card.ui.ResetEffectedBy()
        this.ResetKeywords()
        this.OnResetModel()
        if not (is_flip):
            this.card.components.OnReset()
        this.OnReset(message)
        return True
    def OnPutIntoPlay(self, message):
        message.Send()
        return True
    def OnAfterCardPutIntoPlay(self, message: Message.AfterCardPutIntoPlay):
        message.Send()
    @final
    def PutIntoPlay(self, player, by_effect, *, under_control = False, exhaust = False, target_game_area = None):
        from game.operate.faces import Faces
        this = self.GetThis()
        if by_effect.world.is_game_over:
            return False
        this.card.MoveToTop(this.card.area, by_effect)
        if (player == 'CurrentPlayer'):
            player = this.card.world.GetCurrentPlayer()
        else:
            if (player == 'FirstPlayer'):
                player = this.card.world.GetCurrentPlayer()
        if under_control:
            this.card.SetOwner(player)
        if not (this.IsFaceUp()):
            this.FlipTo(by_effect, face_up=True)
        from_area = this.card.area
        if exhaust:
            def action(effect: Effect, message: Message.WhenCardEnterPlay):
                Faces.ExhaustAll([message.trigger], effect)
            this.effect.RegisterTemp(AbilityFactory.WhenCardEnterPlay(AbilityType.Temp0, this, action), unregister_after_exec=True, until_phase_end=True)
        message = Message.WhenCardPutIntoPlay(this, player, from_area, by_effect, target_game_area)
        if not (this.OnPutIntoPlay(message)):
            return False
        message = Message.AfterCardPutIntoPlay(this, message)
        self.OnAfterCardPutIntoPlay(message)
        return True
    def OnWhenCardWouldReveal(self, message):
        message.Send()
        return True
    def OnPlayerRevealCard(self, message):
        message.Send()
        return True
    def OnWhenCardRevealed(self, revealed_message: Message.WhenCardRevealed):
        from game.card.face.attribute.can_incite import CanIncite
        from game.card.face.card_type import Treachery
        this = self.GetThis()
        if CanIncite.IsType(this):
            if not (this.card.world.rule.fix_treachery):
                if not (Treachery.IsType(this)):
                    effect = this.ResolveIncite()
                    if effect:
                        revealed_message.reveal_message.AddResolved(effect)
            effect = this.ResolveIncite()
            if effect:
                revealed_message.reveal_message.AddResolved(effect)
        if not (revealed_message.reveal_message.cancel_when_revealed):
            revealed_message.Send()
            return
    def OnAfterCardRevealedEnd(self, message: Message.AfterCardRevealedEnd):
        this = self.GetThis()
        reveal_message = message.reveal_message
        if (len(reveal_message.resolved) > 0):
            if message.revealed_message:
                after_message = Message.AfterCardRevealed(this, message.revealed_message)
                after_message.Send()
        message.Send()
    @final
    def Reveal(self, player, by_effect, *, is_by_flipping = False, if_no_entered_play = None, if_entered_play = None):
        from game.effect.rule import GameRule
        from game.message import Message
        from game.card.face.attribute.can_surge import CanSurge
        from game.card.face.card_type import MainScheme
        from game.operate.faces import Faces
        from game.operate.effects import Effects
        this = self.GetThis()
        world = this.card.world
        if (player == 'FirstPlayer'):
            player = world.GetFirstPlayer()
        else:
            if not (player):
                player = world.GetCurrentPlayer()
        from_area = this.card.area
        if not (this.IsInDeck()):
            if not (this.card.area.flags.is_discards):
                if this.card.area.flags.is_removed:
                    if not (this.card.area.flags.is_dealt_encounter):
                        if (this.card.area != world.main_schemes_deck):
                            Faces.MoveAllTo([this], player.dealt_encounter_cards, GameRule(this))
        if not (this.card.area.flags.is_dealt_encounter):
            if (this.card.area != world.main_schemes_deck):
                Faces.MoveAllTo([this], player.dealt_encounter_cards, GameRule(this))
        would_message = Message.WhenCardWouldReveal(this, player, by_effect, from_area, is_by_flipping)
        this.OnWhenCardWouldReveal(would_message)
        if would_message.is_be_instead:
            return
        if not (this.IsInPlay()):
            if not (this.card.area.flags.is_boost_area):
                this.Reset(False)
                if not (MainScheme.IsType(this)):
                    Faces.MoveAllTo([this], world.area_revealing, by_effect)
                    Message.AfterCardsMovedToRevealingArea_Text([this])
        if not ((this.card.state.is_revealing == False)):
            raise AssertionError
        this.card.state.is_revealing = True
        reveal_message = Message.WhenPlayerRevealCard(this, would_message)
        if not (this.OnPlayerRevealCard(reveal_message)):
            this.card.state.is_revealing = False
            return
        if reveal_message.is_be_instead:
            this.card.state.is_revealing = False
            return
        entered = False
        def set_enter_play():
            entered = True
        check_effects = this.effect.RegisterTemp(AbilityFactory.WhenCardEnterPlay(AbilityType.Temp0, None, lambda effect, message: set_enter_play(), conditions=[lambda effect, message: (self == message.trigger)]), unregister_after_exec=False)
        if not (reveal_message.cancel_all_effects):
            revealed_message = Message.WhenCardRevealed(this, reveal_message)
            this.OnWhenCardRevealed(revealed_message)
        else:
            revealed_message = None
        if not (reveal_message.cancel_all_effects):
            if CanSurge.IsType(this):
                effect = this.ResolveSurge(player)
                if effect:
                    reveal_message.AddResolved(effect)
            end_message = Message.AfterCardRevealedEnd(this, reveal_message, revealed_message)
            this.OnAfterCardRevealedEnd(end_message)
        this.card.state.is_revealing = False
        Effects.UnRegister(check_effects)
        if not (entered):
            if if_no_entered_play:
                if_no_entered_play()
        else:
            if if_entered_play:
                if_entered_play()
        if revealed_message:
            return revealed_message
        return reveal_message
    def OnWhenCardEnterPlay(self, message):
        this = self.GetThis()
        message.Send()
        if not (this.IsInPlay()):
            return False
        return True
    def OnAfterCardEnterPlay(self, message: Message.AfterCardEnterPlay):
        message.Send()
    @final
    def ApplyAfterEnterPlay(self, from_area, into_area, by_effect, is_flip):
        from game.message import Message
        this = self.GetThis()
        enter_play_message = Message.WhenCardEnterPlay(this, by_effect, is_flip=is_flip)
        if not (this.OnWhenCardEnterPlay(enter_play_message)):
            return
        after_message = Message.AfterCardEnterPlay(this, from_area, into_area, by_effect, enter_play_message)
        this.OnAfterCardEnterPlay(after_message)
    def OnDefeating(self, message: Message.WhenCardDefeating_Text):
        message.Send()
    def OnWouldDefeated(self, killer: 'CardFace|None', by_effect: Effect, being_message: Message.WhenSchemeBeingThwart|Message.WhenUnitBeingAttack|None) -> Message.WhenSchemeWouldBeDefeated|Message.WhenUnitWouldBeDefeated|None:
        pass
    def OnBeDefeated(self, would_defeated_message, *, as_asset, ignore_when_defeated):
        Unused(as_asset)
        Unused(ignore_when_defeated)
        this = self.GetThis()
        for face in this.GetInventoryDeck().GetAll():
            face.OnBeDefeated(would_defeated_message, as_asset=True, ignore_when_defeated=False)
    @final
    def Defeated(self, killer, by_effect, atk_message = None, *, ignore_when_defeated = False):
        would_defeat_message = self.CheckCanDefeated(killer, by_effect, atk_message)
        if would_defeat_message:
            self.WhenBeDefeated(would_defeat_message, ignore_when_defeated=ignore_when_defeated)
            return True
        return False
    @final
    def CheckCanDefeated(self, killer: 'CardFace|None', by_effect: Effect, atk_message: Message.WhenSchemeBeingThwart|Message.WhenUnitBeingAttack|None = None) -> Message.WhenUnitWouldBeDefeated|Message.WhenSchemeWouldBeDefeated|None:
        would_defeat_message = self.OnWouldDefeated(killer, by_effect, atk_message)
        if would_defeat_message:
            if not (would_defeat_message.is_be_instead):
                return would_defeat_message
    @final
    def WhenBeDefeated(self, defeat_message, *, ignore_when_defeated = False):
        from game.message import Message
        this = self.GetThis()
        this.card.state.is_defeating = True
        defeating_message = Message.WhenCardDefeating_Text(this)
        self.OnDefeating(defeating_message)
        self.OnBeDefeated(defeat_message, as_asset=False, ignore_when_defeated=ignore_when_defeated)
        this.card.state.is_defeating = False
    @final
    def OnBeforeSwapOld(self, by_effect, from_face, no_detach = False):
        this = self.GetThis()
        this.card.state.is_swapping_begin = True
        this.OnBeforeFlip(by_effect, no_detach=no_detach)
        this.card.state.is_swapping_begin = False
    @final
    def OnBeforeSwap(self, by_effect, to_face, no_detach = False):
        this = self.GetThis()
        this.card.state.is_swapping_begin = True
        this.OnBeforeFlip(by_effect, no_detach=no_detach)
        this.card.face = to_face
        this.card.face.card = this.card
        to_face.OnBeforeFlip(by_effect, no_detach=no_detach)
        this.card.state.is_swapping_begin = False
    @final
    def OnAfterSwap(self, by_effect, call_reveal = False):
        this = self.GetThis()
        this.OnFlip(by_effect, None)
        this.card.state.is_swapping_end = True
        this.OnAfterFlip(by_effect, call_reveal=call_reveal)
        this.card.state.is_swapping_end = False
