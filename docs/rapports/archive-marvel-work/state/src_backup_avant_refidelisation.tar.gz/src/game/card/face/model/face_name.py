# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.card.face.model.base import ModelBase
class ModelName(ModelBase):
    def SetName(self, printed_name):
        def extract_prefix(input_string):
            import re
            patterns = [*('(.*) - \\d?[A-F]$', '(.*) \\d?[A-F]$', '(.*) \\([^()]+\\)$')]
            for pattern in patterns:
                match = re.match(pattern, input_string)
                if match:
                    match.group(1)
                    return
            return input_string
        self.name = extract_prefix(printed_name)
        self.printed_name = printed_name
    def SetSubtitle(self, printed_subtitle):
        self.printed_subtitle = printed_subtitle
    @final
    def IsName(self, name, check_cosider_as = True, check_all_face = False):
        this = self.GetThis()
        if check_all_face:
            faces = ([this] + this.card.back_faces)
            for face in faces:
                if face:
                    if face.IsName(name, check_cosider_as):
                        return True
            return False
        if (name == this.printed_name):
            return True
        if (name == this.name):
            return True
        if (name == 'Ronan'):
            if (this.printed_name == 'Ronan the Accuser'):
                return True
        if this.IsCardId(name):
            return True
        if check_cosider_as:
            if this.IsConsiderAs(name=name):
                return True
        return False
    @final
    def IsUnique(self):
        this = self.GetThis()
        return this.paper.is_unique
    @final
    def IsCardId(self, name):
        this = self.GetThis()
        return (name == this.paper.card_id)
    @final
    def IsSubName(self, subname):
        this = self.GetThis()
        return (this.paper.subtitle == subname)
    @final
    def TitleContain(self, title_contain):
        this = self.GetThis()
        for name in ([this.name] + [x for x in this.consider_as.names]):
            if (title_contain in name):
                return True
        return False
    @final
    def CanCoexistWith(self, that):
        from game.card.face.card_type import Identity
        from game.card.face.card_type import Hero
        from game.card.face.card_type import AlterEgo
        this = self.GetThis()
        if not (that.IsUnique()):
            return True
        if not (this.IsUnique()):
            return True
        if (this == that):
            return True
        if not (this.card.IsApplyUniqueRule()):
            return True
        if not (that.card.IsApplyUniqueRule()):
            return True
        def get_titles(face):
            if not (Identity.IsType(face)):
                return set([face.name])
            names = set()
            for check_face in ([face] + face.card.back_faces):
                if Hero.IsType(check_face):
                    names.add(check_face.name)
            return names
        def get_subtitle(face):
            if not (Identity.IsType(face)):
                return face.printed_subtitle
            subtitle = ''
            for check_face in ([face] + face.card.back_faces):
                if AlterEgo.IsType(check_face):
                    subtitle = check_face.name
            if (subtitle in get_titles(face)):
                subtitle = ''
            return subtitle
        if (get_titles(this) & get_titles(that)):
            if (get_subtitle(this) == get_subtitle(that)):
                return False
        return True
    @final
    def GetDisplayName(self, *, no_hidden = False, no_object_id = False):
        this = self.GetThis()
        if no_object_id:
            object_id = 0
        else:
            object_id = '{:02}'.format(this.card.object_id)
        if this.card.IsAsOtherCard():
            id = f'({object_id},{this.paper.card_id},{this.card.printed_faces[0].paper.card_id}) '
        else:
            id = f'({object_id},{this.paper.card_id}) '
        hidden = ''
        if not (no_hidden):
            if not (this.card.IsVisible('Any')):
                hidden = ' ?'
        return '[{}{}{}]'.format(id, self.name, hidden)
