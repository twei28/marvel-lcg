# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.effect import *
from game.message import *
from game.card.face.model.base import ModelBase
from game.buff import *
class ModelTreatBlank(ModelBase):
    def OnResetModel(self):
        self.ResetTreatBlank()
        return super().OnResetModel()
    @final
    def ResetTreatBlank(self):
        this = self.GetThis()
        this.GetBuff(BuffIsTreatAsIfBlank).Reset()
    def OnNotTreatAsIfBlank(self, message: Message.WhenCardTreatAsIfBlank):
        message.Send()
    def OnBeTreatAsIfBlank(self, message: Message.WhenCardTreatAsIfBlank):
        message.Send()
    @final
    def TreatAsIfBlankInternal(self, diff, by_effect):
        from game.message import Message
        this = self.GetThis()
        would_message = Message.WhenCardWouldTreatAsIfBlank(this, by_effect)
        would_message.Send()
        if would_message.is_be_instead:
            return
        if (diff == 1):
            this.GetBuff(BuffIsTreatAsIfBlank).OnGain(by_effect)
        else:
            this.GetBuff(BuffIsTreatAsIfBlank).OnLost(by_effect)
        this.card.ui.SetEffectedBy(diff, by_effect)
        message = Message.WhenCardTreatAsIfBlank(this, by_effect)
        if not (this.is_treat_as_if_blank):
            this.OnNotTreatAsIfBlank(message)
            return
        this.OnBeTreatAsIfBlank(message)
    @property
    @final
    def is_treat_as_if_blank(self):
        this = self.GetThis()
        return bool(this.GetBuff(BuffIsTreatAsIfBlank))
