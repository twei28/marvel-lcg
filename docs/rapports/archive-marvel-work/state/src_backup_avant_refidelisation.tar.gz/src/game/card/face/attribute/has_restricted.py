# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasRestricted(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_restricted = 0
        super().__init__(paper)
        self.RegisterAttribute('Restricted', 'printed_restricted')
        self.RegisterInfoDict('restricted')
    def CheckRestrictedLimit(self, gain_faces):
        player = self.GetControlByPlayer()
        return player.limit_restricted.CheckLimit(gain_faces)
    @override
    def OnNotTreatAsIfBlank(self, message: Message.WhenCardTreatAsIfBlank):
        if self.restricted:
            self.CheckRestrictedLimit([])
        return super().OnNotTreatAsIfBlank(message)
    @override
    def OnWouldEnterPlay(self, into_area):
        if super().OnWouldEnterPlay(into_area):
            if self.restricted:
                if not (self.CheckRestrictedLimit([self])):
                    return False
            return True
        return False
    @override
    def OnAfterCardLeavePlay(self, message: Message.AfterCardLeavePlay):
        player = message.from_area.GetOwner()
        if Player.IsType(player):
            player.limit_restricted.CheckLimit([])
        return super().OnAfterCardLeavePlay(message)
    @override
    def OnAfterCardFlip(self, message: Message.AfterCardFlip):
        face = message.to_face
        if face:
            if HasRestricted.IsType(face):
                if face.restricted:
                    self.CheckRestrictedLimit([])
        super().OnAfterCardFlip(message)
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainRestricted(self.printed_restricted, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def GainRestricted(self, diff, by_effect):
        self.GainKeyword(diff, 'Restricted', by_effect)
        if (diff > 0):
            self.CheckRestrictedLimit([])
            return
    @final
    @property
    def restricted(self):
        return self.GetKeyword('Restricted')
