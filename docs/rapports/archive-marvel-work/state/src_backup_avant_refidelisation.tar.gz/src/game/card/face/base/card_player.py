# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from game.card.face.base import *
from game.card.face import *
from game.deck import *
from game.ability import *
from game.ability.factory import *
from game.message import *
from game.player import *
from cards.paper import Paper
from game.element.resources import Resources
class PlayerCard(CanSurge, CanAccelerationToken, CardFace):
    pass
class ClassCard(HasResourceIcon, HasCost, HasMaxPer, PlayerCard):
    __annotations__ = {}
    ASPECT_CLASS_TYPE = Literal[('Aggression', 'Justice', 'Leadership', 'Protection', "'Pool")]
    ASPECT_CLASS_TYPE: TypeAlias
    CARD_CLASS = Literal[('Aggression', 'Justice', 'Leadership', 'Protection', "'Pool", 'Basic', 'IdentitySpecific', 'Encounter', 'Campaign', 'Aspect')]
    CARD_CLASS: TypeAlias
    DECK_BUILDING_CLASS = Literal[('Cyclops', 'Domino')]
    DECK_BUILDING_CLASS: TypeAlias
    @override
    def __init__(self, paper: Paper):
        self.max_per_deck = 3
        self.card_classes = []
        self
        super().__init__(paper)
        self.RegisterAttribute('MaxPerDeck', 'max_per_deck')
        self.RegisterAttribute('UnitCost', None)
        def parse(value):
            from game.element.utility import IsCardClass
            from game.element.utility import IsAspectClass
            self.card_classes = []
            card_classes = value.split(';')
            for card_class in card_classes:
                if (card_class == 'Hero'):
                    card_class = 'IdentitySpecific'
                if not (IsCardClass(card_class)):
                    raise AssertionError
                self.card_classes.append(card_class)
            for card_class in self.card_classes:
                if IsAspectClass(card_class):
                    self.card_classes.append('Aspect')
                    return
        self.RegisterAttribute('Class', parse)
    @override
    def GetAbilities(self):
        abilities = []
        resources_abilities = self.ability.Find(func_name='CanGenerateResources')
        if not ((len(resources_abilities) <= 1)):
            raise AssertionError
        if resources_abilities:
            if not (self.ability.Find(func_name='DoGenerateResources')):
                abilities.append(AbilityFactory.DoGenerateResources(resources_abilities[0].second_type, 'This', ex_operation=resources_abilities[0].generate_resources_ex_operation))
        if not (self.ability.Find(func_name='CheckThisCanDropPay')):
            abilities.append(AbilityFactory.CheckThisCanDropPay())
        if not (self.ability.Find(func_name='DiscardPay')):
            abilities.append(AbilityFactory.DoDiscardThisToGenerateResources(AbilityType.DiscardForResource))
        return (abilities + super().GetAbilities())
    @override
    def CheckPrintedValue(self):
        if not ((self.card_classes != [])):
            raise AssertionError(f'self.paper.card_id={self.paper.card_id!r}')
        return super().CheckPrintedValue()
    def OnAfterPlay(self, player: Player, by_effect: Effect, play_message: Message.WhenPlayerPlayCard, message: Message2, from_area: Deck):
        from game.message import Message
        played_message = Message.AfterPlayerPlayedCard(player, self, by_effect, play_message, message, from_area)
        played_message.Send()
        by_effect.world.stat.RecordPlayedCard(player, self)
    def Play(self, player, by_effect, message, resource, from_area, is_like_from_hand):
        from game.message import Message
        from game.operate.faces import Faces
        if not (self.card.area.flags.is_processing):
            raise AssertionError
        by_effect.context.paid_this_resources = resource
        by_effect.this.CastTo(HasCost).SetPaidResources(resource)
        if not ((by_effect.GetInitiator() == player)):
            raise AssertionError(f'{self.card.face} player={player!r}')
        if not (by_effect.ProcessSelfCost()):
            Faces.DiscardAll([self], by_effect)
            return False
        would_play_message = Message.WhenPlayerWouldPlayCard(player, by_effect, resource, from_area, is_like_from_hand)
        would_play_message.Send()
        def discard():
            if self.IsInProcessingArea():
                Faces.DiscardAll([self], by_effect)
                return
        if not (would_play_message.is_be_instead):
            play_message = Message.WhenPlayerPlayCard(player, would_play_message)
            play_message.Send()
            if would_play_message.be_cancel:
                pass
            else:
                by_effect.ResolveSelf(message, by_effect, to_player=player, skip_cost=True)
        discard()
        return False
    def IsClass(self, *card_classes):
        for card_class in self.card_classes:
            if (card_class in card_classes):
                return True
        return False
    def IsDeckBuildingClass(self, deck_building_class):
        if not (self.IsClass('IdentitySpecific')):
            return False
        if (self.paper.set_name != deck_building_class):
            return False
        return True
    def GetAspect(self) -> 'ClassCard.ASPECT_CLASS_TYPE|None':
        from game.element.utility import IsAspectClass
        for card_class in self.card_classes:
            if IsAspectClass(card_class):
                card_class
                return
