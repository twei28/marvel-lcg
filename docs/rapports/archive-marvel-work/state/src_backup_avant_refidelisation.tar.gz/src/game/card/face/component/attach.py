# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class PlacedCard(Component):
    @override
    def __init__(self, card: Card):
        super().__init__(card)
        self.deck = Deck2(self.parent, DeckType.PlaceCardArea, CardFace)
    @override
    def OnParentLeavePlay(self, by_effect: Effect):
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        super().OnParentLeavePlay(by_effect)
        Faces.DiscardAll(self.GetDeck().Get(), GameRule(self.parent.face))
    @override
    def OnDiscard(self, by_effect):
        return (self.deck.GetAll() + super().OnDiscard(by_effect))
    def GetDeck(self) -> Deck2[CardFace]:
        return self.deck
