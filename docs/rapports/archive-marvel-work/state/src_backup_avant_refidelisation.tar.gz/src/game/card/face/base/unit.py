# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from game.card.face.base import *
from game.card.face import *
from game.deck import *
from game.ability import *
from game.message import *
class Unit2(CanHealth, CanRetaliate, CanStatus, CanPlaceCounter, CanPlaceToken):
    @override
    def OnWouldEnterPlay(self, into_area):
        from game.effect.rule import ResetKeyword
        self.ResetHealth(ResetKeyword(self))
        return super().OnWouldEnterPlay(into_area)
    @override
    def OnAfterCardEnterPlay(self, message: Message.AfterCardEnterPlay):
        from game.effect.rule import GameRule
        super().OnAfterCardEnterPlay(message)
        if (self.health <= 0):
            if self.IsInPlay():
                if not (self.card.state.is_discarding):
                    self.Death(None, GameRule(self))
                    return
                    return
                    return
    @override
    def OnWouldDefeated(self, killer: CardFace|None, by_effect: 'Effect', being_message: Message.WhenSchemeBeingThwart|Message.WhenUnitBeingAttack|None) -> Message.WhenSchemeWouldBeDefeated|Message.WhenUnitWouldBeDefeated|None:
        if not (isinstance(being_message, (Message.WhenUnitBeingAttack | None))):
            raise AssertionError
        would_message = Message.WhenUnitWouldBeDefeated(self.card.face.CastTo(Unit2), by_effect, killer, being_message)
        would_message.Send()
        return would_message
    @override
    def OnBeDefeated(self, would_defeated_message, *, as_asset, ignore_when_defeated):
        from game.card.face.base import Villain
        from game.card.face.card_type import Identity
        from game.operate.faces import Faces
        from game.effect.rule import GameRule
        being_message = would_defeated_message.being_message
        by_effect = GameRule(self, being_message)
        killer = would_defeated_message.killer
        if not (isinstance(would_defeated_message, Message.WhenUnitWouldBeDefeated)):
            raise AssertionError
        if self.bind_face:
            if as_asset:
                Faces.DiscardAll([self], by_effect)
                return
        if (being_message != None):
            if not ((type(being_message) is Message.WhenUnitBeingAttack)):
                raise AssertionError
        defeated_message = Message.WhenUnitBeDefeated(self, would_defeated_message, ignore_when_defeated)
        defeated_message.Send()
        super().OnBeDefeated(would_defeated_message, as_asset=as_asset, ignore_when_defeated=ignore_when_defeated)
        if self.card.area.flags.is_in_play:
            if self.card.area.flags.is_upgrades:
                if (self.paper.card_id != '40199'):
                    if not (Villain.IsType(self)):
                        if not (Identity.IsType(self)):
                            Faces.DiscardAll([self], by_effect)
            if not (Villain.IsType(self)):
                if not (Identity.IsType(self)):
                    Faces.DiscardAll([self], by_effect)
        after_defeated_message = Message.AfterUnitBeDefeated(self, killer, being_message, would_defeated_message)
        after_defeated_message.Send()
    def CanBeAttackBy(self, effect):
        from game.card.face.base import Enemy
        if Enemy.IsType(self):
            check_message = Message.CheckIfUnitCanBeAttackBy(self, effect)
            check_message.Send()
            return check_message.can_be_attack
        return True
    @final
    def Death(self, killer, by_effect, atk_message = None, *, ignore_when_defeated = False):
        from game.card.face.card_type import Event
        if Event.IsType(killer):
            killer = killer.GetControlByPlayer().GetIdentity()
        if atk_message:
            return UNKNOWN(UNKNOWN, UNKNOWN, atk_message.being_atk_message, ignore_when_defeated=ignore_when_defeated)
        return self.Defeated(killer, by_effect, None, ignore_when_defeated=ignore_when_defeated)
    def GainForThisActive(self, by_effect, active_message, *, attack = None, defense = None, scheme = None, thwart = None, recover = None, attack_consequential_damage = None, thwart_consequential_damage = None, ignore_flip = True, render_ui = True):
        return self.TemporaryGain(by_effect, active_message, attack=attack, defense=defense, scheme=scheme, thwart=thwart, recover=recover, attack_consequential_damage=attack_consequential_damage, thwart_consequential_damage=thwart_consequential_damage, ignore_flip=ignore_flip, render_ui=render_ui)
