# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class CanBoost(CardFace):
    def GetBoostCardNum(self, message):
        raise AssertionError(f'You have to over write this function, self={self!r}')
    def GiveFacedownBoostCardsInternal(self, num, by_effect, would_atk_message):
        from game.card.face.card_type import Minion
        from game.card.face.base import Villain
        def process(face: CardFace):
            self.GiveBoostCard(face, by_effect, would_atk_message)
        from game.operate.worlds import Worlds
        Worlds.PopEncounterCards(num, process, True, by_effect)
        Message.AfterUnitGainFaceDownBoostCards_Text(self.card.CastTo((Minion | Villain)), num, by_effect)
    def GiveBoostCard(self, face: CardFace, by_effect: Effect, would_atk_message: Message.WhenUnitWouldAttack|Message.WhenUnitWouldScheme|None = None):
        from game.card.face.card_type import Minion
        from game.card.face.base import Villain
        face.card.visible.Update()
        self.components.boostable.GiveBoostCard(face, by_effect)
        message = Message.AfterEnemyGivenBoostCard(self.card.CastTo((Minion | Villain)), face, by_effect, would_atk_message)
        message.Send()
    def ResolveBoostCards(self, message, call_back):
        from game.message import Message
        from game.card.face.base import EncounterNonVillainCard
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        from game.operate.worlds import Worlds
        world = self.card.world
        if (self.components.boostable.GetDeck().GetSize() != 0):
            face = self.components.boostable.GetDeck().GetTop()
            if not (face):
                raise AssertionError
            if world.is_game_over:
                return
            would_flip_message = Message.WhenBoostCardWouldTurnedFaceUp(face, message)
            would_flip_message.Send()
            if would_flip_message.is_be_instead:
                pass
            Faces.MoveAllTo([face], world.area_boosting, GameRule(face))
            Message.AfterCardsMovedToBoostingArea_Text([face])
            if not (EncounterNonVillainCard.IsType(face)):
                if face.effect.Find(type=AbilityType.WhenRevealed):
                    if EncounterNonVillainCard.IsType(face):
                        for amplify_face in Worlds.GetAmplifyFaces(self.card.game_area):
                            amplify_face.ResolveAmplify(face)
                    flip_message = Message.WhenBoostCardTurnedFaceUp(face, message)
                    flip_message.Send()
                    become_message = Message.WhenCardBecomeBoost(face, flip_message)
                    become_message.Send()
                    if EncounterNonVillainCard.IsType(face):
                        if flip_message.cancel_boost_icons:
                            boost_icons = 0
                        else:
                            boost_icons = face.CountBoostIconsInternal()
            if EncounterNonVillainCard.IsType(face):
                for amplify_face in Worlds.GetAmplifyFaces(self.card.game_area):
                    amplify_face.ResolveAmplify(face)
            flip_message = Message.WhenBoostCardTurnedFaceUp(face, message)
            flip_message.Send()
            become_message = Message.WhenCardBecomeBoost(face, flip_message)
            become_message.Send()
            if EncounterNonVillainCard.IsType(face):
                if flip_message.cancel_boost_icons:
                    boost_icons = 0
                else:
                    boost_icons = face.CountBoostIconsInternal()
        if not ((self.components.boostable.GetDeck().GetSize() == 0)):
            raise AssertionError(f'self.components.boostable.GetDeck().Get()={self.components.boostable.GetDeck().Get()!r}')
