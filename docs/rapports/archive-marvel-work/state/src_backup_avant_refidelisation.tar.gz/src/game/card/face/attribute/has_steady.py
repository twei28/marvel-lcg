# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasSteady(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_steady = 0
        super().__init__(paper)
        self.RegisterAttribute('Steady', 'printed_steady')
        self.RegisterInfoDict('steady')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainSteady(self.printed_steady, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsSteady(self):
        return (self.steady > 0)
    @final
    @property
    def steady(self):
        return self.GetKeyword('Steady')
    @final
    def GainSteady(self, diff, by_effect):
        self.GainKeyword(diff, 'Steady', by_effect)
