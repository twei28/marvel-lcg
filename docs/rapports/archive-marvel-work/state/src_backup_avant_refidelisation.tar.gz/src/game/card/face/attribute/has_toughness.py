# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasToughness(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_toughness = 0
        super().__init__(paper)
        self.RegisterAttribute('Toughness', 'printed_toughness')
        self.RegisterInfoDict('toughness')
    @override
    def OnWhenCardEnterPlay(self, message):
        from game.effect.rule import Toughness
        from game.operate.faces import Faces
        if super().OnWhenCardEnterPlay(message):
            if self.IsToughness():
                Faces.GiveStatus([self], 'Tough', Toughness(self))
            return True
        return False
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainToughness(self.printed_toughness, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsToughness(self):
        return (self.toughness > 0)
    @final
    @property
    def toughness(self):
        return self.GetKeyword('Toughness')
    @final
    def GainToughness(self, diff, by_effect):
        self.GainKeyword(diff, 'Toughness', by_effect)
