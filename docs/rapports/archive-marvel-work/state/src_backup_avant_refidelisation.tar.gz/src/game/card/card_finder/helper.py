# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from game.ability import *
from game.card.face import *
class CardFinderHelper:
    __annotations__ = {}
    FINDER_TARGET = Literal[('Players', 'OtherPlayers', 'FirstPlayer', 'YourHero', 'YourIdentity', 'YourAlterEgo', 'YourSidekick', 'YouControlUnit', 'YourAlly', 'YouControlCards', 'YourEngagedMinions')]
    FINDER_TARGET: TypeAlias
    FINDER_TARGET_LIST = Types.LiteralToList(FINDER_TARGET)
    FINDER_TARGET_LIST: List[FINDER_TARGET]
    @staticmethod
    def IsFinderTarget(target):
        return (target in CardFinderHelper.FINDER_TARGET_LIST)
    @staticmethod
    def GetTargetType(target):
        from game.card.face.card_type import Identity
        from game.card.face.card_type import Hero
        from game.card.face.card_type import AlterEgo
        from game.card.face.card_type import Ally
        from game.card.face.card_type import StatusCard
        from game.card.face.card_face import CardFace
        from game.card.face.base import Villain
        if (target in ('Players', 'OtherPlayers', 'FirstPlayer', 'YourIdentity')):
            return Identity
        if (target in ('YourHero',)):
            return Hero
        if (target in ('YourAlterEgo',)):
            return AlterEgo
        if (target in ('YourAlly',)):
            return Ally
        if (target in ('YourEngagedMinions',)):
            return Minion
        if (target in ('OnFieldStatusCard',)):
            return StatusCard
        if (target in ('VillainAndEngagedSamePlayerMinion', 'VillainAndYouEngagedMinion')):
            return (Villain | Minion)
        return CardFace
