# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasTeamUp(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.team_up = [[], []]
        super().__init__(paper)
        def parse(value):
            team_up = value.split(';')
            self.team_up[0] = team_up[0].split('/')
            self.team_up[1] = team_up[1].split('/')
        self.RegisterAttribute('TeamUp', parse)
    def GetTeamUpUnits(self):
        from game.operate.worlds import Worlds
        faces = set()
        units = Worlds.GetOnFieldFriendlyCharacters(self.card.game_area)
        for names in self.team_up:
            found = False
            for name in names:
                for unit in units:
                    if not (unit.IsName(name)):
                        if unit.IsSubName(name):
                            faces.add(unit)
                            found = True
                        else:
                            pass
                    faces.add(unit)
                    found = True
            if not (found):
                []
                return
        return list(faces)
