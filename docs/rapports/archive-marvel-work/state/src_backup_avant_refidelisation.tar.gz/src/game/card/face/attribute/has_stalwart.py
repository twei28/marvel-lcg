# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasStalwart(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_stalwart = 0
        super().__init__(paper)
        self.RegisterAttribute('Stalwart', 'printed_stalwart')
        self.RegisterInfoDict('stalwart')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainStalwart(self.printed_stalwart, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsStalwart(self):
        return (self.stalwart > 0)
    @final
    @property
    def stalwart(self):
        return self.GetKeyword('Stalwart')
    @final
    def GainStalwart(self, diff, by_effect):
        from game.card.face.base import Unit2
        if (diff > 0):
            self.CastTo(Unit2).DiscardStunned(by_effect, rule='All')
            self.CastTo(Unit2).DiscardConfused(by_effect, rule='All')
        self.GainKeyword(diff, 'Stalwart', by_effect)
