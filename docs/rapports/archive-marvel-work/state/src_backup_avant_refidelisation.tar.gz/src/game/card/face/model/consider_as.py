# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.card.face.model.base import ModelBase
class ModelConsider(ModelBase):
    class ConsiderAs:
        def __init__(self):
            self.names = {}
            self.traits = {}
            self.card_types = {}
        def __repr__(self):
            texts = [*[x for x in self.names], *[x for x in self.traits], *[str(x) for x in self.card_types]]
            return ', '.join(texts)
    def OnInitModel(self):
        self.ResetConsiderAs()
        return super().OnInitModel()
    def OnResetModel(self):
        self.ResetConsiderAs()
        return super().OnResetModel()
    @final
    def ResetConsiderAs(self):
        self.consider_as = ModelConsider.ConsiderAs()
    @final
    def IsConsiderAs(self, name = None, trait = None, card_type = None):
        if (name != None):
            found = False
            for consider_name in self.consider_as.names:
                if self.GetThis().IsName(consider_name, False):
                    found = True
                else:
                    pass
        if (trait != None):
            if (trait not in self.consider_as.traits):
                return False
        if (card_type != None):
            found = False
            for consider_type in self.consider_as.card_types:
                if issubclass(consider_type, card_type):
                    found = True
                else:
                    pass
        return True
    @final
    def SetConsiderAs(self, face, diff, name = None, trait = None, card_type = None):
        if (diff == 1):
            if name:
                if (name in self.consider_as.names):
                    if not ((face not in self.consider_as.names[name])):
                        raise AssertionError
                    self.consider_as.names[name].append(face)
                else:
                    self.consider_as.names[name] = [face]
            if trait:
                if (trait in self.consider_as.traits):
                    if not ((face not in self.consider_as.traits[trait])):
                        raise AssertionError
                    self.consider_as.traits[trait].append(face)
                else:
                    self.consider_as.traits[trait] = [face]
        if (diff == -1):
            if name:
                self.consider_as.names[name].remove(face)
                if (self.consider_as.names[name] == []):
                    del self.consider_as.names[name]
            if trait:
                self.consider_as.traits[trait].remove(face)
                if (self.consider_as.traits[trait] == []):
                    del self.consider_as.traits[trait]
            if card_type:
                self.consider_as.card_types[card_type].remove(face)
                if (self.consider_as.card_types[card_type] == []):
                    del self.consider_as.card_types[card_type]
                    return
                    return
            return
            return
        raise AssertionError(f'diff={diff!r}')
