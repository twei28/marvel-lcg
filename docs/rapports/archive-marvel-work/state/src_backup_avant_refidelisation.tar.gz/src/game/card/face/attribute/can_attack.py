# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
@dataclass
class AttackProperty(PowerProperty):
    __annotations__ = {}
    additional_boost_card = field(default=0)
    additional_boost_card: int
    do_not_give_boost = field(default=False)
    do_not_give_boost: bool
    overkill = field(default=False)
    overkill: bool
    ranged = field(default=False)
    ranged: bool
    piercing = field(default=False)
    piercing: bool
    other_characters_cannot_defend = field(default=False)
    other_characters_cannot_defend: bool
    must_defend_with_ally = field(default=False)
    must_defend_with_ally: bool
    deal_indirect_damage = field(default=False)
    deal_indirect_damage: bool
    ignore_retaliate = field(default=False)
    ignore_retaliate: bool
    lost_piercing = field(default=False)
    lost_piercing: bool
    attack_in_event = field(default=False)
    attack_in_event: bool
    divide_damage_among_each_character_attacked_player_control = field(default=False)
    divide_damage_among_each_character_attacked_player_control: bool
    against_player = field(default=None)
    against_player: 'Player|None'
    would_act_message = field(default=None)
    would_act_message: 'Message.WhenEnemyWouldActivate|None'
    def HasKeyWord(self):
        return (self.overkill or (self.ranged or self.piercing))
    def GetDamage(self, this):
        value = 0
        if self.divided_evenly:
            value = 0
        else:
            if self.is_basic_power:
                if HasAttack.IsType(this):
                    value = this.attack
        return (self.additional_value + value)
class HasAttack(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.base_attack = 0
        self.printed_attack = 0
        self.printed_attack_consequential_damage = 0
        super().__init__(paper)
        def parse(value):
            if ('*' in value):
                consequential_damage = value.count('*')
                self.printed_attack_consequential_damage = consequential_damage
                value = value.replace('*', '')
            self.printed_attack = int(value)
        self.RegisterAttribute('ATK', parse)
        self.RegisterInfoDict('attack')
    @final
    @property
    def attack(self):
        return max(0, self.GetKeyword('ATK'))
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.base_attack = self.printed_attack
        self.GainAttack(self.base_attack, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def GainAttack(self, diff, by_effect, *, render_ui = False):
        self.GainKeyword(diff, 'ATK', by_effect, render_ui=render_ui)
    @final
    def SetBaseAttack(self, value, by_effect):
        if (self.base_attack != value):
            diff = (value - self.base_attack)
            self.base_attack = value
            self.GainAttack(diff, by_effect)
            return
class CanAttack(CardFace):
    @staticmethod
    def OnDealDamageInternal(this, units, damage, by_effect, *, property = None, attack_in_event):
        has_damage = True
        if not (attack_in_event):
            if by_effect.ability.is_like_attack:
                if not (property):
                    property = AttackProperty(is_basic_power=False, attack_in_event=attack_in_event)
                if isinstance(damage, int):
                    damage = DamageProperty(damage)
                property.additional_value = damage.damage
                attack_message = CanAttack.SpecialAttack(this, units, by_effect, property=property)
                if attack_message:
                    total_damage = attack_message.total_dealt_damage
                    has_damage = True
                else:
                    total_damage = 0
        if not (property):
            property = AttackProperty(is_basic_power=False, attack_in_event=attack_in_event)
        if isinstance(damage, int):
            damage = DamageProperty(damage)
        property.additional_value = damage.damage
        attack_message = CanAttack.SpecialAttack(this, units, by_effect, property=property)
        if attack_message:
            total_damage = attack_message.total_dealt_damage
            has_damage = True
        else:
            total_damage = 0
        if has_damage:
            return total_damage
        return
        return this.DefaultDealDamageTo(this, units, damage, by_effect)
    @override
    def OnDealDamage(self, units, damage, by_effect, *, property = None, attack_in_event):
        return CanAttack.OnDealDamageInternal(self, units, damage, by_effect, property=property, attack_in_event=attack_in_event)
    @staticmethod
    def AttackInternal(this, units, by_effect, *, property, if_this_defeat_unit = None):
        from game.message import Message
        from game.card.face.base import Unit2
        from game.card.face.attribute.can_boost import CanBoost
        from game.card.face.base import Enemy
        from game.effect.rule import GameRule
        from game.operate.worlds import Worlds
        from game.operate.effects import Effects
        def gain_value_when_divided_for_this_target(gain_value_message):
            if (gain_value_message.gain_atk > 0):
                if property.is_divided:
                    return gain_value_message.gain_atk
            return 0
        def gain_value_when_divided(gain_value_message: Message.WhenUnitWouldAttack):
            if (gain_value_message.gain_atk > 0):
                if property.is_divided:
                    gain_value = gain_value_message.gain_atk
                    player = unit.GetControlByPlayer()
                    new_added_targets = player.AskChooseFaces(units, (gain_value, gain_value), GameRule(unit), prompt='Assign', repeat_rules='Any')
                    for check_unit in new_added_targets:
                        if Unit2.IsType(check_unit):
                            gain_value_message.AddTarget(check_unit)
        is_base_attack = property.is_basic_power
        world = this.card.world
        this = this.card.CastTo(Unit2)
        would_atk_message = Message.WhenUnitWouldAttack(this, units, by_effect, property=property)
        would_atk_message.Send()
        if would_atk_message.is_be_instead:
            return
        if Enemy.IsType(this):
            activate_message = Message.WhenEnemyActivateAgainstYou(this, property.against_player, by_effect, would_atk_message, property.would_act_message)
            activate_message.Send()
        else:
            activate_message = None
        if is_base_attack:
            unit = this.card.CastTo(Unit2)
            use_basic_power_message = Message.WhenUnitUseBasicPower(unit, 'ATK', would_atk_message)
            use_basic_power_message.Send()
        else:
            use_basic_power_message = None
        gain_value_when_divided(would_atk_message)
        is_not_delay = (activate_message or (use_basic_power_message or (not by_effect.ability.IsLabel('attack'))))
        attacked_targets = []
        damage_targets = []
        total_dealt_damage = 0
        atk_end_messages = []
        from game.operate.faces_helper import FacesHelper
        unit_dict = FacesHelper.ListToDict(would_atk_message.attacked_targets)
        divided_rest_damage = (this.attack if HasAttack.IsType(this) else 0)
        if unit_dict:
            divided_evenly_damage = int(((divided_rest_damage / len(unit_dict)) + 0.5))
        else:
            divided_evenly_damage = 0
        temp_effects = []
        if if_this_defeat_unit:
            from game.ability.factory import AbilityFactory
            temp_effects = (temp_effects + this.effect.RegisterTemp(AbilityFactory.AfterUnitDefeatedUnit(AbilityType.Temp0, 'This', None, lambda effect, message: if_this_defeat_unit(message.target), is_from_attack=True), unregister_after_exec=False))
        basic_defense_messages = []
        attacker_is_defeated = 0
        for target in unit_dict:
            gain_divided_attack = 0
            if not (this.IsInPlay()):
                pass
            else:
                this = this.card.CastTo(Unit2)
                if not (Unit2.IsType(target)):
                    pass
                if is_base_attack:
                    if not (property.do_not_give_boost):
                        can_boost = this
                        if CanBoost.IsType(can_boost):
                            can_boost.GiveFacedownBoostCardsInternal((can_boost.GetBoostCardNum(would_atk_message) + property.additional_boost_card), GameRule(this), would_atk_message)
                being_atk_message = Message.WhenUnitBeingAttack(target, would_atk_message)
                being_atk_message.Send()
                gain_divided_attack = gain_value_when_divided_for_this_target(being_atk_message)
                defender = being_atk_message.defender
                defense_messages = being_atk_message.defense_messages
                basic_defense_messages = (basic_defense_messages + [x for x in defense_messages if x.use_basic_power_message])
                defense = 0
                if defense_messages:
                    if defender:
                        for defense_message in defense_messages:
                            defense = (defense + defense_message.property.GetDefense(defender))
                attacked_you = None
                def update_atk_target(target: Unit2):
                    attacked_you = target.GetControlByOrOwner()
                    return target
                if defender:
                    atk_target = update_atk_target(defender)
                else:
                    atk_target = update_atk_target(target.card.CastTo(Unit2))
                if not (this.IsInPlay()):
                    atk_end_message = Message.AttackEndsBeforeDamageDealt(this, atk_target, being_atk_message)
                    atk_end_messages.append(atk_end_message)
                else:
                    this = this.card.CastTo(Unit2)
                    would_attack_unit_message = Message.WhenUnitWouldAttackUnit(this, atk_target, being_atk_message)
                    would_attack_unit_message.Send()
                    gain_divided_attack = gain_value_when_divided_for_this_target(would_attack_unit_message)
                    atk_target = update_atk_target(would_attack_unit_message.target)
                    if atk_target.IsDefeated():
                        if Enemy.IsType(atk_target):
                            pass
                    boost_cards = []
                    if is_base_attack:
                        if CanBoost.IsType(this):
                            def gain_att(face, boost_value):
                                attacker = this.card.CastTo(Unit2)
                                boost_cards.append(face)
                                attacker.GainForThisActive(GameRule(face), would_atk_message, attack=boost_value, render_ui=True)
                            this.ResolveBoostCards(being_atk_message, gain_att)
                            if Worlds.IsGameOver(by_effect):
                                return
                        this = this.card.CastTo(Unit2)
                        if not (CanAttack.IsType(this)):
                            raise AssertionError(f'this={this!r}')
                        if being_atk_message.defender:
                            atk_target = update_atk_target(being_atk_message.defender)
                        if defender:
                            if defender.IsDefeated():
                                defense = 0
                                atk_target = update_atk_target(target)
                    has_keyword_message = Message.CheckIfAttackMessageHasKeyword(would_attack_unit_message, by_effect)
                    has_keyword_message.Send()
                    Unused(has_keyword_message)
                    if would_attack_unit_message.HasKeywords():
                        keywords_attack_message = Message.WhenUnitMakeKeyWordAttack(this, would_attack_unit_message)
                        keywords_attack_message.Send()
                    if is_base_attack:
                        this = this.card.CastTo(Unit2)
                        if property.is_divided:
                            damage = 1
                        else:
                            if property.divided_evenly:
                                damage = (property.GetDamage(this) + divided_evenly_damage)
                                divided_rest_damage = (divided_rest_damage - divided_evenly_damage)
                                if (divided_rest_damage <= divided_evenly_damage):
                                    divided_evenly_damage = divided_rest_damage
                            else:
                                damage = property.GetDamage(this)
                        value = (((unit_dict[target] * damage) + would_attack_unit_message.temp_additional_value) + gain_divided_attack)
                        recalculate = Message.WhenRecalculateAttackDamage(this, atk_target, value, would_atk_message)
                        recalculate.Send()
                        calculated_damage = recalculate.will_take_damage
                    else:
                        calculated_damage = ((unit_dict[target] * property.GetDamage(this)) + would_attack_unit_message.temp_additional_value)
                        recalculate = Message.WhenRecalculateAttackDamage(this, atk_target, calculated_damage, would_atk_message)
                        recalculate.Send()
                        calculated_damage = recalculate.will_take_damage
                    calculated_damage = max(0, (calculated_damage - defense))
                    excess_damage = 0
                    if would_attack_unit_message.IsPiercing():
                        if atk_target.IsTough():
                            atk_target.DiscardTough(by_effect, rule='All')
                    from game.card.face.card_type import Ally
                    from game.card.face.card_type import Minion
                    overkill_target = None
                    damaged_overkill_target = None
                    if would_attack_unit_message.IsOverKill():
                        if Minion.IsType(atk_target):
                            overkill_target = Worlds.FindVillain(by_effect)
                        else:
                            if Ally.IsType(atk_target):
                                overkill_target = atk_target.GetControlByPlayer().GetIdentity()
                    took_damage_targets = []
                    if property.deal_indirect_damage:
                        damage_messages = atk_target.TakeIndirectDamage(this, calculated_damage, by_effect, from_atk_message=would_atk_message)
                        took_damage = 0
                        for damage_message in damage_messages:
                            took_damage = (took_damage + damage_message.took_damage)
                            took_damage_targets.append(damage_message.who_took_damage)
                    else:
                        if property.divide_damage_among_each_character_attacked_player_control:
                            if atk_target.GetControlByOrOwner().IsPlayer():
                                if not (property.against_player):
                                    raise AssertionError
                                player_units = atk_target.GetControlByPlayer().GetControlCharacters()
                                divide_damage = Math.DivideEvenly(calculated_damage, player_units)[0]
                                divide_remainder = Math.DivideEvenly(calculated_damage, player_units)[1]
                                if divide_remainder:
                                    remainder_units = property.against_player.AskChooseFaces(player_units, (divide_remainder, divide_remainder), by_effect)
                                else:
                                    remainder_units = []
                                divide_damage_messages = []
                                for divide_target in player_units:
                                    if (divide_target in remainder_units):
                                        deal_divide_damage = (1 + divide_damage)
                                    else:
                                        deal_divide_damage = divide_damage
                                    if deal_divide_damage:
                                        divide_damage_messages.append(divide_target.TakeDamage(this, deal_divide_damage, by_effect))
                                took_damage = 0
                                excess_damage = 0
                                for damage_message in divide_damage_messages:
                                    if damage_message:
                                        took_damage = (took_damage + damage_message.took_damage)
                                        excess_damage = (excess_damage + damage_message.excess_damage)
                                        if (took_damage > 0):
                                            took_damage_targets.append(damage_message.who_took_damage)
                                    took_damage = (took_damage + 0)
                                    excess_damage = (excess_damage + 0)
                            else:
                                damage_messages = atk_target.TakeDamageWithOverkillTarget(this, calculated_damage, by_effect, would_attack_unit_message, overkill_target)
                                if damage_messages:
                                    took_damage = damage_messages[0].took_damage
                                    excess_damage = damage_messages[0].excess_damage
                                    if (took_damage > 0):
                                        took_damage_targets.append(damage_messages[0].who_took_damage)
                                    damaged_overkill_target = damage_messages[0].damaged_overkill_target
                                    if damaged_overkill_target:
                                        took_damage_targets.append(damaged_overkill_target)
                                else:
                                    took_damage = 0
                                    excess_damage = 0
                        else:
                            damage_messages = atk_target.TakeDamageWithOverkillTarget(this, calculated_damage, by_effect, would_attack_unit_message, overkill_target)
                            if damage_messages:
                                took_damage = damage_messages[0].took_damage
                                excess_damage = damage_messages[0].excess_damage
                                if (took_damage > 0):
                                    took_damage_targets.append(damage_messages[0].who_took_damage)
                                damaged_overkill_target = damage_messages[0].damaged_overkill_target
                                if damaged_overkill_target:
                                    took_damage_targets.append(damaged_overkill_target)
                            else:
                                took_damage = 0
                                excess_damage = 0
                    if (atk_target.card.face != atk_target):
                        if Unit2.IsType(atk_target.card.face):
                            atk_target = update_atk_target(atk_target.card.CastTo(Unit2))
                    attacked_targets.append(atk_target)
                    total_dealt_damage = (total_dealt_damage + calculated_damage)
                    if is_not_delay:
                        retaliate_message = atk_target.ResolveRetaliate(would_attack_unit_message)
                        attacker_is_defeated = (attacker_is_defeated + ((retaliate_message != None) and isinstance(retaliate_message, Message.AfterUnitDefeatedUnit)))
                        if being_atk_message.defense_messages:
                            defend_against_message = Message.AfterUnitDefendEnd(being_atk_message.defense_messages, would_atk_message, calculated_damage, took_damage)
                            defend_against_message.Send()
                    else:
                        if not ((being_atk_message.defense_messages == [])):
                            raise AssertionError
                    atk_end_message = Message.AfterUnitAttackUnit(this, atk_target, attacked_you, damaged_overkill_target, took_damage_targets, calculated_damage, took_damage, excess_damage, boost_cards, would_attack_unit_message, being_atk_message.defense_messages)
                    if is_not_delay:
                        atk_end_message.Send()
                    atk_end_messages.append(atk_end_message)
                    damage_targets = (damage_targets + took_damage_targets)
        Effects.UnRegister(temp_effects)
        this = this.CastTo(Unit2)
        end_message = Message.AfterUnitAttackEnd(this, attacked_targets, damage_targets, total_dealt_damage, by_effect, atk_end_messages, would_atk_message)
        if is_not_delay:
            end_message.Send()
            if atk_end_messages:
                if activate_message:
                    if not (Enemy.IsType(this)):
                        raise AssertionError
                    after_activate_message = Message.AfterEnemyActivationEnd(this, end_message, activate_message)
                    after_activate_message.Send()
                if use_basic_power_message:
                    if not (this.IsDefeated()):
                        if not (attacker_is_defeated):
                            unit = this.card.CastTo(Unit2)
                            after_use_basic_power_message = Message.AfterUnitUseBasicPower(unit, 'ATK', end_message, use_basic_power_message)
                            after_use_basic_power_message.Send()
                world.stat.RecordAttack(end_message)
            for basic_defense_message in basic_defense_messages:
                if basic_defense_message.IsBasicDefense():
                    if basic_defense_message.use_basic_power_message:
                        after_use_def_power_message = Message.AfterUnitUseBasicPower(basic_defense_message.defender, 'DEF', basic_defense_message, basic_defense_message.use_basic_power_message)
                        after_use_def_power_message.Send()
            return end_message
        by_effect.context.AddAtkMessage(end_message)
        return end_message
    @staticmethod
    def GetUnits(units):
        from game.card.face.base import Unit2
        targets = []
        for unit in units:
            target = unit.card.face
            if Unit2.IsType(target):
                if target.IsDefeated():
                    pass
            targets.append(target)
        return targets
    @staticmethod
    def SpecialAttack(this, units, by_effect, *, property):
        targets = CanAttack.GetUnits(units)
        message = CanAttack.AttackInternal(this, targets, by_effect, property=property)
        return message
    def BasicAttack(self, units, by_effect, *, property = None, if_this_defeat_unit = None, if_no_character_takes_damage = None, if_characters_damaged_by_this = None, for_each_damage_dealt_by_this = None, if_no_attack_was_made = None, if_unit_defends_against = None, if_undefended = None):
        if not (units):
            if if_no_attack_was_made:
                if_no_attack_was_made()
            return
        if not (self.IsCanAttack(by_effect)):
            return
        if (property == None):
            property = AttackProperty(is_basic_power=True)
        else:
            property.is_basic_power = True
        controller = units[0].GetControlBy()
        if Player.IsType(controller):
            property.against_player = controller
        targets = CanAttack.GetUnits(units)
        message = CanAttack.AttackInternal(self, targets, by_effect, property=property, if_this_defeat_unit=if_this_defeat_unit)
        if if_no_attack_was_made:
            if (message == None):
                if_no_attack_was_made()
        if if_no_character_takes_damage:
            if message:
                if (message.damaged_targets == []):
                    if_no_character_takes_damage()
        if if_characters_damaged_by_this:
            if message:
                if_characters_damaged_by_this(message.damaged_targets)
        if for_each_damage_dealt_by_this:
            if message:
                if (message.total_dealt_damage > 0):
                    for_each_damage_dealt_by_this(message.total_dealt_damage)
        if if_unit_defends_against:
            if message:
                for attack_message in message.atk_messages:
                    if attack_message.defender:
                        if_unit_defends_against(attack_message.defender, attack_message.taken_damage)
        if if_undefended:
            if message:
                for atk_message in message.atk_messages:
                    if (atk_message.defender == None):
                        if_undefended()
        return message
    def IsCanAttack(self, by_effect):
        from game.card.face.base import Unit2
        if not (self.IsInPlay()):
            return False
        if not (Unit2.IsType(self)):
            return False
        check_message = Message.CheckIfUnitCanAttack(self, by_effect)
        check_message.Send()
        return check_message.can_attack
