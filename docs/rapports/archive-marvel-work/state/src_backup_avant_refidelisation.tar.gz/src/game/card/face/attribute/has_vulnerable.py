# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasVulnerable(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_vulnerable = 0
        super().__init__(paper)
        self.RegisterAttribute('Vulnerable', 'printed_vulnerable')
        self.RegisterInfoDict('vulnerable')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainVulnerable(self.printed_vulnerable, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsVulnerable(self):
        return (self.vulnerable > 0)
    @final
    @property
    def vulnerable(self):
        return self.GetKeyword('Vulnerable')
    @final
    def GainVulnerable(self, diff, by_effect):
        self.GainKeyword(diff, 'Vulnerable', by_effect)
