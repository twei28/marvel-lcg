# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasVictory(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_victory = None
        super().__init__(paper)
        self.RegisterAttribute('Victory', 'printed_victory')
    @override
    def GetInfoDict(self):
        return ({'victory': (self.printed_victory if (self.printed_victory != None) else 0)} | super().GetInfoDict())
    @override
    def OnBeDefeated(self, would_defeated_message, *, as_asset, ignore_when_defeated):
        from game.card.face.base import Villain
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        if self.victory:
            if self.IsThisFaceUp():
                do_move = True
                if Villain.IsType(self):
                    next_villain = self.card.world.scenario.GetNextVillain(self)
                    if next_villain:
                        if not (next_villain.IsName(self.name, check_all_face=True)):
                            pass
                        else:
                            do_move = False
        return super().OnBeDefeated(would_defeated_message, as_asset=as_asset, ignore_when_defeated=ignore_when_defeated)
    @final
    @property
    def victory(self):
        return (self.printed_victory != None)
