# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Token(Component):
    @override
    def __init__(self, card: Card):
        self.token = {}
        super().__init__(card)
    @override
    def OnParentReset(self):
        self.SetTokens(0, 'threat')
        return super().OnParentReset()
    def GetAllTokens(self):
        value = 0
        for key in self.token:
            value = (value + self.token[key])
        return value
    def SetTokens(self, token, name):
        if (name in self.token):
            self.token[name] = token
            return
        self.token = (self.token | {name: token})
    def GetTokens(self, name):
        if (name in self.token):
            return self.token[name]
        return 0
    def PlaceTokens(self, token, name):
        self.SetTokens((token + self.GetTokens(name)), name)
        return True
    def RemoveTokens(self, token, name, forced):
        if (name in self.token):
            if (token == 'All'):
                self.token[name] = 0
                return True
            if not (forced):
                if (self.token[name] >= token):
                    self.token[name] = (self.token[name] - token)
                    if (self.token[name] < 0):
                        self.token[name] = 0
                    return True
            self.token[name] = (self.token[name] - token)
            if (self.token[name] < 0):
                self.token[name] = 0
            return True
            return False
        return False
    def GetTokenNames(self):
        return list(self.token.keys())
