# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.states import CardIsStates
from game.card.states import CardCanStates
from game.object import Object
from game.card.face import *
from game.deck import *
from game.player import *
from game.effect import *
from game.message import *
from game.world.game_area import *
from game.world import *
from game.render.descriptor.card import CardDescriptor
@final
class Card(Object):
    def __lt__(self, other: 'Card'):
        return (self.object_id < other.object_id)
    class Visible:
        def __init__(self, card: 'Card'):
            self.visible_players = set()
            self.card = card
        def Clean(self):
            self.visible_players.clear()
        def Update(self):
            for player in self.card.world.const_players:
                if self.card.IsVisible(player):
                    self.visible_players.add(player)
        def Set(self, visible: Literal[False, True]|Player):
            if (visible == False):
                self.Clean()
                return
            if (visible == True):
                for player in self.card.world.const_players:
                    self.visible_players.add(player)
                return
            self.visible_players.add(visible)
        def IsVisible(self, player):
            if (player == 'Any'):
                return (len(self.visible_players) > 0)
            if (player in self.visible_players):
                return True
            return False
    def __init__(self, owner: Player|Scenario, *faces: CardFace, world: 'World'):
        super().__init__('card', world)
        self
        self.owner_original = owner
        self.owner_internal = owner
        self.state = CardIsStates()
        self.can_state = CardCanStates()
        self.visible = Card.Visible(self)
        self.is_apply_unique_rule = None
        self.face = faces[0]
        self.back_faces = list(faces[1:])
        for face in ([self.face] + self.back_faces):
            face.card = self
        self
        self.bind_discard_pile = None
        class Components:
            from game.card.face.component.component import Component
            def __init__(self, card: 'Card'):
                from game.card.face.component.inventory import Inventory
                from game.card.face.component.attach import PlacedCard
                from game.card.face.component.counter import Counter
                from game.card.face.component.boostable import Boostable
                from game.card.face.component.status import Status
                from game.card.face.component.buffs import Buffs
                from game.card.face.component.buffs import Token
                from game.card.face.component.buffs import Health
                self.inventory = Inventory(card)
                self.placed_card = PlacedCard(card)
                self.status = Status(card)
                self.counter = Counter(card)
                self.token = Token(card)
                self.health = Health(card)
                self.boostable = Boostable(card)
                self.buffs = Buffs(card)
            def GetAll(self):
                return [self.inventory, self.placed_card, self.status, self.counter, self.token, self.health, self.boostable]
            def OnRemove(self, by_effect: Effect):
                for component in self.GetAll():
                    component.OnRemove(by_effect)
            def OnAfterLeavePlay(self, by_effect: Effect):
                for component in self.GetAll():
                    component.OnParentLeavePlay(by_effect)
            def OnDiscard(self, by_effect):
                faces = []
                for component in self.GetAll():
                    faces.extend(component.OnDiscard(by_effect))
                return faces
            def OnBeforeFlip(self, by_effect, no_detach = False):
                for component in self.GetAll():
                    component.OnBeforeParentFlip(by_effect, no_detach=no_detach)
            def OnAfterFlip(self, by_effect: Effect):
                for component in self.GetAll():
                    component.OnAfterParentFlip(by_effect)
            def OnReset(self):
                for component in self.GetAll():
                    component.OnParentReset()
        self.components = Components(self)
        self.printed_faces = ([self.face] + self.back_faces)
        from game.card.ui_effect_by import UIEffectBy
        self.ui = UIEffectBy(self)
    def GetCRC(self, *, recalculate = False):
        if self.IsInHand():
            crc = -2
            return crc
        if self.IsInDeck():
            if (self.area.GetAll()[-1] == self.face):
                crc = -3
                return crc
        if self.IsInDeck():
            if (self.area.GetAll()[0] == self.face):
                crc = -4
                return crc
        if not (self.IsOnField()):
            if self.area.flags.is_status_area:
                if recalculate:
                    self.face.GetRenderInfo()
                crc = self.face.crc_value
                return crc
        if recalculate:
            self.face.GetRenderInfo()
        crc = self.face.crc_value
        return crc
        crc = -1
        return crc
    def __repr__(self):
        if self.back_faces:
            return f'{self.face} / {self.back_faces}'
        return {self.face}
    def SetOwner(self, owner: Player|None):
        if (owner == None):
            controller = self.world.GetScenario()
        else:
            controller = owner
        self.owner_internal = controller
    def GetOwner(self) -> Player|Scenario:
        return self.owner_internal
    def GetController(self) -> Player|Scenario|None:
        if self.IsOnField():
            if self.area.flags.is_side_scheme_area:
                if PlayerSideScheme.IsType(self.face):
                    return self.owner_internal
            bind_card = self.area.bind_card
            if bind_card:
                bind_face = bind_card.face
                if MainScheme.IsType(bind_face):
                    return self.owner_internal
                if EncounterSideScheme.IsType(bind_face):
                    return self.owner_internal
                if not (EncounterCard.IsType(bind_face)):
                    if Villain.IsType(bind_face):
                        if ClassCard.IsType(self.face):
                            return self.owner_internal
                if ClassCard.IsType(self.face):
                    return self.owner_internal
                if ClassCard.IsType(bind_face):
                    if EncounterCard.IsType(self.face):
                        return self.owner_internal
                if PlayerSideScheme.IsType(bind_face):
                    return self.owner_internal
            return self.area.GetOwner()
    def IsInHand(self):
        return self.area.flags.is_in_hand
    def IsLikeInHand(self):
        if (self.can_state.is_like_in_hand == None):
            from game.message import Message
            message = Message.CheckIfFaceIsLikeInHand(self.face)
            message.Send()
            self.can_state.is_like_in_hand = message.is_like_in_hand
        return self.can_state.is_like_in_hand
    def IsCanReadyBy(self, by_effect):
        return (not self.IsReady())
    def IsOnField(self):
        return self.area.flags.is_in_play
    def IsOnProcessingArea(self):
        return self.area.flags.is_processing
    def IsInDeck(self):
        return self.area.flags.is_deck
    def IsReady(self):
        return self.state.is_ready
    def IsExhaust(self):
        return (not self.IsReady())
    def IsFaceUp(self):
        return self.state.is_face_up
    def IsApplyUniqueRule(self):
        if (self.is_apply_unique_rule == None):
            from game.message import Message
            this = self.face
            check_message = Message.CheckIfFaceApplyUniqueRule(this)
            check_message.Send()
            self.is_apply_unique_rule = check_message.apply_unique_rule
        return self.is_apply_unique_rule
    def IsVisible(self, player):
        if self.IsFaceUp():
            return True
        if self.area.flags.is_in_hand:
            if (self.area.GetOwnerPlayer() == player):
                return True
        if self.IsLikeInHand():
            if (self.GetOwner() == player):
                return True
        return self.visible.IsVisible(player)
    def GetGameArea(self) -> GameArea:
        if not ((self.game_area != None)):
            raise AssertionError(f'self={self!r}')
        return self.game_area
    @final
    def CastTo(self, face_type):
        face = self.face
        return face.CastTo(face_type)
    def RegisterEffect(self, ability, face, *, is_temp = False, is_local = False, world):
        from game.effect import Effect
        from game.card.face.attribute.has_cost import HasCost
        if ability.paper:
            if (self.face == face):
                if not ((ability.paper == self.face.paper)):
                    raise AssertionError(f'ability.paper={ability.paper!r} self.face.paper={self.face.paper!r}')
            else:
                found = False
                for back_face in self.back_faces:
                    if (back_face == face):
                        if not ((ability.paper == back_face.paper)):
                            raise AssertionError(f'ability.paper={ability.paper!r} back_face.paper={back_face.paper!r}')
                        found = True
                    else:
                        pass
                if not (found):
                    raise AssertionError(f'self={self!r} ability={ability!r} face={face!r}')
        if ability.is_play:
            if not (HasCost.IsType(face)):
                raise AssertionError(f'face={face!r}')
            ability.SetPlayCost(face.GetPrintedCostWithRequirement())
        effect = Effect(face, ability, is_temp=is_temp, is_local=is_local, world=world)
        world.event_manager.RegisterEffect(effect)
        return effect
    def MoveToArea(self, into_area, by_effect, *, up_face = None, ui_group = False, callback1 = None, callback2 = None, target_game_area = None, index = -1):
        message = self.CheckIfCanMove(into_area, by_effect, up_face=up_face, ui_group=ui_group, callback=callback1)
        if (message != None):
            if (message != False):
                if (message != True):
                    return self.MoveToAreaInternal(message, callback=callback2, target_game_area=target_game_area, index=index)
        return False
    def CheckIfCanMove(self, into_area, by_effect, *, up_face = None, ui_group = False, callback = None):
        from game.message import Message
        from game.effect.rule import GameRule
        from_area = self.area
        if (up_face == None):
            up_face = self.face
        if (self.area == into_area):
            return False
        if not (self.GetOwner().is_eliminated):
            if not (self.world.is_game_over):
                if not (ui_group):
                    if not (into_area.flags.is_place_card_area):
                        if from_area.flags.is_deck:
                            if not ((from_area.GetAll()[-1] != up_face)):
                                if not (self.IsFaceUp()):
                                    if into_area.flags.is_face_up:
                                        from_area.MoveToTopAndFlip(self, GameRule(up_face), ui_group=ui_group)
                                    else:
                                        if not (from_area.flags.is_in_hand):
                                            if into_area.flags.is_face_up:
                                                if not (self.IsFaceUp()):
                                                    if not (ui_group):
                                                        self.Flip(GameRule(up_face))
                                else:
                                    if not (from_area.flags.is_in_hand):
                                        if into_area.flags.is_face_up:
                                            if not (self.IsFaceUp()):
                                                if not (ui_group):
                                                    self.Flip(GameRule(up_face))
                            from_area.MoveToTopAndFlip(self, GameRule(up_face), ui_group=ui_group)
                        else:
                            if not (from_area.flags.is_in_hand):
                                if into_area.flags.is_face_up:
                                    if not (self.IsFaceUp()):
                                        if not (ui_group):
                                            self.Flip(GameRule(up_face))
                    else:
                        if not (from_area.flags.is_in_hand):
                            if into_area.flags.is_face_up:
                                if not (self.IsFaceUp()):
                                    if not (ui_group):
                                        self.Flip(GameRule(up_face))
                else:
                    if not (from_area.flags.is_in_hand):
                        if into_area.flags.is_face_up:
                            if not (self.IsFaceUp()):
                                if not (ui_group):
                                    self.Flip(GameRule(up_face))
        message = Message.WhenCardWouldMoveToArea(up_face, from_area, into_area, by_effect, ui_group)
        if not (up_face.OnWhenCardWouldMoveToArea(message)):
            return False
        if (self.area == message.into_area):
            return True
        into_area = message.into_area
        self.can_state.Reset()
        self.is_apply_unique_rule = None
        def early_exit():
            self.state.is_leaving_play = False
        if not (into_area.flags.is_in_play):
            if from_area.flags.is_in_play:
                self.state.is_leaving_play = True
                would_leave_play_message = Message.WhenCardWouldLeavePlay(up_face, from_area, into_area, by_effect, False)
                if not (up_face.OnWhenCardWouldLeavePlay(would_leave_play_message)):
                    early_exit()
                    return False
            else:
                would_leave_play_message = None
        else:
            would_leave_play_message = None
        if callback:
            callback()
        if self.world.is_game_started:
            if into_area.flags.is_in_play:
                if self.world.IsThisUniqueInPlay(up_face):
                    self.Discard(by_effect)
                    early_exit()
                    return False
        leave_play_message = None
        if would_leave_play_message:
            if self.IsAsOtherCard():
                self.ResetToPrintedCard()
                up_face = self.face
            leave_play_message = Message.WhenCardLeavePlay(up_face, would_leave_play_message)
            if not (up_face.OnWhenCardLeavePlay(leave_play_message)):
                return False
            if (self.area != from_area):
                return False
            up_face.OnLeavedPlayEnd(by_effect)
        self.state.is_leaving_play = False
        if into_area.flags.is_boost_area:
            up_face.Reset(False)
        if into_area.flags.is_dealt_encounter:
            up_face.card.visible.Update()
        if into_area.flags.is_in_play:
            if not (from_area.flags.is_in_play):
                if not (from_area.flags.is_boost_area):
                    if not (from_area.flags.is_dealt_encounter):
                        if not (from_area.flags.is_place_card_area):
                            if not (from_area.flags.is_revealing):
                                up_face.Reset(False)
                if not (up_face.OnWouldEnterPlay(into_area)):
                    return False
        if leave_play_message:
            return leave_play_message
        return message
    def MoveToAreaInternal(self, leave_play_message, *, callback = None, target_game_area = None, index = -1):
        from game.message import Message
        up_face = leave_play_message.trigger
        into_area = leave_play_message.into_area
        by_effect = leave_play_message.by_effect
        from_area = leave_play_message.from_area
        self.area.Remove(self)
        into_area.Insert(index, self, target_game_area)
        self.visible.Update()
        if callback:
            callback()
        if not (into_area.flags.is_in_play):
            if from_area.flags.is_in_play:
                self.ResetReady()
        need_shuffle = (from_area.flags.is_deck and (from_area.GetSize() == 0))
        area_before_shuffle = self.area
        if need_shuffle:
            after_deck_runout = Message.AfterDeckRunOut(from_area)
            after_deck_runout.Send()
        if into_area.flags.is_in_hand:
            enter_hand_message = Message.AfterCardEnterHand(up_face, from_area, into_area, by_effect)
            enter_hand_message.Send()
        if (area_before_shuffle != into_area):
            return False
        if not (into_area.flags.is_in_play):
            if from_area.flags.is_in_play:
                if isinstance(leave_play_message, Message.WhenCardLeavePlay):
                    after_leave_message = Message.AfterCardLeavePlay(up_face, from_area, into_area, leave_play_message)
                    up_face.OnAfterCardLeavePlay(after_leave_message)
                    if not (from_area.flags.is_obligations_area):
                        if not (into_area.flags.is_discards):
                            if not (into_area.flags.is_place_card_area):
                                up_face.Reset(False)
                    return True
        if into_area.flags.is_in_play:
            if not (from_area.flags.is_in_play):
                up_face.ApplyAfterEnterPlay(from_area, into_area, by_effect, is_flip=False)
        return True
    def MoveToTop(self, deck, by_effect, *, ui_group = False):
        from game.message import Message
        if not (deck.flags.is_deck):
            if deck.flags.is_dealt_encounter:
                if (deck.GetTop() != self.face):
                    area = self.area
                    if (area == deck):
                        area.Append(self)
                    else:
                        self.MoveToArea(deck, by_effect, ui_group=ui_group)
        if (deck.GetTop() != self.face):
            area = self.area
            if (area == deck):
                area.Append(self)
            else:
                self.MoveToArea(deck, by_effect, ui_group=ui_group)
        return False
    def MoveToBottom(self, deck, by_effect, *, ui_group = False):
        from game.message import Message
        if not (deck.flags.is_deck):
            if deck.flags.is_dealt_encounter:
                if (deck.GetBottom() != self.face):
                    area = self.area
                    if (area == deck):
                        deck.Insert(0, self)
                    else:
                        self.MoveToArea(deck, by_effect, ui_group=ui_group, index=0)
        if (deck.GetBottom() != self.face):
            area = self.area
            if (area == deck):
                deck.Insert(0, self)
            else:
                self.MoveToArea(deck, by_effect, ui_group=ui_group, index=0)
        return False
    def ResetReady(self):
        self.state.is_ready = True
    def Ready(self, by_effect, *, ui_group = False):
        from game.message import Message
        if not (self.IsReady()):
            message = Message.WhenCardWouldReady(self.face, by_effect, ui_group=ui_group)
            message.Send()
            if message.is_be_instead:
                return False
            self.state.is_ready = True
            after_message = Message.AfterCardReady(self.face, by_effect, message, ui_group)
            after_message.Send()
            return True
        return False
    def Exhaust(self, by_effect, *, ui_group = False):
        from game.message import Message
        if self.IsReady():
            self.state.is_ready = False
            after_message = Message.AfterCardExhausted(self.face, by_effect, ui_group=ui_group)
            after_message.Send()
            return True
        return False
    def SetAside(self, by_effect, *, ui_group = False):
        player = self.GetOwner()
        self.components.OnRemove(by_effect)
        if isinstance(player, Player):
            return self.MoveToArea(player.set_aside_deck, by_effect, ui_group=ui_group)
        return self.MoveToArea(self.world.aside_deck, by_effect, ui_group=ui_group)
    def Discard(self, by_effect, *, into_area = None, ui_group = False, up_face = None):
        message = self.CheckIfCanDiscard(by_effect, into_area=into_area, ui_group=ui_group, up_face=up_face)[0]
        discard_message = self.CheckIfCanDiscard(by_effect, into_area=into_area, ui_group=ui_group, up_face=up_face)[1]
        if (message != None):
            if (message != False):
                if (message != True):
                    after_messages = []
                    def action():
                        after_discard_message = Message.AfterCardDiscard(message.trigger, message.from_area, by_effect, discard_message)
                        after_messages.append(after_discard_message)
                    return_value = self.MoveToAreaInternal(message, callback=action)
                    for after_message in after_messages:
                        after_message.Send()
                    return return_value
        return False
    def CheckIfCanDiscard(self, by_effect, *, into_area = None, ui_group = False, up_face = None):
        from game.message import Message
        from game.operate.faces import Faces
        if self.IsAsOtherCard():
            self.ResetToPrintedCard()
        if (up_face == None):
            up_face = self.face
        from_area = self.area
        discard_message = Message.WhenCardWouldDiscard(up_face, by_effect)
        up_face.OnWhenCardWouldDiscard(discard_message)
        if discard_message.is_be_instead:
            return (False, discard_message)
        def get_owner_area(owner: Player|Scenario):
            if isinstance(owner, Player):
                return owner.discard_pile
            return owner.encounter_discard_pile
        if (into_area == 'Owner'):
            player = up_face.GetOwner()
            into_area = get_owner_area(player)
        else:
            if (into_area != None):
                pass
            else:
                if (discard_message.into_area != None):
                    into_area = discard_message.into_area
                else:
                    if (self.bind_discard_pile != None):
                        into_area = self.bind_discard_pile
                    else:
                        if from_area.bind_discard_pile:
                            into_area = from_area.bind_discard_pile
                        else:
                            if EncounterCard.IsType(self.face):
                                into_area = get_owner_area(self.owner_original)
                            else:
                                into_area = get_owner_area(self.owner_internal)
        def action():
            Faces.DiscardAll(up_face.card.components.OnDiscard(by_effect), by_effect, simultaneous=True)
        message = self.CheckIfCanMove(into_area, by_effect, ui_group=ui_group, up_face=up_face, callback=action)
        return (message, discard_message)
    def IsAsOtherCard(self):
        for face in ([self.face] + self.back_faces):
            if (face not in self.printed_faces):
                return True
        return False
    def SetAsCard(self, face, back_faces = [], remove_legacy = False):
        from game.message import Message
        self.state.is_setting_as = True
        message = Message.WhenCardSetAs(self.face, face)
        message.Send()
        if remove_legacy:
            self.printed_faces = [face]
            self.printed_faces = (self.printed_faces + back_faces)
        self.face = face
        self.face.card = self
        self.back_faces = []
        self.back_faces = (self.back_faces + back_faces)
        for check_face in back_faces:
            check_face.card = self
        self.state.is_setting_as = False
        if not ((self.face == face)):
            raise AssertionError
        return face
    def SwapBackToPrintedCard(self, by_effect: Effect) -> CardFace:
        self.SwapCardFace(self.printed_faces[0], by_effect)
        return self.face
    def SwapCardFace(self, to_face, by_effect, call_reveal = False, no_detach = False):
        from_face = self.face
        from_face.OnBeforeSwap(by_effect, to_face, no_detach=no_detach)
        self.face.OnAfterSwap(by_effect, call_reveal)
        if not (self.face.card.area.flags.is_discards):
            if not ((self.face == to_face)):
                raise AssertionError
        return to_face
    def SwapCard(self, to_face, by_effect, *, is_advance = None):
        from_face = self.face
        to_face_card = to_face.card
        self.printed_faces = [to_face]
        to_face_card.printed_faces = [from_face]
        self.face = to_face
        self.face.card = self
        from_face.card = to_face_card
        to_face_card.face = from_face
        if Villain.IsType(to_face):
            if Villain.IsType(from_face):
                to_face.SetEncounterDeck(from_face.encounter_deck)
        self.face.OnBeforeSwapOld(by_effect, from_face)
        self.face.OnAfterSwap(by_effect)
        return self.face
    def ResetToPrintedCard(self) -> CardFace:
        self.face.Reset(False)
        self.face = self.printed_faces[0]
        self.back_faces = self.printed_faces[1:]
        return self.face
    def GetEffects(self):
        effects = []
        for face in ([self.face] + self.back_faces):
            effects = (effects + face.effects[:])
        return effects
    def Destroy(self):
        self.area.Remove(self)
        if self.IsAsOtherCard():
            raise AssertionError(f'self={self!r}')
        for effect in self.GetEffects():
            self.world.event_manager.UnRegisterEffect(effect)
        self.face.OnAfterDestroy()
    def Flip(self, by_effect, call_reveal = True, *, ui_group = False, ui_look_at = False, by_swapping = False):
        from game.message import Message
        self.state.is_flipping = True
        if (self.back_faces == []):
            to_face = None
        else:
            to_face = self.back_faces[0]
        would_flip = Message.WhenCardWouldFlip(self.face, to_face, by_effect, ui_group, ui_look_at, by_swapping)
        would_flip.Send()
        if would_flip.is_be_instead:
            self.state.is_flipping = False
            return False
        self.face.OnBeforeFlip(by_effect)
        flip_message = Message.WhenCardFlip(self.face, by_effect, would_flip)
        self.face.OnWhenCardFlip(flip_message)
        if not (to_face):
            origin_face = None
            self.state.is_face_up = (not self.state.is_face_up)
        else:
            origin_face = self.face
            self.face = to_face
            self.back_faces.remove(to_face)
            self.back_faces = (self.back_faces + [origin_face])
        self.face.OnFlip(by_effect, origin_face)
        self.state.is_flipping = False
        self.state.is_revealing = False
        self.face.OnAfterFlip(by_effect, call_reveal)
        self.visible.Update()
        if not (self.world.is_game_over):
            if self.world.is_game_started:
                pass
        return False
    def Render(self) -> CardDescriptor:
        from game.card.face.base import Villain
        bind_object_id = 0
        if self.area.bind_card:
            bind_object_id = self.area.bind_card.object_id
        face_down_card_id = []
        if self.back_faces:
            face_down_card_id = [x.paper.card_id for x in self.back_faces]
        else:
            if Evidence.IsType(self.face):
                face_down_card_id = {'Means': ['evidence-back-means'], 'Motive': ['evidence-back-motive'], 'Opportunity': ['evidence-back-opportunity']}[self.face.subtype]
            else:
                if self.GetOwner().is_scenario:
                    if Villain.IsType(self.face):
                        face_down_card_id = ['villain']
                    else:
                        face_down_card_id = ['encounter']
                        face_down_card_id = ['player']
                else:
                    face_down_card_id = ['player']
        visible_player = []
        if self.world.rule.show_all_cards:
            visible_player = [0]
        else:
            for player in self.world.players:
                if self.IsVisible(player):
                    visible_player.append(player.player_id)
        def get_non_forced():
            effects = []
            for effect in self.GetEffects():
                if not (effect.is_forced):
                    if not (effect.ability.flags.is_resource):
                        if not (effect.ability.flags.is_discard_pay):
                            effects.append(effect)
            return effects
        def get_resources():
            effects = []
            for effect in self.GetEffects():
                if effect.ability.is_paying:
                    effects.append(effect)
            return effects
        from engine import Engine
        if not (isinstance(self.face, FinalType)):
            raise AssertionError
        if HasCost.IsType(self.face):
            pass
        else:
            UNKNOWN[UNKNOWN] = 0
            UNKNOWN['crc'] = self.GetCRC()
            UNKNOWN['is_new'] = Engine.statistics.IsNew(self.face.paper.card_id)
            UNKNOWN['is_action'] = any((x for x in self.face.effects if x.ability.flags.is_action))
            return UNKNOWN(*UNKNOWN, **UNKNOWN)
        ()[{'id': self.object_id, 'is_ready': self.IsReady(), 'is_face_up': self.IsFaceUp(), 'visible_for_players': visible_player, 'bind_object_id': bind_object_id, 'effect_by_cards': [x.card.object_id for x in self.face.card.ui.GetEffectedByFaces()], 'effect_to_cards': [x.card.object_id for x in self.face.card.ui.GetEffectToFaces()], 'game_area': self.game_area.object_id, 'name': self.face.name, 'info': self.face.GetRenderInfo(), 'traits': self.face.GetInfoTraits(), 'buffs': self.face.GetBuffsText(), 'card_id': self.face.paper.card_id, 'pic_id': self.face.pic_id, 'down_card_ids': face_down_card_id, 'effects': [x.object_id for x in get_non_forced()], 'resources': [x.object_id for x in get_resources()], 'card_type': self.face.type_name}] = 'cost'
        ()['crc'] = self.GetCRC()
        ()['is_new'] = Engine.statistics.IsNew(self.face.paper.card_id)
        ()['is_action'] = any((x for x in self.face.effects if x.ability.flags.is_action))
        return UNKNOWN(*CardDescriptor, **())
