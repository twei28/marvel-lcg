# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasAlliance(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.alliance = False
        super().__init__(paper)
        self.RegisterAttribute('Alliance', 'alliance', bool)
