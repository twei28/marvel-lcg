# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Inventory(Component):
    @override
    def __init__(self, card: Card):
        from game.deck import Deck2
        from game.deck import DeckType
        super().__init__(card)
        self.deck = Deck2(self.parent, DeckType.UpgradesArea, Asset2)
    @override
    def OnParentLeavePlay(self, by_effect: Effect):
        from game.operate.faces import Faces
        super().OnParentLeavePlay(by_effect)
        Faces.DiscardAll(self.GetDeck().GetAll(), by_effect)
    @override
    def OnBeforeParentFlip(self, by_effect, no_detach = False):
        from game.operate.faces import Faces
        face = self.parent.face
        if self.parent.IsOnField():
            for upgrade in self.deck.Get():
                if (by_effect.this == upgrade):
                    if not (no_detach):
                        upgrade.OnDetachFrom(face, True)
                upgrade.OnDetachFrom(face, True)
        else:
            Faces.DiscardAll(self.deck.GetAll(), by_effect, simultaneous=True)
        return super().OnBeforeParentFlip(by_effect)
    @override
    def OnAfterParentFlip(self, by_effect: Effect):
        from game.operate.faces import Faces
        face = self.parent.face
        if self.parent.IsOnField():
            for upgrade in self.deck.Get():
                upgrade.OnAttachTo(face, True)
        else:
            Faces.DiscardAll(self.deck.GetAll(), by_effect, simultaneous=True)
        return super().OnAfterParentFlip(by_effect)
    @override
    def OnDiscard(self, by_effect):
        return (self.deck.GetAll() + super().OnDiscard(by_effect))
    @override
    def OnRemove(self, by_effect: Effect):
        from game.operate.faces import Faces
        Faces.DiscardAll(self.deck.GetAll(), by_effect)
        return super().OnRemove(by_effect)
    def GetDeck(self) -> Deck2[Asset2]:
        return self.deck
