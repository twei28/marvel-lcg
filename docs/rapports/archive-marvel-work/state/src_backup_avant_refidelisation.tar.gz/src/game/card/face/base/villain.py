# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.card.face.base import *
from game.ability import *
from game.message import *
from game.player import *
from game.deck import *
from cards.paper import Paper
from game.element.damage_property import DamageProperty
class Villain(Enemy, HasStage, HasAccelerationIcon, HasHazard, HasAmplify, HasVictory, EncounterCard):
    __annotations__ = {}
    VILLAIN_SCHEME = {}
    VILLAIN_SCHEME: Dict[(str, str)]
    @override
    def __init__(self, paper: Paper):
        self
        self
        super().__init__(paper)
    @override
    def OnWhenCardRevealed(self, revealed_message: Message.WhenCardRevealed):
        if not (self.IsInPlay()):
            self.PutIntoPlay(revealed_message.GetToPlayer(), revealed_message.by_effect)
        return super().OnWhenCardRevealed(revealed_message)
    @override
    def OnPutIntoPlay(self, message: Message.WhenCardPutIntoPlay) -> bool:
        from game.operate.faces import Faces
        if not (self.card.area.flags.is_villain_area):
            scenario = self.GetControlByOrOwner()
            if Scenario.IsType(scenario):
                self.SetEncounterDeck(scenario.encounter_deck)
                area_villain = scenario.area_villain
                Faces.MoveAllTo([self], area_villain, message.by_effect)
        return super().OnPutIntoPlay(message)
    @override
    def OnBeDefeated(self, would_defeated_message, *, as_asset, ignore_when_defeated):
        super().OnBeDefeated(would_defeated_message, as_asset=as_asset, ignore_when_defeated=ignore_when_defeated)
        if not (self.IsInPlay()):
            if self.card.area.flags.is_victory_display:
                self.Advance(would_defeated_message.by_effect)
                return
        self.Advance(would_defeated_message.by_effect)
    @staticmethod
    def GetGuardFaces(effect):
        if effect.initiator.IsPlayer():
            return [minion for minion in effect.GetInitiator().GetEngagedMinions() if minion.IsGuard()]
        return []
    @override
    def CanBeAttackBy(self, effect):
        if not (effect.IsIgnoreKeyword('Guard', effect)):
            if (type(effect.initiator) is Player):
                for minion in effect.GetInitiator().GetEngagedMinions():
                    if minion.IsGuard():
                        return False
        return super().CanBeAttackBy(effect)
    @override
    def GetBoostCardNum(self, message):
        return 1
    @override
    def TakeDamageWithOverkillTarget(self, source, property, by_effect, would_attack_unit_message = None, overkill_target = None, *, from_atk_message = None, operation = None):
        ignore_guard = False
        guard_faces = []
        if by_effect.IsIgnoreKeyword('Guard', by_effect):
            guard_faces = Villain.GetGuardFaces(by_effect)
            if guard_faces:
                ignore_guard = True
        ret_value = super().TakeDamageWithOverkillTarget(source, property, by_effect, would_attack_unit_message, from_atk_message=from_atk_message, operation=operation)
        if ignore_guard:
            ignore_message = Message.AfterIgnoreKeywordOnCard(source, guard_faces, 'Guard')
            ignore_message.Send()
        return ret_value
    def Advance(self, by_effect: 'Effect', to_villain: 'Villain|None'= None, move_old_villain_to: Deck|None = None):
        scenario = self.GetControlByOrOwner()
        if Scenario.IsType(scenario):
            scenario.AdvanceVillainStage(self, by_effect, to_villain, move_old_villain_to)
            return
    def SetActive(self, by_effect: 'Effect'):
        from game.operate.faces import Faces
        from game.operate.worlds import Worlds
        for other_villain in Worlds.GetVillains(by_effect):
            if (other_villain != self):
                if other_villain.IsActive():
                    Faces.RemoveCountersOn([other_villain], 1, 'active', by_effect)
        if not (self.IsActive()):
            Faces.PlaceCountersOn([self], 1, 'active', by_effect)
            return
    def IsActive(self):
        return (self.GetCounters('active') > 0)
    def FindCorrespondingScheme(self) -> Scheme2|None:
        from game.operate.worlds import Worlds
        scheme = None
        if (self.name in Villain.VILLAIN_SCHEME):
            name = Villain.VILLAIN_SCHEME[self.name]
            faces = Worlds.GetOnFieldCards(self.card.game_area)
            schemes = CardFinder(name=name).Checks2(faces, Scheme2)
            if schemes:
                scheme = schemes[0]
        return scheme
    def SetEncounterDeck(self, deck: Deck):
        self.encounter_deck = deck
        if not (deck.bind_discard_pile):
            raise AssertionError
        self.encounter_discard_pile = deck.bind_discard_pile
        if (self == self.card.face):
            for face in self.card.back_faces:
                if Villain.IsType(face):
                    face.SetEncounterDeck(deck)
    def ChangeToFace(self, card_face, by_effect):
        return self.DefaultChangeToFace(card_face, by_effect)
    def ChangeToForm(self, to_trait: CardFace.TRAITS, by_effect: 'Effect'):
        finder = CardFinder2(to_trait)
        return self.DefaultChangeToForm(finder, by_effect)
    def IsFinalStage(self, effect):
        if effect.world.GetScenario().villain_deck.FindCard(name=self.name):
            return False
        return True
