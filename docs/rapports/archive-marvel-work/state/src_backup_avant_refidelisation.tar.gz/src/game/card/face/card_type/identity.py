# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.ability.factory import *
from game.message import *
from game.player import *
from cards.paper import Paper
from game.element.damage_property import DamageProperty
class Identity(Friend, HasHandSize, PlayerCard):
    @override
    def __init__(self, paper: Paper):
        super().__init__(paper)
    @override
    def GetAbilities(self):
        abilities = []
        resources_abilities = self.ability.Find(func_name='CanGenerateResources')
        if not ((len(resources_abilities) <= 1)):
            raise AssertionError
        if resources_abilities:
            if not (self.ability.Find(func_name='DoGenerateResources')):
                name = resources_abilities[0].name
                abilities.append(AbilityFactory.DoGenerateResources(resources_abilities[0].second_type, 'This').SetName(name))
        return (abilities + super().GetAbilities())
    @override
    def OnBeDefeated(self, would_defeated_message, *, as_asset, ignore_when_defeated):
        self.GetControlByPlayer().Eliminate(would_defeated_message.by_effect)
        return super().OnBeDefeated(would_defeated_message, as_asset=as_asset, ignore_when_defeated=ignore_when_defeated)
    @override
    def GetInfoDict(self):
        player = self.GetControlByPlayer()
        return (super().GetInfoDict() | {'ally_limit': player.limit_ally.Get(), 'curr_ally_limit': player.limit_ally.curr_ally, 'restricted_limit': player.limit_restricted.Get(), 'curr_restricted_limit': player.limit_restricted.curr_restricted})
    @override
    def OnPutIntoPlay(self, message: Message.WhenCardPutIntoPlay) -> bool:
        from game.operate.faces import Faces
        if Faces.MoveAllTo([self], message.GetToPlayer().area_hero, message.by_effect):
            return super().OnPutIntoPlay(message)
        return False
    def GetAlterEgoFace(self) -> 'AlterEgo':
        for face in ([self] + self.card.back_faces):
            if AlterEgo.IsType(face):
                face
                return
        raise AssertionError(f'self={self!r}')
    def GetHeroFace(self) -> 'Hero':
        for face in ([self] + self.card.back_faces):
            if Hero.IsType(face):
                face
                return
        raise AssertionError(f'self={self!r}')
    def ChangeToFace(self, card_face, by_effect):
        return self.DefaultChangeToFace(card_face, by_effect)
    def ChangeToForm(self, to_type, by_effect):
        if not (isinstance(to_type, CardFinder)):
            finder = CardFinder(card_type=to_type)
        else:
            finder = to_type
        return self.DefaultChangeToForm(finder, by_effect)
    def ChangeToOtherIdentityForm(self, by_effect: Effect):
        if Hero.IsType(self):
            to_form = AlterEgo
        else:
            to_form = Hero
        self.ChangeToForm(to_form, by_effect)
    def ChangeToOtherHeroForm(self, by_effect: Effect):
        for face in self.card.back_faces:
            if Hero.IsType(face):
                if (face != self):
                    self.ChangeToFace(face, by_effect)
                    return
        raise AssertionError(f'self={self!r} by_effect={by_effect!r}')
    def ChangeToOtherForm(self, by_effect: Effect):
        player = self.GetControlByPlayer()
        face = player.AskChooseOneText([x.name for x in self.card.back_faces])
        self.ChangeToForm(CardFinder(name=face), by_effect)
    def SetActive(self, by_effect: Effect):
        for other_player in [x.GetIdentity() for x in self.card.world.const_players]:
            if (other_player != self):
                if other_player.IsActive():
                    other_player.RemoveTokensInternal(1, 'first_player_token', by_effect)
        if not (self.IsActive()):
            from engine import Engine
            if Engine.game.session.version.IsFirstPlayerToken():
                self.PlaceTokensInternal(1, 'first_player_token', by_effect)
                return
                return
    def IsActive(self):
        return (self.GetTokens('first_player_token') > 0)
    def ChangeAdditionalFrom(self, by_effect, action):
        if not (isinstance(self, (AlterEgo | Hero))):
            raise AssertionError
        message = Message.WhenUnitWouldChangeForm(self, self, True, by_effect)
        message.Send()
        if message.is_be_instead:
            return False
        additional_from = action()
        after_message = Message.AfterUnitChangeForm(self, additional_from, by_effect, message)
        after_message.Send()
        return True
@final
class AlterEgo(HasRecover, CanRecover, CanThwart, Identity, FinalType):
    @override
    def __init__(self, paper: Paper):
        super().__init__(paper)
    @override
    def GetAbilities(self):
        return ([AbilityFactory.ThisCanRecover()] + super().GetAbilities())
    @override
    def OnDealDamage(self, units, damage, by_effect, *, property = None, attack_in_event):
        if self.IsDefeated():
            return
        return CanAttack.OnDealDamageInternal(self, units, damage, by_effect, property=property, attack_in_event=attack_in_event)
@final
class Hero(HasThwart, CanThwart, HasAttack, CanAttack, HasDefense, CanDefense, HasAccelerationIcon, Identity, FinalType):
    @override
    def __init__(self, paper: Paper):
        super().__init__(paper)
    @override
    def GetAbilities(self):
        abilities = []
        if not (self.ability.Find(func_name='ATK')):
            abilities.append(AbilityFactory.ThisCanAttack())
        if not (self.ability.Find(func_name='THW')):
            abilities.append(AbilityFactory.ThisCanThwart())
        if not (self.ability.Find(func_name='DEF')):
            abilities.append(AbilityFactory.ThisCanDefense())
        return (abilities + super().GetAbilities())
