# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Boostable(Component):
    @override
    def __init__(self, card: Card):
        super().__init__(card)
        self.deck = Deck2(self.parent, DeckType.BoostCardsDeck, CardFace)
    @override
    def OnDiscard(self, by_effect):
        return (self.deck.GetAll() + super().OnDiscard(by_effect))
    def GiveBoostCard(self, face, by_effect):
        from game.operate.faces import Faces
        return (Faces.MoveAllTo([face], self.deck, by_effect) != [])
    def GetDeck(self) -> Deck2[CardFace]:
        return self.deck
