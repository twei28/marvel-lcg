# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Counter(Component):
    @override
    def __init__(self, card: Card):
        self.counters = {}
        super().__init__(card)
    @override
    def OnParentReset(self):
        self.counters = {}
        return super().OnParentReset()
    def GetAllCounters(self):
        value = 0
        for key in self.counters:
            value = (value + self.counters[key])
        return value
    def SetCounters(self, counters, name):
        if (name in self.counters):
            self.counters[name] = counters
            return
        self.counters = (self.counters | {name: counters})
    def GetCounters(self, name):
        if (name in self.counters):
            return self.counters[name]
        return 0
    def PlaceCounters(self, counters, name):
        self.SetCounters((counters + self.GetCounters(name)), name)
        return True
    def RemoveCounters(self, counters, name, forced):
        if (name in self.counters):
            if (counters == 'All'):
                self.counters[name] = 0
                return True
            if not (forced):
                if (self.counters[name] >= counters):
                    self.counters[name] = (self.counters[name] - counters)
                    if (self.counters[name] < 0):
                        self.counters[name] = 0
                    return True
            self.counters[name] = (self.counters[name] - counters)
            if (self.counters[name] < 0):
                self.counters[name] = 0
            return True
            return False
        return False
    def GetCounterNames(self):
        return list(self.counters.keys())
