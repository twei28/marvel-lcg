# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class CanAccelerationToken(CanPlaceToken):
    @override
    def OnAfterCardLeavePlay(self, message: Message.AfterCardLeavePlay):
        self.RemoveTokensInternal('All', 'acceleration_token', message.by_effect)
        return super().OnAfterCardLeavePlay(message)
    @final
    @property
    def acceleration_token(self):
        return self.GetTokens('acceleration_token')
    @final
    def PlaceAccelerationToken(self, num, by_effect):
        return self.PlaceTokensInternal(num, 'acceleration_token', by_effect)
