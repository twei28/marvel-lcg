# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from game.card.face.base import *
from game.card.face import *
from game.card import *
from game.ability import *
from game.message import *
from cards.paper import Paper
class Asset2(CanAttach, CardFace):
    @override
    def __init__(self, paper: Paper):
        super().__init__(paper)
    @override
    def OnBeforeFlip(self, by_effect, no_detach = False):
        super().OnBeforeFlip(by_effect, no_detach=no_detach)
        if self.IsInPlay():
            if not ((self.bind_face != None)):
                raise AssertionError
                return
    @override
    def IsDefeated(self):
        return ((self.bind_face == None) or super().IsDefeated())
    def CanAttachTo(self, face):
        def check_max_per_unit():
            this = self.CastTo(HasMaxPer)
            return (face.GetInventoryDeck().FindCardSize(CardFinder(name=this.name, card_type=type(this))) < this.max_per_unit)
        return check_max_per_unit()
