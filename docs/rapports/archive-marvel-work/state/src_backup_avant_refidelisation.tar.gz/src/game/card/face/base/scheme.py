# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face.base import *
from game.card.face import *
from game.deck import *
from game.ability import *
from game.message import *
from cards.paper import Paper
class Scheme2(HasAmplify, HasHazard, CanHinder, CanPlaceCounter, HasAssault, HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.start_threat = 0
        self.corresponding_villain_name = None
        super().__init__(paper)
        self.RegisterAttribute('StartingThreat', 'start_threat')
        def parse(value):
            self.corresponding_villain_name = value
            from game.card.face.base import Villain
            Villain.VILLAIN_SCHEME[value] = self.name
        self.RegisterAttribute('CorrespondingCard', parse)
    @override
    def CheckPrintedValue(self):
        if not ((self.start_threat >= 0)):
            raise AssertionError
        return super().CheckPrintedValue()
    @override
    def OnWouldEnterPlay(self, into_area):
        self.ResetStartThreat()
        return super().OnWouldEnterPlay(into_area)
    def ResetStartThreat(self, *, by_flip = False):
        from game.effect.rule import ResetKeyword
        start_threat = self.start_threat
        if by_flip:
            start_threat = (start_threat + self.threat)
        self.SetTokens(start_threat, 'threat', ResetKeyword(self))
    @override
    def OnFlip(self, by_effect: 'Effect', origin_face: CardFace|None):
        if self.IsInPlay():
            self.ResetStartThreat(by_flip=True)
        return super().OnFlip(by_effect, origin_face)
    @override
    def OnBeDefeated(self, would_defeated_message, *, as_asset, ignore_when_defeated):
        from game.operate.faces import Faces
        being_message = would_defeated_message.being_message
        by_effect = would_defeated_message.by_effect
        killer = would_defeated_message.killer
        if not (isinstance(would_defeated_message, Message.WhenSchemeWouldBeDefeated)):
            raise AssertionError
        if (being_message != None):
            if not ((type(being_message) is Message.WhenSchemeBeingThwart)):
                raise AssertionError
        defeated_message = Message.WhenSchemeBeDefeated(self, would_defeated_message, ignore_when_defeated)
        defeated_message.Send()
        super().OnBeDefeated(would_defeated_message, as_asset=as_asset, ignore_when_defeated=ignore_when_defeated)
        if self.IsInPlay():
            Faces.DiscardAll([self], by_effect)
        after_defeated_message = Message.AfterSchemeBeDefeated(self, by_effect, defeated_message)
        after_defeated_message.Send()
        if not (killer):
            killer = by_effect.this
        unit_defeated_message = Message.AfterUnitDefeatedScheme(killer, self, by_effect)
        unit_defeated_message.Send()
    @override
    def OnWhenCardRevealed(self, revealed_message: Message.WhenCardRevealed):
        player = revealed_message.GetToPlayer()
        if self.PutIntoPlay(player, revealed_message.by_effect):
            return super().OnWhenCardRevealed(revealed_message)
    @override
    def OnWouldDefeated(self, killer: CardFace|None, by_effect: 'Effect', being_message: Message.WhenSchemeBeingThwart|Message.WhenUnitBeingAttack|None) -> Message.WhenSchemeWouldBeDefeated|Message.WhenUnitWouldBeDefeated|None:
        if not (isinstance(being_message, (Message.WhenSchemeBeingThwart | None))):
            raise AssertionError
        would_defeated_message = Message.WhenSchemeWouldBeDefeated(self, by_effect, killer, being_message)
        would_defeated_message.Send()
        return would_defeated_message
    @override
    def PlaceTokensInternal(self, value, name, by_effect):
        if (name == 'threat'):
            message = self.PlaceThreatInternal(value, by_effect)
            if message:
                return message.value
            return
        return super().PlaceTokensInternal(value, name, by_effect)
    def PlaceThreatInternal(self, value, by_effect, sch_message = None):
        from game.message import Message
        from game.operate.worlds import Worlds
        value = Worlds.ConvertPerPlayerIconToInt(value, by_effect)
        message = Message.WhenSchemeWouldPlaceThreat(self, value, by_effect, sch_message)
        message.Send()
        if not (message.is_be_instead):
            if (message.value > 0):
                super().PlaceTokensInternal(message.value, 'threat', by_effect)
                after_message = Message.AfterSchemePlaceThreat(self, message.value, by_effect, message)
                after_message.Send()
                return after_message
    @override
    def RemoveTokensInternal(self, value, name, by_effect, forced = None):
        if (name == 'threat'):
            return self.RemoveThreatInternal(by_effect.this, value, by_effect)
        return super().RemoveTokensInternal(value, name, by_effect, forced)
    def RemoveThreatInternal(self, by_face, value, by_effect, thw_message = None):
        from game.message import Message
        from game.card.face.card_type import MainScheme
        from game.operate.worlds import Worlds
        if (self.threat > 0):
            if (value == 'All'):
                value = self.threat
            else:
                value = Worlds.ConvertPerPlayerIconToInt(value, by_effect)
        return 0
    def MoveThreat(self, value, by_effect, target):
        value = self.RemoveThreatInternal(self, value, by_effect)
        self.PlaceThreatOnSchemes(target, value, by_effect)
        return value
    @property
    def threat(self):
        return self.GetTokens('threat')
    def CanBeThwartBy(self, effect):
        if (self.threat == 0):
            return False
        check_message = Message.CheckIfSchemeCanBeThwartBy(self, effect)
        check_message.Send()
        return check_message.can_be_thwart
    def FindCorrespondingVillain(self) -> 'Villain|None':
        from game.card.face.base import Villain
        from game.operate.worlds import Worlds
        faces = Worlds.GetOnFieldCards(self.card.game_area)
        villains = CardFinder(name=self.corresponding_villain_name).Checks2(faces, Villain)
        if villains:
            return villains[0]
