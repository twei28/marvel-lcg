# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class CanPlaceToken(CardFace):
    @final
    def GetAllTokens(self):
        return self.components.token.GetAllTokens()
    @final
    def SetTokens(self, counters, name, by_effect):
        return self.components.token.SetTokens(counters, name)
    @final
    def GetTokens(self, name):
        return self.components.token.GetTokens(name)
    def PlaceTokensInternal(self, value, name, by_effect):
        from game.message import Message
        from game.operate.worlds import Worlds
        value = Worlds.ConvertPerPlayerIconToInt(value, by_effect)
        would_message = Message.WhenCardWouldBePlacedToken(self, value, name, by_effect)
        would_message.Send()
        if would_message.is_be_instead:
            return
        value = would_message.num
        self.components.token.PlaceTokens(value, name)
        placed_message = Message.AfterCardPlacedToken(self, value, name, by_effect, would_message)
        placed_message.Send()
        return placed_message.num
    def RemoveTokensInternal(self, value, name, by_effect, forced = None):
        counter_num = self.components.token.GetTokens(name)
        if (value != 'All'):
            from game.operate.worlds import Worlds
            value = Worlds.ConvertPerPlayerIconToInt(value, by_effect)
        if (forced == None):
            forced = True
        would_message = Message.WhenCardWouldRemovedToken(self, value, name, by_effect)
        would_message.Send()
        if would_message.is_be_instead:
            return
        if would_message.remove_all:
            value = 'All'
        else:
            if not (would_message.would_remove):
                raise AssertionError
            value = would_message.would_remove
        if self.components.token.RemoveTokens(value, name, forced):
            diff = (counter_num - self.components.token.GetTokens(name))
            after_message = Message.AfterCardRemovedToken(self, diff, would_message)
            after_message.Send()
            return after_message.removed_num
    @final
    def RemoveAllTokens(self, by_effect):
        size = 0
        for name in self.components.token.GetTokenNames():
            num = self.RemoveTokensInternal(Math.INT_INF, name, by_effect, forced=True)
            if num:
                size = (size + num)
        return size
    @override
    def GetInfoDict(self):
        the_dict = {}
        for key in self.components.token.GetTokenNames():
            token = self.GetTokens(key)
            key_name = ('k_' + key)
            the_dict = (the_dict | {key_name: token})
        return (the_dict | super().GetInfoDict())
