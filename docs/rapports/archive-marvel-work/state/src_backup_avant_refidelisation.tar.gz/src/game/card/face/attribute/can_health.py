# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasHealth(HasAttribute, CanAttacked):
    @override
    def __init__(self, paper: Paper):
        self.printed_health = -1
        self.printed_health_numeral = -1
        self.starting_health = -1
        self.is_infinite_health = False
        self.considered_at_least_hp_dict = {}
        self.base_health = 0
        super().__init__(paper)
        def parse(value):
            if (value == 'INF'):
                self.is_infinite_health = True
                self.printed_health = 0
                self.printed_health_numeral = 0
            else:
                self.printed_health = self.FormatPlayerNumValue(value)
                digit = ''.join((ch for ch in value if ch.isdigit()))
                self.printed_health_numeral = int(digit)
            self.starting_health = self.printed_health
        self.RegisterAttribute('HP', parse)
        self.RegisterInfoDict('health')
        self.RegisterInfoDict('is_infinite_health')
    @override
    def CheckPrintedValue(self):
        if not (self.is_infinite_health):
            if not ((self.printed_health >= 0)):
                raise AssertionError(f'self.paper.card_id={self.paper.card_id!r}')
        return super().CheckPrintedValue()
    @final
    @property
    def health(self):
        def get_health():
            if self.is_infinite_health:
                return 1
            return self.components.health.GetHealth()
        health = get_health()
        considered_at_least_hp = self.considered_at_least_hp
        if considered_at_least_hp:
            if (health < considered_at_least_hp):
                return considered_at_least_hp
        return health
    @final
    @property
    def considered_at_least_hp(self):
        health = 0
        for effect in self.considered_at_least_hp_dict:
            if (health < self.considered_at_least_hp_dict[effect]):
                health = self.considered_at_least_hp_dict[effect]
        return health
    @final
    @property
    def max_health(self):
        if self.is_infinite_health:
            return 0
        return self.components.health.GetMaxHealth()
    @final
    @property
    def sustained(self):
        if self.is_infinite_health:
            return 0
        return (self.max_health - self.health)
    @final
    @property
    def is_full_heath(self):
        if self.is_infinite_health:
            return True
        return (self.sustained == 0)
class CanHealth(HasHealth):
    @override
    def OnFlip(self, by_effect: Effect, origin_face: CardFace|None):
        from game.effect.rule import ResetKeyword
        from game.card.face.base import Unit2
        self.base_health = self.printed_health
        self.considered_at_least_hp_dict = {}
        if origin_face:
            if Unit2.IsType(origin_face):
                if origin_face:
                    if origin_face.is_infinite_health:
                        self.ResetHealth(ResetKeyword(self))
        if origin_face:
            if origin_face.is_infinite_health:
                self.ResetHealth(ResetKeyword(self))
        return super().OnFlip(by_effect, origin_face)
    @override
    def OnReset(self, message: Message.WhenCardReset_Text):
        self.components.health.SetHealth(0)
        self.components.health.SetMaxHealth(0)
        return super().OnReset(message)
    @final
    def ResetHealth(self, by_effect, num = 'Max'):
        from game.card.face.base import Unit2
        from game.operate.worlds import Worlds
        self.base_health = self.printed_health
        self.components.health.SetMaxHealth(self.base_health)
        self.considered_at_least_hp_dict = {}
        if not (isinstance(num, int)):
            if not ((self.card.face == self)):
                raise AssertionError
        if (num == 'Printed'):
            health_max = self.printed_health
        else:
            if (num == 'Max'):
                health_max = self.max_health
            else:
                health_max = Worlds.ConvertPerPlayerIconToInt(num, by_effect)
        self.components.health.SetHealth(health_max)
        if not (Unit2.IsType(self)):
            raise AssertionError
        reset_message = Message.AfterUnitHitPointReset(self, by_effect)
        reset_message.Send()
    @final
    def MoveDamage(self, damage, target, by_effect):
        lost_heath = self.GetLostHealth()
        if (lost_heath < damage):
            damage = lost_heath
        if (damage != 0):
            self.HealHealth(damage, by_effect)
            if by_effect.ability.IsLabel('attack'):
                self.DealDamage([target], damage, by_effect)
                return
            target.TakeDamage(self, damage, by_effect)
            return
    @final
    def HealHealth(self, value, by_effect):
        if not (self.IsInPlay()):
            return
        if (value == 'All'):
            value = self.sustained
        else:
            if (value == 'Printed'):
                value = (self.printed_health - self.health)
        message = self.GainOnlyHealth(value, by_effect)
        if isinstance(message, Message.AfterUnitHealHealth):
            return message
    @final
    def TakeIndirectDamage(self, source, damage, by_effect, *, from_atk_message = None, as_group = False, operation = None):
        from game.operate.worlds import Worlds
        player = self.GetControlByPlayer()
        if as_group:
            units = Worlds.GetOnFieldFriendlyCharacters(by_effect)
        else:
            units = ([player.GetIdentity()] + player.GetControlAllies())
        return player.AssignDamage(units, source, damage, by_effect, operation=operation, from_atk_message=from_atk_message)
    @override
    def TakeDamage(self, source, property, by_effect, would_attack_unit_message = None, *, from_atk_message = None, operation = None):
        messages = self.TakeDamageWithOverkillTarget(source, property, by_effect, would_attack_unit_message, from_atk_message=from_atk_message, operation=operation)
        if messages:
            return messages[0]
    @override
    def TakeDamageWithOverkillTarget(self, source, property, by_effect, would_attack_unit_message = None, overkill_target = None, *, from_atk_message = None, operation = None):
        from game.card.face.base import Unit2
        return_messages = []
        lost_message_overkill_helper = None
        lost_message_helper = self.TakeDamageNoDeath(source, property, by_effect, would_attack_unit_message, from_atk_message=from_atk_message, operation=operation)
        excess_damage = 0
        if (lost_message_helper != None):
            if lost_message_helper.lost_message:
                total_took_damage = lost_message_helper.lost_message.value
            else:
                total_took_damage = 0
            excess_damage = lost_message_helper.excess_damage
            if overkill_target:
                if excess_damage:
                    lost_message_overkill_helper = overkill_target.TakeDamageNoDeath(source, DamageProperty(damage=excess_damage, is_from_overkill=True), by_effect, would_attack_unit_message, from_atk_message=from_atk_message)
            units = []
            if self.IsInPlay():
                if Unit2.IsType(self):
                    units.append(self)
            if overkill_target:
                if overkill_target.IsInPlay():
                    if excess_damage:
                        units.append(overkill_target)
            world = self.card.world
            first_player = world.GetFirstPlayer()
            if units:
                if not (units):
                    pass
                else:
                    sorted_units = first_player.ChooseOrder(units, prompt='Simultaneous Overkill')
                    unit = sorted_units[0]
                    if unit:
                        if lost_message_overkill_helper:
                            if lost_message_overkill_helper.lost_message:
                                if (lost_message_overkill_helper.lost_message.trigger == unit):
                                    would_take_damage_message = lost_message_overkill_helper.would_take_damage_message
                                else:
                                    would_take_damage_message = lost_message_helper.would_take_damage_message
                            else:
                                would_take_damage_message = lost_message_helper.would_take_damage_message
                        else:
                            would_take_damage_message = lost_message_helper.would_take_damage_message
                        units.remove(unit)
                        if (unit.health <= 0):
                            if unit.Death(source, by_effect, would_attack_unit_message):
                                if would_attack_unit_message:
                                    would_attack_unit_message.would_atk_message.has_defeated_target = True
                                if unit.IsInPlay():
                                    took_damage_message = Message.AfterUnitTookDamage(unit, source, (total_took_damage - excess_damage), by_effect, would_take_damage_message, excess_damage=excess_damage)
                                    took_damage_message.Send()
                                    if operation:
                                        operation(took_damage_message)
                                message = Message.AfterUnitDefeatedUnit(source, unit, total_took_damage, excess_damage, overkill_target, by_effect, would_take_damage_message)
                                message.Send()
                                return_messages.append(message)
                            else:
                                if not (overkill_target):
                                    damage = total_took_damage
                                else:
                                    if (unit == overkill_target):
                                        damage = excess_damage
                                    else:
                                        damage = (total_took_damage - excess_damage)
                                took_damage_message = Message.AfterUnitTookDamage(unit, source, damage, by_effect, would_take_damage_message, excess_damage=0)
                                took_damage_message.Send()
                                if operation:
                                    operation(took_damage_message)
                                return_messages.append(took_damage_message)
                        else:
                            if not (overkill_target):
                                damage = total_took_damage
                            else:
                                if (unit == overkill_target):
                                    damage = excess_damage
                                else:
                                    damage = (total_took_damage - excess_damage)
                            took_damage_message = Message.AfterUnitTookDamage(unit, source, damage, by_effect, would_take_damage_message, excess_damage=0)
                            took_damage_message.Send()
                            if operation:
                                operation(took_damage_message)
                            return_messages.append(took_damage_message)
                    # backward conditional jump to 194: units
        if lost_message_helper:
            if (lost_message_helper.would_take_damage_message.would_deal_damage_message.damage > 0):
                after_damage_message = Message.AfterFaceDealDamage(lost_message_helper.would_take_damage_message.would_deal_damage_message, return_messages, by_effect)
                after_damage_message.Send()
        return return_messages
    @final
    def TakeDamageNoDeath(self, source, property, by_effect, would_attack_unit_message = None, *, from_atk_message = None, operation = None):
        from game.card.face.base import Unit2
        if not (Unit2.IsType(self)):
            raise AssertionError
        this = self
        if this.IsDefeated():
            return
        if isinstance(property, int):
            property = DamageProperty(property)
        if (from_atk_message == None):
            if (would_attack_unit_message != None):
                from_atk_message = would_attack_unit_message.would_atk_message
        would_deal_damage_message = Message.WhenFaceWouldDealDamage(source, this, property, by_effect, would_attack_unit_message, from_atk_message)
        would_deal_damage_message.Send()
        if not ((property.damage == would_deal_damage_message.damage)):
            raise AssertionError
        if would_deal_damage_message.is_be_instead:
            return
        if (property.damage <= 0):
            Message.WhenDamageIsZero_Text(this, source, True)
            return
        would_take_damage_message = Message.WhenUnitWouldTakeDamage(this, source, property, by_effect, would_deal_damage_message)
        would_take_damage_message.Send()
        if would_take_damage_message.is_be_instead:
            return
        if would_attack_unit_message:
            if not (source.IsInPlay()):
                return
        value = would_take_damage_message.will_take_damage
        if not ((value == 0)):
            if would_take_damage_message.IsBePrevent():
                excess_damage = would_take_damage_message.overkill_damage
                return Message.AfterUnitLossHealthHelper(None, would_take_damage_message, excess_damage)
        excess_damage = would_take_damage_message.overkill_damage
        return Message.AfterUnitLossHealthHelper(None, would_take_damage_message, excess_damage)
        if not (would_take_damage_message.IsBePrevent()):
            excess_damage = 0
            if not (this.IsInPlay()):
                raise AssertionError
            max_sustained = would_take_damage_message.cannot_have_more_than_sustained
            damage_message = this.UpdateHealth((-1 * value), by_effect, max_sustained=max_sustained)
            if damage_message:
                if (this.health < 0):
                    deal_message = Message.WhenCalcDealExcessDamage(source, this, (-1 * this.health), by_effect, would_attack_unit_message)
                    deal_message.Send()
                    excess_damage = deal_message.excess_damage
            if isinstance(damage_message, Message.AfterUnitLossHealth):
                return Message.AfterUnitLossHealthHelper(damage_message, would_take_damage_message, excess_damage)
            return
    @final
    def CanHeath(self):
        return (self.GetLostHealth() > 0)
    @final
    def GetLostHealth(self):
        return (self.max_health - self.health)
    @override
    def IsDefeated(self):
        return ((self.health <= 0) or super().IsDefeated())
    @final
    def SetHealth(self, value, by_effect):
        from game.card.face.base import Unit2
        self.components.health.SetHealth(value)
        if not (self.is_infinite_health):
            if not ((self.health <= self.max_health)):
                raise AssertionError(f'self.health={self.health!r} self.max_health={self.max_health!r}')
        self.LimitHealth(by_effect)
        if Unit2.IsType(self):
            message = Message.AfterUnitHitPointSet(self, by_effect)
            message.Send()
            return
    @final
    def GainHealth(self, value, by_effect):
        if self.card.state.is_flipping:
            self.GainOnlyMaxHealth(value, by_effect)
            return
        self.GainHealthAndMaxHealth(value, by_effect)
    @final
    def GainOnlyMaxHealth(self, value, by_effect):
        self.UpdateMaxHealth(value, by_effect)
    @final
    def GainOnlyHealth(self, value, by_effect):
        message = self.UpdateHealth(value, by_effect)
        self.LimitHealth(by_effect)
        return message
    @final
    def GainHealthAndMaxHealth(self, value, by_effect):
        if (value > 0):
            self.GainOnlyMaxHealth(value, by_effect)
            self.GainOnlyHealth(value, by_effect)
            return
        self.GainOnlyHealth(value, by_effect)
        self.GainOnlyMaxHealth(value, by_effect)
    @final
    def SetBaseHealth(self, value, by_effect):
        if (self.base_health != value):
            diff = (value - self.base_health)
            self.base_health = value
            self.UpdateMaxHealth(diff, by_effect)
            self.GainOnlyMaxHealth(diff, by_effect)
            self.GainOnlyHealth(diff, by_effect)
            return
    @final
    def UpdateMaxHealth(self, value, by_effect):
        self.components.health.AddMaxHealth(value)
    @final
    def UpdateHealth(self, value, by_effect, *, max_sustained = None):
        from game.card.face.base import Unit2
        if not (self.IsInPlay()):
            return
        if not (Unit2.IsType(self)):
            raise AssertionError
        def limit_health(health):
            if (max_sustained != None):
                if ((self.max_health - health) > max_sustained):
                    health = (self.max_health - max_sustained)
            return health
        if (value == 0):
            return
        if (value > 0):
            health = min(self.max_health, (self.health + int(value)))
            health = limit_health(health)
            value = (health - self.health)
            if (value > 0):
                message = Message.WhenUnitHealHealth(self, value, by_effect)
                message.Send()
                self.components.health.AddHealth(value)
                after_message = Message.AfterUnitHealHealth(self, value, by_effect, message)
                after_message.Send()
                return after_message
            return
        message = Message.WhenUnitLossHealth(self, (-1 * value), by_effect)
        message.Send()
        health = (self.health + int(value))
        health = limit_health(health)
        self.components.health.SetHealth(health)
        after_message = Message.AfterUnitLossHealth(self, (-1 * value), message)
        after_message.Send()
        return after_message
    @final
    def LimitHealth(self, by_effect, check_death = True):
        from game.card.face.base import Unit2
        if not (Unit2.IsType(self)):
            raise AssertionError
        if self.is_infinite_health:
            return
        if (self.health > self.max_health):
            self.SetHealth(self.max_health, by_effect)
            return
        if (self.health <= 0):
            if self.IsInPlay():
                if check_death:
                    if not (self.card.state.is_leaving_play):
                        self.Death(None, by_effect)
                        return
                        return
                        return
                        return
    @final
    def GainConsideredAtLeastHP(self, diff, by_effect):
        from game.card.face.base import Unit2
        if (by_effect not in self.considered_at_least_hp_dict):
            self.considered_at_least_hp_dict[by_effect] = 0
        self.considered_at_least_hp_dict[by_effect] = (self.considered_at_least_hp_dict[by_effect] + diff)
        if (self.health < 0):
            self.Defeated(None, by_effect)
        message = Message.AfterUnitHitPointSet(self.CastTo(Unit2), by_effect)
        message.Send()
