# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
CONFUSED_FINDER = CardFinder(name='Confused')
STUNNED_FINDER = CardFinder(name='Stunned')
TOUGH_FINDER = CardFinder(name='Tough')
class Status(Component):
    @override
    def __init__(self, card: Card):
        from game.deck import Deck2
        from game.deck import DeckType
        super().__init__(card)
        self.deck = Deck2(self.parent, DeckType.StatusArea, StatusCard)
    @property
    def confused(self):
        return self.deck.FindCardSize(CONFUSED_FINDER)
    @property
    def stunned(self):
        return self.deck.FindCardSize(STUNNED_FINDER)
    @property
    def tough(self):
        return self.deck.FindCardSize(TOUGH_FINDER)
    @override
    def OnParentReset(self):
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        Faces.DiscardAll(self.deck.GetAll(True), GameRule(self.parent.face))
    @override
    def OnDiscard(self, by_effect):
        self.deck.DiscardAll(by_effect)
        return super().OnDiscard(by_effect)
    def GiveStatusCard(self, name: CardFace.STATUS, by_effect: Effect) -> StatusCard:
        from game.card.factory import CardFactory
        card = CardFactory.GenerateCard(name, self.deck, world=by_effect.world)
        return card.face.CastTo(StatusCard)
    def DiscardStatusCard(self, name, by_effect, rule):
        from game.operate.faces import Faces
        this = self.parent.face.CastTo(Unit2)
        need_discard = Math.INT_INF
        if (rule == 'Steady'):
            if (name in ('Confused', 'Stunned')):
                if this.IsSteady():
                    need_discard = 2
                else:
                    need_discard = 1
                    need_discard = 1
                    if (rule == 'All'):
                        need_discard = Math.INT_INF
                    else:
                        need_discard = rule
            else:
                need_discard = 1
                if (rule == 'All'):
                    need_discard = Math.INT_INF
                else:
                    need_discard = rule
        else:
            if (rule == 'All'):
                need_discard = Math.INT_INF
            else:
                need_discard = rule
        status = self.deck.FindCards(name=name, card_type=StatusCard, max=need_discard)
        discard_size = len(Faces.DiscardAll(status, by_effect))
        return discard_size
    def GetStatusSize(self):
        return self.deck.GetSize()
    def GetDeck(self) -> Deck2[StatusCard]:
        return self.deck
