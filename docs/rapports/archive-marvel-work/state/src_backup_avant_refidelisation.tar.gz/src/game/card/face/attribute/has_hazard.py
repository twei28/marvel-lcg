# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasHazard(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_hazard = 0
        super().__init__(paper)
        self.RegisterAttribute('Hazard', 'printed_hazard')
        self.RegisterInfoDict('hazard')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainHazard(self.printed_hazard, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    @property
    def hazard(self):
        return self.GetKeyword('Hazard')
    @final
    def GainHazard(self, diff, by_effect):
        self.GainKeyword(diff, 'Hazard', by_effect)
    @final
    def SetIgnoreHazard(self, diff, by_effect):
        self.SetIgnoreKeyword(diff, 'Hazard', by_effect)
