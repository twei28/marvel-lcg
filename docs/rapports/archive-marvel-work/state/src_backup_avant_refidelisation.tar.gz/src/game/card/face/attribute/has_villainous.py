# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasVillainous(HasAttribute, CanBoost):
    @override
    def __init__(self, paper: Paper):
        self.printed_villainous = 0
        super().__init__(paper)
        self.RegisterAttribute('Villainous', 'printed_villainous')
        self.RegisterInfoDict('villainous')
    @override
    def GetBoostCardNum(self, message):
        if self.IsVillainous():
            return 1
        return 0
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainVillainous(self.printed_villainous, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsVillainous(self):
        return (self.villainous > 0)
    @final
    @property
    def villainous(self):
        return self.GetKeyword('Villainous')
    @final
    def GainVillainous(self, diff, by_effect):
        self.GainKeyword(diff, 'Villainous', by_effect)
