# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.card import *
from game.effect import *
class UIEffectBy:
    class UITypeSimple:
        def __init__(self, card: Card):
            self.card = card
            self.unavailable_by_faces = []
        def Get(self):
            return self.unavailable_by_faces
        def Add(self, *effect: Effect):
            self.unavailable_by_faces = (self.unavailable_by_faces + [x.this.card for x in effect])
        def Append(self, card: Card):
            self.unavailable_by_faces.append(card)
        def Remove(self, card: Card):
            self.unavailable_by_faces.remove(card)
        def Reset(self):
            self.unavailable_by_faces = []
    class UIType:
        def __init__(self, card: Card):
            self.card = card
            self.effected_faces = {}
        def Get(self):
            card_faces = []
            for cards in [self.effected_faces[x] for x in self.effected_faces]:
                if cards:
                    card_faces = (card_faces + cards)
            return card_faces
        def Add(self, effect: Effect, face: CardFace):
            if (self.card != face.card):
                if (effect in self.effected_faces):
                    self.effected_faces[effect].append(face.card)
                    return
                self.effected_faces[effect] = [face.card]
                return
        def Reset(self, effect: Effect|Literal["All"]):
            if (effect == 'All'):
                self.effected_faces = {}
                return
            self.effected_faces[effect] = []
    def __init__(self, card: Card):
        self.card = card
        self.temp = UIEffectBy.UIType(card)
        self.cost = UIEffectBy.UIType(card)
        self.effected_to = UIEffectBy.UITypeSimple(card)
        self.effected_by = UIEffectBy.UITypeSimple(card)
        self.unavailable = UIEffectBy.UITypeSimple(card)
        self.ResetEffectedBy(False)
    @final
    def GetEffectedByFaces(self):
        return ((([x.face for x in self.effected_by.Get()] + [x.face for x in self.unavailable.Get()]) + [x.face for x in self.temp.Get()]) + [x.face for x in self.cost.Get()])
    @final
    def GetEffectToFaces(self):
        return [x.face for x in self.effected_to.Get()]
    @final
    def SetEffectedBy(self, diff, effect):
        if (self.card.face != effect.this):
            if not ((diff != 0)):
                raise AssertionError
            if (diff > 0):
                self.effected_by.Append(effect.this.card)
                effect.this.card.ui.effected_to.Append(self.card)
                return
            if (effect.this.card in self.effected_by.Get()):
                self.effected_by.Remove(effect.this.card)
            if (self.card in effect.this.card.ui.effected_to.Get()):
                effect.this.card.ui.effected_to.Remove(self.card)
                return
                return
    @final
    def ResetEffectedBy(self, remove_relate = True):
        self.ResetTempEffectBy('All')
        self.cost.Reset('All')
        if remove_relate:
            for card in self.effected_by.Get():
                card.ui.effected_to.Remove(self.card)
            for card in self.effected_to.Get():
                card.ui.effected_by.Remove(self.card)
        self.effected_to.Reset()
        self.effected_by.Reset()
    @final
    def SetTempEffectBy(self, effect: Effect, face: CardFace):
        self.temp.Add(effect, face)
    @final
    def ResetTempEffectBy(self, effect: Effect|Literal["All"]):
        self.temp.Reset(effect)
