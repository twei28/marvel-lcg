# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from game.card.face import *
from game.effect import *
from game.player import *
from game.card.face.model.base import ModelBase
class ModelForm(ModelBase):
    def DefaultChangeToFace(self, to_form, by_effect):
        from game.card.face.base import Unit2
        from game.message import Message
        this = self.GetThis().CastTo(Unit2)
        if (this == to_form):
            return True
        if not (this.card.world.is_game_started):
            raise AssertionError
        would_message = Message.WhenUnitWouldChangeForm(this, to_form, False, by_effect)
        would_message.Send()
        if would_message.is_be_instead:
            return False
        if (to_form in this.card.back_faces):
            this.FlipTo(by_effect, card_face=to_form)
        else:
            this.FlipTo(by_effect, card_face=this.card.back_faces[0])
        after_message = Message.AfterUnitChangeForm(to_form, None, by_effect, would_message)
        after_message.Send()
        end_message = Message.AfterUnitChangeFormEnd(to_form, by_effect, after_message)
        end_message.Send()
        return True
    def DefaultChangeToForm(self, finder: 'CardFinder', by_effect: Effect):
        from game.card.face.base import Villain
        from game.player import Player
        this = self.GetThis()
        if finder.Check(this):
            return
        player = this.GetControlBy()
        if Player.IsType(player):
            faces = player.GetAllIdentityFace()
            faces = [face for face in faces if finder.Check(face)]
            if (len(faces) > 0):
                face_dict = {}
                for face in faces:
                    name = face.traits_str
                    face_dict[name] = face
                face_name = player.AskChooseOneText([x for x in face_dict])
                face = face_dict[face_name]
            else:
                face = faces[0]
        face = self.GetThis()
        for check_face in ([face] + face.card.back_faces):
            if finder.Check(check_face):
                if not (Villain.IsType(check_face)):
                    raise AssertionError
                this.DefaultChangeToFace(check_face, by_effect)
                return
        raise AssertionError(f'this={this!r} by_effect={by_effect!r}')
