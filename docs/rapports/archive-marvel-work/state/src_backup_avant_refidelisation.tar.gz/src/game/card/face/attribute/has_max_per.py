# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasMaxPer(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.max_per_unit = 256
        super().__init__(paper)
        self.RegisterAttribute('MaxPerUnit', 'max_per_unit')
