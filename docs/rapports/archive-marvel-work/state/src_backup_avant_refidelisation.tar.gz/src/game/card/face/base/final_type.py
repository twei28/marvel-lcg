# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from game.card.face import *
class FinalType(CardFace):
    is_final = True
    @property
    def type_name(self):
        return self.__class__.__name__
