# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasTemporary(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_temporary = 0
        super().__init__(paper)
        self.RegisterAttribute('Temporary', 'printed_temporary')
        self.RegisterInfoDict('temporary')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainTemporary(self.printed_temporary, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def GainTemporary(self, diff, by_effect):
        self.GainKeyword(diff, 'Temporary', by_effect)
    @final
    def IsTemporary(self):
        return (self.temporary > 0)
    @final
    @property
    def temporary(self):
        return self.GetKeyword('Temporary')
