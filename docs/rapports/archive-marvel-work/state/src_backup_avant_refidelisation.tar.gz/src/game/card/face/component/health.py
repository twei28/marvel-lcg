# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Health(Component):
    @override
    def __init__(self, card: Card):
        self.health = 0
        self.max_health = 0
        super().__init__(card)
    @override
    def OnParentReset(self):
        self.health = 0
        self.max_health = 0
        return super().OnParentReset()
    def SetHealth(self, health):
        self.health = health
    def AddHealth(self, health):
        self.health = (self.health + health)
    def GetHealth(self):
        return self.health
    def SetMaxHealth(self, health):
        self.max_health = health
    def AddMaxHealth(self, health):
        self.max_health = (self.max_health + health)
    def GetMaxHealth(self):
        return self.max_health
