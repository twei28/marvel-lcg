# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasGuard(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_guard = 0
        super().__init__(paper)
        self.RegisterAttribute('Guard', 'printed_guard')
        self.RegisterInfoDict('guard')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainGuard(self.printed_guard, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsGuard(self):
        return (self.guard > 0)
    @final
    @property
    def guard(self):
        return self.GetKeyword('Guard')
    @final
    def GainGuard(self, diff, by_effect):
        from game.card.face.card_type import Minion
        if not (Minion.IsType(self)):
            raise AssertionError
        self.ClearGuardPatrolEffectTargets()
        self.GainKeyword(diff, 'Guard', by_effect)
        self.SetGuardPatrolEffectedBy(self.IsGuard(), self.IsPatrol())
