# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class Component:
    def __init__(self, card: Card):
        self.parent = card
    def OnParentReset(self):
        pass
    def OnParentLeavePlay(self, by_effect: Effect):
        pass
    def OnBeforeParentFlip(self, by_effect, no_detach = False):
        pass
    def OnAfterParentFlip(self, by_effect: Effect):
        pass
    def OnRemove(self, by_effect: Effect):
        pass
    def OnDiscard(self, by_effect):
        return []
