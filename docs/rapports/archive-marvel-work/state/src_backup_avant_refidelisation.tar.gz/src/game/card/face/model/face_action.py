# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability.factory import *
from game.message import *
from game.card.face.model.base import ModelBase
class ModelAction(ModelBase):
    def TreatAsIfBlank(self, by_effect, only_for_this_active_message = None, *, until_round_end = False, until_phase_end = False, until_next_villain_phase_begin = False):
        end_event = None
        if until_round_end:
            end_event = Message.WhenRoundEnd
        if until_phase_end:
            end_event = Message.WhenPhaseEnd
        return self.TemporaryGain(by_effect, only_for_this_active_message=only_for_this_active_message, end_event=end_event, until_next_villain_phase_begin=until_next_villain_phase_begin, ignore_flip=True, treat_as_blank=True)
    def TemporaryGain(self, by_effect, only_for_this_active_message, end_event = None, until_next_villain_phase_begin = False, *, trait = None, hand_size = None, attack = None, defense = None, scheme = None, thwart = None, recover = None, retaliate = None, treat_as_blank = None, attack_consequential_damage = None, thwart_consequential_damage = None, ignore_flip = True, render_ui = False):
        from game.card.face.card_type import Ally
        from game.operate.effects import Effects
        from game.ability.condition import Condition2
        this = self.GetThis()
        if (hand_size != None):
            if (this.paper.card_id in ('31002a', '31002b')):
                faces = this.GetControlByPlayer().GetAllIdentityFace()
                for face in faces:
                    if (face != this):
                        face.TemporaryGain(by_effect, only_for_this_active_message, end_event, until_next_villain_phase_begin, hand_size=hand_size)
                    else:
                        pass
        effects_temp_unit = []
        effects_temp_ally = []
        if only_for_this_active_message:
            if attack:
                only_for_this_active_message.AddGainedATK(attack)
            if thwart:
                only_for_this_active_message.AddGainedTHW(thwart)
        if isinstance(only_for_this_active_message, (Message.WhenUnitBeingAttack | Message.WhenSchemeBeingScheme)):
            only_for_this_active_message = only_for_this_active_message.would_message
        def process_fn_ally(diff):
            face = this.card.face
            if face.Gain(by_effect, diff, attack_consequential_damage=attack_consequential_damage, thwart_consequential_damage=thwart_consequential_damage):
                Message.AfterCardApply_Text([face], by_effect, diff)
                return
        def process_fn(diff):
            face = this.card.face
            if face.Gain(by_effect, diff, hand_size=hand_size, attack=attack, defense=defense, scheme=scheme, thwart=thwart, recover=recover, retaliate=retaliate, treat_as_blank=treat_as_blank, trait=trait):
                Message.AfterCardApply_Text([face], by_effect, diff)
                return
        def unregister_effects_unit(effect: Effect, message: Message2):
            Effects.UnRegister(effects_temp_unit)
            effects_temp_unit = []
        def unregister_effects_ally(effect: Effect, message: Message2):
            Effects.UnRegister(effects_temp_ally)
            effects_temp_ally = []
        def unregister_effects_all(effect: Effect, message: Message2):
            unregister_effects_unit(effect, message)
            unregister_effects_ally(effect, message)
        def lost_gained_ally(effect: Effect, message: Message2):
            unregister_effects_ally(effect, message)
            if not (ignore_flip):
                if this.IsInPlay():
                    process_fn_ally(-1)
                    return
                return
            if this.card.face.IsInPlay():
                process_fn_ally(-1)
                return
        def lost_gained_unit(effect: Effect, message: Message2):
            unregister_effects_unit(effect, message)
            if not (ignore_flip):
                if this.IsInPlay():
                    process_fn(-1)
                    return
                return
            if this.card.face.IsInPlay():
                process_fn(-1)
                return
        def create_effect_interal(ability, *, is_ally = False):
            new_effects = this.effect.Registers(ability)
            if is_ally:
                effects_temp_ally = (effects_temp_ally + new_effects)
                return
            effects_temp_unit = (effects_temp_unit + new_effects)
        def create_effect(end_event, condition):
            create_effect_interal(Ability(AbilityType.Temp2, end_event, [condition], lost_gained_unit))
        def create_effect_ally(event, condition):
            create_effect_interal(Ability(AbilityType.Temp2, event, [condition], lost_gained_ally), is_ally=True)
        process_fn(1)
        process_fn_ally(1)
        if Ally.IsType(this):
            if isinstance(only_for_this_active_message, Message.AfterUnitAttackEnd):
                create_effect_ally(Message.AfterUnitUseBasicPower, lambda effect, message: (only_for_this_active_message == message.end_message))
            if isinstance(only_for_this_active_message, Message.WhenUnitWouldAttack):
                create_effect_ally(Message.AfterUnitUseBasicPower, lambda effect, message: (isinstance(message.end_message, Message.AfterUnitAttackEnd) and (only_for_this_active_message in message.end_message.would_atk_messages)))
            if isinstance(only_for_this_active_message, Message.WhenUnitWouldThwart):
                create_effect_ally(Message.AfterUnitUseBasicPower, lambda effect, message: (isinstance(message.end_message, Message.AfterUnitThwartEnd) and (only_for_this_active_message in message.end_message.would_thw_messages)))
        if isinstance(only_for_this_active_message, Message.AfterUnitAttackEnd):
            create_effect(Message.AfterUnitAttackEnd, lambda effect, message: (only_for_this_active_message == message))
        else:
            if isinstance(only_for_this_active_message, Message.WhenUnitWouldAttack):
                create_effect(Message.AfterUnitAttackEnd, lambda effect, message: (only_for_this_active_message in message.would_atk_messages))
            else:
                if isinstance(only_for_this_active_message, Message.WhenUnitWouldScheme):
                    create_effect(Message.AfterUnitSchemeEnd, lambda effect, message: (only_for_this_active_message in message.would_sch_messages))
                else:
                    if isinstance(only_for_this_active_message, Message.WhenUnitWouldThwart):
                        create_effect(Message.AfterUnitThwartEnd, lambda effect, message: (only_for_this_active_message in message.would_thw_messages))
                    else:
                        if isinstance(only_for_this_active_message, Message.WhenUnitWouldAttackUnit):
                            create_effect(Message.AfterUnitAttackEnd, lambda effect, message: (only_for_this_active_message.would_atk_message in message.would_atk_messages))
                        else:
                            if isinstance(only_for_this_active_message, Message.WhenSchemeBeingThwart):
                                create_effect(Message.AfterUnitThwartEnd, lambda effect, message: (only_for_this_active_message.would_thw_message in message.would_thw_messages))
                            else:
                                if isinstance(only_for_this_active_message, Message.WhenUnitUseBasicPower):
                                    create_effect(Message.AfterUnitUseBasicPower, lambda effect, message: (only_for_this_active_message == message.pre_message))
                                else:
                                    if isinstance(only_for_this_active_message, Message.WhenUnitWouldRecovery):
                                        create_effect(Message.AfterUnitRecovery, lambda effect, message: (only_for_this_active_message == message.pre_message))
                                    else:
                                        if isinstance(only_for_this_active_message, Message.WhenPlayerPlayCard):
                                            create_effect(Message.AfterPlayerPlayedCard, lambda effect, message: (only_for_this_active_message == message.pre_message))
                                        else:
                                            if isinstance(only_for_this_active_message, Message.WhenEffectWouldResolve):
                                                create_effect(Message.AfterEffectResolved, lambda effect, message: (only_for_this_active_message == message.pre_message))
                                            else:
                                                if (only_for_this_active_message == None):
                                                    pass
                                                else:
                                                    raise AssertionError(f'only_for_this_active_message={only_for_this_active_message!r}')
        if only_for_this_active_message:
            create_effect(Message.WhenMessageBeInstead, lambda effect, message: (only_for_this_active_message == message.message))
        create_effect_interal(Ability(AbilityType.Temp0, Message.WhenUnitBeDefeated, [Condition2.ThisIsTrigger], unregister_effects_all))
        if (end_event == None):
            pass
        else:
            if (end_event == Message.WhenPhaseEnd):
                create_effect(Message.WhenPhaseEnd, lambda effect, message: True)
            else:
                if (end_event == Message.WhenRoundEnd):
                    create_effect(Message.WhenRoundEnd, lambda effect, message: True)
                else:
                    if (end_event == Message.WhenPlayerTurnEnd):
                        create_effect(Message.WhenPlayerTurnEnd, lambda effect, message: True)
        if (until_next_villain_phase_begin == True):
            round_id = (by_effect.world.round_id + 1)
            create_effect_interal(AbilityFactory.WhenPhaseBegin(AbilityType.Temp0, 'Villain', lost_gained_unit, round_id=round_id))
        if ignore_flip:
            create_effect_interal(Ability(AbilityType.Temp0, Message.AfterCardFlip, [lambda effect, message: (effect.this.card == message.trigger.card)], lambda effect, message: process_fn(1)))
        create_effect_interal(Ability(AbilityType.Temp0, Message.WhenCardWouldFlip, [Condition2.ThisIsTrigger], lambda effect, message: process_fn(-1)))
        if ignore_flip:
            create_effect_interal(Ability(AbilityType.Temp0, Message.WhenCardLeavePlay, [Condition2.ThisIsTrigger], unregister_effects_all))
            create_effect_interal(Ability(AbilityType.Temp0, Message.AfterVillainAdvanced, [lambda effect, message: (effect.this.card == message.trigger.card)], lambda effect, message: process_fn(1)))
            return
        create_effect_interal(AbilityFactory.WhileThisStateUpdate(AbilityType.Temp2, lost_gained_unit))
    def GainUntilRoundEnd(self, by_effect, *, trait = None, hand_size = None, attack = None, defense = None, scheme = None, thwart = None, ignore_flip = True):
        return self.TemporaryGain(by_effect, None, Message.WhenRoundEnd, trait=trait, hand_size=hand_size, attack=attack, defense=defense, scheme=scheme, thwart=thwart, ignore_flip=ignore_flip, render_ui=True)
    def GainUntilPhaseEnd(self, by_effect, *, trait = None, hand_size = None, attack = None, defense = None, scheme = None, thwart = None, retaliate = None, ignore_flip = True):
        return self.TemporaryGain(by_effect, None, Message.WhenPhaseEnd, trait=trait, hand_size=hand_size, attack=attack, defense=defense, scheme=scheme, thwart=thwart, retaliate=retaliate, ignore_flip=ignore_flip, render_ui=True)
    def GainUntilTurnEnd(self, by_effect, trait = None, hand_size = None, attack = None, defense = None, scheme = None, thwart = None, ignore_flip = True):
        return self.TemporaryGain(by_effect, None, Message.WhenPlayerTurnEnd, trait=trait, hand_size=hand_size, attack=attack, defense=defense, scheme=scheme, thwart=thwart, ignore_flip=ignore_flip, render_ui=True)
    def CannotReadyDuringNextTurn(self, by_effect: Effect):
        from game.card.face.card_type import Identity
        from game.card.face.card_type import Ally
        if not (isinstance(self, (Identity | Ally))):
            raise AssertionError
        self.effect.RegisterTemp(AbilityFactory.WhenCardWouldReady(AbilityType.Temp0, 'This', lambda effect, message: message.SetBeInstead(by_effect)), unregister_after_exec=False, until_next_turn_end=True)
