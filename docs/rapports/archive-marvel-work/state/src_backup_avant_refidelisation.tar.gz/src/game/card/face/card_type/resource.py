# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.deck import *
from game.ability import *
from game.message import *
from game.player import *
from cards.paper import Paper
from game.element.resources import Resources
@final
class Resource(ClassCard, FinalType):
    @override
    def __init__(self, paper: Paper):
        super().__init__(paper)
    @override
    def Play(self, player, by_effect, message, resource, from_area, is_like_from_hand):
        raise AssertionError(f'Resource cards can not be played, self={self!r}')
