# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasForm(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.form = None
        super().__init__(paper)
        self.RegisterAttribute('Form', 'form', str)
    @override
    def GetInfoDict(self):
        info = {}
        if self.form:
            info = (info | {f'f_{self.form}': 1})
        return (info | super().GetInfoDict())
