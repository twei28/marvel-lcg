# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.message import *
from game.player import *
from game.world.game_area import *
from cards.paper import Paper
@final
class Minion(Enemy, CanQuickstrike, CanTeamwork, HasGuard, HasPatrol, HasVillainous, HasAccelerationIcon, HasHazard, HasAmplify, CanAttach, EncounterNonVillainCard, FinalType):
    @override
    def __init__(self, paper: Paper):
        self.nemesis = ''
        super().__init__(paper)
        self.RegisterAttribute('Nemesis', 'nemesis', str)
    @override
    def GetInfoDict(self):
        if self.IsInPlay():
            if (self.engaged_player != None):
                engaged_with = (self.GetEngagedPlayer().player_id + 1)
            else:
                engaged_with = 0
        else:
            engaged_with = 0
        return (super().GetInfoDict() | {'engaged_with': engaged_with})
    @override
    def OnAfterCardRevealedEnd(self, message: Message.AfterCardRevealedEnd):
        if not (message.world.is_game_over):
            if self.card.area.flags.is_dealt_encounter:
                raise AssertionError(f'self.card.area={self.card.area!r}')
        if self.card.area.flags.is_in_play:
            if (self.engaged_player == None):
                if not (self.card.world.is_game_over):
                    raise AssertionError(f'self.engaged_player={self.engaged_player!r}')
        return super().OnAfterCardRevealedEnd(message)
    @override
    def OnWhenCardRevealed(self, revealed_message: Message.WhenCardRevealed):
        from game.effect.rule import UniqueMinionRevealed
        player = revealed_message.GetToPlayer()
        if self.PutIntoPlay(player, revealed_message.by_effect):
            return super().OnWhenCardRevealed(revealed_message)
        if revealed_message.IsFromEncounterDeck():
            player.DealEncounterCards(1, UniqueMinionRevealed(self))
    @override
    def OnPutIntoPlay(self, message: Message.WhenCardPutIntoPlay) -> bool:
        player = message.GetToPlayer()
        if (self.engaged_player == player):
            return True
        if self.EngagePlayer(player, message.by_effect):
            return super().OnPutIntoPlay(message)
        return False
    def ClearGuardPatrolEffectTargets(self):
        self.SetGuardPatrolEffectedBy((-1 * self.IsGuard()), (-1 * self.IsPatrol()), forced=True)
    @override
    def OnLeaveGameArea(self, game_area: GameArea):
        self.ClearGuardPatrolEffectTargets()
        return super().OnLeaveGameArea(game_area)
    @override
    def OnEnterGameArea(self, game_area: GameArea):
        self.ClearGuardPatrolEffectTargets()
        return super().OnEnterGameArea(game_area)
    @override
    def OnAfterCardLeavePlay(self, message: Message.AfterCardLeavePlay):
        self.ClearGuardPatrolEffectTargets()
        return super().OnAfterCardLeavePlay(message)
    def SetGuardPatrolEffectedBy(self, guard_diff, patrol_diff, forced = False):
        from game.effect.rule import GameRule
        from game.operate.worlds import Worlds
        if (guard_diff != 0):
            if not (self.card.area.flags.is_engaged):
                if forced:
                    for villain in Worlds.GetVillains(self.card.game_area):
                        villain.card.ui.SetEffectedBy(guard_diff, GameRule(self))
            for villain in Worlds.GetVillains(self.card.game_area):
                villain.card.ui.SetEffectedBy(guard_diff, GameRule(self))
        if (patrol_diff != 0):
            if not (self.card.area.flags.is_engaged):
                if forced:
                    for scheme in Worlds.GetMainSchemes(self.card.game_area):
                        scheme.card.ui.SetEffectedBy(patrol_diff, GameRule(self))
            for scheme in Worlds.GetMainSchemes(self.card.game_area):
                scheme.card.ui.SetEffectedBy(patrol_diff, GameRule(self))
    def OnWhenCardEnterPlay(self, message):
        if not (super().OnWhenCardEnterPlay(message)):
            return False
        if self.card.area.flags.is_engaged:
            self.OnEngagePlayer(message.by_effect)
        return True
    @final
    def OnEngagePlayer(self, by_effect: 'Effect'):
        player = self.GetEngagedPlayer()
        would_message = Message.WhenMinionWouldEngagePlayer(self, player, by_effect)
        would_message.Send()
        engaged_message = Message.WhenMinionEngagePlayer(would_message)
        engaged_message.Send()
        self.ResolveQuickstrike(player)
        after_message = Message.AfterMinionEngagePlayer(self, player, engaged_message)
        after_message.Send()
        self.SetGuardPatrolEffectedBy(self.IsGuard(), self.IsPatrol())
    def EngagePlayer(self, player, by_effect):
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        if (self.engaged_player == player):
            return True
        was_in_play = self.card.area.flags.is_in_play
        if Faces.MoveAllTo([self], player.engaged_minions, GameRule(self)):
            if was_in_play:
                self.OnEngagePlayer(by_effect)
            return True
        return False
    def GetEngagedPlayer(self) -> Player:
        if (self.engaged_player == None):
            return self.card.area.GetOwnerPlayer()
        if not (self.engaged_player):
            raise AssertionError(f'self={self!r}')
        return self.engaged_player
    @property
    def engaged_player(self) -> Player|None:
        if self.card.area.flags.is_engaged:
            return self.card.area.play_area
