# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasUses(CanPlaceCounter, HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.uses_counters = 0
        self
        super().__init__(paper)
        def parse(value):
            from game.element.utility import IsCounter
            values = value.split(',')
            self.uses_counters = self.FormatPlayerNumValue(values[0])
            if not (IsCounter(values[1])):
                raise AssertionError
            self.uses_counter_name = values[1]
        self.RegisterAttribute('Uses', parse)
    @override
    def OnWhenCardEnterPlay(self, message):
        if super().OnWhenCardEnterPlay(message):
            if self.uses_counters:
                if (self.card.face == self):
                    name = self.uses_counter_name
                    counter = self.uses_counters
                    self.components.counter.PlaceCounters(counter, name)
            return True
        return False
    @override
    def ConvertAllPurpose(self) -> CardFace.COUNTER:
        if (self.uses_counters != 0):
            return self.uses_counter_name
        return super().ConvertAllPurpose()
    @override
    def RemoveCountersInternal(self, counters, name, by_effect, *, forced = None):
        from game.operate.faces import Faces
        from game.effect.rule import GameRule
        after_message = super().RemoveCountersInternal(counters, name, by_effect, forced=forced)
        if after_message:
            if self.IsInPlay():
                if (self.GetAllCounters() <= 0):
                    if (self.uses_counters != 0):
                        effect = GameRule(self)
                        if isinstance(self, HasVictory):
                            if self.victory:
                                Faces.AddToVictoryDisplay([self], effect)
                                return after_message
                        Faces.DiscardAll([self], effect)
        return after_message
    @override
    def GetInfoDict(self):
        the_dict = {}
        for key in self.components.counter.GetCounterNames():
            if (self.uses_counters > 0):
                if (self.uses_counter_name == key):
                    key_name = ('c_' + key)
                    the_dict = (the_dict | {(key_name + '_printed'): self.uses_counters})
        return (the_dict | super().GetInfoDict())
