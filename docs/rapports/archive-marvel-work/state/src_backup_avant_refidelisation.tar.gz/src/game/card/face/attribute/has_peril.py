# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasPeril(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_peril = 0
        super().__init__(paper)
        self.RegisterAttribute('Peril', 'printed_peril')
        self.RegisterInfoDict('peril')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainPeril(self.printed_peril, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def IsPeril(self):
        return (self.peril > 0)
    @final
    @property
    def peril(self):
        return self.GetKeyword('Peril')
    @final
    def GainPeril(self, diff, by_effect):
        self.GainKeyword(diff, 'Peril', by_effect)
