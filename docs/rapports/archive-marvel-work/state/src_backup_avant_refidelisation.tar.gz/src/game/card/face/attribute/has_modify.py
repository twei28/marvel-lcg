# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasModify(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.modify_atk = 0
        self.modify_sch = 0
        self.modify_thw = 0
        super().__init__(paper)
        self.RegisterAttribute('ATK+', 'modify_atk')
        self.RegisterAttribute('SCH+', 'modify_sch')
        self.RegisterAttribute('THW+', 'modify_thw')
    @override
    def GetAbilities(self):
        def get_value(num):
            if (num == 0):
                return
            return num
        if not ((self.modify_atk != 0)):
            if not ((self.modify_sch != 0)):
                if (self.modify_thw != 0):
                    abilities = AbilityFactory.GiveKeywordToAttached(attack=get_value(self.modify_atk), scheme=get_value(self.modify_sch), thwart=get_value(self.modify_thw))
                else:
                    abilities = []
        abilities = AbilityFactory.GiveKeywordToAttached(attack=get_value(self.modify_atk), scheme=get_value(self.modify_sch), thwart=get_value(self.modify_thw))
        abilities = []
        return (abilities + super().GetAbilities())
