# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasAccelerationIcon(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_acceleration_icon = 0
        self.ignore_acceleration_icon = False
        super().__init__(paper)
        self.RegisterAttribute('Acceleration', 'printed_acceleration_icon')
        self.RegisterInfoDict('acceleration_icon')
    @final
    @property
    def acceleration_icon(self):
        return self.GetKeyword('Acceleration')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.ignore_acceleration_icon = False
        self.GainAccelerationIcon(self.printed_acceleration_icon, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def GainAccelerationIcon(self, diff, by_effect):
        self.GainKeyword(diff, 'Acceleration', by_effect)
    @final
    def SetIgnoreAccelerationIcon(self, diff, by_effect):
        self.SetIgnoreKeyword(diff, 'Acceleration', by_effect)
