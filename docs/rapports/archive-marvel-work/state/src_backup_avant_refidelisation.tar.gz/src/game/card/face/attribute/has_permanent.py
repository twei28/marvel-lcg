# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasPermanent(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_permanent = False
        super().__init__(paper)
        self.RegisterAttribute('Permanent', 'printed_permanent', bool)
        self.RegisterInfoDict('permanent')
    @override
    def OnWhenCardLeavePlay(self, message):
        from game.player import Player
        if self.permanent:
            by_effect = message.by_effect
            if (self.paper.set_name in ('Flight', 'Super Strength', 'Telepathy')):
                if (by_effect.this.paper.card_id == '40139a'):
                    pass
            else:
                if (self.paper.set_name == 'Weather'):
                    if (by_effect.this.paper.set_name == 'Storm'):
                        pass
                else:
                    if (self.name == 'Power Stone'):
                        controller = self.GetBindFace().GetControlBy()
                        if Player.IsType(controller):
                            if controller.is_eliminated:
                                pass
                    else:
                        if (self.name == 'Milano'):
                            if (by_effect.this.name == 'The Missing Milano'):
                                pass
                        else:
                            if (self.paper.set_name != by_effect.this.paper.set_name):
                                return False
        return super().OnWhenCardLeavePlay(message)
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainPermanent(self.printed_permanent, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def GainPermanent(self, diff, by_effect):
        self.GainKeyword(diff, 'Permanent', by_effect)
    @final
    @property
    def permanent(self):
        return (self.GetKeyword('Permanent') > 0)
