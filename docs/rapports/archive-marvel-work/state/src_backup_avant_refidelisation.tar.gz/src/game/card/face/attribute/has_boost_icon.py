# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasBoostIcon(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_boost = 0
        super().__init__(paper)
        self.RegisterAttribute('Boost', 'printed_boost')
        self.RegisterInfoDict('boost_const')
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainKeywordBoostInternal(self.printed_boost, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def GainKeywordBoostInternal(self, diff, by_effect):
        self.GainKeyword(diff, 'Boost', by_effect)
    @final
    @property
    def boost_const(self):
        return self.GetKeyword('Boost')
    @final
    def CountBoostIconsInternal(self):
        from game.message import Message
        if self.card.area.flags.is_place_card_area:
            return self.printed_boost
        message = Message.WhenBoostIconsWouldBeCount(self)
        message.Send()
        if message.is_be_instead:
            return message.set_boost_icons
        if not (self.IsInDeck()):
            if self.card.area.flags.is_attach_boost_area:
                value = self.printed_boost
            else:
                value = self.GetKeyword('Boost')
        value = self.printed_boost
        value = self.GetKeyword('Boost')
        return max(0, (value + message.update_boost_icons))
    @final
    @property
    def boost_star(self):
        value = 0
        if self.effect.Find(type=AbilityType.Boost):
            value = (value + 1)
        return value
    @final
    def GainBoostIcons(self, value, by_effect):
        from game.message import Message
        Message.WhenCardWouldGainBoostIcons_Text(self, value, by_effect)
        self.GainKeywordBoostInternal(value, by_effect)
        Message.WhenCardGainBoostIcons_Text(self, value, by_effect)
    @final
    def SetBoostIcon(self, value, by_effect):
        from game.message import Message
        Message.WhenCardWouldGainBoostIcons_Text(self, value, by_effect)
        self.SetKeywords(value, 'Boost', by_effect)
        Message.WhenCardGainBoostIcons_Text(self, value, by_effect)
