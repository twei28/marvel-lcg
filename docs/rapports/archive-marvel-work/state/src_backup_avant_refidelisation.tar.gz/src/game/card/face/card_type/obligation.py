# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.message import *
from game.ability import *
from game.ability.factory import *
from game.player import *
from cards.paper import Paper
@final
class Obligation(Asset2, CanHinder, HasHazard, HasAccelerationIcon, HasUses, EncounterNonVillainCard, FinalType):
    @override
    def __init__(self, paper: Paper):
        self.printed_give_to = None
        super().__init__(paper)
        self.RegisterAttribute('GiveTo', 'printed_give_to', str)
    @override
    def GetAbilities(self):
        abilities = []
        if (self.paper.card_id in ('04163', '04164', '04165', '04166')):
            def action(effect: Effect, message: Message.AfterPlayerDrewCards):
                self.PutIntoPlay(message.GetToPlayer(), effect)
            abilities.append(AbilityFactory.AfterPlayerDrewCards(AbilityType.Campaign, 'AnyPlayer', self, action))
        return (abilities + super().GetAbilities())
    @override
    def CheckPrintedValue(self):
        if not ((self.printed_give_to != None)):
            raise AssertionError(self.paper.card_id)
        return super().CheckPrintedValue()
    @override
    def OnPlayerRevealCard(self, message):
        from game.operate.worlds import Worlds
        from game.operate.faces import Faces
        from game.effect.rule import GameRule
        if self.give_to:
            found_player = Worlds.FindPlayerByName(self.give_to, message.by_effect)
        else:
            found_player = message.GetToPlayer()
        if found_player:
            message.SetGiveToPlayer(found_player)
            return super().OnPlayerRevealCard(message)
        from game.operate.faces import Faces
        Faces.RemoveAllFromGame([self], GameRule(self))
        player = message.GetToPlayer()
        player.DealEncounterCards(1, GameRule(self), by_surge=True)
        return False
    @override
    def OnPutIntoPlay(self, message):
        from game.operate.faces import Faces
        Faces.MoveAllTo([self], message.GetToPlayer().obligations_area, message.by_effect)
        return super().OnPutIntoPlay(message)
    @override
    def OnWhenCardRevealed(self, revealed_message: Message.WhenCardRevealed):
        from game.operate.faces import Faces
        from game.effect.rule import GameRule
        found_player = revealed_message.GetGaveToPlayer()
        self.PutIntoPlay(found_player, GameRule(self))
        super().OnWhenCardRevealed(revealed_message)
        give_message = Message.WhenObligationGiveToPlayer(found_player, revealed_message)
        give_message.Send()
        if self.card.area.flags.is_dealt_encounter:
            Faces.DiscardAll([self], GameRule(self))
            return
    def GetGaveToPlayer(self) -> Player:
        player = self.card.area.play_area
        if not (player):
            raise AssertionError
        return player
    @property
    def give_to(self):
        if not ((self.printed_give_to != None)):
            raise AssertionError
        return self.printed_give_to
    @property
    @override
    def bind_face(self) -> 'Hero|AlterEgo|None':
        player = self.card.area.play_area
        if (player == None):
            return
        return player.GetIdentity()
    @override
    def GetBindFace(self) -> 'Hero|AlterEgo':
        from game.card.face.card_type import Hero
        from game.card.face.card_type import AlterEgo
        face = super().GetBindFace()
        return face.CastTo((Hero | AlterEgo))
