# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasCost(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_cost = Cost('0')
        self.has_printed_cost = False
        self.requirement = Cost('0')
        super().__init__(paper)
        def parse(value):
            self.has_printed_cost = True
            if ('*' in value):
                self.printed_cost = Cost.FromText(str(self.FormatPlayerNumValue(value)))
                return
            self.printed_cost = Cost.FromText(value)
        self.RegisterAttribute('Cost', parse)
        def parse2(value):
            self.requirement = Cost.FromText(value)
        self.RegisterAttribute('Requirement', parse2)
    def GetPrintedCostWithRequirement(self) -> Cost:
        return ((self.printed_cost - self.requirement.val) + self.requirement)
    def SetPaidResources(self, res: Resources):
        pass
    def GetTurnPlayEffects(self):
        return [x for x in self.effects if x.ability.is_play if (x.ability.when == Message.WhenPlayerInTurn)]
    @override
    def CanPlayBy(self, player):
        from game.event.manager import EventManager
        from game.effect.rule import GameRule
        effects = self.effect.Find(func_name='Play', when=Message.WhenPlayerInTurn)
        message = Message.WhenPlayerLikeInTurn(player, GameRule(player.GetIdentity()))
        message.Send()
        self.card.can_state.is_like_in_hand = True
        filtered_effects = EventManager.FilterAvailableEffects(message, effects, player, self.card.world, None)
        self.card.can_state.is_like_in_hand = None
        return (filtered_effects != [])
