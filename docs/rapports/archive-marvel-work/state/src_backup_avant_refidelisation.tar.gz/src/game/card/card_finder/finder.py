# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from game.effect import *
from game.card.face import *
from game.world.game_area import *
from game.player import *
from game.element.resources import Resources


class CardFinder(metaclass=Tracker.Meta):

    NonEliteMinion: 'CardFinder'

    class KWArgs(TypedDict, total=False):
        names: List[str] | None
        card_ids: List[str] | None
        with_texts: List[Literal['Hero Action', 'Hero Response']] | None
        set_name: 'CardFace.SETNAMES|None'
        non_set_name: 'CardFace.SETNAMES|None'
        traits: List['CardFace.TRAITS'] | None
        card_class: 'ClassCard.CARD_CLASS|None'
        card_classes: List['ClassCard.CARD_CLASS'] | None
        non_card_type: 'Type[CardFace]|Any|None'
        is_unique: bool | None
        is_face_up: bool | None
        is_temporary: bool | None
        is_stunned: bool | None
        canbe_attach_to: 'CardFace|None'
        stage: int | None
        is_nemesis: 'Player|None|Literal[True, False]'
        obligation_give_to: 'Player|None'
        amplify: bool | None
        acceleration_icon: bool | None
        acceleration_token: bool | None
        crisis: bool | None
        hazard: bool | None
        has_counter: 'CardFace.COUNTER|Literal["all-purpose"]|None'
        with_attach: 'bool|CardFinder|Type[CardFace]|None'
        cost_less_than: int | None
        cost_equal_or_less: int | None
        has_printed_res: 'Resources.RBYG|List[Resources.RBYG]|None|Literal[True]'
        is_scenario_specific: bool | None
        check_face_fn: Callable[['CardFace'], bool] | None

    def __init__(self, *,
                 name: 'str|None' = None,
                 names: List[str] | None = None,
                 subtitle: 'str|None' = None,
                 non_name: str | None = None,
                 card_ids: List[str] | None = None,
                 title_contain: str | None = None,
                 non_face: 'CardFace|None' = None,
                 with_texts: List[Literal['Hero Action', 'Hero Response']] | None = None,
                 subtype: 'Evidence.SUBTYPE|None' = None,
                 set_name: 'CardFace.SETNAMES|None' = None,
                 non_set_name: 'CardFace.SETNAMES|None' = None,
                 trait: 'CardFace.TRAITS|None' = None,
                 traits: List['CardFace.TRAITS'] | None = None,
                 non_trait: 'CardFace.TRAITS|None' = None,
                 share_trait: 'CardFace|None' = None,
                 card_class: 'ClassCard.CARD_CLASS|None' = None,
                 card_classes: List['ClassCard.CARD_CLASS'] | None = None,
                 deck_building_class: 'ClassCard.DECK_BUILDING_CLASS|None' = None,
                 card_type: 'Type[TC]|Any|None' = None,
                 non_card_type: 'Type[TC]|Any|None' = None,
                 form: 'CardFace.FORM|None' = None,
                 is_unique: bool | None = None,
                 is_permanent: bool | None = None,
                 is_face_up: bool | None = None,
                 is_temporary: bool | None = None,
                 canbe_play: bool | None = None,
                 canbe_exhaust: bool | None = None,
                 canbe_ready: bool | None = None,
                 canbe_flip: bool | None = None,
                 canbe_discard: bool | None = None,
                 game_area: 'GameArea|None' = None,
                 canbe_heal: bool | None = None,
                 sustained: bool | None = None,
                 has_non_health: bool | None = None,
                 with_health: int | None = None,
                 with_tough: bool | None = None,
                 is_confused: bool | None = None,
                 is_stunned: bool | None = None,
                 has_confuse_status: bool | None = None,
                 canbe_tough: bool | None = None,
                 canbe_confused: bool | None = None,
                 canbe_stunned: bool | None = None,
                 has_status: 'CardFace.STATUS|Literal["Any"]' | List['CardFace.STATUS'] | None = None,
                 canbe_status: 'CardFace.STATUS|Literal["Any"]' | List['CardFace.STATUS'] | None = None,
                 canbe_attach_by: 'CardFace|None' = None,
                 canbe_attach_to: 'CardFace|None' = None,
                 has_threat: bool | None = None,
                 is_active_villain: bool | None = None,
                 stage: int | None = None,
                 is_nemesis: 'Player|None|Literal[True, False]' = None,
                 engaged_with: 'CardFinder|Player|None' = None,
                 not_engaged_with: 'Player|None' = None,
                 obligation_give_to: 'Player|None' = None,
                 amplify: bool | None = None,
                 acceleration_icon: bool | None = None,
                 acceleration_token: bool | None = None,
                 crisis: bool | None = None,
                 hazard: bool | None = None,
                 has_counter: 'CardFace.COUNTER|Literal["all-purpose"]|None' = None,
                 has_token: 'CardFace.TOKEN|None' = None,
                 has_attach: 'CardFinder|None' = None,
                 attach_to: 'CardFinder|None' = None,
                 with_attach: 'bool|CardFinder|Type[CardFace]|None' = None,
                 not_with_attach: 'CardFinder|Type[CardFace]|None' = None,
                 bind_to: 'CardFinder|CardFace|None' = None,
                 cost_less_than: int | None = None,
                 cost_equal_or_greater: int | None = None,
                 cost_equal_or_less: int | None = None,
                 has_printed_res: 'Resources.RBYG|List[Resources.RBYG]|None|Literal[True]' = None,
                 non_printed_res: 'Resources.RBYG|None' = None,
                 with_res: 'Resources.RBY|None' = None,
                 owner: 'Player|None' = None,
                 is_scenario_specific: bool | None = None,
                 not_has_that_unique_in_play: bool | None = None,
                 check_face_fn: Callable[['TC'], bool] | None = None,
                 check_effect_fn: Callable[['Effect', 'TC'], bool] | None = None) -> None:
        from game.card.face.card_face import CardFace
        if card_type == CardFace or card_type == 'CardFace':
            card_type = None

        self.name = name
        self.names = names if names else []
        self.non_name = non_name
        self.subtitle = subtitle
        self.card_ids = card_ids if card_ids else []
        self.title_contain = title_contain
        self.non_face = non_face
        self.with_texts = with_texts if with_texts else []
        self.subtype = subtype
        self.set_name = set_name
        self.non_set_name = non_set_name
        self.trait = trait
        self.traits = traits if traits else []
        self.non_trait = non_trait
        self.share_trait = share_trait
        self.card_class = card_class
        self.card_classes = card_classes if card_classes else []
        self.deck_building_class = deck_building_class
        self.card_type = card_type
        self.non_card_type = non_card_type
        self.form = form
        self.is_unique = is_unique
        self.is_permanent = is_permanent
        self.is_face_up = is_face_up
        self.is_temporary = is_temporary
        self.canbe_play = canbe_play
        self.canbe_exhaust = canbe_exhaust
        self.canbe_ready = canbe_ready
        self.canbe_flip = canbe_flip
        self.canbe_discard = canbe_discard
        self.game_area = game_area
        self.canbe_heal = canbe_heal
        self.sustained = sustained
        self.has_non_health = has_non_health
        self.with_health = with_health
        self.with_tough = with_tough
        self.is_confused = is_confused
        self.is_stunned = is_stunned
        self.has_confuse_status = has_confuse_status
        self.canbe_tough = canbe_tough
        self.canbe_confused = canbe_confused
        self.canbe_stunned = canbe_stunned
        self.has_status = has_status
        self.canbe_status = canbe_status
        self.canbe_attach_by = canbe_attach_by
        self.canbe_attach_to = canbe_attach_to
        self.has_threat = has_threat
        self.is_active_villain = is_active_villain
        self.stage = stage
        self.is_nemesis = is_nemesis
        self.engaged_with = engaged_with
        self.not_engaged_with = not_engaged_with
        self.obligation_give_to = obligation_give_to
        self.amplify = amplify
        self.acceleration_icon = acceleration_icon
        self.acceleration_token = acceleration_token
        self.crisis = crisis
        self.hazard = hazard
        self.has_counter = has_counter
        self.has_token = has_token
        self.has_attach = has_attach
        self.attach_to = attach_to
        self.with_attach = with_attach
        self.not_with_attach = not_with_attach
        self.bind_to = bind_to
        self.cost_less_than = cost_less_than
        self.cost_equal_or_greater = cost_equal_or_greater
        self.cost_equal_or_less = cost_equal_or_less
        self.has_printed_res = has_printed_res
        self.non_printed_res = non_printed_res
        self.with_res = with_res
        self.owner = owner
        self.is_scenario_specific = is_scenario_specific
        self.not_has_that_unique_in_play = not_has_that_unique_in_play
        self.check_face_fns = [check_face_fn] if check_face_fn else []
        self.check_effect_fns = [check_effect_fn] if check_effect_fn else []
        self.or_finders = []

        from game.card.card_finder.checker import Check
        from game.card.card_finder.checker import Checks
        from game.card.card_finder.checker import Checks2
        CardFinder.Check = Check
        CardFinder.Checks = Checks
        CardFinder.Checks2 = Checks2

        self.is_empty = not self.params

    def Check(self, face: 'CardFace', effect: 'Effect|None' = None) -> bool:
        ...

    def Checks(self, faces: Sequence['TC'], effect: 'Effect|None' = None) -> List['TC']:
        ...

    def Checks2(self, faces: Sequence['CardFace'], card_type: Type[TF]) -> List['TF']:
        ...

    def __and__(self, other: 'CardFinder|None') -> 'CardFinder':
        if other == None or other.is_empty:
            return self
        if self.is_empty:
            return other
        params = self.params
        for key, value in other.params.items():
            if key in params:
                if issubclass(params[key], value):
                    value = params[key]
                elif issubclass(value, params[key]):
                    value = value
                else:
                    assert False
            setattr(self, key, value)
        return self

    def __or__(self, other: 'CardFinder|None') -> 'CardFinder':
        if other == None or other.is_empty:
            return self
        if self.is_empty:
            return other
        self.or_finders.append(other)
        return self

    @property
    def params(self) -> Dict[str, Any]:
        return {key: value for key, value in self.__dict__.items() if value != None if value != [] if key != 'is_empty'}

    def __repr__(self) -> str:
        return f'{self.params}'

    def __bool__(self) -> bool:
        return not self.is_empty

    def __eq__(self, other: Any) -> bool:
        if other is None:
            return self.is_empty
        return NotImplemented

    @property
    def check_by_name(self) -> List[str]:
        names = []
        if self.name != None:
            names.append(self.name)
        if self.names != []:
            names.extend(self.names)
        for or_finder in self.or_finders:
            by_name = or_finder.check_by_name
            if by_name:
                names.extend(by_name)
            else:
                return []
        return names


CardFaceType: TypeAlias = 'CardFace'


class CardFinder2(Generic[TC], CardFinder):
    def __init__(self,
                 trait: 'CardFace.TRAITS|None' = None,
                 card_type: 'Type[TC]|None' = CardFaceType) -> None:
        from game.card.face.card_face import CardFace
        if card_type == CardFace or card_type == 'CardFace':
            card_type = None
        card_type2 = card_type
        super().__init__(trait=trait, card_type=card_type2)
