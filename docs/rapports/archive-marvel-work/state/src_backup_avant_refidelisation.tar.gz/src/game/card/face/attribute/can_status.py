# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class CanStatus(HasVulnerable, HasSteady, HasToughness, HasStalwart):
    BASE_MAX_TOUGH = 1
    DISCARD_RULE = (Literal[('All', 'Steady')] | int)
    @override
    def __init__(self, paper: Paper):
        super().__init__(paper)
    def ResetStates(self):
        self.components.status.OnParentReset()
    @override
    def OnReset(self, message: Message.WhenCardReset_Text):
        if not (message.is_flip):
            self.ResetStates()
        return super().OnReset(message)
    @override
    def OnAfterCardLeavePlay(self, message: Message.AfterCardLeavePlay):
        self.ResetStates()
        return super().OnAfterCardLeavePlay(message)
    @property
    def confused(self):
        return self.components.status.confused
    @property
    def stunned(self):
        return self.components.status.stunned
    @property
    def tough(self):
        return self.components.status.tough
    @property
    def tough_max(self):
        from game.message import Message
        from game.card.face.base import Unit2
        value = CanStatus.BASE_MAX_TOUGH
        message = Message.GettingUnitAdditionalTough(self.card.CastTo(Unit2))
        message.Send()
        additional = message.return_value
        if additional:
            value = (value + additional)
        return value
    def GainStatus(self, name, by_effect):
        from game.message import Message
        from game.operate.faces import Faces
        from game.effect.rule import GameRule
        if not (self.card.IsOnField()):
            return False
        if (name == 'Confused'):
            if not (self.CanbeConfused()):
                return False
        if (name == 'Stunned'):
            if not (self.CanbeStunned()):
                return False
        if (name == 'Tough'):
            if self.IsTough():
                if (self.tough >= self.tough_max):
                    return False
        would_message = Message.WhenStatusWouldCardPlaceOn(self, name, by_effect)
        would_message.Send()
        if would_message.is_be_instead:
            return False
        status_face = self.components.status.GiveStatusCard(name, by_effect)
        placed_message = Message.AfterStatusCardPlaceOn(status_face, would_message)
        placed_message.Send()
        if self.CastTo(HasVulnerable).IsVulnerable():
            if not (self.IsStunned()):
                if self.IsConfused():
                    rule = GameRule(self)
                    Faces.DiscardAll([self], rule)
            rule = GameRule(self)
            Faces.DiscardAll([self], rule)
        return True
    def LoseState(self, name, by_effect, rule):
        if not (self.card.IsOnField()):
            return False
        return self.components.status.DiscardStatusCard(name, by_effect, rule)
    def DiscardConfused(self, by_effect, *, rule):
        return self.LoseState('Confused', by_effect, rule)
    def DiscardStunned(self, by_effect, *, rule):
        return self.LoseState('Stunned', by_effect, rule)
    def DiscardTough(self, by_effect, *, rule):
        return self.LoseState('Tough', by_effect, rule)
    def DiscardAllTough(self, by_effect):
        return self.DiscardTough(by_effect, rule='All')
    def DiscardEachStatus(self, by_effect: Effect):
        self.DiscardConfused(by_effect, rule='All')
        self.DiscardStunned(by_effect, rule='All')
        self.DiscardAllTough(by_effect)
    def IsConfused(self):
        from game.card.face.base import Unit2
        if self.card.CastTo(Unit2).IsSteady():
            return (self.confused > 1)
        return (self.confused > 0)
    def IsTough(self):
        return (self.tough != 0)
    def IsStunned(self):
        from game.card.face.base import Unit2
        if self.card.CastTo(Unit2).IsSteady():
            return (self.stunned > 1)
        return (self.stunned > 0)
    def CanGainTough(self):
        if not (self.IsInPlay()):
            return False
        return (self.tough < self.tough_max)
    def CanbeStunned(self):
        if not (self.IsInPlay()):
            return False
        if self.IsStalwart():
            return False
        if self.IsStunned():
            return False
        if self.GetBuff(BuffCannotBeStunned):
            return False
        return True
    def CanbeConfused(self):
        if not (self.IsInPlay()):
            return False
        if self.IsStalwart():
            return False
        if self.IsConfused():
            return False
        if self.GetBuff(BuffCannotBeConfused):
            return False
        return True
    def HasStatus(self, name):
        if (name == 'Any'):
            return ((self.confused > 0) or ((self.stunned > 0) or (self.tough > 0)))
        if (name == 'Confused'):
            return (self.confused > 0)
        if (name == 'Stunned'):
            return (self.stunned > 0)
        if (name == 'Tough'):
            return (self.tough > 0)
        raise AssertionError(f'self={self!r} name={name!r}')
    def GetStatusSize(self):
        return self.components.status.GetStatusSize()
class CanNoStatus(CanStatus):
    @override
    def CanGainTough(self):
        return False
    @override
    def CanbeStunned(self):
        return False
    @override
    def CanbeConfused(self):
        return False
