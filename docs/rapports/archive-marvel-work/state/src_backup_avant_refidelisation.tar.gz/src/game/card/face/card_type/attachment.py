# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.message import *
from cards.paper import Paper
@final
class Attachment(Asset2, HasModify, HasAmplify, HasHazard, CanCrisis, CanAttacked, CanNoStatus, HasUses, HasAccelerationIcon, HasPermanent, HasMaxPer, HasSetup, EncounterNonVillainCard, FinalType):
    @override
    def __init__(self, paper: Paper):
        super().__init__(paper)
    @override
    def OnWhenCardRevealed(self, revealed_message: Message.WhenCardRevealed):
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        player = revealed_message.GetToPlayer()
        if self.PutIntoPlay(player, revealed_message.by_effect):
            super().OnWhenCardRevealed(revealed_message)
        if not (self.card.area.flags.is_in_play):
            Faces.DiscardAll([self], GameRule(self))
            return
    @override
    def CanAttachTo(self, face):
        if not (super().CanAttachTo(face)):
            return False
        return True
