# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.ability.factory import *
from game.message import *
from cards.paper import Paper
@final
class StatusCard(FinalType):
    @override
    def __init__(self, paper: Paper):
        self
        super().__init__(paper)
        self.symbol_name = {'Tough': Symbol.tough, 'Stunned': Symbol.stunned, 'Confused': Symbol.confused}[self.name]
    @override
    def GetAbilities(self):
        def remove_this(effect: Effect, message: Message.WhenCardWouldDiscard):
            this = effect.this.CastTo(StatusCard)
            Unused(this)
            message.SetToArea(self.card.world.area_status_cards)
        def send_lost_status(effect: Effect, message: Message.AfterCardDiscard):
            from game.message import Message
            from game.card.face.base import Unit2
            this = effect.this.CastTo(StatusCard)
            if message.from_area.bind_card:
                unit = message.from_area.bind_card.face.CastTo(Unit2)
                discard_message = Message.AfterStatusDiscardFrom(unit, this, message.by_effect)
                discard_message.Send()
                return
        return ([AbilityFactory.WhenCardWouldDiscard(AbilityType.Rule, 'This', remove_this).NoOutOfPlayLimit(), AbilityFactory.AfterCardDiscard(AbilityType.Rule, 'This', send_lost_status).NoOutOfPlayLimit()] + super().GetAbilities())
    @property
    @override
    def bind_face(self) -> Unit2|None:
        unit_card = self.card.area.bind_card
        if unit_card:
            if Unit2.IsType(unit_card.face):
                return unit_card.face
    @override
    def GetBindFace(self) -> Unit2:
        face = super().GetBindFace()
        return face.CastTo(Unit2)
    def IsStatusName(self, name):
        return super().IsName(name, False, False)
