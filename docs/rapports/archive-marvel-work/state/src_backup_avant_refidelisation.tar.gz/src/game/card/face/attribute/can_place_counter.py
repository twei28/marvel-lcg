# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class CanPlaceCounter(CardFace):
    @final
    def GetAllCounters(self):
        return self.components.counter.GetAllCounters()
    @final
    def SetCounters(self, counters, name, by_effect):
        return self.components.counter.SetCounters(counters, name)
    @final
    def GetCounters(self, name):
        if (name == 'all-purpose'):
            return self.GetAllCounters()
        return self.components.counter.GetCounters(name)
    def ConvertAllPurpose(self) -> CardFace.COUNTER:
        names = self.components.counter.GetCounterNames()
        if names:
            return names[0]
        return 'counter'
    def PlaceCountersInternal(self, num, name, by_effect, *, maximum = None):
        from game.message import Message
        from game.operate.worlds import Worlds
        if (name == 'all-purpose'):
            name = self.ConvertAllPurpose()
        num = Worlds.ConvertPerPlayerIconToInt(num, by_effect)
        would_message = Message.WhenCardWouldBePlacedCounter(self, num, name, by_effect)
        would_message.Send()
        if would_message.is_be_instead:
            return False
        num = would_message.counters
        maximum = (would_message.maximum or maximum)
        if (maximum != None):
            if ((self.GetCounters(name) + num) > maximum):
                num = (maximum - self.GetCounters(name))
        self.components.counter.PlaceCounters(num, name)
        after_message = Message.AfterCardPlacedCounter(self, num, name, by_effect, would_message)
        after_message.Send()
        return num
    def RemoveCountersInternal(self, counters, name, by_effect, *, forced = None):
        from game.message import Message
        if (name == 'all-purpose'):
            name = self.ConvertAllPurpose()
        counter_num = self.components.counter.GetCounters(name)
        if (forced == None):
            forced = True
        would_message = Message.WhenCardWouldRemovedCounter(self, counters, name, by_effect)
        would_message.Send()
        if would_message.is_be_instead:
            return
        if would_message.remove_all:
            counters = 'All'
        else:
            if (would_message.counters != None):
                if not ((would_message.counters >= 0)):
                    raise AssertionError
            raise AssertionError
            counters = would_message.counters
        if self.components.counter.RemoveCounters(counters, name, forced):
            diff = (counter_num - self.components.counter.GetCounters(name))
            after_message = Message.AfterCardRemovedCounter(self, diff, would_message)
            after_message.Send()
            return after_message
    @final
    def RemoveAllCounters(self, by_effect: Effect):
        for name in self.components.counter.GetCounterNames():
            self.RemoveCountersInternal(Math.INT_INF, name, by_effect, forced=True)
    @override
    def GetInfoDict(self):
        the_dict = {}
        for key in self.components.counter.GetCounterNames():
            counter = self.GetCounters(key)
            key_name = ('c_' + key)
            the_dict = (the_dict | {key_name: counter})
        return (the_dict | super().GetInfoDict())
