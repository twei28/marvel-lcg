# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasHinder(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_hinder = 0
        super().__init__(paper)
        self.RegisterAttribute('Hinder', 'printed_hinder')
    @override
    def CheckPrintedValue(self):
        if not ((self.printed_hinder >= 0)):
            raise AssertionError
        return super().CheckPrintedValue()
    @override
    def OnResetKeywords(self, by_effect: Effect):
        self.GainHinder(self.printed_hinder, by_effect)
        return super().OnResetKeywords(by_effect)
    @final
    def GainHinder(self, diff, by_effect):
        self.GainKeyword(diff, 'Hinder', by_effect)
    @property
    def hinder(self):
        return self.GetKeyword('Hinder')
class CanHinder(HasHinder, CanPlaceToken):
    @override
    def OnWouldEnterPlay(self, into_area):
        self.ResolveHinder()
        return super().OnWouldEnterPlay(into_area)
    @override
    def OnAfterFlip(self, by_effect, call_reveal = False):
        super().OnAfterFlip(by_effect, call_reveal)
        if self.IsInPlay():
            self.ResolveHinder()
            return
    @final
    def ResolveHinder(self):
        from game.effect.rule import ResetKeyword
        if self.hinder:
            self.PlaceTokensInternal(self.hinder, 'threat', ResetKeyword(self))
            return
