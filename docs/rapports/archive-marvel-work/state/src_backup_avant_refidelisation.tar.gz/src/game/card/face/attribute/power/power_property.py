# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
@dataclass
class PowerProperty:
    __annotations__ = {}
    is_basic_power = field(default=False)
    is_basic_power: bool
    is_divided = field(default=False)
    is_divided: bool
    divided_evenly = field(default=False)
    divided_evenly: bool
    additional_value = field(default=0)
    additional_value: int
