# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasTeamwork(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_teamwork = None
        self.teamwork_internal = {}
        super().__init__(paper)
        self.RegisterAttribute('Teamwork', 'printed_teamwork', str)
        self.RegisterInfoDict('teamwork')
    def CheckPrintedValue(self):
        from game.element.utility import IsTrait
        if not ((self.printed_teamwork == None)):
            if not (IsTrait(self.printed_teamwork)):
                raise AssertionError
        return super().CheckPrintedValue()
    @override
    def OnResetKeywords(self, by_effect: Effect):
        if self.printed_teamwork:
            self.GainTeamwork(1, self.printed_teamwork, by_effect)
        return super().OnResetKeywords(by_effect)
    def GainTeamwork(self, diff, teamworks, by_effect):
        face = by_effect.this
        def gain_teamwork(trait: CardFace.TRAITS):
            if (diff == 1):
                if (trait in self.teamwork_internal):
                    self.teamwork_internal[trait].append(face)
                    return
                self.teamwork_internal[trait] = [face]
                return
            if (diff == -1):
                self.teamwork_internal[trait].remove(face)
                if (self.teamwork_internal[trait] == []):
                    del self.teamwork_internal[trait]
                    return
                return
            raise AssertionError
        the_traits = []
        if isinstance(teamworks, list):
            the_traits = teamworks
        else:
            the_traits = [teamworks]
        for trait in the_traits:
            gain_teamwork(trait)
    @property
    def teamwork(self):
        return [x for x in self.teamwork_internal if (len(self.teamwork_internal[x]) > 0)]
class CanTeamwork(HasTeamwork):
    @override
    def OnAfterCardEnterPlay(self, message: Message.AfterCardEnterPlay):
        from game.effect.rule import Teamwork
        from game.card.face.card_type import Minion
        from game.operate.worlds import Worlds
        if self.teamwork:
            has_teamwork = False
            minions = Worlds.GetOnFieldMinions(self.card.game_area)
            for minion in minions:
                if (minion != self):
                    if minion.HasTrait(*self.teamwork):
                        has_teamwork = True
                    else:
                        pass
                else:
                    pass
            if has_teamwork:
                if self.card.world.rule.v16_teamwork:
                    minion = self.card.CastTo(Minion)
                    minion.DoActivate(minion.GetEngagedPlayer(), Teamwork(minion))
                else:
                    for minion in minions:
                        if (minion.teamwork == self.teamwork):
                            if not (minion.IsDefeated()):
                                minion.DoActivate(minion.GetEngagedPlayer(), Teamwork(minion))
        return super().OnAfterCardEnterPlay(message)
