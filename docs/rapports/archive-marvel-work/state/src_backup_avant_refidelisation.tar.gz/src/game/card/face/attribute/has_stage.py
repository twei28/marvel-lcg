# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class HasStage(HasAttribute):
    @override
    def __init__(self, paper: Paper):
        self.printed_stage = 0
        self.printed_stage_text = 0
        super().__init__(paper)
        def parse(value):
            if (value == 'I'):
                self.printed_stage = 1
            else:
                if (value == 'II'):
                    self.printed_stage = 2
                else:
                    if (value == 'III'):
                        self.printed_stage = 3
                    else:
                        if (value == 'IV'):
                            self.printed_stage = 4
                        else:
                            if not (value.endswith('1')):
                                if not ((value == 'A')):
                                    if (value == 'B'):
                                        self.printed_stage = 1
                                    else:
                                        if value.endswith('2'):
                                            self.printed_stage = 2
                                        else:
                                            self.printed_stage = int(value[0])
                            self.printed_stage = 1
                            if value.endswith('2'):
                                self.printed_stage = 2
                            else:
                                self.printed_stage = int(value[0])
            self.printed_stage_text = value
        self.RegisterAttribute('Stage', parse)
        self.RegisterInfoDict('printed_stage')
    @override
    def CheckPrintedValue(self):
        if not ((self.printed_stage != 0)):
            raise AssertionError(f'self.paper.card_id={self.paper.card_id!r}')
        return super().CheckPrintedValue()
