# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.effect import *
from game.ability.factory import *
from game.selector import *
from game.player import *
HACK_HERO_ID = '3100'
class PlayerSetup:
    def __init__(self, player: Player):
        self.player = player
    def SetupPlayerAbility(self, hero: CardFace):
        from game.message import Message
        player = self.player
        def register_change_form():
            from game.ability import AbilityType
            from game.card.face.card_type import AlterEgo
            from game.card.face.card_type import Hero
            def add_change_form_effect(identity, identities):
                def check_is_same_card(effect, message):
                    this = effect.this
                    if (len(this.card.back_faces) == 1):
                        return True
                    return (face.paper.card_id[:-1] == this.card.face.paper.card_id[:-1])
                def invoke_change_form(to_face: AlterEgo|Hero, effect: Effect):
                    initiator = effect.GetInitiator()
                    initiator.has_change_form = True
                    initiator.GetIdentity().ChangeToFace(to_face, effect)
                faces = identities[:]
                faces.remove(identity)
                if not (identity.paper.card_id.startswith(HACK_HERO_ID)):
                    if (len(identities) > 2):
                        faces = [x for x in faces if (x.paper.card_id[:-1] == identity.paper.card_id[:-1])]
                for face in faces:
                    def register_change_to(face, name):
                        identity.effect.Registers(AbilityFactory.WhenInYourPlayTurn(AbilityType.PlayTurnOption, lambda effect, message: invoke_change_form(face, effect), conditions=[lambda effect, message: ((not effect.GetInitiator().has_change_form) and ((identity.card.face != face) and identity.IsInPlay(is_same_face=True))), check_is_same_card]).SetFuncName('Change Form').SetName(name).NoOutOfPlayLimit())
                    name = ''
                    if (len(faces) > 1):
                        if (face.name in [x.name for x in identities if (x != face)]):
                            name = face.traits_str
                            name = ('Change To ' + name.strip())
                        else:
                            name = ('Change To ' + face.name)
                    register_change_to(face, name)
            identities = set([])
            for face in (player.area_hero.GetAll() + [hero.card.face]):
                for identity in ([face] + face.card.back_faces):
                    if isinstance(identity, (AlterEgo | Hero)):
                        identities.add(identity)
            for identity in sorted(identities):
                add_change_form_effect(identity, list(identities))
        def register_ask_effect():
            if (player.world.GetPlayerNum() > 1):
                def invoke_ask(effect: Effect, message: Message.WhenPlayerInTurn):
                    def get_player_can_asked_effects(player):
                        return [x for x in effect.world.event_manager.FindEffectsList('Optional', Message.WhenPlayerInTurn, TimingPriority.Normal) if x.is_action]
                    # RECOVER_TODO SETUP_WITH arg=27 target=96
                    player = effect.targets[0].GetControlByPlayer()
                    turn_message = Message.WhenPlayerLikeInTurn(player, effect)
                    turn_message.Send()
                    player.ChooseEffects(get_player_can_asked_effects(player), turn_message)
                    UNKNOWN(None, None, None)
                    return
                    # RECOVER_TODO WITH_EXCEPT_START arg=0 target=0
                    if not (UNKNOWN):
                        # RECOVER_TODO RERAISE arg=1 target=1
                        pass
                    # RECOVER_TODO POP_EXCEPT arg=0 target=0
                hero.effect.Registers(AbilityFactory.WhenInYourPlayTurn(AbilityType.Ask, lambda effect, message: invoke_ask(effect, message)).SetFuncName('Ask').SetTarget('OtherPlayers').NoOutOfPlayLimit())
                def get_player_can_def_effects(player):
                    effects = []
                    for face in player.GetControlCharacters():
                        for face_effect in face.effects:
                            if face_effect.ability.IsFunction('DEF'):
                                if face.CanExhaust():
                                    effects.append(face_effect)
                            if face_effect.ability.IsLabel('defense'):
                                effects.append(face_effect)
                    return effects
                def invoke_defense(effect: Effect, message: Message.WhenUnitBeingAttack):
                    # RECOVER_TODO SETUP_WITH arg=31 target=76
                    player = effect.targets[0].GetControlByPlayer()
                    bing_atk_message = Message.WhenUnitLikeBeingAttack(player.GetIdentity(), message.would_atk_message, message)
                    bing_atk_message.Send()
                    player.ChooseEffects(get_player_can_def_effects(player), bing_atk_message)
                    UNKNOWN(None, None, None)
                    return
                    # RECOVER_TODO WITH_EXCEPT_START arg=0 target=0
                    if not (UNKNOWN):
                        # RECOVER_TODO RERAISE arg=1 target=1
                        pass
                    # RECOVER_TODO POP_EXCEPT arg=0 target=0
                def on_field_other_players(effect):
                    from game.card.face.card_type import AlterEgo
                    from game.card.face.card_type import Hero
                    units = Select.From('OtherPlayers').GetAllLegalTargets(effect)
                    return [x for x in units if (get_player_can_def_effects(x.GetControlByPlayer()) != []) if isinstance(x, (AlterEgo | Hero))]
                hero.effect.Registers(Ability(AbilityType.Ask, Message.WhenUnitBeingAttack, [lambda effect, message: ((message.defender == None) and (effect.initiator == message.trigger.card.GetController()))], invoke_defense).SetFuncName('Ask').SetTarget(on_field_other_players).NoOutOfPlayLimit())
                return
        register_change_form()
        register_ask_effect()
    def SelectIdentity(self, name, hero_names, hero_deck, obligations, nemesis_set, player_deck):
        from game.effect.rule import GameRule
        from game.message import Message
        from game.card.factory import CardFactory
        player = self.player
        player.hero_name = name
        def move_b_to_front(s):
            parts = s.split(',')
            b_part = [part for part in parts if part.endswith('b')]
            other_parts = [part for part in parts if not (part.endswith('b'))]
            result = (b_part + other_parts)
            return ','.join(result)
        if hero_names[0].startswith(HACK_HERO_ID):
            hero_names = ['31002a,31002b']
        else:
            hero_names = [move_b_to_front(s) for s in hero_names]
        CardFactory.GenerateCards(hero_names, player.set_aside_deck, player.world)
        hero_card = player.set_aside_deck.GetAll()[0]
        rule = GameRule(hero_card)
        hero_card.PutIntoPlay(player, rule)
        if player.world.is_game_over:
            return
        select_message = Message.WhenPlayerSelectHero(player, player.GetIdentity())
        select_message.Send()
        if hero_card.card.back_faces:
            self.SetupPlayerAbility(hero_card)
        player.set_aside_obligations = []
        player.set_aside_obligations = (player.set_aside_obligations + CardFactory.GenerateCards(obligations, player.set_aside_nemesis_sets, player.world))
        CardFactory.GenerateCards(nemesis_set, player.set_aside_nemesis_sets, player.world)
        if player.world.rule.create_player_deck_first:
            player_hero_deck = (list(player_deck) + list(hero_deck))
        else:
            player_hero_deck = (list(hero_deck) + list(player_deck))
        CardFactory.GenerateCards(player_hero_deck, player.player_deck, player.world)
        player.stat.ResetPlayedRevealedCards()
        player.flag.Reset()
        player.res_pool.Reset()
        Message.WhenDeckCreated_Text(player.player_deck)
        player.player_deck.Shuffle(rule)
        if player.world.is_game_over:
            return
        selected_message = Message.AfterPlayerSelectHeroEnd(player, player.GetIdentity())
        selected_message.Send()
