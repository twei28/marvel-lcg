# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from build import Build
from engine.log import Log
from game.card.face import *
from game.card import *
from game.deck import *
from game.ability import *
from game.selector import *
from game.ability.factory import *
from game.message import *
from game.player import *
from game.element.resources import Resources
from game.element.cost import Cost
from game.effect.effect_target_cost import TargetCost
CATEGORY_NAME = 'PLAYER'
CardFaceType = 'CardFace'
CardFaceType: TypeAlias
class PlayerAction:
    def GetPlayer(self) -> 'Player':
        from game.player import Player
        return Cast(Player, self)
    def DealEncounterCard(self, face, by_effect, *, by_surge = False):
        from game.message import Message
        from game.operate.faces import Faces
        player = self.GetPlayer()
        world = self.GetPlayer().world
        would_message = Message.WhenPlayerWouldBeDealtEncounterCard(player, by_effect, face)
        would_message.Send()
        if would_message.is_be_instead:
            return
        pos = None
        if world.rule.v16_reveal:
            pos = 'Bottom'
            if by_surge:
                pos = 'Top'
            Faces.MoveAllToDeck([face], player.dealt_encounter_cards, pos, by_effect)
        else:
            Faces.MoveAllTo([face], player.dealt_encounter_cards, by_effect)
        message = Message.AfterPlayerDealEncounterCard(player, would_message)
        message.Send()
    def DealEncounterCards(self, size, by_effect, *, by_surge = False):
        world = self.GetPlayer().world
        if world.is_game_over:
            return
        faces = []
        def process(face: 'CardFace'):
            faces.append(face)
            self.DealEncounterCard(face, by_effect, by_surge=by_surge)
        from game.operate.worlds import Worlds
        Worlds.PopEncounterCards(size, process, True, by_effect)
    def RevealEncounterCards(self):
        from game.effect.rule import GameRule
        player = self.GetPlayer()
        last_face = None
        if (player.dealt_encounter_cards.GetSize() > 0):
            face = player.dealt_encounter_cards.GetTop()
            if not (face):
                pass
            else:
                if not ((face != last_face)):
                    raise AssertionError(f'face={face!r} last_face={last_face!r}')
                face.Reveal(player, GameRule(face))
                if player.world.is_game_over:
                    pass
                else:
                    if player.is_eliminated:
                        pass
                    else:
                        last_face = face
                        player.stat.RecordReveal(last_face)
                        # backward conditional jump to 38: (player.dealt_encounter_cards.GetSize() > 0)
        player.dealt_encounter_cards.DiscardAll(GameRule(player.GetIdentity()))
    def AssignDamage(self, targets, source, damage, by_effect, *, operation = None, from_atk_message = None):
        from game.operate.faces_helper import FacesHelper
        player = self.GetPlayer()
        messages = []
        def assign():
            effects = player.ChooseAbilities(by_effect, AbilityFactory.ForChoiceAbility(f'Assign {damage} damage', lambda targets: None).SetTarget(targets, range=('Zero', damage), repeat_rules='Health'))
            if (effects == []):
                return {}
            assign_targets = effects[0].targets
            return FacesHelper.ListToDict(assign_targets)
        units = assign()
        from game.element.damage_property import DamageProperty
        for unit in units:
            damage = units[unit]
            message = unit.TakeDamage(source, DamageProperty(damage, is_indirect_damage=True), by_effect, operation=operation, from_atk_message=from_atk_message)
            if message:
                messages.append(message)
        return messages
    def AssignHeal(self, targets, value, by_effect):
        player = self.GetPlayer()
        def assign(targets, value, by_effect):
            if not (Select.From(faces=targets, repeat_rules='Sustained').GetAllLegalTargets(by_effect)):
                return {}
            effects = player.ChooseAbilities(by_effect, AbilityFactory.ForChoiceAbility('', lambda targets: None).SetTarget(targets, repeat_rules='Sustained', range=('Zero', value)))
            if (effects == []):
                if not ((value == 0)):
                    raise AssertionError
                return {}
            from game.operate.faces_helper import FacesHelper
            return FacesHelper.ListToDict(effects[0].targets)
        units = assign(targets, value, by_effect)
        for unit in units:
            value = units[unit]
            unit.HealHealth(value, by_effect)
    def ChooseEffects(self, effects, message, *, forced = False, priority = TimingPriority.Normal):
        from game.event.manager import EventManager
        player = self.GetPlayer()
        filtered_effects = EventManager.FilterAvailableEffects(message, effects, player, player.world, None)
        if (filtered_effects == []):
            return
        from game.message import Message
        Message.PlayerOnEvent_Text(player, message)
        effect = self.ChoiceAndSpellEffect(filtered_effects, message, priority, forced)[0]
        cheat = self.ChoiceAndSpellEffect(filtered_effects, message, priority, forced)[1]
        if cheat:
            pass
        return effect
    def ChooseAbilities(self, by_effect, *abilities, forced = True, repeat = 1, choose_x_different_options = None, for_second_target = False):
        all_abilities = list(abilities)
        chose_effects = []
        must_different = False
        if (choose_x_different_options != None):
            must_different = True
            repeat = choose_x_different_options
        for i in range(repeat):
            effect = self.ChooseAbilitiesHelper(*tuple([by_effect, *all_abilities]), **{'forced': forced, 'step': ((i + 1), repeat), 'for_second_target': for_second_target})
            if effect:
                chose_effects.append(effect)
                if must_different:
                    all_abilities.remove(effect.ability)
        return chose_effects
    def ChooseAbilitiesHelper(self, by_effect, *abilities, forced = True, step = (1, 1), for_second_target = False):
        priority = TimingPriority.Normal
        if not (by_effect.is_rule):
            type = by_effect.ability.flags
            if type.is_interrupt:
                priority = TimingPriority.Interrupt
            else:
                if type.is_response:
                    priority = TimingPriority.Response
        player = self.GetPlayer()
        player.world.object_manager.ResetChooseEffect()
        effects = []
        identity = player.GetIdentity()
        for ability in abilities:
            if (ability == None):
                pass
            effect = Effect(identity, ability, world=by_effect.world)
            effects.append(effect)
            if ('ForChoiceAbilityWithCost' in ability.func_names):
                forced = False
        message = Message.WhenPlayerChooseAbility(player, by_effect, step, for_second_target)
        message.Send()
        return self.ChooseEffects(effects, message, forced=forced, priority=priority)
    def MayChooseOneAbility(self, by_effect: Effect, *abilities: Ability) -> Effect|None:
        cancel_ability = AbilityFactory.ForChoiceAbility('Cancel', lambda targets: None)
        effects = self.ChooseAbilities(*tuple([by_effect, *abilities, cancel_ability]))
        if effects:
            if (effects[0].ability == cancel_ability):
                return
        return effects[0]
    def ChoiceAndSpellEffect(self, filtered_effects, message, priority, forced = False):
        from engine import Engine
        game = Engine.game
        player = self.GetPlayer()
        if not ((filtered_effects != [])):
            raise AssertionError(f'filtered_effects={filtered_effects!r} message={message!r}')
        fallthrough_effect = None
        need_choose = True
        backup_effects = filtered_effects[:]
        for find_effect in filtered_effects[:]:
            if find_effect.context.only_work_when_no_other_options:
                filtered_effects.remove(find_effect)
        if (filtered_effects == []):
            filtered_effects = backup_effects
        for find_effect in filtered_effects:
            if (forced == True):
                fallthrough_effect = find_effect
                min_target_num = fallthrough_effect.context.target_range[0]
                max_target_num = fallthrough_effect.context.target_range[1]
                fallthrough_effect.context.targets_internal = fallthrough_effect.context.all_legal_targets[:min_target_num]
                if not (forced):
                    if fallthrough_effect.ability.NeedCost():
                        raise AssertionError({fallthrough_effect.ability})
                if (min_target_num == max_target_num):
                    if (min_target_num <= 1):
                        if (len(find_effect.context.all_legal_targets) <= find_effect.context.target_range[0]):
                            need_choose = False
                    else:
                        if (len([x for x in fallthrough_effect.targets if (x == fallthrough_effect.targets[0])]) == len(fallthrough_effect.targets)):
                            if (fallthrough_effect.context.all_legal_targets == fallthrough_effect.targets):
                                need_choose = False
            else:
                pass
        if (len(filtered_effects) != 1):
            need_choose = True
        else:
            if filtered_effects[0].ability.is_play:
                if not (filtered_effects[0].ability.flags.is_delay_ability):
                    if filtered_effects[0].this.IsLikeInHand():
                        if not (filtered_effects[0].this.card.area.flags.is_processing):
                            need_choose = True
        if (fallthrough_effect == None):
            for find_effect in filtered_effects:
                if find_effect.must_choose:
                    fallthrough_effect = find_effect
                    min_target_num = fallthrough_effect.context.target_range[0]
                    fallthrough_effect.context.targets_internal = fallthrough_effect.context.all_legal_targets[:min_target_num]
                    if fallthrough_effect.ability.NeedCost():
                        raise AssertionError({fallthrough_effect.ability})
        def choice_one_effect(effect_list):
            if not (need_choose):
                return (fallthrough_effect, False)
            if fallthrough_effect:
                if fallthrough_effect.IsName('Cancel'):
                    if (len(effect_list) == 1):
                        return (fallthrough_effect, False)
            if not (player.is_eliminated):
                if message.world.is_game_over:
                    return (None, False)
            return (None, False)
            if (type(message) is Message.WhenPlayerChooseAbility):
                bind_effect = message.by_effect
            else:
                bind_effect = None
            from game.world.world import Phase
            set_undo = False
            if (type(message) == Message.WhenPlayerInTurn):
                set_undo = True
            else:
                if (message.world.phase.state == Phase.State.PlayerTurnEnd):
                    set_undo = True
                else:
                    if (message.world.phase.state == Phase.State.EnemyActivation):
                        if (type(message) == Message.WhenUnitBeingAttack):
                            set_undo = True
                    else:
                        if (message.world.phase.state == Phase.State.RevealsEncounterCards):
                            if (type(message) == Message.WhenPlayerRevealCard):
                                set_undo = True
                        else:
                            if (message.world.phase.state == Phase.State.ResolveMulligans):
                                set_undo = True
            if set_undo:
                game.controller_manager.undo.PushNewStep(game.controller_manager.replay.current_step_id)
            selected = player.GetController().ChoiceOne(effect_list, bind_effect, message, priority, forced)[0]
            is_cheating = player.GetController().ChoiceOne(effect_list, bind_effect, message, priority, forced)[1]
            game.controller_manager.undo.UpdateLastStep()
            if message.world.is_game_over:
                return (None, False)
            return (selected, is_cheating)
        effect = choice_one_effect(filtered_effects)[0]
        is_cheating = choice_one_effect(filtered_effects)[1]
        if is_cheating:
            return (None, True)
        if not (effect):
            if fallthrough_effect:
                effect = fallthrough_effect
        if not (effect):
            return (effect, False)
        if message.world.is_game_over:
            return (effect, False)
        if self.ResolveEffect(effect, message):
            return (effect, False)
        if (effect != fallthrough_effect):
            if (type(message) == Message.WhenPlayerInTurn):
                game.controller_manager.replay.Pop()
                if not (Build.release):
                    game.controller_manager.skip.Clean()
                message.world.render.PresentForceNoWait(is_update=False)
                Log.Assert(CATEGORY_NAME, f'{effect} failed')
                return (effect, False)
            if (fallthrough_effect != None):
                effect = fallthrough_effect
            else:
                effect = None
                return (effect, False)
                return (None, False)
        else:
            return (None, False)
    def ResolveSpecialAbility(self, faces, by_effect):
        player = self.GetPlayer()
        for face in faces:
            face.ResolveSpecialAbility(player, by_effect, sequence=faces)
    def ResolveEffect(self, effect, message):
        from game.card.face.base import ClassCard
        from game.operate.faces import Faces
        this = effect.this
        is_like_from_hand = this.IsLikeInHand()
        if effect.ability.is_play:
            if not (effect.ability.flags.is_delay_ability):
                from_area = this.card.area
                Faces.MoveAllToProcessingArea([this], effect)
            else:
                from_area = None
        else:
            from_area = None
        player = self.GetPlayer()
        if effect.checker.CheckBeforeActive(player):
            if effect.ability.is_play:
                if not (effect.ability.flags.is_delay_ability):
                    if not ((from_area != None)):
                        raise AssertionError
                    this = effect.this.CastTo(ClassCard)
                    if this.Play(player, effect, message, effect.context.paid_this_resources, from_area, is_like_from_hand):
                        player.stat.RecordPlayedFace(this)
                        player.world.buff_manager.OnRecordPlayedFace(this)
                    return True
            effect.ResolveSelf(message, effect)
            return True
        if effect.ability.is_play:
            Faces.DiscardAll([this], effect)
        if effect.ability.selectors:
            if effect.ability.selectors[0]:
                effect.ability.selectors[0].IfSelectTargetFailure(effect)
        from game.test import Test
        if Test.IsInTesting():
            from core.lib.beep import Beep
            Beep.Warning()
        Log.Assert(CATEGORY_NAME, f'{effect} failed')
        if not (Build.release):
            controller_manager = player.controller.manager
            if controller_manager.skip.SetIsSkipping(False):
                if player.world:
                    player.world.render.PresentForceNoWait()
        return False
    def GetCountHandSizeFaces(self):
        player = self.GetPlayer()
        count_faces = []
        for face in player.hand_cards.Get():
            message = Message.CheckIfFaceCountHandSize(player, face)
            message.Send()
            if message.count_hand_size:
                count_faces.append(face)
        return count_faces
    def DrawUp(self, size, by_effect):
        from game.message import Message
        from game.card.face.card_type import Obligation
        player = self.GetPlayer()
        if player.world.is_game_over:
            return []
        if player.is_eliminated:
            return []
        faces = []
        if (size == 'Max'):
            max_repeat_times = 10
            if not ((max_repeat_times > 0)):
                raise AssertionError
            max_repeat_times = (max_repeat_times - 1)
            if player.is_eliminated:
                return []
            if by_effect.world.is_game_over:
                return []
            count_hand_cards = player.GetCountHandSizeFaces()
            size = (player.hand_size - len(count_hand_cards))
            size = (size - len([x for x in faces if Obligation.IsType(x)]))
            if (size > 0):
                faces = (faces + player.DrawUp(size, by_effect))
            else:
                return faces
        def draw_up(face: 'CardFace'):
            message = Message.WhenPlayerWouldDrawCard(player, face, by_effect)
            message.Send()
            if not (message.is_be_instead):
                face.card.MoveToArea(player.hand_cards, by_effect, ui_group=True)
                return
        faces = self.PopPlayerDeckCards(size, draw_up, by_effect, continue_after_shuffle=True)
        if (len(faces) < size):
            player.Eliminate(by_effect)
        message = Message.AfterPlayerDrewCards(player, {x: player.player_deck for x in faces}, by_effect)
        message.Send()
        return faces
    def GainCard(self, faces, by_effect):
        from game.operate.faces import Faces
        from game.card.face.card_face import CardFace
        from game.player import Player
        from game.effect.rule import GameRule
        player = self.GetPlayer()
        if isinstance(faces, CardFace):
            faces = [faces]
        for face in faces:
            if face.IsInPlay():
                Faces.DiscardAll(face.GetInventoryDeck().Get(), GameRule(face))
                Faces.DiscardAll(face.GetPlacedCardArea().Get(), GameRule(face))
            from game.card.face.base import ClassCard
            if (type(face.card.GetOwner()) is not Player):
                if ClassCard.IsType(face):
                    face.card.SetOwner(player)
        moved_faces = Faces.MoveAllTo(faces, player.hand_cards, by_effect)
        Message.AfterPlayerGainCards_Text(player, moved_faces, by_effect)
        return moved_faces
    def DiscardRandomHandCards(self, size, by_effect, rule = ''):
        from game.operate.faces import Faces
        faces = self.GetRandomHandCards(size, rule)
        Faces.DiscardAll(faces, by_effect)
        return faces
    def GetRandomHandCards(self, size, rule = ''):
        from game.card.face.base import ClassCard
        player = self.GetPlayer()
        faces = player.hand_cards.Get()
        if (rule == 'IdentitySpecific'):
            for face in faces[:]:
                if ClassCard.IsType(face):
                    if not (face.IsClass('IdentitySpecific')):
                        faces.remove(face)
                faces.remove(face)
        if (len(faces) > size):
            from game.operate.rand import Rand
            return Rand.RandomChoice2(faces, size, player.world)
        return player.hand_cards.Get()
    def DiscardAllHands(self, by_effect, finder = None):
        from game.operate.faces import Faces
        player = self.GetPlayer()
        faces = player.hand_cards.FindCards(finder)
        return len(Faces.DiscardAll(faces, by_effect))
    def GetAllResourceHandCards(self, text):
        from game.card.face.base import ClassCard
        player = self.GetPlayer()
        return [x for x in player.hand_cards.Get() if ClassCard.IsType(x) if x.printed_resource.HasColorPrinted(text)]
    def PlayAnAlly(self, ally, paying_cost):
        from game.element.resources import Resources
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        player = self.GetPlayer()
        effects = ally.effect.Find(func_name='Play')
        for effect in effects:
            effect.context.initiator = player
            message = Message.WhenPlayerLikeInTurn(player, GameRule(player.GetIdentity()))
            message.Send()
            effect.checker.UpdateLegalTargets()
            effect.context.targets_internal = effect.context.all_legal_targets[:effect.context.target_range[1]]
            effect.context.bind_message = message
            from_area = ally.card.area
            if paying_cost:
                ally.card.can_state.is_like_in_hand = True
                self.ChooseEffects([effect], message)
                ally.card.can_state.is_like_in_hand = None
        return False
    def PlayOneCardLikeInTurn(self, faces, by_effect, *, ignore_resources_cost = False, update_resources_cost = 0, forced = False):
        from game.card.face.attribute.has_cost import HasCost
        from game.operate.faces import Faces
        player = self.GetPlayer()
        faces = [x for x in faces if x.CanPlayBy(player)]
        face = player.AskChooseFace(faces, by_effect, forced=forced, peek=True, not_move=False)
        if HasCost.IsType(face):
            player.PlayCardsLikeInTurn([face], by_effect, ignore_resources_cost=ignore_resources_cost, update_resources_cost=update_resources_cost, forced=forced)
        if face:
            if face.card.area.flags.is_processing:
                Faces.DiscardAll([face], by_effect)
                return
                return
    def MakeBasicPowerLikeInTurn(self, faces, by_effect, which_powers, *, when_use = None):
        from game.card.face.base import Friend
        from game.operate.effects import Effects
        effects = []
        temp_effects = []
        for face in faces:
            if Friend.IsType(face):
                effects = (effects + face.GetBasicPowerEffects(which_powers))
        player = self.GetPlayer()
        identity = player.GetIdentity()
        if when_use:
            when_use_effects = identity.effect.Registers(AbilityFactory.WhenUnitUseBasicPower(AbilityType.Temp0, faces, lambda effect, message: when_use(message.trigger, message)))
            temp_effects = (temp_effects + when_use_effects)
        message = Message.WhenPlayerLikeInTurn(player, by_effect)
        message.Send()
        player.ChooseEffects(effects, message)
        Effects.UnRegister(temp_effects)
    def PlayCardsLikeInTurn(self, faces, by_effect, *, ignore_resources_cost = False, update_resources_cost = 0, give_piercing = False, forced = True, after_play = None, if_not_play_discard_it = True):
        from game.card.face.attribute.has_cost import HasCost
        from game.operate.effects import Effects
        from game.operate.faces import Faces
        player = self.GetPlayer()
        identity = player.GetIdentity()
        def play_card(face):
            effects = face.GetTurnPlayEffects()
            temp_effects = []
            if ignore_resources_cost:
                for check_effect in effects:
                    temp_effects = (temp_effects + face.effect.Registers(AbilityFactory.IgnoreThisCostIf(AbilityType.Temp0)))
            else:
                if (update_resources_cost != 0):
                    for check_effect in effects:
                        temp_effects = (temp_effects + face.effect.RegisterTemp(AbilityFactory.ReduceCostToPlayThis(lambda effect: (-1 * update_resources_cost), which_effect=check_effect), unregister_after_exec=False))
            if give_piercing:
                for check_effect in effects:
                    temp_effects = (temp_effects + identity.effect.Registers(AbilityFactory.WhenUnitWouldAttack(AbilityType.Temp0, None, lambda effect, message: message.GainPiercing(effect), by_effect=check_effect)))
            message = Message.WhenPlayerLikeInTurn(player, by_effect)
            message.Send()
            forced_play = forced
            if forced_play:
                if not (ignore_resources_cost):
                    forced_play = False
            face.card.can_state.is_like_in_hand = True
            played = player.ChooseEffects(effects, message, forced=forced_play)
            face.card.can_state.is_like_in_hand = None
            Effects.UnRegister(temp_effects)
            if after_play:
                after_play(face)
            if not (played):
                if if_not_play_discard_it:
                    if face.IsInProcessingArea():
                        Faces.DiscardAll([face], by_effect)
            return played
        played_faces = []
        for face in faces:
            if HasCost.IsType(face):
                if play_card(face):
                    played_faces.append(face)
        return played_faces
    def PopPlayerDeckCards(self, size, process, by_effect, *, continue_after_shuffle = False):
        player = self.GetPlayer()
        if player.is_eliminated:
            return []
        faces = player.player_deck.PopInternal(size, process, by_effect, continue_after_shuffle=continue_after_shuffle)
        return faces
    def DiscardDeckTopCards(self, size, by_effect):
        player = self.GetPlayer()
        if player.is_eliminated:
            return []
        from game.operate.worlds import Worlds
        size = Worlds.ConvertPerPlayerIconToInt(size, by_effect)
        faces = player.player_deck.DiscardCardsInternal(size, by_effect, continue_after_shuffle=False)
        return faces
    def DiscardDeckTopCard(self, by_effect: Effect) -> 'CardFace':
        faces = self.DiscardDeckTopCards(1, by_effect)
        return faces[0]
    def DiscardDeckUntil(self, by_effect, *, name = None, trait = None, card_type = CardFaceType, return_other_faces = None, **kwargs):
        player = self.GetPlayer()
        if player.is_eliminated:
            return
        face = player.player_deck.DiscardUntil(*(by_effect,), **{'name': name, 'trait': trait, 'card_type': card_type, **kwargs})[0]
        other = player.player_deck.DiscardUntil(*(by_effect,), **{'name': name, 'trait': trait, 'card_type': card_type, **kwargs})[1]
        if (return_other_faces != None):
            return_other_faces.clear()
            return_other_faces.extend(other)
        return face
    def SpendResource(self, for_effect, paid_effects, payment):
        from game.message import Message
        player = self.GetPlayer()
        paid_faces = []
        for paying_effect in paid_effects:
            paid = False
            for pay_info in payment.payments:
                if (paying_effect in pay_info):
                    paid = True
                    expected_res = Resources.FromText(pay_info[paying_effect])
                    paying_effect.context.initiator = player
                    cost_check_effect = payment.cost_check[paying_effect]
                    message = Message.WhenPlayerPayingResources(player, paying_effect, for_effect, for_effect.targets, expected_res, cost_check_effect)
                    message.Send()
                    paid_faces.append(paying_effect.this)
                else:
                    pass
            if not (paid):
                raise AssertionError(f'paying_effect={paying_effect!r} for_effect={for_effect!r}')
        spent_message = Message.AfterCardsBeSpendAsResource(paid_faces, for_effect, player)
        spent_message.Send()
        for_effect.world.DiscardResourcesArea()
        resource = player.res_pool.Get()
        player.res_pool.Reset()
        return resource
    def AskSpendResources(self, cost, by_effect):
        paid_res = self.AskSpendResourcesInternal(cost, by_effect)
        return (paid_res != None)
    def AskSpendResourcesInternal(self, cost: Cost, by_effect: Effect) -> Resources|None:
        player = self.GetPlayer()
        effects = player.ChooseAbilities(by_effect, AbilityFactory.ForChoiceAbilityWithCost(cost))
        if effects:
            return effects[0].context.paid_this_resources
    def PayCardPrintCost(self, face: 'HasCost', by_effect: Effect) -> Resources|None:
        player = self.GetPlayer()
        player.world.object_manager.ResetChooseEffect()
        ability = AbilityFactory.ForChoiceAbilityWithCost(face.printed_cost)
        message = Message.WhenPlayerChooseAbility(player, by_effect, (1, 1), False)
        message.Send()
        effect = self.ChooseEffects([Effect(face, ability, world=by_effect.world)], message)
        if effect:
            return effect.context.paid_this_resources
    def LookAtDeck(self, deck, num, by_effect, *, from_top = True):
        from game.operate.faces import Faces
        from game.operate.worlds import Worlds
        player = self.GetPlayer()
        num = Worlds.ConvertPerPlayerIconToInt(num, by_effect)
        if (deck == 'EncounterDeck'):
            deck = Worlds.GetEncounterDeck(by_effect)
        faces = deck.Get(from_top)[:num]
        Faces.LookAt(faces, player, by_effect)
        return faces
    def SwapTheseCards(self, faces, by_effect):
        from game.operate.faces import Faces
        def action(targets):
            Faces.SwapTwoCards(targets, by_effect)
        effect = self.MayChooseOneAbility(by_effect, AbilityFactory.ForChoiceAbility('Select 2 cards to swap', action).SetTargetInternal(Select.From(faces=faces, range=(2, 2), by_search=True, not_shuffle=True, not_move=True)))
        if (effect == None):
            return
        if effect.world.is_game_over:
            return
