# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.player.limit_monitor.ally_limit import AllyLimit
from game.player.limit_monitor.restricted_limit import RestrictedLimit
from game.player.limit_monitor.team_limit import TeamLimit
Unused(AllyLimit)
Unused(RestrictedLimit)
Unused(TeamLimit)
