# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.object import Object
from game.world.game_area import *
from game.card.face import *
from game.world import *
class User(Object):
    def __init__(self, name, world):
        self
        self.is_eliminated = False
        super().__init__(name, world)
    def __repr__(self):
        from game.player import Player
        from game.player import Scenario
        if not (isinstance(self, (Player | Scenario))):
            raise AssertionError(f'self={self!r} type(self)={type(self)!r}')
        return self.name
    @final
    def IsScenario(self):
        return self.is_scenario
    def IsPlayer(self):
        return False
    def GetRoleCharacter(self) -> 'Identity|Villain':
        raise AssertionError
    def GetGameArea(self) -> GameArea:
        raise AssertionError(f'You need to override this function, self={self!r}')
