# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
class PlayerFlag:
    def __init__(self):
        self.Reset()
    FLAG = Literal[('MAGIK_ONCE_PER_PHASE', 'YOU_TAKE_THE_FIRST_TURN_DURING_THE_PLAYER_PHASE')]
    def Reset(self):
        self.flags = {}
    def Set(self, flag, value):
        self.flags[flag] = value
    def Get(self, flag):
        if (flag in self.flags):
            return self.flags[flag]
        return 0
    def Update(self, flag, value):
        value = (value + self.Get(flag))
        self.Set(flag, value)
