# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.selector import *
from game.deck import *
from game.ability.factory import *
from game.message import *
from game.player import *
from game.element.resources import Resources
class PlayerAsk:
    def GetPlayer(self) -> 'Player':
        from game.player import Player
        return Cast(Player, self)
    def AskSpecifyResources(self, res: Resources) -> Resources:
        g = res.GetColor('G', convert_green_res=False)
        if (g == 0):
            return res
        from itertools import combinations_with_replacement
        def generate_combinations(n):
            letters = [*('R', 'B', 'Y')]
            combinations = combinations_with_replacement(letters, n)
            return [''.join(comb) for comb in combinations]
        res_text = ((('R' * res.r) + ('B' * res.b)) + ('Y' * res.y))
        res_text = (res_text + self.AskChooseOneText(generate_combinations(g)))
        return Resources.FromText(res_text)
    def MayChoosePaper(self, name_list):
        name_list = [f'p_{x}' for x in name_list]
        name = self.MayChooseOneText(name_list)
        if name:
            return name.lstrip('p_')
    def AskChoosePaper(self, name_list):
        name_list = [f'p_{x}' for x in name_list]
        name = self.AskChooseOneText(name_list)
        return name.lstrip('p_')
    T = TypeVar('T')
    def MayChooseOneText(self, item_list, text_list = None):
        item_list2 = (list(item_list) + [None])
        if text_list:
            text_list2 = (list(text_list) + ['Cancel'])
        else:
            text_list2 = None
        return self.AskChooseOneText(item_list2, text_list2)
    def AskChooseOneText(self, item_list, text_list = None):
        from game.card.face.card_face import CardFace
        from game.effect.rule import GameRule
        abilities = []
        select = item_list[0]
        player = self.GetPlayer()
        def create_ability(item, text):
            def invoke_select():
                select = item
            ability = AbilityFactory.ForChoiceAbility(text, lambda targets: invoke_select())
            return ability
        for item in item_list:
            if text_list:
                text = text_list[item_list.index(item)]
            else:
                if not (item):
                    if (item == 0):
                        if isinstance(item, CardFace):
                            text = item.name
                        else:
                            text = str(item)
                            text = 'Cancel'
                    else:
                        text = 'Cancel'
                if isinstance(item, CardFace):
                    text = item.name
                else:
                    text = str(item)
                    text = 'Cancel'
            abilities.append(create_ability(item, text))
        effect = player.ChooseAbilities(*tuple([GameRule(player.GetIdentity()), *abilities]))
        if not (effect):
            raise AssertionError
        return select
    def DeclareCardType(self):
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Hero
        from game.card.face.card_type import AlterEgo
        from game.card.face.card_type import Minion
        from game.card.face.base import Villain
        from game.card.face.card_type import MainScheme
        from game.card.face.card_type import EncounterSideScheme
        from game.card.face.card_type import PlayerSideScheme
        from game.card.face.card_type import Upgrade
        from game.card.face.card_type import Support
        from game.card.face.card_type import Attachment
        from game.card.face.card_type import Environment
        from game.card.face.card_type import Event
        from game.card.face.card_type import Obligation
        from game.card.face.card_type import Treachery
        from game.card.face.card_type import Resource
        from game.card.face.card_type import Evidence
        item_list = [Hero, AlterEgo, Ally, Event, Resource, Support, Upgrade, Obligation, MainScheme, EncounterSideScheme, PlayerSideScheme, Minion, Villain, Treachery, Attachment, Environment, Evidence]
        text_list = []
        for item in item_list:
            text_list.append(item.__name__)
        return self.AskChooseOneText(item_list, text_list)
    def DeclareNumber(self, min, max):
        return self.AskChooseOneText(list(range(min, (max + 1))))
    def DeclareResourceType(self, r = True, b = True, y = True, g = True):
        text = []
        if r:
            text.append('R')
        if b:
            text.append('B')
        if y:
            text.append('Y')
        if g:
            text.append('G')
        return self.AskChooseOneText(text)
    def DeclareStatusCard(self, *, confused = True, stunned = True, tough = True):
        from game.card.face.card_face import CardFace
        status_text = []
        if confused:
            status_text.append('confused')
        if stunned:
            status_text.append('stunned')
        if tough:
            status_text.append('tough')
        if (status_text == []):
            return
        status = self.AskChoosePaper(status_text)
        status = (status[0].upper() + status[1:])
        return Cast(CardFace.STATUS, status)
    def ChooseOrder(self, faces, *, prompt = ''):
        from game.effect.rule import GameRule
        if (len(faces) == 1):
            return list(faces)
        player = self.GetPlayer()
        effect = player.ChooseAbilities(GameRule(player.GetIdentity()), AbilityFactory.ForChoiceAbility(prompt).SetTarget(faces, range='All'))
        if not (effect):
            if not ((len(faces) == 0)):
                raise AssertionError
            return []
        return effect[0].targets
    def AskChooseSelect(self, selector, by_effect, *, prompt = '', forced = True, labels = [], for_second_target = False):
        player = self.GetPlayer()
        ability = AbilityFactory.ForChoiceAbility(prompt).SetLabel(*labels).SetTargetInternal(selector)
        if forced:
            effects = player.ChooseAbilities(by_effect, ability, for_second_target=for_second_target)
            effect = (effects[0] if effects else None)
        else:
            effect = player.MayChooseOneAbility(by_effect, ability)
        if effect:
            return effect.targets
        return []
    def AskChooseFaces(self, faces, range, by_effect, *, prompt = '', forced = True, peek = False, not_move = False, not_shuffle = False, repeat_rules = []):
        player = self.GetPlayer()
        selector = Select.From(faces=faces, range=range, by_search=peek, not_move=not_move, not_shuffle=not_shuffle, repeat_rules=repeat_rules)
        return_faces = player.AskChooseSelect(selector, by_effect, prompt=prompt, forced=forced)
        return return_faces
    def AskChooseFace(self, faces, by_effect, *, prompt = '', forced = True, peek = False, not_move = True):
        targets = self.AskChooseFaces(faces, (1, 1), by_effect, prompt=prompt, forced=forced, peek=peek, not_move=not_move)
        if targets:
            return targets[0]
    def MayChooseFace(self, faces, by_effect, *, not_move = False):
        return self.AskChooseFace(faces, by_effect, forced=False, not_move=not_move)
    def AskDiscardFaces(self, faces, range, by_effect, *, not_shuffle = False):
        from game.operate.faces import Faces
        from game.card.card_finder import CardFinder
        if (range == 'Any'):
            range = (0, 'All')
        if (range == (0, 0)):
            return []
        selector = Select.From(faces=faces, finder=CardFinder(canbe_discard=True), range=range, not_shuffle=not_shuffle, by_search=True, not_move=True)
        player = self.GetPlayer()
        if by_effect.is_rule:
            text = ''
        else:
            text = 'Discard'
        faces = player.AskChooseSelect(selector, by_effect, prompt=text)
        if faces:
            Faces.DiscardAll(faces, by_effect)
            return faces
        return []
    def AskDiscardFace(self, faces, by_effect, *, not_shuffle = False):
        player = self.GetPlayer()
        faces = player.AskDiscardFaces(faces, (1, 1), by_effect, not_shuffle=not_shuffle)
        if not ((len(faces) <= 1)):
            raise AssertionError
        if faces:
            return faces[0]
    def DiscardHandCards(self, range, by_effect, *, card_type = None, most_printed_res = False, highest_cost = False, lowest_cost = False, finder = None):
        from game.operate.filter import Filter
        player = self.GetPlayer()
        faces = player.hand_cards.Get()
        if card_type:
            faces = Filter.ByType(faces, card_type)
        if finder:
            faces = finder.Checks(faces)
        faces = Filter.All(faces, most_printed_res=most_printed_res, highest_cost=highest_cost, lowest_cost=lowest_cost)
        if (len(faces) == 0):
            return []
        faces = player.AskDiscardFaces(faces, range, by_effect)
        return faces
    def DiscardControlCards(self, by_effect, *, ally = False, upgrade = False, support = False, control = False, range = (1, 1), card_type = None, finder = None, highest_cost = False, lowest_cost = False, most_printed_res = False):
        from game.operate.filter import Filter
        from game.card.card_finder import CardFinder
        player = self.GetPlayer()
        player_side_scheme = False
        if not (control):
            if (ally == False):
                if (upgrade == False):
                    if (support == False):
                        ally = True
                        upgrade = True
                        support = True
                        player_side_scheme = True
        ally = True
        upgrade = True
        support = True
        player_side_scheme = True
        faces = player.GetControlCardsByType(ally=ally, upgrade=upgrade, support=support, player_side_scheme=player_side_scheme)
        if card_type:
            faces = Filter.ByType(faces, card_type)
        if finder:
            faces = finder.Checks(faces)
        faces = CardFinder(canbe_discard=True).Checks(faces)
        faces = Filter.All(faces, highest_cost=highest_cost, lowest_cost=lowest_cost, most_printed_res=most_printed_res)
        faces = player.AskDiscardFaces(faces, range, by_effect)
        if faces:
            return faces[0]
