# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
class PlayerStat:
    def __init__(self):
        self.this_turn_played_cards = []
        self.this_round_played_cards = []
        self.this_phase_played_cards = []
        self.this_phase_revealed_cards = []
        self.kill_counter = []
    def ResetPlayedRevealedCards(self):
        self.this_turn_played_cards.clear()
        self.this_round_played_cards.clear()
        self.this_phase_played_cards.clear()
        self.this_phase_revealed_cards.clear()
    def ResetKillCounter(self):
        self.kill_counter.clear()
    def UpdateKillCounter(self, unit: Unit2):
        self.kill_counter.append(unit)
    def RecordPlayedFace(self, face: CardFace):
        self.this_turn_played_cards.append(face)
        self.this_round_played_cards.append(face)
        self.this_phase_played_cards.append(face)
    def RecordReveal(self, face: CardFace):
        self.this_phase_revealed_cards.append(face)
    def GetThisRoundPlayedCard(self, index):
        if (index < len(self.this_round_played_cards)):
            return self.this_round_played_cards[index]
    def GetThisPhasePlayedCard(self, index):
        if (index < len(self.this_phase_played_cards)):
            return self.this_phase_played_cards[index]
    def IsFirstCardPlayedThisRound(self):
        return (self.GetThisRoundPlayedCard(0) == None)
    def OnBeginTurn(self):
        self.this_turn_played_cards.clear()
    def OnEndTurn(self):
        self.this_turn_played_cards.clear()
    def OnBeginPhase(self):
        self.this_phase_revealed_cards.clear()
        self.this_phase_played_cards.clear()
        self.ResetKillCounter()
    def OnEndPhase(self):
        self.this_phase_revealed_cards.clear()
        self.this_phase_played_cards.clear()
    def OnBeginRound(self):
        self.this_round_played_cards.clear()
    def OnEndRound(self):
        self.this_round_played_cards.clear()
