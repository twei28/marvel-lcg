# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.card import *
from game.ability import *
from game.ability.condition import *
from game.ability.factory import *
from game.selector import *
from game.player import *
from game.world.game_area import *
from engine.controller import *
from game.player.model.player_ask import PlayerAsk
from game.player.model.player_cards import PlayerCards
from game.player.action.player_get import PlayerGet
from game.player.action.player_action import PlayerAction
from game.player.element.resources_pool import ResourcesPool
from game.player.element.player_flag import PlayerFlag
from game.player.element.player_phase import PlayerPhase
from game.world import *
class Player(User, PlayerAsk, PlayerCards, PlayerGet, PlayerAction):
    def __enter__(self):
        self.world.asking_player.append(self)
        return self
    def __exit__(self, *obj):
        self.world.asking_player.pop()
    def __init__(self, name, controller, player_id, world):
        from game.effect.rule import GameRule
        super().__init__('player', world)
        self.is_scenario = False
        self.name = name
        self.controller = controller
        self.player_id = player_id
        self.get_additional_from_function = None
        from game.deck import Deck2
        from game.deck import DeckType
        from game.card.face.card_face import CardFace
        from game.card.face.card_type import Support
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Minion
        from game.card.face.card_type import Obligation
        from game.card.face.card_type import AlterEgo
        from game.card.face.card_type import Hero
        from game.card.face.card_type import Environment
        from game.player.element.player_stat import PlayerStat
        from game.player.limit_monitor import AllyLimit
        from game.player.limit_monitor import RestrictedLimit
        from game.player.limit_monitor import TeamLimit
        from game.player.form.form import Form
        from game.player.element.player_setup import PlayerSetup
        self
        self.set_aside_nemesis_sets = Deck2(world.GetScenario(), DeckType.AsideDeck, CardFace)
        self.hand_cards = Deck2(self, DeckType.HandsArea, CardFace)
        self.player_deck = Deck2(self, DeckType.PlayerDeck, CardFace)
        self.discard_pile = Deck2(self, DeckType.DiscardPile, CardFace)
        def process_after_shuffle(deck: 'Deck', by_effect: Effect):
            self.DealEncounterCards(1, GameRule(self.GetIdentity()))
        self.player_deck.BindDiscardPile(self.discard_pile, process_after_shuffle)
        self.supports = Deck2(self, DeckType.SupportsArea, Support)
        self.allies = Deck2(self, DeckType.AlliesArea, Ally)
        self.area_hero = Deck2(self, DeckType.HeroArea, (AlterEgo | Hero))
        self.engaged_minions = Deck2(world.GetScenario(), DeckType.EngagedEnemiesArea, Minion, related_player=self)
        self.area_environment = Deck2(world.GetScenario(), DeckType.EnvironmentArea, Environment, related_player=self)
        self.obligations_area = Deck2(world.GetScenario(), DeckType.ObligationsArea, Obligation, related_player=self)
        self.dealt_encounter_cards = Deck2(world.GetScenario(), DeckType.DealtEncounterCardsDeck, CardFace, related_player=self)
        self.area_resources = Deck2(self, DeckType.ResourcesArea, CardFace)
        self.area_processing = Deck2(self, DeckType.ProcessingArea, CardFace)
        self.stat = PlayerStat()
        self.res_pool = ResourcesPool()
        self.flag = PlayerFlag()
        self.form = Form(self)
        self.phase = PlayerPhase(self)
        self.setup = PlayerSetup(self)
        self.has_change_form = False
        self.additional_deck = Deck2(self, DeckType.AdditionalDeck, CardFace)
        self.additional_discard_pile = Deck2(self, DeckType.AdditionalDiscardPile, CardFace)
        self.additional_deck.BindDiscardPile(self.additional_discard_pile, lambda deck, effect: None)
        self.set_aside_deck = self.additional_discard_pile
        self.limit_ally = AllyLimit(self, 3)
        self.limit_restricted = RestrictedLimit(self, 2)
        self.limit_team = TeamLimit(self)
        self.is_eliminated = False
        self.hero_name = ''
    def Eliminate(self, by_effect: Effect):
        from game.operate.faces import Faces
        from game.operate.worlds import Worlds
        from game.effect.rule import GameRule
        from game.message import Message
        from game.card.card_finder import CardFinder
        from game.card.face.card_type import Identity
        world = self.world
        if not ((self.is_eliminated == False)):
            raise AssertionError
        self.is_eliminated = True
        if not (world.rule.disable_game_over):
            world.CheckIsAllPlayersEliminated()
            if not (world.is_game_over):
                hero = self.GetIdentity()
                rule = GameRule(hero)
                next_player = Worlds.GetNextPlayer(self, by_effect)
                if (next_player != None):
                    world.UpdatePlayersOrder(by_effect)
                    game_area = self.GetGameArea()
                    if (next_player.GetGameArea() == world.GetFirstGameArea()):
                        for face in self.GetEngagedMinions():
                            if next_player:
                                face.EngagePlayer(next_player, by_effect)
                    else:
                        if (game_area.FindAllPlayers() == [self]):
                            schemes = []
                            main_schemes = []
                            for scheme in Worlds.GetAllMainSchemes(by_effect):
                                if (scheme.card.GetGameArea() == game_area):
                                    main_schemes.append(scheme)
                            for scheme in Worlds.GetAllSideSchemes(by_effect):
                                if (scheme.card.GetGameArea() == game_area):
                                    schemes.append(scheme)
                            Faces.DiscardAll(self.GetEngagedMinions(), rule)
                            Faces.DiscardAll(schemes, rule)
                            Faces.RemoveAllFromGame(main_schemes, rule)
    def GetController(self) -> 'Controller':
        if not ((self.controller != None)):
            raise AssertionError
        return self.controller
    @override
    def GetRoleCharacter(self):
        return self.GetIdentity()
    def IsHero(self):
        from game.card.face.card_type import Hero
        hero = self.GetIdentity()
        return Hero.IsType(hero)
    def IsInHeroForm(self, trait = None):
        if not (self.IsHero()):
            return False
        if (trait != None):
            if not (self.GetIdentity().HasTrait(trait)):
                return False
        return True
    def IsAlterEgo(self):
        from game.card.face.card_type import AlterEgo
        hero = self.GetIdentity()
        return AlterEgo.IsType(hero)
    def IsName(self, *names):
        identity = self.GetIdentity()
        def is_name(name):
            if (name == 'SP//dr'):
                if identity.IsName('SP//dr Suit'):
                    return True
            if (name == 'Peni Parker'):
                if identity.IsName('SP//dr Suit'):
                    return True
            if (name == 'Spider-Man - Morales'):
                if identity.paper.card_id.startswith('27'):
                    return True
            return identity.IsName(name, check_all_face=True)
        for name in names:
            if is_name(name):
                return True
        return False
    @property
    def hand_size(self):
        return self.GetIdentity().hand_size
    @override
    def GetGameArea(self) -> GameArea:
        if self.world.is_game_started:
            return self.GetIdentity().card.GetGameArea()
        return self.world.GetFirstGameArea()
    @override
    def IsPlayer(self):
        return True
    @classmethod
    def IsType(cls, user):
        if (user == None):
            return False
        return user.IsPlayer()
    def IsFirstPlayer(self):
        if self.is_eliminated:
            return False
        return (self == self.world.GetFirstPlayer())
