# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.message import *
from game.player import *
class Form:
    __annotations__ = {}
    MASS_FORM_TYPE = Literal[('Intangible', 'Dense', 'Solid', 'Phased')]
    SUIT_FORM_TYPE = Literal[('Assault', 'Stealth')]
    ENERGY_FROM_TYPE = Literal[('Gamma', 'Photon', 'Pulsar')]
    FORM_TYPE = ((MASS_FORM_TYPE | SUIT_FORM_TYPE) | ENERGY_FROM_TYPE)
    ENERGY_FROM_TYPE_LIST = Types.LiteralToList(ENERGY_FROM_TYPE)
    ENERGY_FROM_TYPE_LIST: List[ENERGY_FROM_TYPE]
    FORM_TYPE_LIST = [arg for arg in get_args(FORM_TYPE)]
    def __init__(self, player: Player):
        self.get_additional_from_function = None
        self.player = player
    def FindSuitForm(self) -> 'Upgrade|None':
        upgrades = self.FindFormUpgradeInternal(face_up=True)
        if upgrades:
            return upgrades[0]
    def FindMassForm(self) -> 'Upgrade|None':
        upgrades = self.FindFormUpgradeInternal(face_up=True)
        if upgrades:
            return upgrades[0]
    def FindEnergyForm(self) -> 'Upgrade|None':
        upgrades = self.FindFormUpgradeInternal(face_up=True)
        if upgrades:
            return upgrades[0]
    def FindAllEnergyForms(self):
        return self.FindFormUpgradeInternal()
    def FindFormUpgradeInternal(self, *, face_up = None):
        from game.card.face.card_type import Upgrade
        hero = self.player.GetIdentity()
        faces = hero.GetInventoryDeck().FindCards(include_removed=True, names=Form.FORM_TYPE_LIST, is_face_up=face_up, card_type=Upgrade)
        return faces
    def GetNameInternal(self):
        upgrades = self.FindFormUpgradeInternal(face_up=True)
        if upgrades:
            for from_name in Form.FORM_TYPE_LIST:
                if upgrades[0].IsName(from_name):
                    from_name
                    return
    def ChangeFormInternal(self, by_effect, name = None):
        from game.card.card_finder import CardFinder
        from game.operate.faces import Faces
        if (name != None):
            if self.IsFormInternal(name):
                return False
        identity = self.player.GetIdentity()
        upgrades = self.FindFormUpgradeInternal(face_up=True)
        all_upgrades = self.FindFormUpgradeInternal()
        rest_upgrades = [x for x in all_upgrades if (x not in upgrades)]
        if not (rest_upgrades):
            upgrade = upgrades[0]
        else:
            if (name == None):
                upgrade = self.player.AskChooseFace(rest_upgrades, by_effect)
            else:
                faces = CardFinder(name=name).Checks(rest_upgrades)
                if faces:
                    upgrade = faces[0]
                else:
                    return False
        if upgrade:
            def action():
                if not ((upgrade != None)):
                    raise AssertionError
                if (upgrade in upgrades):
                    upgrade.card.Flip(by_effect)
                    if not ((name == None)):
                        if not (upgrade.card.face.IsName(name)):
                            raise AssertionError
                    return upgrade.card.face
                no_choose_upgrade = [x for x in all_upgrades if (x != upgrade)]
                Faces.FlipAllTo(no_choose_upgrade, False, by_effect)
                upgrade.FlipTo(by_effect, face_up=True)
                return upgrade.card.face
            return identity.ChangeAdditionalFrom(by_effect, action)
        return False
    def ChangeSuitForm(self, by_effect, name = None):
        return self.ChangeFormInternal(by_effect, name)
    def ChangeMassForm(self, by_effect, name = None):
        return self.ChangeFormInternal(by_effect, name)
    def ChangeEnergyForm(self, by_effect, name = None):
        return self.ChangeFormInternal(by_effect, name)
    def SetChangeFromFunc(self, func):
        self.get_additional_from_function = func
    def IsFormInternal(self, form):
        return (self.GetNameInternal() == form)
    def IsInMassForm(self, mass_form):
        return self.IsFormInternal(mass_form)
    def IsInSuitForm(self, suit_form):
        return self.IsFormInternal(suit_form)
    def IsInEnergyForm(self, energy_form):
        return self.IsFormInternal(energy_form)
