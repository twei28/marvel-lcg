# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.player import *
class PlayerGet:
    def GetPlayer(self) -> 'Player':
        from game.player import Player
        return Cast(Player, self)
    def GetSelfFieldAndHandCards(self):
        player = self.GetPlayer()
        return (player.GetOnFieldCards() + player.hand_cards.Get())
    def GetOnFieldCards(self):
        player = self.GetPlayer()
        cards = []
        faces = ((player.area_hero.GetAll() + player.allies.GetAll()) + player.supports.GetAll())
        for face in faces:
            cards = (cards + ([face] + face.GetInventoryDeck().GetAll()))
        return cards
    def GetPlayerAreaCards(self):
        return self.GetOnFieldCards()
    def GetControlUpgrade(self, finder = None):
        from game.card.face.card_type import Upgrade
        from game.operate.worlds import Worlds
        player = self.GetPlayer()
        game_area = player.GetGameArea()
        upgrades = [x for x in self.GetControlCharacters()]
        check_faces = ((Worlds.GetOnFieldEnvironment(game_area) + Worlds.GetOnFieldEnemies(game_area)) + Worlds.GetOnFieldSchemes(game_area))
        upgrades = (upgrades + [x for x in check_faces])
        if finder:
            faces = finder.Checks(upgrades)
            return faces
        faces = upgrades
        return faces
    def GetControlAttachment(self, finder = None):
        from game.card.face.card_type import Attachment
        upgrades = [x.GetInventoryDeck().Get() for x in self.GetControlCharacters()]
        faces = [x for x in upgrades]
        if finder:
            faces = finder.Checks(faces)
        return faces
    def GetControlPlayerSideScheme(self, finder = None):
        from game.card.face.card_type import PlayerSideScheme
        from game.operate.worlds import Worlds
        faces = []
        player = self.GetPlayer()
        schemes = Worlds.GetSideSchemes(player.GetIdentity().card.game_area)
        for scheme in schemes:
            if PlayerSideScheme.IsType(scheme):
                if (scheme.GetControlBy() == player):
                    faces.append(scheme)
        return faces
    def GetControlCharacters(self, finder = None):
        player = self.GetPlayer()
        units = ([self.GetIdentity()] + player.allies.Get())
        if finder:
            units = finder.Checks(units)
        return units
    def GetControlAllies(self, finder = None):
        player = self.GetPlayer()
        units = player.allies.Get()
        if finder:
            units = finder.Checks(units)
        return units
    def GetControlCardsByType(self, finder = None, *, ally = False, upgrade = False, support = False, identity = False, attachment = False, player_side_scheme = False):
        faces = []
        player = self.GetPlayer()
        if ally:
            faces = (faces + player.allies.Get())
        if upgrade:
            faces = (faces + self.GetControlUpgrade())
        if support:
            faces = (faces + player.supports.Get())
        if identity:
            faces.append(player.GetIdentity())
        if attachment:
            faces = (faces + self.GetControlAttachment())
        if player_side_scheme:
            faces = (faces + self.GetControlPlayerSideScheme())
        if finder:
            faces = finder.Checks(faces)
        return faces
    TCA = TypeVar('TCA', bound='CardFace')
    def GetControlCards2(self, finder):
        faces = self.GetControlCardsByType(finder, ally=True, upgrade=True, support=True, identity=True, attachment=False)
        return faces
    def GetControlCards(self, finder = None):
        faces = self.GetControlCardsByType(finder, ally=True, upgrade=True, support=True, identity=True, attachment=False)
        return faces
    def IsControlAttachment(self, finder):
        return (self.GetControlCardsByType(finder, attachment=True) != [])
    def IsControl(self, finder):
        return (self.GetControlCards(finder) != [])
    def GetEngagedMinions(self, finder = None):
        player = self.GetPlayer()
        faces = player.engaged_minions.Get(True)
        if finder:
            faces = finder.Checks(faces)
        return faces
    def GetIdentity(self) -> 'AlterEgo|Hero':
        from game.card.card_finder import CardFinder
        from game.card.face.card_type import AlterEgo
        from game.card.face.card_type import Hero
        player = self.GetPlayer()
        if player.IsScenario():
            raise AssertionError(f'self={self!r}')
        if (player.area_hero.GetSize() == 0):
            identity = player.world.insert
            if not ((identity != None)):
                raise AssertionError
            return identity
        if player.area_hero.Get():
            return player.area_hero.Get()[0]
        faces = player.GetControlCards(CardFinder(card_type=(AlterEgo | Hero)))
        if not (isinstance(faces[0], (AlterEgo | Hero))):
            raise AssertionError
        return faces[0]
    def GetHero(self) -> 'Hero':
        from game.card.face.card_type import Hero
        hero = self.GetIdentity()
        if Hero.IsType(hero):
            return hero
        raise AssertionError(f'hero={hero!r}')
    def GetAlterEgo(self) -> 'AlterEgo':
        from game.card.face.card_type import AlterEgo
        hero = self.GetIdentity()
        if AlterEgo.IsType(hero):
            return hero
        raise AssertionError(f'hero={hero!r}')
    def GetAllIdentityFace(self, exclude = None):
        from game.card.face.card_type import AlterEgo
        from game.card.face.card_type import Hero
        identities = []
        identity = self.GetIdentity()
        identity_card_id = identity.paper.card_id[:-1]
        if identity.paper.card_id.startswith('3100'):
            for face in self.GetControlCardsByType(upgrade=True, support=True, identity=True):
                for check_face in ([face] + face.card.back_faces):
                    if (check_face == exclude):
                        pass
                    if isinstance(check_face, (AlterEgo | Hero)):
                        identities.append(check_face)
            return identities
        if identity_card_id.startswith('test_'):
            for check_face in ([identity] + identity.card.back_faces):
                if (check_face == exclude):
                    pass
                if isinstance(check_face, (AlterEgo | Hero)):
                    identities.append(check_face)
            return identities
        for check_face in ([identity] + identity.card.back_faces):
            if (check_face == exclude):
                pass
            if isinstance(check_face, (AlterEgo | Hero)):
                if (check_face.paper.card_id[:-1] == identity_card_id):
                    identities.append(check_face)
        return identities
