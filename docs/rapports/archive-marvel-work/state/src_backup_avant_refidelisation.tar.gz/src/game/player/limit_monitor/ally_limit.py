# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.effect import *
from game.card.face import *
from game.player import *
class AllyLimit:
    def __init__(self, player, ally_limit):
        self.player = player
        self.ally_limit = ally_limit
        self.curr_ally = 0
    def Get(self):
        return self.ally_limit
    def Increase(self, diff, by_effect):
        self.ally_limit = (self.ally_limit + diff)
        if (diff < 0):
            self.CheckLimit([])
            return
    def CheckLimit(self, gain_faces):
        from game.card.face.card_face import CardFace
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        from game.card.card_finder import CardFinder
        from game.message import Message
        from game.ability.factory import AbilityFactory
        player = self.player
        max_repeat_times = 10
        if not ((max_repeat_times > 0)):
            raise AssertionError
        max_repeat_times = (max_repeat_times - 1)
        if player.is_eliminated:
            return False
        if player.world.is_game_over:
            return False
        not_count_allies = []
        for ally in (player.allies.Get() + gain_faces):
            message = Message.CheckIfAllyCountLimit(ally)
            message.Send()
            if message.not_count:
                not_count_allies.append(ally)
        self.curr_ally = ((player.allies.GetSize() - len(not_count_allies)) + len(gain_faces))
        exceed_num = (self.curr_ally - self.ally_limit)
        if (exceed_num > 0):
            rule = GameRule(player.GetIdentity())
            allies = player.allies.Get()
            for face in allies:
                if not ((face in not_count_allies)):
                    if (face in gain_faces):
                        allies.remove(face)
                allies.remove(face)
            player.ChooseAbilities(rule, AbilityFactory.ForChoiceAbility('Ally Limit', lambda targets: Faces.DiscardAll(targets, rule)).SetTarget(allies, finder=CardFinder(canbe_discard=True)))
        else:
            return True
