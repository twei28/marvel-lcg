# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from game.effect import *
from game.element.resources import Resources
class ResourcesPool:
    def __init__(self):
        self.Reset()
    def Gain(self, res: Resources, by_effect: Effect):
        self.resource_pool = (self.resource_pool + res)
    def Reset(self):
        self.resource_pool = Resources('0')
    def Get(self) -> Resources:
        return self.resource_pool
    def Set(self, res: Resources):
        self.resource_pool = res
