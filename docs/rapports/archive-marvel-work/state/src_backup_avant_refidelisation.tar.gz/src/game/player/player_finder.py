# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.player import *
from game.card.face import *
class PlayerFinder:
    def __init__(self, is_unit = None, *, name = None, non_name = None, trait = None, card_type = None, engaged_with = None, controls = None, with_attach = None):
        self.name = name
        self.non_name = non_name
        self.trait = trait
        self.card_type = card_type
        self.engaged_with = engaged_with
        self.controls = controls
        self.with_attach = with_attach
        self.is_unit = is_unit
    def Check(self, player):
        from game.card.card_finder import CardFinder
        if (self.name != None):
            if not (player.IsName(self.name)):
                return False
        if (self.non_name != None):
            if player.IsName(self.non_name):
                return False
        if (self.trait != None):
            if not (player.GetIdentity().HasTrait(self.trait)):
                return False
        if (self.card_type != None):
            if not (self.card_type.IsType(player.GetIdentity())):
                return False
        if (self.engaged_with != None):
            if not (player.engaged_minions.FindCardSizeOld(self.engaged_with)):
                return False
        if (self.controls != None):
            if not (player.IsControl(self.controls)):
                return False
        if (self.with_attach != None):
            if not (CardFinder(with_attach=self.with_attach).Check(player.GetIdentity())):
                return False
        if self.is_unit:
            return self.is_unit.Check(player.GetIdentity())
        return True
