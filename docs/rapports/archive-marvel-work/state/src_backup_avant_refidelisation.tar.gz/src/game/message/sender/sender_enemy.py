# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderEnemy:
    class WhenVillainWouldAdvance(TriggerUnitMessage):
        def __init__(self, unit: 'Villain'):
            super().__init__(trigger=unit)
            text = TransText('{unit} would advance', unit=unit)
            self.Present(text, '', unit)
    class WhenVillainAdvance(TriggerUnitMessage, HasEndEventMessage):
        def __init__(self, unit: 'Villain', by_effect: 'Effect'):
            from game.message import Message
            super().__init__(trigger=unit, end_event=Message.AfterVillainAdvanced)
    class AfterVillainAdvanced(TriggerUnitMessage, HasPreEventMessage):
        def __init__(self, unit: 'Villain', by_effect: 'Effect', message: 'Message.WhenVillainAdvance'):
            super().__init__(trigger=unit, pre_message=message)
            text = TransText('{unit} advanced', unit=unit)
            self.Present(text, 'set', unit)
    class WhenMinionWouldEngagePlayer(TriggerUnitMessage, HasEndEventMessage):
        def __init__(self, unit: 'Minion', player: 'Player', by_effect: 'Effect'):
            from game.message import Message
            self.player = player
            self.by_effect = by_effect
            self.minion = unit
            self.would_engaged_player = player
            super().__init__(trigger=unit, player=player, end_event=Message.WhenMinionEngagePlayer)
        @property
        def engaged_message(self) -> 'Message.WhenMinionEngagePlayer':
            return self.next_message
    class WhenMinionEngagePlayer(TriggerUnitMessage, HasPreEventMessage, HasEndEventMessage):
        def __init__(self, would_message: 'Message.WhenMinionWouldEngagePlayer'):
            from game.message import Message
            self.player = would_message.would_engaged_player
            self.by_effect = would_message.by_effect
            self.minion = would_message.minion
            super().__init__(trigger=self.minion, player=self.player, pre_message=would_message, end_event=Message.AfterMinionEngagePlayer)
            text = TransText('{unit} is engaging {player} ({by_effect})', unit=self.minion, player=self.player, by_effect=self.by_effect.this)
            self.Present(text, '', self.minion, self.player.GetIdentity(), self.by_effect.this)
        @property
        def engaged_player(self) -> 'Player':
            return self.player
    class AfterMinionEngagePlayer(TriggerUnitMessage, TriggerPlayerMessage, HasPreEventMessage):
        def __init__(self, unit: 'Minion', player: 'Player', message: 'Message.WhenMinionEngagePlayer'):
            self.player = player
            super().__init__(trigger=unit, player=player, pre_message=message)
            text = TransText('{unit} engaged {player}', unit=unit, player=player)
            self.Present(text, '', unit)
        @property
        def engaged_player(self) -> 'Player':
            return self.player
    class AfterEnemyGivenBoostCard(TriggerUnitMessage, AttackerNoneOldMessage):
        def __init__(self, unit: 'Minion|Villain', boost_card: 'CardFace', by_effect: 'Effect', would_message: 'Message.WhenUnitWouldAttack|Message.WhenUnitWouldScheme|None'):
            from game.message import Message
            self.boost_card = boost_card
            self.by_effect = by_effect
            self.trigger_attacker = unit
            self.would_atk_message = (would_message if isinstance(would_message, Message.WhenUnitWouldAttack) else None)
            attacker = (self.would_atk_message.attacker if self.would_atk_message else None)
            attacked = (self.would_atk_message.attacker if self.would_atk_message else None)
            super().__init__(trigger=unit, attacker=attacker, attacked=[attacked], would_atk_message=self.would_atk_message)
            text = TransText('{unit} gains {face} as boost card ({by_effect})', unit=unit, face=boost_card, by_effect=by_effect.this)
            self.Present(text, '', by_effect.this)
        def GetAttacker(self) -> 'Minion|Villain':
            if not ((self.would_atk_message != None)):
                raise AssertionError
            return self.trigger_attacker
    class AfterUnitGainFaceDownBoostCards_Text(TextMessage):
        def __init__(self, unit, size, by_effect):
            super().__init__(world=by_effect.world)
    class WhenEnemyWouldActivate(TriggerUnitMessage, TriggerNonePlayerMessage, CanBeInstead):
        def __init__(self, unit: 'Enemy', player: 'Player'):
            self.power = ('SCH' if player.IsAlterEgo() else 'ATK')
            super().__init__(trigger=unit, player=player)
        def GiveBoostCardForThisActivation(self, num, by_effect):
            from game.ability.ability import AbilityType
            from game.ability.factory import AbilityFactory
            self.trigger.effect.RegisterTemp(AbilityFactory.WhenEnemyActivateAgainstYou(AbilityType.Temp0, 'This', lambda effect, message: message.GiveAdditionalBoostCardForThisActivation(num, by_effect), conditions=[lambda effect, message: (self == message.would_act_message)]), unregister_after_exec=True, until_phase_end=True)
    class WhenEnemyActivateAgainstYou(TriggerUnitMessage, TriggerNonePlayerMessage, HasEndEventMessage):
        def __init__(self, unit: 'Enemy', player: 'Player|None', by_effect: 'Effect', would_message: 'Message.WhenUnitWouldScheme|Message.WhenUnitWouldAttack', would_act_message: 'Message.WhenEnemyWouldActivate|None'):
            from game.message import Message
            self.by_effect = by_effect
            self.would_message = would_message
            self.would_act_message = would_act_message
            super().__init__(trigger=unit, player=player, end_event=Message.AfterEnemyActivationEnd)
            if player:
                text = TransText('{unit} would activate against {player}', unit=unit, player=player)
                self.Present(text, '', unit, player.GetIdentity())
                return
            text = TransText('{unit} would activate', unit=unit, player=player)
            self.Present(text, '', unit)
        def GiveAdditionalBoostCardForThisActivation(self, num, by_effect):
            from game.card.face.attribute.can_boost import CanBoost
            if CanBoost.IsType(self.trigger):
                self.trigger.GiveFacedownBoostCardsInternal(num, by_effect, self.would_message)
                return
    class AfterEnemyActivationEnd(TriggerUnitMessage, TriggerNonePlayerMessage, HasPreEventMessage):
        def __init__(self, unit: 'Enemy', message: 'Message.AfterUnitAttackEnd|Message.AfterUnitSchemeEnd', activate_message: 'Message.WhenEnemyActivateAgainstYou'):
            from game.message import Message
            if not (message):
                raise AssertionError
            is_scheme = (type(message) is Message.AfterUnitSchemeEnd)
            self.atk_message = (None if is_scheme else message.CastTo(Message.AfterUnitAttackEnd))
            self.sch_message = (message.CastTo(Message.AfterUnitSchemeEnd) if is_scheme else None)
            self.active_message = message
            super().__init__(trigger=unit, player=activate_message.to_player, pre_message=activate_message)
            self.AddRelatedFace(unit.card.face)
            text = TransText('{unit} activation ends', unit=unit)
            if unit.IsInPlay():
                self.Present(text, '', unit)
                return
            self.Present(text, '')
        def HasThisBoost(self, face):
            boost_faces = []
            if self.atk_message:
                for message in self.atk_message.atk_messages:
                    boost_faces = (boost_faces + message.boost_faces)
            if self.sch_message:
                boost_faces = (boost_faces + self.sch_message.boost_cards)
            return (face in boost_faces)
        @property
        def activate_message(self) -> 'Message.WhenEnemyActivateAgainstYou':
            return self.pre_message
        def GetAgainstPlayer(self) -> 'Player':
            return self.activate_message.GetToPlayer()
    class GettingEnemySchemeTarget(TriggerUnitMessage, GettingMessage):
        def __init__(self, unit: 'Unit2', by_effect: 'Effect'):
            self.who_scheme = unit
            self.by_effect = by_effect
            self.target_scheme = None
            super().__init__(unit)
            self.AddRelatedFace(unit, by_effect)
        def SetSchemeTarget(self, target_scheme: 'Scheme2', by_effect: 'Effect'):
            self.target_scheme = target_scheme
    class WhenUnitWouldScheme(TriggerUnitMessage, SchemerMessage, CanGainValueMessage, CanBeInstead):
        def __init__(self, unit: 'Unit2', by_effect: 'Effect', *, property: 'SchemeProperty'):
            self.property = property
            self.by_effect = by_effect
            self.remove_threat_instead_of_placing = None
            if self.property.additional_value:
                if self.IsBasicScheme():
                    value = self.property.additional_value
                    self.property.additional_value = 0
                    unit.GainForThisActive(by_effect, self, scheme=value)
            super().__init__(trigger=unit, schemer=unit)
            text = TransText('{unit} will scheme ({additional_value:+}) ({by_effect})', unit=unit, additional_value=property.additional_value, by_effect=by_effect)
            self.Present(text, '', unit)
        def GainSCHForThisScheme(self, value, by_effect):
            from game.card.face.base import Enemy
            enemy = self.trigger.CastTo(Enemy)
            enemy.GainForThisActive(by_effect, self, scheme=value)
        def IsBasicScheme(self):
            return self.property.is_basic_power
        def SetRemoveThreatInsteadOfPlacing(self, by_effect: 'Effect'):
            self.remove_threat_instead_of_placing = by_effect
        def GetAgainstPlayer(self) -> 'Player|None':
            return self.against_player
        @property
        def against_player(self) -> 'Player|None':
            return self.property.against_player
        def DoNotGiveBoostCardForThisActivation(self, by_effect: 'Effect'):
            self.property.do_not_give_boost = True
        def GiveAdditionalBoostCardForThisActivation(self, num, by_effect):
            from game.ability.ability import AbilityType
            from game.ability.factory import AbilityFactory
            self.trigger.effect.RegisterTemp(AbilityFactory.WhenEnemyActivateAgainstYou(AbilityType.Temp0, 'This', lambda effect, message: message.GiveAdditionalBoostCardForThisActivation(num, by_effect), conditions=[lambda effect, message: (self == message.would_message)]), unregister_after_exec=True, until_phase_end=True)
    class WhenSchemeBeingScheme(TriggerUnitMessage, HasEndEventMessage, CanGainValueMessage):
        def __init__(self, scheme: 'Scheme2', would_sch_message: 'Message.WhenUnitWouldScheme'):
            from game.message import Message
            self.scheme = scheme
            self.property = would_sch_message.property
            self.would_sch_message = would_sch_message
            self.would_message = would_sch_message
            self.by_face = would_sch_message.trigger
            super().__init__(trigger=would_sch_message.trigger, end_event=Message.AfterUnitThwartScheme)
        def IsAttack(self):
            return False
        def IsScheme(self):
            return True
    class WhenRecalculateSchemeValue(CalculateMessage, TriggerUnitMessage):
        def __init__(self, unit, target, value, would_sch_message):
            self.scheme = target
            self.would_sch_message = would_sch_message
            self.value = value
            super().__init__(trigger=unit)
        def UpdateSchemeValue(self, value):
            self.value = (self.value + value)
    class AfterUnitSchemeEnd(TriggerUnitMessage):
        def __init__(self, unit, threat, target, boost_faces, by_effect, would_sch_messages):
            self.placed_threat = threat
            self.boost_cards = boost_faces
            self.by_effect = by_effect
            self.would_sch_messages = would_sch_messages
            self.target_scheme = target
            super().__init__(trigger=unit)
        def GetAgainstPlayer(self) -> 'Player|None':
            return self.against_player
        @property
        def against_player(self) -> 'Player|None':
            if (len(self.would_sch_messages) == 1):
                return self.would_sch_messages[0].against_player
