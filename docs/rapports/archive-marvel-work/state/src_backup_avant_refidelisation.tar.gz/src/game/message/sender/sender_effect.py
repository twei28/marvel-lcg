# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderEffect:
    class WhenEffectWouldResolve(TriggerFaceMessage, TriggerNonePlayerMessage, CanBeInstead, CanGainValueMessage, HasEndEventMessage):
        def __init__(self, effect: 'Effect', message: Message2|None, by_effect: 'Effect', to_player: 'Player|None', control_by: 'Player|Scenario|None'):
            from game.message import Message
            from game.card.face.base import EncounterCard
            self.effect = effect
            face = effect.this
            self.by_effect = by_effect
            self.control_by = control_by
            self.message = message
            player = (to_player if (to_player != None) else effect.initiator)
            if not (player.IsPlayer()):
                if EncounterCard.IsType(face):
                    if isinstance(message, TriggerNonePlayerMessage):
                        player = message.to_player
                    else:
                        player = None
                else:
                    player = None
            super().__init__(trigger=face, player=player, end_event=Message.AfterEffectResolved)
            if effect.ability.flags.need_render_ui:
                if effect.targets:
                    text = TransText('{face} activates, targets {targets}', face=face, targets=effect.targets)
                else:
                    text = TransText('{face} activates', face=face)
    class AfterEffectResolved(TriggerFaceMessage, TriggerNonePlayerMessage, HasPreEventMessage):
        def __init__(self, effect: 'Effect', message: Message2|None, resolve_message: 'Message.WhenEffectWouldResolve'):
            self.effect = effect
            self.by_effect = resolve_message.by_effect
            self.control_by = resolve_message.control_by
            face = effect.this
            self.message = message
            player = resolve_message.to_player
            super().__init__(trigger=face, player=player, pre_message=resolve_message)
        @property
        def when_resolve_message(self) -> 'Message.WhenEffectWouldResolve':
            return self.pre_message
    class WhenSurgeWouldBeResolved(TriggerPlayerMessage, TriggerFaceMessage, CanBeInstead):
        def __init__(self, face: 'CanSurge', player: 'Player'):
            super().__init__(player=player, trigger=face)
            text = TransText('{face} would surge against {player}', face=face, player=player)
            self.Present(text, 'activate', face, player.GetIdentity())
