# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderCard:
    class LookAt_Text(TextMessage):
        def __init__(self, player, faces):
            for face in faces:
                face.card.visible.Set(player)
            super().__init__(world=player.world)
            text = TransText('{player} looks at {faces}', player=player, faces=faces)
            self.Present(*tuple([text, '', *faces]))
    class WhenCardResetKeyword(TriggerFaceMessage):
        def __init__(self, face: 'CardFace'):
            super().__init__(trigger=face)
    class WhenCardDefeating_Text(TextMessage):
        def __init__(self, this: 'CardFace'):
            super().__init__(world=this.card.world)
            text = TransText('{this} is being defeated', this=this)
            self.Present(text, 'destroyed', this)
    class WhenCardWouldUpdateKeyword_Text(TextMessage):
        def __init__(self, face, diff, keyword, by_effect, *, render_ui = False):
            super().__init__(world=by_effect.world)
            if not ((keyword != 'HP')):
                raise AssertionError
            if face.IsFaceUp():
                if (diff != 0):
                    from game.effect.rule import ResetKeyword
                    if not (self.world.is_game_started):
                        return
                    if (type(by_effect) == ResetKeyword):
                        return
                    if render_ui:
                        text = TransText('{face} would {diff:+} {keyword}', face=face, diff=diff, keyword=keyword)
                        self.Present(text, '', face, by_effect.this)
                    return
                    return
    class WhenCardKeywordUpdated(CardStateUpdatedMessage):
        def __init__(self, face, diff, keyword, by_effect):
            if not ((keyword != 'HP')):
                raise AssertionError
            self.keyword = keyword
            super().__init__(trigger=face)
    class WhenCardWouldGainBoostIcons_Text(TextMessage):
        def __init__(self, face, value, effect):
            super().__init__(world=effect.world)
            self.Present(None, '', effect.this, face)
    class WhenCardGainBoostIcons_Text(TextMessage):
        def __init__(self, face, value, effect):
            super().__init__(world=effect.world)
            sound = ('activate' if (value > 0) else '')
            text = TransText('{face} gains {value} boost icons', face=face, value=value)
            self.Present(text, sound, effect.this, face)
    class WhenCardBeSpendAsResource(TriggerFaceMessage, TriggerPlayerMessage):
        def __init__(self, face: 'CardFace', res: Resources, for_effect: 'Effect', player: 'Player'):
            self.for_effect = for_effect
            if self.for_effect.ability.is_play:
                pay_for_card = self.for_effect.this
            else:
                pay_for_card = None
            self.pay_for_card = pay_for_card
            self.res = res
            super().__init__(player=player, trigger=face)
            text = TransText('{player} gains resource {resource} from {by_effect}, total {total_res}', by_effect=face, player=player, resource=res, total_res=player.res_pool.Get())
            self.Present(text, 'token', face)
    class AfterCardsBeSpendAsResource(TriggerPlayerMessage):
        def __init__(self, faces, for_effect, player):
            self.for_effect = for_effect
            if self.for_effect.ability.is_play:
                pay_for_card = self.for_effect.this
            else:
                pay_for_card = None
            self.pay_for_card = pay_for_card
            self.faces = faces
            super().__init__(player=player)
            self.AddRelatedFace(*tuple([*faces, for_effect]))
    class WhenCardWouldFlip(TriggerFaceMessage, CanBeInstead, HasEndEventMessage):
        def __init__(self, face, to_face, by_effect, ui_group, ui_look_at, by_swapping):
            from game.message import Message
            self.to_face = to_face
            self.ui_group = ui_group
            self.ui_look_at = ui_look_at
            self.by_swapping = by_swapping
            super().__init__(trigger=face, end_event=Message.WhenCardFlip)
    class WhenCardFlip(TriggerFaceMessage, HasPreEventMessage, HasEndEventMessage):
        def __init__(self, face: 'CardFace', by_effect: 'Effect', message: 'Message.WhenCardWouldFlip'):
            from game.message import Message
            self.by_effect = by_effect
            self.to_face = message.to_face
            self.ui_group = message.ui_group
            self.ui_look_at = message.ui_look_at
            self.by_swapping = message.by_swapping
            super().__init__(trigger=face, pre_message=message, end_event=Message.AfterCardFlip)
            self.AddRelatedFace(*tuple([face, *face.card.back_faces, by_effect]))
    class AfterCardFlip(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, from_face: 'CardFace', to_face: 'CardFace', when_flip_message: 'Message.WhenCardFlip'):
            from game.message import OnEvent
            self.from_face = from_face
            self.to_face = to_face
            self.by_effect = when_flip_message.by_effect
            area = to_face.card.area
            super().__init__(trigger=to_face, pre_message=when_flip_message)
            if not (when_flip_message.ui_group):
                if not (area.flags.is_processing):
                    if not (area.flags.is_deck):
                        if not (area.flags.is_in_play):
                            if area.flags.is_boost_area:
                                if to_face.IsFaceUp():
                                    if not (to_face.IsInPlay()):
                                        if not (to_face.card.area.flags.is_boost_area):
                                            if when_flip_message.ui_look_at:
                                                text = TransText('{to_face} was flipped ({effect})', to_face=to_face, effect=self.by_effect.this)
                                                self.Present(text, 'flip', to_face, self.by_effect.this)
                                    text = TransText('{to_face} was flipped ({effect})', to_face=to_face, effect=self.by_effect.this)
                                    self.Present(text, 'flip', to_face, self.by_effect.this)
                if to_face.IsFaceUp():
                    if not (to_face.IsInPlay()):
                        if not (to_face.card.area.flags.is_boost_area):
                            if when_flip_message.ui_look_at:
                                text = TransText('{to_face} was flipped ({effect})', to_face=to_face, effect=self.by_effect.this)
                                self.Present(text, 'flip', to_face, self.by_effect.this)
                    text = TransText('{to_face} was flipped ({effect})', to_face=to_face, effect=self.by_effect.this)
                    self.Present(text, 'flip', to_face, self.by_effect.this)
            if to_face.IsFaceUp():
                self.TriggerOnEvent(OnEvent.Faceup)
                return
        @property
        def when_flip_message(self) -> 'Message.WhenCardFlip':
            return self.pre_message
    class AfterCardGainUpgradeAbility(TriggerFaceMessage):
        def __init__(self, this: 'CardFace', upgrade: 'CanAttach'):
            self.upgrade = upgrade
            super().__init__(trigger=this)
    class AfterCardLostUpgradeAbility(TriggerFaceMessage):
        def __init__(self, this, upgrade, by_flip):
            self.upgrade = upgrade
            self.by_flip = by_flip
            super().__init__(trigger=this)
    class WhenCardWouldAttachTo(TriggerFaceMessage, CanBeInstead, HasEndEventMessage):
        def __init__(self, this: 'CanAttach', to_face: 'CardFace', by_effect: 'Effect'):
            from game.message import Message
            self.to_face = to_face
            self.upgrade = this
            self.by_effect = by_effect
            super().__init__(trigger=this, end_event=Message.AfterCardAttachTo)
        def AttachToInstead(self, to_face: 'CardFace', by_effect: 'Effect'):
            self.SetBeInstead(by_effect)
            self.upgrade.AttachTo2(to_face, by_effect)
    class AfterCardAttachTo(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, this: 'CardFace', upgrade: 'CanAttach', message: 'Message.WhenCardWouldAttachTo'):
            self.upgrade = upgrade
            self.to_face = this
            super().__init__(trigger=upgrade, pre_message=message)
            text = TransText('{this} equipped {upgrade} ({effect})', this=this, upgrade=upgrade, effect=message.by_effect.this)
            self.Present(text, 'equip', this)
            self.AddRelatedFace(this, upgrade)
    class AfterCardDetachFrom(TriggerFaceMessage):
        def __init__(self, this: 'CardFace', upgrade: 'CanAttach'):
            self.upgrade = upgrade
            self.from_face = this
            super().__init__(trigger=upgrade)
            text = TransText('{this} unequipped {upgrade}', this=this, upgrade=upgrade)
            self.Present(text, '', this)
    class AfterCardExhausted(TriggerFaceMessage):
        def __init__(self, face, by_effect, *, ui_group = False):
            super().__init__(trigger=face)
            if not (ui_group):
                text = TransText('{face} exhausted', face=face)
                self.Present(text, 'flip', face, by_effect.this)
                return
    class WhenCardWouldReady(TriggerFaceMessage, CanBeInstead, HasEndEventMessage):
        def __init__(self, face, by_effect, *, ui_group):
            from game.message import Message
            self.by_effect = by_effect
            super().__init__(trigger=face, end_event=Message.AfterCardReady)
    class AfterCardReady(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face, by_effect, message, ui_group):
            self.by_effect = by_effect
            super().__init__(trigger=face, pre_message=message)
            if not (ui_group):
                text = TransText('{face} readied', face=face)
                self.Present(text, 'flip', face, by_effect.this)
                return
    class WhenCardSetup(TriggerFaceMessage):
        def __init__(self, face, before_put_setup_cards):
            self.before_put_setup_cards = before_put_setup_cards
            super().__init__(trigger=face)
    class WhenCardWouldMoveToArea(TriggerFaceMessage):
        def __init__(self, face, from_area, into_area, by_effect, ui_group):
            self.from_area = from_area
            self.into_area = into_area
            self.cannot = False
            self.by_effect = by_effect
            super().__init__(trigger=face)
            if not (ui_group):
                if not (into_area.flags.is_discards):
                    if not (into_area.flags.is_removed):
                        if not (into_area.flags.is_engaged):
                            if not (into_area.flags.is_upgrades):
                                if not (into_area.flags.is_processing):
                                    if not (into_area.flags.is_in_play):
                                        if not (into_area.flags.is_in_hand):
                                            if not (into_area.flags.is_boost_area):
                                                if not (into_area.flags.is_resources_area):
                                                    if not (into_area.flags.is_dealt_encounter):
                                                        if into_area.flags.is_deck:
                                                            if not (from_area.flags.is_discards):
                                                                if from_area.flags.is_discards:
                                                                    if into_area.flags.is_deck:
                                                                        return
                                                        if from_area.flags.is_discards:
                                                            if into_area.flags.is_deck:
                                                                return
                return
                text = TransText('{face} is moving to {into_area}', face=face, into_area=into_area)
                self.Present(text, '', face)
                return
        def ChangeToArea(self, into_area: 'Deck|None', by_effect: 'Effect'):
            if (into_area != None):
                self.into_area = into_area
                text = TransText('{this} changes the area to {into_area}', this=by_effect.this, into_area=into_area)
            else:
                self.into_area = self.from_area
                text = TransText('{this} cancels this move', this=by_effect.this)
            self.Present_Activate(text, by_effect)
        def SetCannot(self, by_effect: 'Effect'):
            self.cannot = True
            text = TransText('{this} prevents {face} from moving', this=by_effect.this, face=self.trigger)
            self.Present_Activate(text, by_effect)
    class AfterCardEnterHand(TriggerFaceMessage, TriggerPlayerMessage):
        def __init__(self, face: 'CardFace', from_area: 'Deck', into_area: 'Deck', by_effect: 'Effect'):
            self.from_area = from_area
            self.into_deck = into_area
            super().__init__(trigger=face, player=into_area.GetOwnerPlayer())
    class WhenCardWouldLeavePlay(TriggerFaceMessage, CanBeInstead, HasEndEventMessage):
        def __init__(self, face, from_area, into_area, by_effect, by_swapping):
            from game.message import Message
            self.into_area = into_area
            self.by_effect = by_effect
            self.by_swapping = by_swapping
            self.from_area = from_area
            super().__init__(trigger=face, end_event=Message.WhenCardLeavePlay)
    class WhenCardLeavePlay(TriggerFaceMessage, HasPreEventMessage, HasEndEventMessage):
        __doc__ = "\n        Haven't lose equipment\n        "
        def __init__(self, face: 'CardFace', pre_message: 'Message.WhenCardWouldLeavePlay'):
            from game.message import Message
            self.into_area = pre_message.into_area
            self.by_effect = pre_message.by_effect
            self.by_swapping = pre_message.by_swapping
            self.from_area = pre_message.from_area
            super().__init__(trigger=face, pre_message=pre_message, end_event=Message.AfterCardLeavePlay)
        @property
        def would_leave_play_message(self) -> 'Message.WhenCardWouldLeavePlay':
            return self.pre_message
    class AfterCardLeavePlay(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face: 'CardFace', from_area: 'Deck', into_area: 'Deck', leave_play_message: 'Message.WhenCardLeavePlay'):
            self.from_area = from_area
            self.into_area = into_area
            self.by_effect = leave_play_message.by_effect
            self.by_swapping = leave_play_message.by_swapping
            super().__init__(trigger=face, pre_message=leave_play_message)
        @property
        def when_leave_play_message(self) -> 'Message.WhenCardLeavePlay':
            return self.pre_message
        @property
        def would_leave_play_message(self) -> 'Message.WhenCardWouldLeavePlay':
            return self.when_leave_play_message.would_leave_play_message
    class WhenCardWouldDiscard(TriggerFaceMessage, CanBeInstead, HasEndEventMessage):
        def __init__(self, trigger: 'CardFace', by_effect: 'Effect'):
            from game.message import Message
            self.into_area = None
            self.by_effect = by_effect
            self.is_top = (trigger.card.area.GetTop() == trigger)
            super().__init__(trigger, end_event=Message.AfterCardDiscard)
        def SetToArea(self, deck: 'Deck'):
            self.into_area = deck
    class AfterCardDiscard(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, trigger: 'CardFace', from_area: 'Deck', by_effect: 'Effect', discard_message: 'Message.WhenCardWouldDiscard'):
            self.from_area = from_area
            self.by_effect = by_effect
            super().__init__(trigger, pre_message=discard_message)
            if not (from_area.flags.is_deck):
                if from_area.flags.is_in_play:
                    text = TransText('{face} was discarded to {into_area} ({effect})', face=trigger, into_area=trigger.card.area, effect=by_effect.this)
                    self.Present(text, 'carddrop', trigger, by_effect.this)
                    return
            text = TransText('{face} was discarded to {into_area} ({effect})', face=trigger, into_area=trigger.card.area, effect=by_effect.this)
            self.Present(text, 'carddrop', trigger, by_effect.this)
        @property
        def discard_message(self) -> 'Message.WhenCardWouldDiscard':
            return self.pre_message
    class WhenEffectBeCancel(TriggerFaceMessage):
        def __init__(self, face, by_effect, be_cancel_effect):
            self.cancel_by_effect = by_effect
            self.be_cancel_effect = be_cancel_effect
            super().__init__(trigger=face)
            text = TransText("{face}'s {be_cancel_effect} effect was canceled by {by_effect}", face=face, be_cancel_effect=be_cancel_effect, by_effect=by_effect.this)
            self.Present(text, 'negate', by_effect.this)
    class WhenCardWouldReveal(TriggerPlayerMessage, TriggerFaceMessage, CanBeInstead, HasEndEventMessage):
        __doc__ = 'Before flip'
        def __init__(self, face, player, by_effect, from_area, is_by_flipping):
            from game.message import Message
            self.by_effect = by_effect
            self.from_area = from_area
            self.is_by_flipping = is_by_flipping
            super().__init__(player=player, trigger=face, end_event=Message.AfterCardRevealedEnd)
            if face.card.area.flags.is_dealt_encounter:
                text = TransText('{face} would be revealed ({by_effect})', face=face, by_effect=by_effect.this)
                self.Present(text, '', face, player.GetIdentity())
                return
    class AfterCardsMovedToRevealingArea_Text(TextMessage):
        def __init__(self, faces):
            super().__init__(world=faces[0].card.world)
            text = TransText('{faces} moved to revealing area', faces=faces)
            self.Present(*tuple([text, 'set', *faces]))
    class WhenCardPutIntoPlay(TriggerPlayerMessage, TriggerFaceMessage, HasEndEventMessage):
        def __init__(self, face: 'CardFace', player: 'Player', from_area: 'Deck', by_effect: 'Effect', target_game_area: GameArea|None = None):
            from game.message import Message
            self.by_effect = by_effect
            self.from_area = from_area
            self.target_game_area = target_game_area
            super().__init__(player=player, trigger=face, end_event=Message.AfterCardPutIntoPlay)
    class AfterCardPutIntoPlay(TriggerPlayerMessage, TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face: 'CardFace', message: 'Message.WhenCardPutIntoPlay'):
            from game.message import Message
            self.by_effect = message.by_effect
            moved_message = Message.AfterCardsMoved({face: message.from_area}, by_put_into_play=True)
            moved_message.Send()
            super().__init__(player=message.GetToPlayer(), trigger=face, pre_message=message)
        @property
        def when_card_put_into_play(self) -> 'Message.WhenCardPutIntoPlay':
            return self.pre_message
    class WhenPlayerRevealCard(TriggerPlayerMessage, TriggerFaceMessage, CanBeInstead, HasEndEventMessage):
        def __init__(self, face, message, **kwargs):
            from game.message import Message
            from game.message import OnEvent
            from game.card.face.attribute.has_permanent import HasPermanent
            from game.card.face.base import Villain
            from game.card.face.card_type import MainScheme
            self.from_area = message.from_area
            self.would_reveal_message = message
            self.cancel_when_revealed = False
            self.cancel_all_effects = False
            self.cannot_be_cancel = False
            if HasPermanent.IsType(face):
                if face.permanent:
                    self.cannot_be_cancel = True
                else:
                    if not (Villain.IsType(face)):
                        if MainScheme.IsType(face):
                            self.cannot_be_cancel = True
                    self.cannot_be_cancel = True
            else:
                if not (Villain.IsType(face)):
                    if MainScheme.IsType(face):
                        self.cannot_be_cancel = True
                self.cannot_be_cancel = True
            effects = face.effect.Find(type=AbilityType.WhenRevealed)
            for effect in effects:
                if effect.ability.cannot_be_cancel:
                    self.cannot_be_cancel = True
                else:
                    pass
            self.by_effect = message.by_effect
            self.resolved = []
            player = message.GetToPlayer()
            self.give_to_player = player
            super().__init__(player=player, trigger=face, end_event=Message.WhenCardRevealed)
            text = TransText('{face} is being revealed', face=face)
            self.Present(text, 'reveal', face, player.GetIdentity())
            self.TriggerOnEvent(OnEvent.Reveal)
        def AddResolved(self, by_effect: 'Effect'):
            self.resolved.append(by_effect)
        def CancelWhenRevealedEffect(self, by_effect: 'Effect'):
            from game.message import Message
            self.cancel_when_revealed = True
            if self.cannot_be_cancel:
                raise AssertionError
            message = Message.WhenEffectBeCancel(self.trigger, by_effect, 'WhenReveal')
            message.Send()
        def IsFromEncounterDeck(self):
            from game.operate.worlds import Worlds
            if self.from_area.flags.is_dealt_encounter:
                return True
            for villain in Worlds.GetAllVillains(self.world):
                if (self.from_area == villain.encounter_deck):
                    return True
            return False
        def CancelAllEffectsAndDiscardIt(self, by_effect: 'Effect'):
            return self.CancelAllEffectsInternal(by_effect, discard_it=True)
        def CancelAllEffectsInternal(self, by_effect, *, discard_it = False):
            from game.message import Message
            from game.operate.faces import Faces
            self.cancel_all_effects = True
            message = Message.WhenEffectBeCancel(self.trigger, by_effect, 'All')
            message.Send()
            if discard_it:
                Faces.DiscardAll([self.trigger], by_effect)
                self.trigger.card.state.is_revealing = False
                return
        def CanBeCancel(self, cancel_level, by_effect):
            from game.message import Message
            from game.card.face.card_type import Treachery
            message = Message.CheckIfEffectCanBeCancelBy(self.by_effect, by_effect)
            message.Send()
            if self.cannot_be_cancel:
                return False
            if not (message.can_be_cancel):
                return False
            if (cancel_level == 'WhenRevealed'):
                return ((not (not self.trigger.effect.Find(type=AbilityType.WhenRevealed))) and ((not self.cancel_all_effects) and (not self.cancel_when_revealed)))
            if (cancel_level == 'All'):
                face = self.trigger
                return ((not self.cancel_all_effects) and ((not Treachery.IsType(face)) or ((face.incite > 0) or ((not self.cancel_when_revealed) and (not (not face.effect.Find(type=AbilityType.WhenRevealed)))))))
        def GetGaveToPlayer(self) -> 'Player':
            return self.give_to_player
        def SetGiveToPlayer(self, player: 'Player'):
            self.give_to_player = player
    class CheckIfEffectCanBeCancelBy(CheckIfMessage):
        def __init__(self, check_effect: 'Effect', by_effect: 'Effect'):
            self.can_be_cancel = True
            self.check_effect = check_effect
            self.by_effect = by_effect
            super().__init__(by_effect.this)
        def SetCannotBeThwart(self, by_effect: 'Effect'):
            self.can_be_cancel = False
            self.SetCauseBy(by_effect)
    class WhenObligationGiveToPlayer(TriggerPlayerMessage, TriggerFaceMessage):
        def __init__(self, player: 'Player', message: 'Message.WhenCardRevealed'):
            face = message.trigger
            super().__init__(player=player, trigger=face)
        def GetGaveToPlayer(self) -> 'Player':
            return self.GetToPlayer()
    class WhenCardRevealed(TriggerPlayerMessage, TriggerFaceMessage, HasPreEventMessage, HasEndEventMessage):
        def __init__(self, face: 'CardFace', message: 'Message.WhenPlayerRevealCard'):
            from game.message import Message
            self.reveal_message = message
            self.by_effect = message.by_effect
            self.from_area = message.from_area
            player = message.GetToPlayer()
            super().__init__(player=player, trigger=face, pre_message=message, end_event=Message.AfterCardRevealed)
            text = TransText('{face} was revealed', face=face)
            self.Present(text, '', face)
        @property
        def is_by_flipping(self):
            return self.when_player_reveal_message.would_reveal_message.is_by_flipping
        @property
        def when_player_reveal_message(self) -> 'Message.WhenPlayerRevealCard':
            return self.pre_message
        def IsFromEncounterDeck(self):
            return self.reveal_message.IsFromEncounterDeck()
        def GetGaveToPlayer(self) -> 'Player':
            return self.when_player_reveal_message.GetGaveToPlayer()
    class AfterCardRevealed(TriggerPlayerMessage, TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face, message, **kwargs):
            reveal_message = message.reveal_message
            revealed_message = message
            self.reveal_message = reveal_message
            self.revealed_message = revealed_message
            self.is_cancel_all = reveal_message.cancel_all_effects
            self.is_cancel_when_revealed = reveal_message.cancel_when_revealed
            super().__init__(player=message.GetToPlayer(), trigger=face, pre_message=revealed_message)
    class AfterCardRevealedEnd(TriggerPlayerMessage, TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face, message, revealed_message, **kwargs):
            self.reveal_message = message
            self.revealed_message = revealed_message
            would_message = message.would_reveal_message
            super().__init__(player=message.GetToPlayer(), trigger=face, pre_message=would_message)
    class WhenBoostIconsWouldBeCount(TriggerFaceMessage, CanBeInstead):
        def __init__(self, face: 'HasBoostIcon'):
            self.update_boost_icons = 0
            self.set_boost_icons = 0
            super().__init__(trigger=face)
            text = TransText('{face} would count boost icons ({boost})', face=face, boost=(face.printed_boost * Symbol.boost))
            self.Present(text, ('token' if (face.printed_boost > 0) else ''), face)
        def UpdateBoostIcon(self, value, by_effect):
            from game.card.face.attribute.has_boost_icon import HasBoostIcon
            if not (HasBoostIcon.IsType(self.trigger)):
                raise AssertionError
            self.update_boost_icons = value
            text = TransText('{trigger} boost icons {value:+} ({by_effect})', trigger=self.trigger, value=value, by_effect=by_effect.this)
            self.Present_ByEffect(text, '', self.trigger, by_effect.this)
        def SetBoostIcon(self, value, by_effect):
            from game.card.face.attribute.has_boost_icon import HasBoostIcon
            if not (HasBoostIcon.IsType(self.trigger)):
                raise AssertionError
            self.set_boost_icons = value
            text = TransText('{trigger} boost icons were set to {value} ({by_effect})', trigger=self.trigger, value=value, by_effect=by_effect.this)
            self.Present_ByEffect(text, '', self.trigger, by_effect.this)
    class WhenBoostCardWouldTurnedFaceUp(TriggerFaceMessage, TriggerNonePlayerMessage, AttackerNoneMessage, CanBeInstead):
        def __init__(self, face: 'CardFace', being_message: 'Message.WhenUnitBeingAttack|Message.WhenSchemeBeingScheme'):
            from game.message import Message
            player = being_message.would_message.property.against_player
            self.being_message = being_message
            self.would_message = being_message.would_message
            self.would_atk_message = (being_message.would_message if isinstance(being_message.would_message, Message.WhenUnitWouldAttack) else None)
            being_atk_message = (being_message if self.would_atk_message else None)
            super().__init__(player=player, being_atk_message=being_atk_message, trigger=face)
    class AfterCardsMovedToBoostingArea_Text(TextMessage):
        def __init__(self, faces):
            super().__init__(world=faces[0].card.world)
            text = TransText('{faces} moved to boosting area', faces=faces)
            self.Present(*tuple([text, 'set', *faces]))
    class WhenBoostCardTurnedFaceUp(TriggerFaceMessage, TriggerNonePlayerMessage):
        def __init__(self, face: 'CardFace', being_message: 'Message.WhenUnitBeingAttack|Message.WhenSchemeBeingScheme'):
            from game.card.face.base import EncounterNonVillainCard
            from game.message import Message
            player = being_message.would_message.property.against_player
            self.being_message = being_message
            self.would_message = being_message.would_message
            if isinstance(being_message, Message.WhenUnitBeingAttack):
                self.would_atk_message = being_message.would_atk_message
            self.boost_icons = (face.boost_const if EncounterNonVillainCard.IsType(face) else 0)
            self.original_boost_icons = self.boost_icons
            self.cancel_boost_icons = False
            self.cancel_boost_ability = False
            super().__init__(player=player, trigger=face)
        def CancelAllBoostIcons(self, by_effect):
            self.cancel_boost_icons = True
            cancel_num = self.boost_icons
            self.boost_icons = 0
            from game.card.face.attribute.has_boost_icon import HasBoostIcon
            if HasBoostIcon.IsType(self.trigger):
                self.trigger.SetBoostIcon(0, by_effect)
                return cancel_num
            return 0
        def CancelBoostAbility(self, by_effect: 'Effect'):
            self.cancel_boost_ability = True
    class WhenCardBecomeBoost(TriggerFaceMessage, HasEndEventMessage, TriggerNonePlayerMessage):
        def __init__(self, face: 'CardFace', flip_message: 'Message.WhenBoostCardTurnedFaceUp'):
            from game.message import Message
            from game.card.face.base import Enemy
            self.is_cancel_boost_ability = flip_message.cancel_boost_ability
            self.being_message = flip_message.being_message
            self.would_message = self.being_message.would_message
            self.against_player = self.would_message.property.against_player
            player = self.against_player
            if isinstance(self.being_message, Message.WhenSchemeBeingScheme):
                self.would_sch_message = self.being_message.would_sch_message
            if isinstance(self.being_message, Message.WhenUnitBeingAttack):
                self.would_atk_message = self.being_message.would_atk_message
                if self.being_message.defender:
                    player = self.being_message.defender.GetControlByPlayer()
            self.activating_enemy = self.would_message.trigger.CastTo(Enemy)
            super().__init__(player=player, trigger=face, end_event=Message.AfterCardBecomeBoost)
        def GetAgainstPlayer(self) -> 'Player|None':
            return self.against_player
        def GainBoostIcon(self, value, by_effect):
            from game.card.face.base import EncounterNonVillainCard
            from game.message import Message
            trigger = self.trigger
            if not (EncounterNonVillainCard.IsType(trigger)):
                raise AssertionError
            trigger.GainBoostIcons(value, by_effect)
            from game.ability.ability import Ability
            from game.ability.ability import AbilityType
            trigger.effect.RegisterTemp(Ability(AbilityType.Temp0, Message.AfterCardBecomeBoost, [lambda effect, message: (self == message.boost_message)], lambda boost_effect, message: trigger.GainBoostIcons((-1 * value), by_effect)), unregister_after_exec=True, until_turn_end=True)
        def GiveActivatingEnemyAdditionalBoostCard(self, num, by_effect):
            self.GiveBoostCardForThisActivation(self.activating_enemy, num, by_effect)
        def GiveBoostCardForThisActivation(self, card_type, num, by_effect):
            from game.card.face.attribute.can_boost import CanBoost
            from game.card.face.base import Villain
            from game.card.face.card_face import CardFace
            trigger = self.being_message.by_face
            face = None
            if isinstance(card_type, CardFace):
                if (trigger == card_type):
                    face = trigger
            else:
                if Villain.IsType(trigger):
                    face = trigger
            if face:
                face.CastTo(CanBoost).GiveFacedownBoostCardsInternal(num, by_effect, self.would_message)
                return
        def AfterThisActivation(self, effect, action):
            from game.operate.run_at import RunAt
            RunAt.AfterEnemyActivationEnd(effect, self.being_message, action)
        @override
        def GetToPlayer(self) -> 'Player':
            from game.player import Player
            if (type(self.to_player) is Player):
                return self.to_player
            return self.world.GetCurrentPlayer()
    class AfterCardBecomeBoost(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face: 'CardFace', message: 'Message.WhenCardBecomeBoost'):
            self.boost_message = message
            super().__init__(trigger=face, pre_message=message)
        def GetAgainstPlayer(self) -> 'Player|None':
            return self.boost_message.would_message.property.against_player
    class WhenCardReset_Text(TextMessage):
        def __init__(self, face, is_flip):
            self.is_flip = is_flip
    class AfterCardsDiscard_Text(TextMessage):
        def __init__(self, face_deck):
            from game.message import Message
            if face_deck:
                face = list(face_deck.keys())[0]
                super().__init__(world=face.card.world)
                if not (any(((face_deck[face].flags.is_in_play or face_deck[face].flags.is_deck) for face in face_deck))):
                    text = TransText('{cards} were discarded', cards=list(face_deck.keys()))
                    self.Present(text, 'carddrop')
                message = Message.AfterCardsMoved(face_deck, by_discard=True)
                message.Send()
                return
    class AfterCardsReturnToHand_Text(TextMessage):
        def __init__(self, faces, by_effect):
            from game.message import Message
            from game.operate.faces import Faces
            if (len(faces) > 0):
                super().__init__(world=faces[0].card.world)
                text = TransText('{cards} were returned to hand ({by_effect})', cards=faces, by_effect=by_effect.this)
                self.Present(*tuple([text, '', *faces, by_effect.this]))
                from_decks = Faces.GetDecksInDeck(faces)
                message = Message.AfterCardsMoved(from_decks, by_return_to_hand=True)
                message.Send()
                return
    class AfterCardsMoved_Text(TextMessage):
        def __init__(self, faces, from_area = None, into_area = None):
            if (len(faces) > 0):
                super().__init__(world=faces[0].card.world)
                sound = ''
                if (into_area == None):
                    into_area = faces[0].card.area
                if into_area.flags.is_resources_area:
                    text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                else:
                    if from_area:
                        if from_area.flags.is_in_hand:
                            text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                            sound = 'set'
                        else:
                            if into_area.flags.is_boost_area:
                                if into_area.bind_card:
                                    text = TransText("{faces} were moved to {into_area}'s boost area", faces=faces, into_area=into_area.bind_card.face)
                                else:
                                    text = TransText('{faces} moved to boost area', faces=faces)
                                sound = 'token'
                            else:
                                if into_area.flags.is_in_hand:
                                    if from_area:
                                        if not (from_area.flags.is_in_hand):
                                            text = TransText('{player} drew {faces} from {from_area}', player=into_area.bind_owner, faces=faces, from_area=from_area)
                                            sound = 'draw'
                                        else:
                                            if into_area.flags.is_removed:
                                                text = TransText('{faces} were removed from {from_area}', faces=faces, from_area=from_area)
                                                sound = 'banished'
                                            else:
                                                if into_area.flags.is_resources_area:
                                                    text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                                else:
                                                    if into_area.flags.is_discards:
                                                        text = TransText('{faces} were discarded to {into_area}', faces=faces, into_area=into_area)
                                                        sound = 'carddrop'
                                                    else:
                                                        text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                                        sound = 'set'
                                    else:
                                        if into_area.flags.is_removed:
                                            text = TransText('{faces} were removed from {from_area}', faces=faces, from_area=from_area)
                                            sound = 'banished'
                                        else:
                                            if into_area.flags.is_resources_area:
                                                text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                            else:
                                                if into_area.flags.is_discards:
                                                    text = TransText('{faces} were discarded to {into_area}', faces=faces, into_area=into_area)
                                                    sound = 'carddrop'
                                                else:
                                                    text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                                    sound = 'set'
                                else:
                                    if into_area.flags.is_removed:
                                        text = TransText('{faces} were removed from {from_area}', faces=faces, from_area=from_area)
                                        sound = 'banished'
                                    else:
                                        if into_area.flags.is_resources_area:
                                            text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                        else:
                                            if into_area.flags.is_discards:
                                                text = TransText('{faces} were discarded to {into_area}', faces=faces, into_area=into_area)
                                                sound = 'carddrop'
                                            else:
                                                text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                                sound = 'set'
                    else:
                        if into_area.flags.is_boost_area:
                            if into_area.bind_card:
                                text = TransText("{faces} were moved to {into_area}'s boost area", faces=faces, into_area=into_area.bind_card.face)
                            else:
                                text = TransText('{faces} moved to boost area', faces=faces)
                            sound = 'token'
                        else:
                            if into_area.flags.is_in_hand:
                                if from_area:
                                    if not (from_area.flags.is_in_hand):
                                        text = TransText('{player} drew {faces} from {from_area}', player=into_area.bind_owner, faces=faces, from_area=from_area)
                                        sound = 'draw'
                                    else:
                                        if into_area.flags.is_removed:
                                            text = TransText('{faces} were removed from {from_area}', faces=faces, from_area=from_area)
                                            sound = 'banished'
                                        else:
                                            if into_area.flags.is_resources_area:
                                                text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                            else:
                                                if into_area.flags.is_discards:
                                                    text = TransText('{faces} were discarded to {into_area}', faces=faces, into_area=into_area)
                                                    sound = 'carddrop'
                                                else:
                                                    text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                                    sound = 'set'
                                else:
                                    if into_area.flags.is_removed:
                                        text = TransText('{faces} were removed from {from_area}', faces=faces, from_area=from_area)
                                        sound = 'banished'
                                    else:
                                        if into_area.flags.is_resources_area:
                                            text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                        else:
                                            if into_area.flags.is_discards:
                                                text = TransText('{faces} were discarded to {into_area}', faces=faces, into_area=into_area)
                                                sound = 'carddrop'
                                            else:
                                                text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                                sound = 'set'
                            else:
                                if into_area.flags.is_removed:
                                    text = TransText('{faces} were removed from {from_area}', faces=faces, from_area=from_area)
                                    sound = 'banished'
                                else:
                                    if into_area.flags.is_resources_area:
                                        text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                    else:
                                        if into_area.flags.is_discards:
                                            text = TransText('{faces} were discarded to {into_area}', faces=faces, into_area=into_area)
                                            sound = 'carddrop'
                                        else:
                                            text = TransText('{faces} were moved to {into_area}', faces=faces, into_area=into_area)
                                            sound = 'set'
    class AfterCardsMoved(Message2):
        def __init__(self, face_areas, *, by_shuffle = False, by_discard = False, by_put_into_play = False, by_place_on_table = False, by_return_to_hand = False, by_swap = False, by_setaside = False, by_draw_up = False, by_resources = False, by_deal_encounter_card = False, by_boost = False, by_remove = False, move_by_position = False):
            from game.message import Message
            self.face_areas = face_areas
            self.faces = list(face_areas.keys())
            self.from_areas = set(face_areas.values())
            self.into_areas = set([x.card.area for x in self.faces])
            self.related_decks = (set(self.from_areas) | set(self.into_areas))
            self.by_shuffle = by_shuffle
            if (len(self.faces) > 0):
                super().__init__(world=self.faces[0].card.world)
                self.AddRelatedFace(*self.faces)
                if not (by_shuffle):
                    if not (by_discard):
                        if not (by_put_into_play):
                            if not (by_place_on_table):
                                if not (by_return_to_hand):
                                    if not (by_swap):
                                        if not (by_setaside):
                                            if not (by_draw_up):
                                                if not (by_resources):
                                                    if not (by_deal_encounter_card):
                                                        if not (by_boost):
                                                            if not (by_remove):
                                                                if move_by_position:
                                                                    return
                return
                if not ((len(self.into_areas) == 1)):
                    raise AssertionError
        def IsDeckTypeRelated(self, deck_type):
            for deck in self.related_decks:
                if (deck.deck_type == deck_type):
                    return True
            return False
        @override
        def Send(self):
            if self.face_areas:
                return super().Send()
        def IsIncludeFace(self, which_card: Condition.CARD_TYPE, by_effect: 'Effect') -> 'CardFace|None':
            for face in self.face_areas:
                if Condition.CheckWhichCard(which_card, face, by_effect):
                    face
                    return
    class AfterCardsExhaust_Text(TextMessage):
        def __init__(self, faces, by_effect):
            if (len(faces) > 0):
                super().__init__(world=faces[0].card.world)
                text = TransText('{cards} exhausted ({by_effect})', cards=faces, by_effect=by_effect.this)
                self.Present(*tuple([text, 'flip', *faces, by_effect.this]))
                return
    class AfterCardsSwapDeck_Text(TextMessage):
        def __init__(self, face0: 'CardFace', face1: 'CardFace'):
            from game.message import Message
            super().__init__(world=face0.card.world)
            text = TransText('{face0} {face1} swapped', face0=face0, face1=face1)
            self.Present(text, 'set')
            message = Message.AfterCardsMoved({face0: face1.card.area, face1: face0.card.area}, by_swap=True)
            message.Send()
    class AfterCardsPlaceOnTable_Text(TextMessage):
        def __init__(self, faces):
            if (len(faces) > 0):
                super().__init__(world=faces[0].card.world)
                text = TransText('{cards} were placed on table', cards=faces)
                self.Present(*tuple([text, 'set', *faces]))
                return
    class AfterCardsRemove_Text(TextMessage):
        def __init__(self, cards):
            if (len(cards) > 0):
                super().__init__(world=cards[0].card.world)
                text = TransText('{cards} removed', cards=cards)
                self.Present(text, 'carddrop')
                return
    class AfterCardsFlipAll_Text(TextMessage):
        def __init__(self, faces):
            if (len(faces) > 0):
                super().__init__(world=faces[0].card.world)
                text = TransText('{cards} were flipped', cards=faces)
                self.Present(text, 'flip')
                return
    class AfterCardsSetAside_Text(TextMessage):
        def __init__(self, face_deck):
            from game.message import Message
            if face_deck:
                super().__init__(world=list(face_deck.keys())[0].card.world)
                text = TransText('{cards} were set aside', cards=list(face_deck.keys()))
                self.Present(text, 'set')
                message = Message.AfterCardsMoved(face_deck, by_setaside=True)
                message.Send()
                return
    class AfterCardsReadied_Text(TextMessage):
        def __init__(self, faces, by_effect):
            super().__init__(world=by_effect.world)
            if (len(faces) > 0):
                text = TransText('{cards} readied ({by_effect})', cards=faces, by_effect=by_effect.this)
                self.Present(*tuple([text, 'flip', *faces, by_effect.this]))
                return
    class WhenCardUpdateTrait_Text(TextMessage):
        def __init__(self, face, diff, traits, by_effect):
            from game.message import Message
            face.card.ui.SetEffectedBy(diff, by_effect)
            if (diff == 1):
                message = Message.AfterCardGainTrait(face, traits, by_effect)
                message.Send()
                return
            if (diff == -1):
                message = Message.AfterCardLoseTrait(face, traits, by_effect)
                message.Send()
                return
    class AfterCardGainTrait(CardStateUpdatedMessage):
        def __init__(self, face, traits, by_effect):
            self.by_effect = by_effect
            self.traits = traits
            super().__init__(trigger=face)
    class AfterCardLoseTrait(CardStateUpdatedMessage):
        def __init__(self, face, traits, by_effect):
            self.by_effect = by_effect
            self.traits = traits
            super().__init__(trigger=face)
    class WhenAreaCardUpdateConsiderAs(TriggerFaceMessage):
        def __init__(self, face: 'CardFace'):
            raise AssertionError
    class WhenCardEnterPlay(TriggerFaceMessage, HasEndEventMessage):
        def __init__(self, face, by_effect, *, is_flip):
            from game.card.face.attribute.has_cost import HasCost
            from game.element.resources import Resources
            from game.element.cost import Cost
            from game.ability.cost_func import CostFunc
            from game.message import Message
            self.by_effect = by_effect
            self.is_flip = is_flip
            paid_cost = Resources('0')
            need_cost = Cost('0')
            if not (by_effect.is_rule):
                if HasCost.IsType(face):
                    if by_effect.is_forced:
                        pass
                    else:
                        if (by_effect.this == face):
                            paid_cost = by_effect.context.paid_this_resources
                            if by_effect.context.this_effect_need_cost:
                                need_cost = by_effect.context.this_effect_need_cost
                            else:
                                need_cost = Cost('0')
                                if by_effect.ability.is_play:
                                    cost_fn = by_effect.cost_func.Has(CostFunc.PayPrintCost)
                                    if cost_fn:
                                        paid_cost = cost_fn.return_paid_resources
                                    need_cost = face.printed_cost
                        else:
                            if by_effect.ability.is_play:
                                cost_fn = by_effect.cost_func.Has(CostFunc.PayPrintCost)
                                if cost_fn:
                                    paid_cost = cost_fn.return_paid_resources
                                need_cost = face.printed_cost
            if (by_effect.this == face):
                paid_cost = by_effect.context.paid_this_resources
                if by_effect.context.this_effect_need_cost:
                    need_cost = by_effect.context.this_effect_need_cost
                else:
                    need_cost = Cost('0')
                    if by_effect.ability.is_play:
                        cost_fn = by_effect.cost_func.Has(CostFunc.PayPrintCost)
                        if cost_fn:
                            paid_cost = cost_fn.return_paid_resources
                        need_cost = face.printed_cost
            else:
                if by_effect.ability.is_play:
                    cost_fn = by_effect.cost_func.Has(CostFunc.PayPrintCost)
                    if cost_fn:
                        paid_cost = cost_fn.return_paid_resources
                    need_cost = face.printed_cost
            self.paid_cost = paid_cost
            self.overpaid = (paid_cost.val - need_cost.val)
            super().__init__(trigger=face, end_event=Message.AfterCardEnterPlay)
            text = TransText('{face} is entering play ({by_effect})', face=face, by_effect=by_effect.this)
            self.Present(text, '', face)
    class AfterCardEnterPlay(TriggerFaceMessage, HasPreEventMessage):
        __doc__ = '\n        Includes after flip\n        '
        def __init__(self, face: 'CardFace', from_area: 'Deck', into_area: 'Deck', by_effect: 'Effect', enter_play_message: 'Message.WhenCardEnterPlay'):
            self.from_area = from_area
            self.into_area = into_area
            self.by_effect = by_effect
            self.paid_resources = by_effect.context.paid_this_resources
            super().__init__(trigger=face, pre_message=enter_play_message)
            text = TransText('{face} entered play ({by_effect})', face=face, by_effect=by_effect.this)
            self.Present(text, ('set' if not (from_area.flags.is_in_play) else ''), face)
    class WhenCardWouldRemoveFromGame(TriggerFaceMessage, CanBeInstead, HasEndEventMessage):
        def __init__(self, face, by_effect, *, ui_group = False):
            from game.message import Message
            self.by_effect = by_effect
            super().__init__(trigger=face, end_event=Message.AfterCardRemoveFromGame)
            if not (ui_group):
                text = TransText('{face} would be removed from game', face=face)
                self.Present(text, '', face)
                return
    class AfterCardRemoveFromGame(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face: 'CardFace', would_remove_message: 'Message.WhenCardWouldRemoveFromGame'):
            super().__init__(trigger=face, pre_message=would_remove_message)
    class WhenCardTreatAsIfBlank(TriggerFaceMessage):
        def __init__(self, face: 'CardFace', by_effect: 'Effect'):
            self.by_effect = by_effect
            super().__init__(trigger=face)
            text = TransText('{face} is treated as if blank ({by_effect})', face=face, by_effect=by_effect.this)
            self.Present(text, '', face)
    class WhenCardWouldTreatAsIfBlank(TriggerFaceMessage, CanBeInstead):
        def __init__(self, face: 'CardFace', by_effect: 'Effect'):
            self.by_effect = by_effect
            super().__init__(trigger=face)
    class WhenCardSetAs(TriggerFaceMessage):
        def __init__(self, face: 'CardFace', to_face: 'CardFace'):
            self.to_face = to_face
            super().__init__(trigger=face)
