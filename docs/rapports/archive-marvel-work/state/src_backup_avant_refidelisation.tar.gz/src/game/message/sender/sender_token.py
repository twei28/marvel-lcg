# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderTokenCounter:
    class WhenCardWouldBePlacedToken(TriggerFaceMessage, HasEndEventMessage, CanBeInstead):
        def __init__(self, face, num, name, by_effect):
            from game.message import Message
            self.num = num
            self.token_name = name
            self.by_effect = by_effect
            super().__init__(trigger=face, end_event=Message.AfterCardPlacedToken)
    class AfterCardPlacedToken(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face, num, name, by_effect, message):
            self.num = num
            self.token_name = name
            self.by_effect = by_effect
            super().__init__(trigger=face, pre_message=message)
            if (num > 0):
                if not (face.IsInPlay()):
                    if (name != 'threat'):
                        text = TransText("{face} placed {tokens} '{name}' token ({by_effect})", face=face, tokens=num, name=name, by_effect=by_effect.this)
                        self.Present(text, 'addcounter', face, by_effect.this)
                        return
                        return
                text = TransText("{face} placed {tokens} '{name}' token ({by_effect})", face=face, tokens=num, name=name, by_effect=by_effect.this)
                self.Present(text, 'addcounter', face, by_effect.this)
                return
    class WhenCardWouldRemovedToken(TriggerFaceMessage, HasEndEventMessage, CanBeInstead):
        def __init__(self, face, num, name, by_effect):
            from game.message import Message
            self.would_remove = (num if isinstance(num, int) else None)
            self.remove_all = (num == 'All')
            self.token_name = name
            self.by_effect = by_effect
            super().__init__(trigger=face, end_event=Message.AfterCardRemovedToken)
    class AfterCardRemovedToken(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face, removed_num, pre_message):
            self.removed_num = removed_num
            self.token_name = pre_message.token_name
            self.by_effect = pre_message.by_effect
            super().__init__(trigger=face, pre_message=pre_message)
            if (removed_num > 0):
                text = TransText("{face} removed {tokens} '{name}' token ({by_effect})", face=face, tokens=removed_num, name=self.token_name, by_effect=self.by_effect.this)
                self.Present(text, 'removecounter', face, self.by_effect.this)
                return
    class WhenCardWouldBePlacedCounter(TriggerFaceMessage, HasEndEventMessage, CanBeInstead):
        def __init__(self, face, counters, name, by_effect):
            from game.message import Message
            from game.player import Player
            self.counters = counters
            self.counter_name = name
            self.by_effect = by_effect
            def get_place_player() -> Player|None:
                for_message = by_effect.bind_message
                if isinstance(for_message, Message.WhenCardRevealed):
                    player = for_message.GetToPlayer()
                    return player
                if isinstance(for_message, Message.WhenCardBecomeBoost):
                    player = for_message.GetToPlayer()
                    return player
                if isinstance(for_message, TriggerPlayerMessage):
                    player = for_message.to_player
                    return player
                if isinstance(self.by_effect.initiator, Player):
                    player = self.by_effect.initiator
                    return player
                player = None
                return player
            self.place_player = get_place_player()
            self.maximum = None
            super().__init__(trigger=face, end_event=Message.AfterCardPlacedCounter)
            text = TransText("{face} would place {counters} '{name}' counter ({by_effect})", face=face, counters=counters, name=name, by_effect=by_effect.this)
            self.Present(text, '', face, by_effect.this)
    class AfterCardPlacedCounter(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face, counters, name, by_effect, message):
            self.counters = counters
            self.counter_name = name
            self.by_effect = by_effect
            self.place_player = message.place_player
            super().__init__(trigger=face, pre_message=message)
            if (counters > 0):
                text = TransText("{face} placed {counters} '{name}' counter ({by_effect})", face=face, counters=counters, name=name, by_effect=by_effect.this)
                self.Present(text, 'addcounter', face, by_effect.this)
                return
        @property
        def would_place(self) -> 'Message.WhenCardWouldBePlacedCounter':
            return self.pre_message
    class WhenCardWouldRemovedCounter(TriggerFaceMessage, CanBeInstead, HasEndEventMessage):
        def __init__(self, face, counters, name, by_effect):
            from game.message import Message
            self.counters = (counters if isinstance(counters, int) else None)
            self.remove_all = (counters == 'All')
            self.counter_name = name
            self.by_effect = by_effect
            super().__init__(trigger=face, end_event=Message.AfterCardRemovedCounter)
    class AfterCardRemovedCounter(TriggerFaceMessage, HasPreEventMessage):
        def __init__(self, face, removed_counters, message):
            self.removed_counters = removed_counters
            self.counter_name = message.counter_name
            self.by_effect = message.by_effect
            super().__init__(trigger=face, pre_message=message)
            if (removed_counters > 0):
                text = TransText("{face} removed {counters} '{name}' counter ({by_effect})", face=face, counters=removed_counters, name=self.counter_name, by_effect=self.by_effect.this)
                self.Present(text, 'removecounter', face, self.by_effect.this)
                return
