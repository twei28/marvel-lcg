# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderRound:
    class WhenGameBeginSetup(Message2):
        def __init__(self, campaign: CampaignDescriptor, world: 'World'):
            self.skip_create_encounter_deck = False
            self.no_use_obligation = False
            self.encounter_set_names = campaign.encounter_sets[:]
            self.set_aside_card_ids = campaign.set_aside[:]
            self.set_aside_modular_card_ids = []
            self.skip_put_villain_into_play = False
            super().__init__(world=world)
        def CreateSetAside(self):
            from game.card.factory import CardFactory
            from game.message import Message
            CardFactory.GenerateCards(self.set_aside_card_ids, self.world.aside_deck, self.world)
            Message.WhenDeckCreated_Text(self.world.aside_deck)
        def CreateSetAsideModular(self):
            from game.card.factory import CardFactory
            from game.message import Message
            CardFactory.GenerateCards(self.set_aside_modular_card_ids, self.world.aside_modular, self.world)
            Message.WhenDeckCreated_Text(self.world.aside_modular)
    class WhenCampaignSetup(Message2):
        def __init__(self, world: 'World'):
            super().__init__(world=world)
    class WhenGameInitialize(Message2):
        def __init__(self, world: 'World'):
            super().__init__(world=world)
    class WhenGameWouldBegin(Message2):
        def __init__(self, world: 'World'):
            super().__init__(world=world)
    class WhenGameOver(Message2):
        def __init__(self, players_won, reason, by_effect):
            self.players_won = players_won
            self.reason = reason
            self.by_effect = by_effect
            super().__init__(world=by_effect.world)
        def SetPlayerLost(self, by_effect: 'Effect'):
            self.by_effect = by_effect
            self.reason = 'Players Lost'
            self.players_won = False
        def IsRule(self):
            return self.by_effect.is_rule
    class GameOver_Text(TextMessage):
        def __init__(self, players_won, reason, by_effect, world):
            super().__init__(world=world)
            if not ((reason != 'Undo')):
                raise AssertionError
            if not (by_effect.is_rule):
                reason = f'{reason} ({by_effect.this.name})'
            text = TransText('\n--- Game Over ---\n{reason}\n{win}', reason=reason, win=players_won)
            self.PresentGameOver(text, '', self.name)
    class WhenRoundStart(Message2):
        def __init__(self, turn_cnt, world):
            self.turn_cnt = turn_cnt
            super().__init__(world=world)
            text = TransText('\n=== Round {turn_cnt} Start ===', turn_cnt=turn_cnt)
            self.Present(text, '')
    class WhenRoundEnd(HasEndEventMessage):
        def __init__(self, world: 'World'):
            from game.message import Message
            self.round_id = world.round_id
            super().__init__(end_event=Message.AfterRoundEnd, world=world)
            text = TransText('\n--- Round {round_id} End ---', round_id=world.round_id)
            self.Present(text, 'nextturn')
    class AfterRoundEnd(HasPreEventMessage):
        def __init__(self, message: 'Message.WhenRoundEnd'):
            self.round_id = message.round_id
            super().__init__(pre_message=message)
    class WhenPhaseBegin(HasEndEventMessage):
        def __init__(self, phase_name, world):
            from game.message import Message
            self.phase_id = world.phase_id
            self.round_id = world.round_id
            self.phase_name = phase_name
            super().__init__(end_event=Message.AfterPhaseBegin, world=world)
            text = TransText('\n--- {phase_name} Phase ---', phase_name=phase_name)
            self.Present(text, '')
    class AfterPhaseBegin(HasPreEventMessage):
        def __init__(self, message: 'Message.WhenPhaseBegin'):
            self.phase_id = message.phase_id
            self.round_id = message.round_id
            self.phase_name = message.phase_name
            super().__init__(pre_message=message)
    class WhenPhaseEnd(HasEndEventMessage):
        def __init__(self, phase_id, phase_name, world):
            from game.message import Message
            self.phase_id = phase_id
            self.phase_name = phase_name
            super().__init__(end_event=Message.AfterPhaseEnd, world=world)
            text = TransText('\n--- {phase_name} Phase End ---', phase_name=phase_name)
            self.Present(text, '')
    class AfterPhaseEnd(HasPreEventMessage):
        def __init__(self, phase_id, phase_name, message):
            self.phase_id = phase_id
            self.phase_name = phase_name
            super().__init__(pre_message=message)
    class WhenVillainPhaseStepStart(HasEndEventMessage):
        def __init__(self, step, world):
            from game.message import Message
            self.step = step
            super().__init__(end_event=Message.AfterResolveVillainPhaseStep, world=world)
    class AfterResolveVillainPhaseStep(HasPreEventMessage):
        def __init__(self, step, message):
            self.step = step
            super().__init__(pre_message=message)
