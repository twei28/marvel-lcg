# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderFriend:
    class WhenAllyWouldTakeConsequentialDamage(TriggerUnitMessage, CanBeInstead, DamageMessage, HasEndEventMessage):
        def __init__(self, unit, damage, message):
            from game.message import Message
            end_message = message.end_message
            is_thwart = (type(end_message) is Message.AfterUnitThwartEnd)
            self.atk_message = (None if is_thwart else end_message.CastTo(Message.AfterUnitAttackEnd))
            self.thw_message = (end_message.CastTo(Message.AfterUnitThwartEnd) if is_thwart else None)
            super().__init__(trigger=unit, damage=damage, end_event=Message.AfterAllyTakeConsequentialDamage)
        def ReduceDamage(self, damage, by_effect):
            from game.message import Message
            self.UpdateDamageInternal((-1 * damage))
            Message.WhenDamageUpdated_Text((-1 * damage), by_effect)
        def IncreaseDamage(self, damage, by_effect):
            from game.message import Message
            self.UpdateDamageInternal(damage)
            Message.WhenDamageUpdated_Text(damage, by_effect)
    class AfterAllyTakeConsequentialDamage(TriggerUnitMessage, HasPreEventMessage):
        def __init__(self, unit: 'Ally', message: 'Message.AfterUnitUseBasicPower', would_message: 'Message.WhenAllyWouldTakeConsequentialDamage'):
            from game.message import Message
            end_message = message.end_message
            is_thwart = (type(end_message) is Message.AfterUnitThwartEnd)
            self.atk_message = (None if is_thwart else end_message.CastTo(Message.AfterUnitAttackEnd))
            self.thw_message = (end_message.CastTo(Message.AfterUnitThwartEnd) if is_thwart else None)
            super().__init__(trigger=unit, pre_message=would_message)
    class WhenUnitWouldThwart(TriggerUnitMessage, ThwarterMessage, CanGainValueMessage, CanBeInstead):
        def __init__(self, unit, schemes, by_effect, *, property):
            self.schemes = schemes
            self.property = property
            self.does_not_take_consequential_damage = False
            self.by_effect = by_effect
            super().__init__(trigger=unit, thwarter=unit, thwarted=schemes)
            if (schemes == []):
                text = TransText('{unit} will thwart', unit=unit)
                return
            text = TransText('{unit} will thwart {schemes} ({additional_value:+})', unit=unit, schemes=schemes, additional_value=property.additional_value)
            self.Present(*tuple([text, 'target', unit, *schemes]))
        @property
        def get_schemes(self):
            return self.schemes
        def DoesNotTakeConsequentialDamage(self, by_effect: 'Effect'):
            self.does_not_take_consequential_damage = True
        def RemoveAdditionalThreat(self, value, by_effect):
            self.property.additional_value = (self.property.additional_value + value)
            text = TransText('This thwart will remove {value} additional threat ({by_effect})', value=value, by_effect=by_effect.this)
            self.Present_Activate(text, by_effect)
        def GainTHWForThisThwart(self, value, by_effect):
            if not (self.IsBasicThwart()):
                raise AssertionError
            from game.card.face.base import Unit2
            this = self.trigger.CastTo(Unit2)
            this.GainForThisActive(by_effect, self, thwart=value)
        def UseATKInsteadTHW(self, by_effect: 'Effect'):
            from game.card.face.attribute.can_attack import HasAttack
            from game.card.face.attribute.can_thwart import HasThwart
            unit = self.trigger
            if HasAttack.IsType(unit):
                atk = unit.attack
            else:
                atk = 0
            if HasThwart.IsType(unit):
                thw = unit.thwart
            else:
                thw = 0
            diff = (atk - thw)
            self.GainTHWForThisThwart(diff, by_effect)
        def AddMatchingPowerToThisPerformance(self, face: 'CardFace', by_effect: 'Effect'):
            from game.card.face.attribute.can_attack import HasAttack
            from game.card.face.attribute.can_thwart import HasThwart
            if not (self.IsBasicThwart()):
                raise AssertionError
            is_assault = False
            for scheme in self.schemes:
                if scheme.assault:
                    is_assault = True
            if is_assault:
                if HasAttack.IsType(face):
                    self.trigger.GainForThisActive(by_effect, self, attack=face.attack)
                    return
                return
            if HasThwart.IsType(face):
                self.GainTHWForThisThwart(face.thwart, by_effect)
                return
        def AfterThreatRemoved(self, action):
            from game.ability.factory import AbilityFactory
            self.by_effect.this.effect.RegisterTemp(AbilityFactory.AfterSchemeRemoveThreat(AbilityType.Temp0, None, lambda effect, message: action(message.value), by_thwart=self), unregister_after_exec=True, until_event_end=self)
        def IsBasicThwart(self):
            return self.property.is_basic_power
    class WhenSchemeBeingThwart(TriggerUnitMessage, HasEndEventMessage, CanGainValueMessage):
        def __init__(self, scheme: 'Scheme2', would_thw_message: 'Message.WhenUnitWouldThwart'):
            from game.message import Message
            self.scheme = scheme
            self.property = would_thw_message.property
            self.would_thw_message = would_thw_message
            self.would_message = would_thw_message
            self.who_make_thwart = would_thw_message.trigger
            super().__init__(trigger=would_thw_message.trigger, end_event=Message.AfterUnitThwartScheme)
            self.AddRelatedFace(scheme)
        def IsBasicThwart(self):
            return self.would_thw_message.IsBasicThwart()
        def GainThwartForThisThwart(self, value, by_effect):
            if self.IsBasicThwart():
                from game.card.face.base import Unit2
                this = self.trigger.CastTo(Unit2)
                this.GainForThisActive(by_effect, self, thwart=value)
                return
            self.property.additional_value = (self.property.additional_value + value)
            text = TransText('This thwart gains {value} additional value from {by_effect}', value=value, by_effect=by_effect.this)
            self.Present_Activate(text, by_effect)
    class AfterUnitThwartScheme(TriggerUnitMessage, HasPreEventMessage):
        def __init__(self, unit, scheme, remove_threat, would_thw_message):
            self.scheme = scheme
            self.remove_threat = remove_threat
            super().__init__(trigger=unit, pre_message=would_thw_message)
            self.AddRelatedFace(unit, scheme)
        def IsBasicThwart(self):
            return self.would_thw_message.IsBasicThwart()
        @property
        def would_thw_scheme_message(self) -> 'Message.WhenSchemeBeingThwart':
            return self.pre_message
        @property
        def would_thw_message(self) -> 'Message.WhenUnitWouldThwart':
            return self.would_thw_scheme_message.would_thw_message
    class AfterUnitThwartEnd(TriggerUnitMessage, ThwarterMessage):
        def __init__(self, unit, schemes, total_remove_threat, by_effect, after_thw_messages):
            self.schemes = schemes
            self.by_effect = by_effect
            self.total_remove_threat = total_remove_threat
            self.after_thw_messages = after_thw_messages
            self.would_thw_messages = [x.would_thw_message for x in after_thw_messages]
            remove_all = False
            for message in self.after_thw_messages:
                if (message.scheme.threat == 0):
                    remove_all = True
                else:
                    pass
            self.remove_the_last_threat = remove_all
            super().__init__(trigger=unit, thwarter=unit, thwarted=schemes)
        def IsBasicThwart(self):
            return ((len(self.would_thw_messages) == 1) and self.would_thw_messages[0].IsBasicThwart())
    class WhenUnitWouldRecovery(TriggerUnitMessage, HasEndEventMessage, CanGainValueMessage, CanBeInstead):
        def __init__(self, unit: 'Unit2'):
            from game.message import Message
            super().__init__(trigger=unit, end_event=Message.AfterUnitRecovery)
        def GainRECForThisRecover(self, value, by_effect):
            self.trigger.GainForThisActive(by_effect, self, recover=value)
    class AfterUnitRecovery(CanBeInstead, TriggerUnitMessage, HasPreEventMessage):
        def __init__(self, unit: 'Unit2', rec_message: 'Message.AfterUnitHealHealth|None', would_message: 'Message.WhenUnitWouldRecovery'):
            self.rec_message = rec_message
            super().__init__(trigger=unit, pre_message=would_message)
