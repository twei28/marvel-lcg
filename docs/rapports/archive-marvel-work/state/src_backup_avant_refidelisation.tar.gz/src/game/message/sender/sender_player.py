# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderPlayer:
    class PlayerOnEvent_Text(TextMessage):
        def __init__(self, player: 'Player', message: Message2):
            from game.message import Message
            from game.test import Test
            super().__init__(world=player.world)
            if not (Test.IsInTesting()):
                if isinstance(message, Message.WhenPlayerInTurn):
                    text = TransText('\n{player} on event {message}', player=player, message=message.GetDisplayName())
                    self.Present(text, '')
                    return
                    return
    class WhenPlayerSearchingDeckCards_Text(TextMessage):
        def __init__(self, player, deck, size, faces):
            if (len(faces) > 0):
                if player.world.is_game_started:
                    super().__init__(world=player.world)
                    cards = sorted(faces)
                    from collections import Counter
                    instances = [x.GetDisplayName(no_hidden=True, no_object_id=True) for x in cards]
                    counted_elements = Counter(instances)
                    formatted_list = []
                    for _item in counted_elements.items():
                        element = UNKNOWN[0]
                        count = UNKNOWN[1]
                        if (count > 1):
                            formatted_list.append(f'{element}x{count}')
                        formatted_list.append(element)
    class WhenPlayerResolveMulligans(TriggerPlayerMessage):
        def __init__(self, player: 'Player'):
            super().__init__(player=player)
            text = TransText('{player} resolves mulligans', player=player)
            self.Present(text, '')
    class WhenPlayerWouldDrawCard(TriggerPlayerMessage, TriggerFaceMessage, CanBeInstead):
        def __init__(self, player: 'Player', face: 'CardFace', by_effect: 'Effect'):
            self.by_effect = by_effect
            super().__init__(player=player, trigger=face)
    class AfterPlayerDrewCards(TriggerPlayerMessage):
        def __init__(self, player, face_deck, by_effect):
            from game.message import Message
            self.size = len(face_deck)
            self.drew_faces = [x for x in face_deck.keys()]
            super().__init__(player=player)
            if (self.size > 0):
                message = Message.AfterCardsMoved(face_deck, by_draw_up=True)
                message.Send()
                text = TransText('{player} draws {size} card(s) ({effect})', player=player, size=self.size, effect=by_effect.this)
                self.Present(*tuple([text, 'draw', by_effect.this, *face_deck.keys()]))
                return
    class AfterPlayerGainCards_Text(TextMessage):
        def __init__(self, player, faces, by_effect):
            super().__init__(world=player.world)
            text = TransText('{player} gains {faces}', player=player, faces=faces)
            self.Present(*tuple([text, 'draw', by_effect.this, *faces]))
    class GameAreaAddPlayer(TriggerPlayerMessage):
        def __init__(self, player: 'Player'):
            super().__init__(player=player)
            text = TransText('{player} enters game area', player=player)
            self.Present(text, 'activate', player.GetIdentity())
    class GameAreaAddCard(TriggerFaceMessage):
        def __init__(self, face: 'CardFace'):
            super().__init__(trigger=face)
    class WhenPlayerSelectHero(TriggerPlayerMessage, TriggerFaceMessage):
        def __init__(self, player: 'Player', unit: 'Identity'):
            super().__init__(player=player, trigger=unit)
    class AfterPlayerSelectHeroEnd(TriggerPlayerMessage, TriggerFaceMessage):
        def __init__(self, player: 'Player', unit: 'Identity'):
            super().__init__(player=player, trigger=unit)
            text = TransText('{player} selected {unit}', player=player, unit=unit)
            self.Present(text, '')
    class WhenPlayerWouldPlayCard(TriggerPlayerMessage, TriggerFaceMessage, CanBeInstead):
        def __init__(self, player, play_effect, resource, from_area, is_like_in_hand):
            from game.card.face.attribute.has_cost import HasCost
            self.play_face = play_effect.this.CastTo(HasCost)
            self.play_effect = play_effect
            self.paid_resources = resource
            self.be_cancel = False
            self.from_area = from_area
            self.is_like_from_hand = is_like_in_hand
            super().__init__(player=player, trigger=player.GetIdentity())
            text = TransText('{player} would play {this} with ({resource})', this=play_effect.this, player=player, resource=resource)
            self.Present(text, '', play_effect.this)
            self.AddRelatedFace(player, play_effect)
        def CancelEffects(self, by_effect, *, discard_it = False):
            from game.operate.faces import Faces
            self.Present_Activate(None, by_effect)
            self.be_cancel = True
            if discard_it:
                Faces.DiscardAll([self.play_face], by_effect)
            return True
    class WhenPlayerPlayCard(TriggerPlayerMessage, TriggerFaceMessage, CanGainValueMessage, HasEndEventMessage):
        def __init__(self, player: 'Player', message: 'Message.WhenPlayerWouldPlayCard'):
            from game.message import Message
            self.played_face = message.play_face
            self.played_effect = message.play_effect
            self.paid_resources = message.paid_resources
            self.from_area = message.from_area
            self.paid_res_effects = self.played_effect.context.paid_this_res_effects
            self.is_like_from_hand = message.is_like_from_hand
            super().__init__(player=player, trigger=player.GetIdentity(), end_event=Message.AfterPlayerPlayedCard)
        def IncreaseDamage(self, num, by_effect):
            from game.ability.ability import AbilityType
            from game.ability.factory import AbilityFactory
            self.played_face.effect.RegisterTemp(AbilityFactory.WhenUnitWouldAttack(AbilityType.Temp0, None, lambda effect, message: message.DealAdditionalDamage(2, effect), by_effect=self.played_effect), unregister_after_exec=False, until_resolve_effect=self.played_effect)
        def IncreaseThreatRemove(self, num, by_effect):
            from game.ability.ability import AbilityType
            from game.ability.factory import AbilityFactory
            self.played_face.effect.RegisterTemp(AbilityFactory.WhenUnitWouldThwart(AbilityType.Temp0, who_make_thwart=None, operation=lambda effect, message: message.RemoveAdditionalThreat(2, effect), conditions=[lambda effect, message: (self.played_effect == message.by_effect)]), unregister_after_exec=False, until_resolve_effect=self.played_effect)
    class AfterPlayerPlayedCard(TriggerPlayerMessage, HasPreEventMessage):
        def __init__(self, player: 'Player', face: 'ClassCard', effect: 'Effect', play_message: 'Message.WhenPlayerPlayCard', message: Message2, from_area: 'Deck'):
            self.played_face = face
            self.from_area = from_area
            self.on_message = message
            self.play_effect = effect
            self.paid_resources = play_message.paid_resources
            self.paid_res_effects = play_message.paid_res_effects
            self.is_like_from_hand = (from_area.flags.is_in_hand or play_message.is_like_from_hand)
            super().__init__(player=player, pre_message=play_message)
            self.AddRelatedFace(player, face, effect)
        @property
        def play_message(self) -> 'Message.WhenPlayerPlayCard':
            return self.pre_message
    class CheckEffectCondition(CheckIfMessage):
        def __init__(self, check_effect: 'Effect', by_unit: 'CardFace'):
            self.effect_valid = True
            self.check_effect = check_effect
            super().__init__(by_unit)
            self.AddRelatedFace(check_effect, by_unit)
        def SetEffectInvalid(self, by_effect: 'Effect'):
            self.effect_valid = False
            self.SetCauseBy(by_effect)
        def GetAttacker(self):
            bind_message = self.check_effect.bind_message
            if isinstance(bind_message, AttackerNoneMessage):
                return bind_message.attacker
    class WhenCalculateEffectCost(CalculateMessage, TriggerPlayerMessage):
        def __init__(self, player, check_effect, for_targets):
            self.check_effect = check_effect
            self.for_targets = for_targets
            self.is_play = check_effect.ability.is_play
            self.cost = check_effect.ability.GetCost(check_effect, for_targets)
            super().__init__(player=player)
            self.AddRelatedFace(*tuple([player, check_effect, *for_targets]))
        def UpdateToCost(self, value, by_effect):
            self.cost = Cost(value)
        def UpdateCost(self, value, by_effect):
            self.cost = (self.cost + value)
        def IgnoreResourceCost(self, by_effect: 'Effect'):
            self.check_effect.context.ignore_resource_cost = True
    class CheckEffectGeneratedResources(CheckIfMessage, TriggerNonePlayerMessage):
        def __init__(self, from_effect: 'Effect', check_message: 'Message.CheckPlayerCanPayCost', res: Resources):
            self.for_effect = check_message.paying_for_effect
            self.for_targets = check_message.paying_for_targets
            self.for_target = check_message.paying_for_target
            self.from_effect = from_effect
            self.res = res.Copy()
            super().__init__(player=check_message.to_player, by_face=from_effect.this)
            self.AddRelatedFace(from_effect, self.for_effect)
        def SetResources(self, res: Resources, by_effect: 'Effect'):
            self.res = res
            self.SetCauseBy(by_effect)
    class CheckPlayerCanPayCost(TriggerPlayerMessage, CheckNoneMessage):
        def __init__(self, player, for_effect, cost, for_targets):
            from game.card.face.base import ClassCard
            self.paying_for_effect = for_effect
            self.paying_for_targets = for_targets
            self.paying_for_target = (for_targets[0] if (for_targets != []) else None)
            self.cost = cost
            if ClassCard.IsType(self.paying_for_effect.this):
                paying_for_card = self.paying_for_effect.this
            else:
                paying_for_card = None
            self.paying_for_card = paying_for_card
            self.can_pay_effects = []
            super().__init__(player=player, by_face=self.paying_for_target)
        def AddPayment(self, cost_effect: 'Effect', res: Resources, check_effect: 'Effect'):
            self.can_pay_effects.append((cost_effect, res, check_effect))
    class WhenPlayerPayingResources(TriggerPlayerMessage):
        def __init__(self, player, by_effect, for_effect, for_targets, expected_res, cost_check_effect):
            from game.card.face.base import ClassCard
            self.by_effect = by_effect
            self.for_effect = for_effect
            self.for_targets = for_targets
            self.for_target = (for_targets[0] if (for_targets != []) else None)
            self.expected_res = expected_res
            self
            self.cost_check_effect = cost_check_effect
            if ClassCard.IsType(self.for_effect.this):
                paying_card = self.for_effect.this
            else:
                paying_card = None
            self.paying_card = paying_card
            super().__init__(player=player)
        def SetGenerateRes(self, res: Resources):
            self.generated_res = res
    class WhenPlayerTurnBegin(TriggerPlayerMessage, HasEndEventMessage):
        def __init__(self, player: 'Player'):
            from game.message import Message
            super().__init__(player=player, end_event=Message.AfterPlayerTurnBegin)
    class AfterPlayerTurnBegin(TriggerPlayerMessage, HasPreEventMessage):
        def __init__(self, player: 'Player', message: 'Message.WhenPlayerTurnBegin'):
            super().__init__(player=player, pre_message=message)
    class WhenPlayerTurnEnd(TriggerPlayerMessage, HasEndEventMessage):
        def __init__(self, player, round_id):
            from game.message import Message
            self.round_id = round_id
            super().__init__(player=player, end_event=Message.AfterPlayerTurnEnd)
            text = TransText('\n--- {player} Turn End ---', player=player)
            self.Present(text, 'phase')
    class AfterPlayerTurnEnd(TriggerPlayerMessage, HasPreEventMessage):
        def __init__(self, player: 'Player', message: 'Message.WhenPlayerTurnEnd'):
            super().__init__(player=player, pre_message=message)
    class WhenPlayerInTurn(TriggerPlayerMessage):
        def __init__(self, player, turn_cnt, **kwargs):
            self.turn_cnt = turn_cnt
            super().__init__(*(), **{'player': player, **kwargs})
            if (turn_cnt != -1):
                text = TransText("\n--- {player}'s Turn ({turn_cnt}) ---", player=player, turn_cnt=turn_cnt)
                self.Present(text, 'phase')
                return
    class WhenPlayerLikeInTurn(WhenPlayerInTurn, LikeFakeMessage, NoSendMessage):
        def __init__(self, player: 'Player', by_effect: 'Effect'):
            self.by_effect = by_effect
            super().__init__(player=player, turn_cnt=-1)
    class WhenPlayerEndPhase(TriggerPlayerMessage):
        def __init__(self, player, **kwargs):
            super().__init__(*(), **{'player': player, **kwargs})
            text = TransText('{player} End Phase', player=player)
            self.Present(text, '')
    class WhenPlayerEliminated(Message2):
        def __init__(self, player: 'Player'):
            super().__init__(world=player.world)
            text = TransText('{player} eliminated', player=player)
            self.Present(text, '')
    class WhenPlayerChooseAbility(TriggerPlayerMessage, NoSendResolve):
        def __init__(self, player, by_effect, step, for_second_target):
            self.by_effect = by_effect
            self.step = step
            self.for_second_target = for_second_target
            super().__init__(player=player)
    class WhenPlayerWouldBeDealtEncounterCard(TriggerPlayerMessage, HasEndEventMessage, CanBeInstead):
        def __init__(self, player: 'Player', by_effect: 'Effect', face: 'CardFace'):
            from game.message import Message
            self.by_effect = by_effect
            self.face = face
            super().__init__(player=player, end_event=Message.AfterPlayerDealEncounterCard)
    class AfterPlayerDealEncounterCard(TriggerPlayerMessage, HasPreEventMessage):
        def __init__(self, player: 'Player', message: 'Message.WhenPlayerWouldBeDealtEncounterCard'):
            self.by_effect = message.by_effect
            super().__init__(player=player, pre_message=message)
        @property
        def would_message(self) -> 'Message.WhenPlayerWouldBeDealtEncounterCard':
            return self.pre_message
    class WhenResolveSpecialAbility(TriggerFaceMessage, TriggerNonePlayerMessage):
        def __init__(self, face, name, sequence, to_player, by_effect):
            self.face = face
            self.sequence = sequence
            self.by_effect = by_effect
            self.ability_name = name
            super().__init__(trigger=face, player=to_player, world=face.card.world)
            text = TransText("{player} resolves {face}'s {ability_name} ({by_effect})", player=to_player, face=face, ability_name=name, by_effect=by_effect.this)
            self.Present(text, '', face, by_effect.this)
        def GetToPlayer(self) -> 'Player|None':
            return self.to_player
    class WhenResolvePreparationAbility(TriggerFaceMessage, AttackerNoneMessage, TriggerNonePlayerMessage):
        def __init__(self, face: 'CardFace', to_player: 'Player|None', by_effect: 'Effect'):
            from game.message import Message
            self.face = face
            self.by_effect = by_effect
            self.would_atk_message_unit = (by_effect.bind_message.CastTo(Message.WhenUnitWouldAttackUnit) if by_effect.bind_message else None)
            self.would_atk_message = (self.would_atk_message_unit.would_atk_message if self.would_atk_message_unit else None)
            being_atk_message = (self.would_atk_message_unit.being_atk_message if self.would_atk_message_unit else None)
            self.damage = (self.would_atk_message_unit.property.GetDamage(face) if self.would_atk_message_unit else 0)
            super().__init__(trigger=face, player=to_player, being_atk_message=being_atk_message, world=face.card.world)
            text = TransText("{player} resolves {face}'s Preparation ({by_effect})", player=to_player, face=face, by_effect=by_effect.this)
            self.Present(text, '', face, by_effect.this)
        def GetToPlayer(self) -> 'Player|None':
            return self.to_player
        def PreventAllDamage(self, by_effect: 'Effect'):
            if self.would_atk_message:
                self.would_atk_message.PreventDamage('All', by_effect)
                return
        def AfterThisAttack(self, action):
            from cards.pack import RunAt
            if self.would_atk_message:
                RunAt.AfterEventEnd(self.by_effect, self.would_atk_message, action)
                return
        def ResolveThisAttackToInstead(self, unit: 'Unit2', by_effect: 'Effect'):
            if self.would_atk_message_unit:
                self.would_atk_message_unit.ChangeTarget(unit, by_effect)
                return
    class CheckIfAllyCountLimit(CheckIfMessage):
        def __init__(self, face: 'CardFace'):
            self.not_count = False
            self.check_ally = face
            super().__init__(by_face=face)
        def SetNotCountAlly(self, by_effect: 'Effect'):
            self.not_count = True
            self.SetCauseBy(by_effect)
    class AfterPlayersOrderChange(Message2):
        def __init__(self, world: 'World', by_effect: 'Effect'):
            super().__init__(world=world)
    class CheckIfFaceCountHandSize(TriggerPlayerMessage, TriggerFaceMessage, CheckIfMessage):
        def __init__(self, player: 'Player', face: 'CardFace'):
            self.count_hand_size = True
            super().__init__(player=player, trigger=face, by_face=face)
        def SetNotCountHandSize(self, by_effect: 'Effect'):
            self.count_hand_size = False
            self.SetCauseBy(by_effect)
    class WhenCountingResourcesOnCards(CalculateMessage):
        def __init__(self, face: 'ClassCard', from_deck: 'Deck|None'):
            self.face = face
            self.from_deck = from_deck
            self.return_res = face.printed_resource_internal
            super().__init__(world=face.card.world)
        def SetReturnValue(self, res, effect):
            self.return_res = res
