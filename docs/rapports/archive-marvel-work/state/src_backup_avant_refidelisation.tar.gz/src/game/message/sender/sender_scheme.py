# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderScheme:
    class WhenMainSchemeStageWouldBeCompleted(TriggerSchemeMessage, InActivationMessage, CanBeInstead, HasEndEventMessage):
        def __init__(self, scheme: 'MainScheme', activate_message: 'Message.WhenUnitWouldScheme|None'):
            from game.message import Message
            super().__init__(trigger=scheme, activate_message=activate_message, end_event=Message.WhenMainSchemeStageCompleted)
            text = TransText('{scheme} would be completed', scheme=scheme)
            self.Present(text, '', scheme)
    class WhenMainSchemeStageCompleted(TriggerSchemeMessage, HasPreEventMessage, HasEndEventMessage):
        def __init__(self, scheme: 'MainScheme', would_messasge: 'Message.WhenMainSchemeStageWouldBeCompleted'):
            from game.message import Message
            super().__init__(trigger=scheme, pre_message=would_messasge, end_event=Message.AfterMainSchemeCompleted)
            text = TransText('{scheme} completed', scheme=scheme)
            self.Present(text, '', scheme)
    class AfterMainSchemeCompleted(TriggerSchemeMessage, HasPreEventMessage):
        def __init__(self, scheme: 'MainScheme', message: 'Message.WhenMainSchemeStageCompleted'):
            super().__init__(trigger=scheme, pre_message=message)
    class WhenMainSchemeWouldAdvance(TriggerSchemeMessage, HasEndEventMessage, CanBeInstead):
        def __init__(self, scheme: 'MainScheme', by_effect: 'Effect'):
            from game.message import Message
            self.by_effect = by_effect
            super().__init__(trigger=scheme, end_event=Message.AfterMainSchemeAdvanced)
            text = TransText('{scheme} advances', scheme=scheme)
            self.Present(text, '', scheme)
        @property
        def scheme(self) -> 'MainScheme':
            from game.card.face import MainScheme
            return self.private_trigger.CastTo(MainScheme)
    class AfterMainSchemeAdvanced(TriggerSchemeMessage, HasPreEventMessage):
        def __init__(self, message: 'Message.WhenMainSchemeWouldAdvance'):
            scheme = message.scheme
            self.scheme = scheme
            super().__init__(trigger=scheme, pre_message=message)
    class WhenMainSchemePhaseStart(Message2):
        def __init__(self, world: 'World'):
            super().__init__(world=world)
            text = TransText('Main scheme phase start')
            self.Present(text, '')
    class WhenMainSchemePhaseEnd(Message2):
        def __init__(self, world: 'World'):
            super().__init__(world=world)
            text = TransText('Main scheme phase end')
            self.Present(text, '')
    class CalcMainSchemeEscalation(TriggerSchemeMessage):
        def __init__(self, scheme, escalation_threat, icons, tokens):
            for face in icons:
                escalation_threat = (escalation_threat + face.acceleration_icon)
            for face in tokens:
                escalation_threat = (escalation_threat + face.acceleration_token)
            self.escalation_threat = escalation_threat
            super().__init__(trigger=scheme)
            self.Present(*tuple([None, '', scheme, *icons, *tokens]))
        def UpdateEscalationThreat(self, value):
            self.escalation_threat = (self.escalation_threat + value)
    class WhenSchemeWouldPlaceThreat(TriggerSchemeMessage, HasEndEventMessage, CanBeInstead):
        def __init__(self, scheme, value, by_effect, sch_message):
            from game.message import Message
            self.value = value
            self.by_effect = by_effect
            self.sch_message = sch_message
            super().__init__(trigger=scheme, end_event=Message.AfterSchemePlaceThreat)
            text = TransText('{scheme} would place {value}{symbol} ({effect})', scheme=scheme, value=value, symbol=Symbol.threat, effect=by_effect)
            self.Present(text, '', scheme, by_effect.this)
        def UpdateValue(self, value, by_effect):
            self.value = (self.value + value)
        def PreventThreat(self, value, by_effect):
            if (value == 'All'):
                self.value = 0
                return
            self.UpdateValue((-1 * value), by_effect)
        def ReduceThreat(self, value, by_effect):
            self.UpdateValue((-1 * value), by_effect)
    class AfterSchemePlaceThreat(TriggerSchemeMessage, HasPreEventMessage):
        def __init__(self, scheme, value, by_effect, would_message):
            self.value = value
            super().__init__(trigger=scheme, pre_message=would_message)
            text = TransText('{scheme} gained {value}{symbol}', scheme=scheme, value=value, symbol=Symbol.threat)
            self.Present(text, '', scheme, by_effect.this)
    class WhenSchemeWouldRemoveThreat(TriggerSchemeMessage, HasEndEventMessage, CanBeInstead):
        def __init__(self, scheme, by_face, value, by_effect, being_thw_message):
            from game.message import Message
            self.value = value
            self.by_face = by_face
            self.by_effect = by_effect
            self.being_thw_message = being_thw_message
            self.would_thw_message = (being_thw_message.would_thw_message if being_thw_message else None)
            self.cannot_be_removed = False
            super().__init__(trigger=scheme, end_event=Message.AfterSchemeRemoveThreat)
            text = TransText('{scheme} would remove {value}{symbol}', scheme=scheme, value=value, symbol=Symbol.threat)
            self.Present(text, '', scheme, by_face)
        def SetCannotBeRemoved(self, by_effect: 'Effect'):
            self.cannot_be_removed = True
            text = TransText('Threat cannot be removed from {trigger}', trigger=self.trigger)
            self.Present_ByEffect(text, 'activate', self.trigger, by_effect.this)
    class AfterSchemeRemoveThreat(TriggerSchemeMessage, HasPreEventMessage):
        def __init__(self, scheme, value, by_effect, would_remove_message):
            self.value = value
            self.would_thw_message = would_remove_message.would_thw_message
            self.by_effect = by_effect
            super().__init__(trigger=scheme, pre_message=would_remove_message)
            if scheme.IsInPlay():
                text = TransText('{scheme} removed {value}{symbol}', scheme=scheme, value=value, symbol=Symbol.threat)
                self.Present(text, '', scheme, by_effect.this)
                return
        @property
        def would_remove_message(self) -> 'Message.WhenSchemeWouldRemoveThreat':
            return self.pre_message
        def GetByPlayer(self) -> 'Player|None':
            from game.player import Player
            would_sch_message = self.would_thw_message
            if would_sch_message:
                player = would_sch_message.trigger.GetControlByOrOwner()
            else:
                player = self.by_effect.initiator
            if isinstance(player, Player):
                return player
    class WhenSchemeWouldBeDefeated(TriggerSchemeMessage, CanBeInstead):
        def __init__(self, scheme: 'Scheme2', by_effect: 'Effect', killer: 'CardFace|None', being_thw_message: 'Message.WhenSchemeBeingThwart|None'):
            self.by_effect = by_effect
            self.killer = killer
            self.being_message = being_thw_message
            super().__init__(trigger=scheme)
    class WhenSchemeBeDefeated(TriggerSchemeMessage, HasEndEventMessage):
        def __init__(self, this, would_defeat_message, ignore_when_defeated):
            from game.message import Message
            killer = would_defeat_message.killer
            by_effect = would_defeat_message.by_effect
            self.killer = (killer if killer else by_effect.this)
            self.by_effect = by_effect
            self.ignore_when_defeated = ignore_when_defeated
            def get_defeated_player():
                from game.player import Player
                if self.killer:
                    player = self.killer.GetControlBy()
                    if Player.IsType(player):
                        return player
                if self.by_effect:
                    if isinstance(self.by_effect.initiator, Player):
                        return self.by_effect.initiator
                        return
            self.defeating_player = get_defeated_player()
            super().__init__(trigger=this, end_event=Message.AfterSchemeBeDefeated)
            text = TransText('{this} was defeated', this=this)
            self.Present(text, '', this, by_effect.this)
        def GetDefeatingPlayer(self) -> 'Player':
            if not (self.defeating_player):
                raise AssertionError
            return self.defeating_player
    class AfterSchemeBeDefeated(TriggerSchemeMessage, HasPreEventMessage):
        def __init__(self, this: 'Scheme2', by_effect: 'Effect', message: 'Message.WhenSchemeBeDefeated'):
            self.killer = by_effect.this
            super().__init__(trigger=this, pre_message=message)
            text = TransText('{this} was defeated', this=this)
            self.Present(text, '', this, by_effect.this)
    class AfterUnitDefeatedScheme(TriggerFaceMessage, ThwarterMessage):
        def __init__(self, killer: 'CardFace', scheme: 'Scheme2', by_effect: 'Effect'):
            self.killer = killer
            self.scheme = scheme
            self.by_effect = by_effect
            super().__init__(trigger=killer, thwarter=killer, thwarted=[scheme])
            self.AddRelatedFace(killer, scheme, by_effect)
