# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderDeck:
    class WhenDeckCreated_Text(TextMessage):
        def __init__(self, deck: 'Deck'):
            super().__init__(world=deck.world)
            text = TransText('{deck} was created', deck=deck)
            if deck.GetSize():
                UNKNOWN(UNKNOWN, 'set')
                return
            self.Present(text, '')
    class AfterCardMovedToDeck_Text(TextMessage):
        def __init__(self, deck, faces, pos, effect):
            super().__init__(world=deck.world)
            text = TransText('{faces} were moved to {deck} {pos} ({effect})', faces=faces, deck=deck, pos=pos, effect=effect.this)
            self.Present(*tuple([text, 'set', *faces]))
    class CardsShuffleToDeck_Text(TextMessage):
        def __init__(self, faces, deck):
            super().__init__(world=deck.world)
            text = TransText('{faces} are being shuffled into {deck}', deck=deck, faces=faces)
            self.Present(text, '')
    class AfterDeckShuffle(DeckMessage):
        def __init__(self, deck: 'Deck', discard_pile: 'Deck|None'):
            self.discards = discard_pile
            super().__init__(deck=deck)
            if discard_pile:
                text = TransText('{deck} was shuffled with {discard_pile}', deck=deck, discard_pile=discard_pile)
            else:
                text = TransText('{deck} was shuffled', deck=deck)
            self.Present(text, 'shuffle')
    class AfterDeckRunOut(DeckMessage):
        def __init__(self, deck: 'Deck'):
            super().__init__(deck=deck)
            if deck.flags.is_deck:
                if not (deck.flags.is_discards):
                    text = TransText('{deck} has run out', deck=deck)
                    self.Present(text, '')
                    return
                    return
    class AfterDeckReset(DeckMessage):
        def __init__(self, deck: 'Deck'):
            super().__init__(deck=deck)
            if deck.flags.is_deck:
                if not (deck.flags.is_discards):
                    text = TransText('{deck} has been reset', deck=deck)
                    self.Present(text, '')
                    return
                    return
