# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card import *
from game.card.face import *
from game.deck import *
from game.ability import *
from game.message import *
from game.world import *
from game.player import *
from game.world.game_area import *
from engine.lib import TransText
from game.message.message_type import TextMessage
from game.message.message_type import TriggerPlayerMessage
from game.message.message_type import TriggerFaceMessage
from game.message.message_type import TriggerUnitMessage
from game.message.message_type import TriggerSchemeMessage
from game.message.message_type import CalculateMessage
from game.message.message_type import CheckIfMessage
from game.message.message_type import GettingMessage
from game.message.message_type import CanBeInstead
Unused(TextMessage, TriggerPlayerMessage, TriggerFaceMessage, TriggerUnitMessage, TriggerSchemeMessage, CalculateMessage, CheckIfMessage, CanBeInstead, GettingMessage)
from game.message.sender.sender_player import SenderPlayer
from game.message.sender.sender_round import SenderRound
from game.message.sender.sender_card import SenderCard
from game.message.sender.sender_token import SenderTokenCounter
from game.message.sender.sender_deck import SenderDeck
from game.message.sender.sender_scheme import SenderScheme
from game.message.sender.sender_enemy import SenderEnemy
from game.message.sender.sender_unit import SenderUnit
from game.message.sender.sender_friend import SenderFriend
from game.message.sender.sender_damage import SenderDamage
from game.message.sender.sender_effect import SenderEffect
from game.message.sender.sender_environment import SenderEnvironment
CATEGORY_NAME = 'SENDER'
class Message(SenderRound, SenderPlayer, SenderCard, SenderTokenCounter, SenderDeck, SenderScheme, SenderEnemy, SenderUnit, SenderFriend, SenderDamage, SenderEffect, SenderEnvironment):
    class TextLog(TextMessage):
        def __init__(self, text):
            from engine.log import Log
            from game.test import Test
            if not (Test.IsInTesting()):
                Log.PrintGameInfo(text, sound_name='')
                return
    class TextRender(TextMessage):
        def __init__(self, origin_text, world):
            from game.test import Test
            super().__init__(world=world)
            if not (Test.IsInTesting()):
                text = TransText(origin_text)
                self.Present(text, '')
    class WhenMessageBeInstead(Message2):
        def __init__(self, message: Message2, by_effect: 'Effect'):
            self.message = message
            self.by_effect = by_effect
            faces = [by_effect.this]
            if isinstance(message, TriggerMessage):
                faces.append(message.trigger)
            super().__init__(world=by_effect.world)
            text = TransText('{message} is instead by {by_effect}', message=message.GetDisplayName(), by_effect=by_effect.this)
            self.Present(*tuple([text, 'activate', *faces]))
    class CheckIfUnitCanBeAttackBy(CheckIfMessage):
        def __init__(self, attacked: 'Unit2', effect: 'Effect'):
            from game.card.face.base import Unit2
            from game.card.face.card_type import Event
            from game.card.face.card_type import Support
            from game.card.face.card_type import Upgrade
            self.can_be_attack = True
            this = effect.this
            attacker = this
            if Unit2.IsType(this):
                attacker = this
            else:
                if Event.IsType(this):
                    attacker = this.GetControlByOrOwner().GetRoleCharacter()
                else:
                    if Upgrade.IsType(this):
                        attacker = this.GetBindFace()
                    else:
                        if Support.IsType(this):
                            attacker = this
                        else:
                            attacker = this
            self.attacker = attacker
            self.being_attack = attacked
            self.by_effect = effect
            super().__init__(effect.this)
            self.AddRelatedFace(attacker, attacked, effect)
        def SetCannotBeAttack(self, by_effect: 'Effect'):
            self.can_be_attack = False
            self.SetCauseBy(by_effect)
    class CheckIfSchemeCanBeThwartBy(CheckIfMessage):
        def __init__(self, scheme: 'Scheme2', effect: 'Effect'):
            from game.card.face.base import Unit2
            from game.card.face.card_type import Event
            from game.card.face.card_type import Support
            from game.card.face.card_type import Upgrade
            self.can_be_thwart = True
            this = effect.this
            who_thwart = this
            if Unit2.IsType(this):
                who_thwart = this
            else:
                if Event.IsType(this):
                    who_thwart = this.GetControlByOrOwner().GetRoleCharacter()
                else:
                    if Upgrade.IsType(this):
                        who_thwart = this.GetBindFace()
                    else:
                        if Support.IsType(this):
                            who_thwart = this
                        else:
                            who_thwart = this
            self.who_thwart = who_thwart
            self.scheme = scheme
            self.by_effect = effect
            super().__init__(effect.this)
            self.AddRelatedFace(scheme, who_thwart, effect)
        def SetCannotBeThwart(self, by_effect: 'Effect'):
            self.can_be_thwart = False
            self.SetCauseBy(by_effect)
    class CheckIfUnitCanDefendAgainstAttack(CheckIfMessage):
        def __init__(self, unit: 'Ally|Hero', attacker: 'Unit2'):
            self.can_defend = True
            self.friend = unit
            self.attacker = attacker
            self.check_unit = unit
            super().__init__(unit)
            self.AddRelatedFace(attacker, unit)
        def SetCannotDefend(self, by_effect: 'Effect'):
            self.can_defend = False
            self.SetCauseBy(by_effect)
    class CheckIfUnitCanAttack(CheckIfMessage):
        def __init__(self, unit: 'Unit2', effect: 'Effect'):
            self.can_attack = True
            self.by_effect = effect
            self.check_unit = unit
            super().__init__(unit)
        def SetCannotAttack(self, by_effect: 'Effect'):
            self.can_attack = False
            self.SetCauseBy(by_effect)
    class CheckIfUnitCanThwart(CheckIfMessage):
        def __init__(self, unit: 'Unit2', effect: 'Effect'):
            self.can_thwart = True
            self.by_effect = effect
            self.check_unit = unit
            super().__init__(unit)
        def SetCannotThwart(self, by_effect: 'Effect'):
            self.can_thwart = False
            self.SetCauseBy(by_effect)
    class CheckIfUnitCanRecover(CheckIfMessage):
        def __init__(self, unit: 'AlterEgo', effect: 'Effect'):
            self.can_recover = True
            self.by_effect = effect
            self.check_identity = unit
            super().__init__(unit)
        def SetCannotRecover(self, by_effect: 'Effect'):
            self.can_recover = False
            self.SetCauseBy(by_effect)
    class CheckIfFaceCanAttachTo(CheckIfMessage):
        def __init__(self, which_face: 'CardFace', to_face: 'CardFace', effect: 'Effect'):
            self.can_attach_to = True
            self.to_face = to_face
            self.upgrade = which_face
            super().__init__(effect.this)
        def SetCannotAttachTo(self, by_effect: 'Effect'):
            self.can_attach_to = False
            self.SetCauseBy(by_effect)
    class CheckIfFaceApplyUniqueRule(CheckIfMessage):
        def __init__(self, face: 'CardFace'):
            self.which_face = face
            self.apply_unique_rule = True
            super().__init__(face)
        def IgnoreUniqueRule(self, by_effect: 'Effect'):
            self.apply_unique_rule = False
    class CheckIfFaceIsLikeInHand(CheckIfMessage):
        def __init__(self, face: 'CardFace'):
            self.which_face = face
            self.is_like_in_hand = False
            super().__init__(face)
            self.AddRelatedFace(face)
        def SetIsLikeInHand(self, by_effect: 'Effect'):
            self.is_like_in_hand = True
    class CheckIfFaceCanBeReadied(CheckIfMessage):
        def __init__(self, face: 'CardFace', by_effect: 'Effect'):
            self.which_face = face
            self.is_can_be_readied = True
            self.by_effect = by_effect
            super().__init__(face)
            self.AddRelatedFace(face)
        def SetCannotBeReadied(self, by_effect: 'Effect'):
            self.is_can_be_readied = False
    class CheckIfRefersToTheVillainRefersToAttached(CheckIfMessage):
        def __init__(self, face: 'CardFace'):
            self.which_face = face
            self.refers_to = False
            super().__init__(face)
            self.AddRelatedFace(face)
        def SetRefersTo(self, by_effect: 'Effect'):
            self.refers_to = True
    class GettingMainScheme(GettingMessage):
        def __init__(self, game_area: GameArea, face: 'CardFace'):
            self.game_area = game_area
            self.by_face = face
            super().__init__(world=face.card.world)
        def SetReturn(self, val: 'MainScheme'):
            self.return_value = val
    class GettingScenario(GettingMessage):
        def __init__(self, game_area: GameArea|None, world: 'World'):
            self.game_area = game_area
            super().__init__(world=world)
        def SetReturn(self, val: 'Scenario'):
            self.return_value = val
    class GettingVillain(GettingMessage):
        def __init__(self, game_area: GameArea|None, world: 'World'):
            self.game_area = game_area
            super().__init__(world=world)
        def SetReturn(self, val: 'Villain'):
            self.return_value = val
    class GettingUnitAdditionalTough(TriggerUnitMessage, GettingMessage):
        def __init__(self, unit: 'Unit2'):
            super().__init__(trigger=unit)
        def SetReturn(self, val):
            self.return_value = val
    class CheckIfEffectIsIgnoreKeyWord(CheckIfMessage):
        def __init__(self, effect, keyword):
            self.effect = effect
            self.keyword = keyword
            self.is_ignore_this_keyword = False
            super().__init__(effect.this)
            self.AddRelatedFace(effect)
        def SetIgnore(self):
            self.is_ignore_this_keyword = True
    class WhenScenarioEvent(Message2):
        def __init__(self, text, *params, world):
            self.text = text
            self.params = params
            super().__init__(world=world)
    class CheckIfAttackMessageHasKeyword(CheckIfMessage, AttackerMessage):
        def __init__(self, check_attack: 'Message.WhenUnitWouldAttackUnit', by_effect: 'Effect'):
            self.check_attack = check_attack
            self.property = check_attack.property
            self.by_effect = by_effect
            super().__init__(attacker=check_attack.attacker, attacked=check_attack.attacked_targets, would_atk_message=check_attack.would_atk_message, by_face=by_effect.this)
            self.AddRelatedFace(self.attacker, by_effect)
        def GainRanged(self, by_effect: 'Effect'):
            if not (self.property.ranged):
                from game.message import Message
                self.property.ranged = True
                message = Message.WhenAttackGainKeyword('ranged', by_effect, self)
                message.Send()
                return
        def GainOverKill(self, by_effect: 'Effect'):
            if not (self.property.overkill):
                from game.message import Message
                self.property.overkill = True
                message = Message.WhenAttackGainKeyword('overkill', by_effect, self)
                message.Send()
                return
        def GainPiercing(self, by_effect: 'Effect'):
            if not (self.property.piercing):
                from game.message import Message
                self.property.piercing = True
                message = Message.WhenAttackGainKeyword('piercing', by_effect, self)
                message.Send()
                return
        def SetDealIndirectDamage(self, by_effect: 'Effect'):
            if not (self.property.deal_indirect_damage):
                self.property.deal_indirect_damage = True
                return
        def SetIgnoreRetaliate(self, by_effect: 'Effect'):
            if not (self.property.ignore_retaliate):
                self.property.ignore_retaliate = True
                return
        def SetLostPiercing(self, by_effect: 'Effect'):
            if not (self.property.lost_piercing):
                self.property.lost_piercing = True
                return
        def IsBasicAttack(self):
            return self.check_attack.would_atk_message.IsBasicAttack()
    class AfterCardsGenerated_Text(TextMessage):
        def __init__(self, card: 'Card'):
            super().__init__(world=card.world)
            faces = [card.face]
            text = TransText('{faces} created', faces=faces)
            self.Present(*tuple([text, 'set', *faces]))
