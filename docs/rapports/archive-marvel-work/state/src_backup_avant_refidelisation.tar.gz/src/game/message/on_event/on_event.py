# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from typing import TypeAlias
from core import *
from game.card.face import *
from game.card.card_finder import *
from game.message import *
from game.ability import *
from game.deck.deck_type import DeckType
from game.ability.condition import Condition
CardTypeMin = Condition.CARD_TYPE_MIN
CardType = Condition.CARD_TYPE
TM2 = TypeVar('TM2', bound='TriggerMessage', covariant=True)
class OnEvent:
    class Base(metaclass=ClassNameMeta):
        def GenerateAbilities(self, ability_type, condition, operation):
            if (self != OnEvent.NONE):
                raise AssertionError
            return []
        @final
        def GenerateAbilities2(self, ability_type, condition, operation):
            abilities = self.GenerateAbilities(ability_type, condition, operation)
            for ability in abilities:
                ability.on_event = self
            return abilities
        def __repr__(self):
            return str(self.__class__)
    class GameArea(Base):
        pass
    class EnterPlayWhen(Base):
        def __init__(self, which_card):
            self.which_card = which_card
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            return [Ability(ability_type, Message.WhenCardEnterPlay, [lambda effect, message: Condition.CheckWhichCard(self.which_card, message.trigger, effect), condition], operation)]
    class EnterPlayAfter(Base):
        def __init__(self, which_card):
            self.which_card = which_card
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            return [Ability(ability_type, Message.AfterCardEnterPlay, [lambda effect, message: Condition.CheckWhichCard(self.which_card, message.trigger, effect), condition], operation)]
    class LeavePlayWhen(Base):
        pass
    class LeavePlayAfter(Base):
        def __init__(self, which_card):
            self.which_card = which_card
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            return [Ability(ability_type, Message.AfterCardLeavePlay, [lambda effect, message: Condition.CheckWhichCard(self.which_card, message.trigger, effect), condition], operation)]
    class CardInPlay(GameArea):
        def __init__(self, which_card):
            self.which_card = which_card
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            def check_cards(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            def check_card_in_play(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            def check_card_move(effect, message):
                face = message.IsIncludeFace(self.which_card, effect)
                if not (face):
                    return False
                from_area = message.face_areas[face]
                into_area = face.card.area
                if from_area.flags.is_in_play:
                    pass
                return ((not from_area.flags.is_in_play) and into_area.flags.is_in_play)
            return [Ability(ability_type, Message.AfterCardsMoved, [check_card_move, condition], operation), Ability(ability_type, (Message.WhenCardLeavePlay | Message.WhenCardEnterPlay), [check_card_in_play, condition], operation), Ability(ability_type, Message.GameAreaAddCard, [check_cards, condition], operation)]
    EngagedPlayer = CardInPlay
    class PlayAreaCard(GameArea):
        def __init__(self, which_card):
            self.which_card = which_card
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            from game.selector import Select
            def check_cards_move(effect, message):
                found_face = None
                if (self.which_card == 'YouControlCards'):
                    player = Select.GetYouSafe(effect)
                    for face in message.faces:
                        if not ((message.face_areas[face].GetOwner() == player)):
                            if (face.card.area.GetOwner() == player):
                                found_face = face
                            else:
                                pass
                        found_face = face
                else:
                    found_face = message.IsIncludeFace(self.which_card, effect)
                if not (found_face):
                    return False
                from_area = message.face_areas[found_face]
                into_area = found_face.card.area
                if from_area.flags.is_in_play:
                    if into_area.flags.is_in_play:
                        if not (from_area.flags.is_in_play):
                            if into_area.flags.is_in_play:
                                return True
                if not (from_area.flags.is_in_play):
                    if into_area.flags.is_in_play:
                        return True
                if not ((from_area.play_area != into_area.play_area)):
                    if (from_area.bind_owner != into_area.bind_owner):
                        if not (from_area.flags.is_in_play):
                            if into_area.flags.is_in_play:
                                return True
                        return True
                if not (from_area.flags.is_in_play):
                    if into_area.flags.is_in_play:
                        return True
                return True
                return False
            def check_cards(effect, message):
                trigger = message.trigger
                if (self.which_card == 'YouControlCards'):
                    return (Select.GetYouSafe(effect) == trigger.GetControlBy())
                return Condition.CheckWhichCard(self.which_card, trigger, effect)
            return [Ability(ability_type, Message.AfterCardsMoved, [check_cards_move, condition], operation), Ability(ability_type, Message.GameAreaAddCard, [check_cards, condition], operation)]
    class CardType(CardInPlay):
        def __init__(self, which_card):
            self.which_card = which_card
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            def check_cards(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            def check_card_in_play(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            def check_card_move(effect, message):
                face = message.IsIncludeFace(self.which_card, effect)
                if not (face):
                    return False
                return True
            return [Ability(ability_type, Message.AfterCardsMoved, [check_card_move, condition], operation), Ability(ability_type, (Message.WhenCardLeavePlay | Message.WhenCardEnterPlay), [check_card_in_play, condition], operation), Ability(ability_type, Message.GameAreaAddCard, [check_cards, condition], operation)]
    NONE = Base()
    class AssetEffect(Base):
        def __init__(self):
            pass
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            return [Ability(ability_type, Message.AfterCardGainUpgradeAbility, [lambda effect, message: ((effect.this == message.upgrade) and Condition.CheckWhichCard('AttachedCard', message.trigger, effect)), condition], operation), Ability(ability_type, Message.AfterCardLostUpgradeAbility, [lambda effect, message: ((effect.this == message.upgrade) and Condition.CheckWhichCard('AttachedCard', message.trigger, effect)), condition], operation)]
    class TemplateCardArea(Base):
        def __init__(self, deck_type, condition):
            self.deck_type = deck_type
            self.condition = condition
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            def check_which_area(effect, message):
                return message.IsDeckTypeRelated(self.deck_type)
            def check_which_area2(effect, message):
                return (message.deck.deck_type == self.deck_type)
            return [Ability(ability_type, Message.AfterCardsMoved, [check_which_area, self.condition, condition], operation), Ability(ability_type, Message.AfterDeckShuffle, [check_which_area2, condition], operation)]
    class Victory(TemplateCardArea):
        def __init__(self, which_card):
            def check_which_card(effect, message):
                for face in message.faces:
                    if Condition.CheckWhichCard(which_card, face, effect):
                        return True
                return False
            super().__init__(DeckType.VictoryDisplay, check_which_card)
    class HandCards(TemplateCardArea):
        def __init__(self, which_player):
            def check(effect, message):
                from game.selector import Select
                return (Select.GetYou(effect).hand_cards in message.related_decks)
            super().__init__(DeckType.HandsArea, check)
    class TuckUnder(TemplateCardArea):
        def __init__(self, under_where):
            def check_under_here(effect, message):
                if (under_where == 'Here'):
                    area = effect.this.GetPlacedCardArea()
                    return (area in message.related_decks)
                return True
            super().__init__(DeckType.PlaceCardArea, check_under_here)
    class PlacedCard(TuckUnder):
        pass
    class DealtEncounterCard(TemplateCardArea):
        def __init__(self, dealt_to_who):
            def check_under_here(effect, message):
                area = effect.this.GetControlByPlayer().dealt_encounter_cards
                return (area in message.related_decks)
            super().__init__(DeckType.DealtEncounterCardsDeck, check_under_here)
    class DeckTopCard(TemplateCardArea):
        def __init__(self, from_where):
            from game.selector import Select
            def check(effect, message):
                player_deck = Select.GetYou(effect).player_deck
                return (player_deck in message.related_decks)
            super().__init__(DeckType.PlayerDeck, check)
    class TemplateTriggerInPlay(GameArea):
        def __init__(self, when, which_card, *conditions):
            self.which_card = which_card
            self.when = when
            self.conditions = conditions
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            def check_game_area(effect, message):
                if (self.which_card == None):
                    return True
                if Condition.CheckWhichCard(self.which_card, message.trigger, effect):
                    return True
                if Condition.CheckWhichCard('This', message.trigger, effect):
                    return True
                return False
            return [Ability(ability_type, self.when, [*self.conditions, condition], operation), Ability(ability_type, Message.GameAreaAddCard, [check_game_area, condition], operation), Ability(ability_type, (Message.AfterCardLeavePlay | Message.AfterCardEnterPlay), [check_game_area, condition], operation)]
    class AccelerationToken(TemplateTriggerInPlay):
        MESSAGE_TYPE = (Message.AfterCardPlacedToken | Message.AfterCardRemovedToken)
        def __init__(self, which_card):
            def check_token_name(effect, message):
                return (message.token_name == 'acceleration_token')
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(which_card, message.trigger, effect)
            super().__init__(OnEvent.AccelerationToken.MESSAGE_TYPE, which_card, check_token_name, check_which_card)
    class CardKeyword(TemplateTriggerInPlay):
        MESSAGE_TYPE = Message.WhenCardKeywordUpdated
        def __init__(self, which_card):
            def check_keywords(effect, message):
                return (message.keyword in ('ATK', 'THW', 'SCH'))
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(which_card, message.trigger, effect)
            super().__init__(OnEvent.CardKeyword.MESSAGE_TYPE, which_card, check_keywords, check_which_card)
    class Icons(TemplateTriggerInPlay):
        MESSAGE_TYPE = Message.WhenCardKeywordUpdated
        def __init__(self, where):
            def check_icon(effect, message):
                return (message.keyword in ('Hazard', 'Crisis', 'Acceleration', 'Amplify'))
            def check_which_area(effect, message):
                return message.trigger.IsInPlay()
            super().__init__(OnEvent.Icons.MESSAGE_TYPE, None, check_icon, check_which_area)
    class TemplateTrigger(Base):
        def __init__(self, when, *conditions):
            self.when = when
            self.conditions = conditions
        @override
        def GenerateAbilities(self, ability_type, condition, operation):
            from game.ability import Ability
            return [Ability(ability_type, self.when, [*self.conditions, condition], operation)]
    class MainSchemeStage(TemplateTrigger):
        def __init__(self, scheme):
            MESSAGE_TYPE = Message.AfterMainSchemeAdvanced
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(scheme, message.scheme, effect)
            super().__init__(MESSAGE_TYPE, check_which_card)
    class Reveal(TemplateTrigger):
        def __init__(self, face):
            MESSAGE_TYPE = Message.WhenPlayerRevealCard
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(face, message.trigger, effect)
            super().__init__(MESSAGE_TYPE, check_which_card)
    class Health(TemplateTrigger):
        MESSAGE_TYPE = (((Message.AfterUnitHealHealth | Message.AfterUnitLossHealth) | Message.AfterUnitHitPointReset) | Message.AfterUnitHitPointSet)
        def __init__(self, which_card):
            self.which_card = which_card
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            super().__init__(OnEvent.Health.MESSAGE_TYPE, check_which_card)
    class Counter(TemplateTrigger):
        MESSAGE_TYPE = (Message.AfterCardPlacedCounter | Message.AfterCardRemovedCounter)
        def __init__(self, which_card, counter_name):
            self.which_card = which_card
            self.counter_name = counter_name
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            super().__init__(OnEvent.Counter.MESSAGE_TYPE, check_which_card)
    class Trait(TemplateTrigger):
        MESSAGE_TYPE = (((Message.AfterCardGainTrait | Message.AfterCardLoseTrait) | Message.AfterCardLeavePlay) | Message.AfterCardEnterPlay)
        def __init__(self, which_card):
            from game.selector import Select
            self.which_card = which_card
            def check_which_card(effect, message):
                if (self.which_card == 'YouControlCharacter'):
                    trigger = message.trigger
                    return (Select.GetYou(effect) == trigger.GetControlBy())
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            super().__init__(OnEvent.Trait.MESSAGE_TYPE, check_which_card)
    class Threat(TemplateTrigger):
        MESSAGE_TYPE = (((Message.AfterSchemePlaceThreat | Message.AfterSchemeRemoveThreat) | Message.AfterCardLeavePlay) | Message.AfterCardEnterPlay)
        def __init__(self, which_card):
            self.which_card = which_card
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            super().__init__(OnEvent.Threat.MESSAGE_TYPE, check_which_card)
    class Status(TemplateTrigger):
        __annotations__ = {}
        MESSAGE_TYPE = (Message.AfterStatusCardPlaceOn | Message.AfterStatusDiscardFrom)
        MESSAGE_TYPE: TypeAlias
        def __init__(self, which_card, which_status):
            self.which_card = which_card
            self.which_status = which_status
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            def check_which_status(effect, message):
                return (self.which_status == message.status.name)
            super().__init__(OnEvent.Status.MESSAGE_TYPE, check_which_card, check_which_status)
    class Faceup(TemplateTrigger):
        MESSAGE_TYPE = Message.AfterCardFlip
        def __init__(self, which_card):
            self.which_card = which_card
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            super().__init__(OnEvent.Faceup.MESSAGE_TYPE, check_which_card)
    class Form(TemplateTrigger):
        MESSAGE_TYPE = ((Message.AfterUnitChangeForm | Message.AfterCardLeavePlay) | Message.AfterCardEnterPlay)
        def __init__(self, which_card):
            from game.card.face.card_type import Upgrade
            self.which_card = which_card
            def check_which_card(effect, message):
                return (Condition.CheckWhichCard(self.which_card, message.trigger, effect) or (isinstance(message.trigger, Upgrade) and (message.trigger.form != None)))
            super().__init__(OnEvent.Form.MESSAGE_TYPE, check_which_card)
    class AttachedMove(TemplateTrigger):
        MESSAGE_TYPE = (Message.AfterCardAttachTo | Message.AfterCardDetachFrom)
        def __init__(self, which_card):
            self.which_card = which_card
            def check_which_card(effect, message):
                return Condition.CheckWhichCard(self.which_card, message.trigger, effect)
            super().__init__(OnEvent.AttachedMove.MESSAGE_TYPE, check_which_card)
