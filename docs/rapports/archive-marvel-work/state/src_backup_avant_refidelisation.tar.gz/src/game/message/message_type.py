# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.card.face import *
from game.deck import *
from game.effect import *
from game.message import *
from game.world import *
from game.player import *
class WorldKwargs(TypedDict):
    __annotations__ = {}
    world: 'World'
class NoSendMessage(Message2):
    @override
    def Send(self):
        pass
class LikeFakeMessage(Message2):
    pass
class TextMessage(NoSendMessage, Message2):
    def __init__(self, **kwargs):
        super().__init__(*(), **{'send_resolve_message': False, **kwargs})
class NoSendResolve(Message2):
    def __init__(self, **kwargs):
        super().__init__(*(), **{'send_resolve_message': False, **kwargs})
class TriggerNonePlayerMessage(Message2):
    def __init__(self, player, **kwargs):
        self.to_player = player
        super().__init__(*(), **{**kwargs})
    def GetToPlayer(self) -> 'Player':
        from game.player import Player
        if not ((type(self.to_player) is Player)):
            raise AssertionError
        return self.to_player
    def IsToPlayer(self):
        from game.player import Player
        return (type(self.to_player) is Player)
class TriggerPlayerMessage(TriggerNonePlayerMessage):
    def __init__(self, player, **kwargs):
        kwargs.pop('world', None)
        super().__init__(*(), **{'player': player, 'world': player.world, **kwargs})
class TriggerMessage(Message2):
    def __init__(self, trigger, type, **kwargs):
        self.private_trigger = trigger
        kwargs.pop('world', None)
        super().__init__(*(), **{**kwargs, **{'world': self.private_trigger.card.world}})
        self.AddRelatedFace(trigger)
    @property
    def trigger(self) -> 'CardFace':
        return self.private_trigger
class TriggerFaceMessage(TriggerMessage):
    def __init__(self, trigger, **kwargs):
        from game.card.face.card_face import CardFace
        super().__init__(*(trigger, CardFace), **{**kwargs})
class TriggerUnitMessage(TriggerMessage):
    def __init__(self, trigger, **kwargs):
        from game.card.face.base import Unit2
        super().__init__(*(trigger, Unit2), **{**kwargs})
    @property
    def trigger(self) -> 'Unit2':
        from game.card.face.base import Unit2
        if not (Unit2.IsType(self.private_trigger)):
            raise AssertionError
        return self.private_trigger
class TriggerSchemeMessage(TriggerMessage):
    def __init__(self, trigger, **kwargs):
        from game.card.face.base import Scheme2
        super().__init__(*(trigger, Scheme2), **{**kwargs})
    @property
    def trigger(self) -> 'Scheme2':
        from game.card.face.base import Scheme2
        if not (Scheme2.IsType(self.private_trigger)):
            raise AssertionError
        return self.private_trigger
class TargetsMessage(Message2):
    def __init__(self, targets, **kwargs):
        self.targets_internal = list(targets)
        super().__init__(*(), **{**kwargs})
        self.AddRelatedFace(*targets)
    @property
    def targets(self):
        return self.targets_internal
    def AddTarget(self, *face: 'CardFace'):
        self.targets_internal = (self.targets_internal + list(face))
    def ReplaceTarget(self, *face: 'CardFace'):
        self.targets_internal = list(face)
class AttackMessage(Message2):
    def __init__(self, would_atk_message, **kwargs):
        if (would_atk_message == None):
            would_atk_messages = []
        else:
            if isinstance(would_atk_message, list):
                would_atk_messages = would_atk_message
            else:
                would_atk_messages = [would_atk_message]
        self.would_atk_messages = would_atk_messages
        super().__init__(*(), **{**kwargs})
    @property
    def has_resolves_defense_labeled_ability(self):
        for would_atk_message in self.would_atk_messages:
            if would_atk_message.has_resolves_defense_labeled_ability_internal:
                would_atk_message.has_resolves_defense_labeled_ability_internal
                return
class AttackerMessageInternal(TargetsMessage, AttackMessage):
    def __init__(self, attacker, attacked, **kwargs):
        self.attacker_internal = attacker
        super().__init__(*(), **{'targets': attacked, **kwargs})
        self.AddRelatedFace(self.attacker)
    @property
    def attacker(self) -> 'Unit2|None':
        return self.attacker_internal
    @property
    def attacked_targets(self):
        from game.operate.filter import Filter
        from game.card.face.base import Unit2
        return Filter.ByType(self.targets, Unit2)
class AttackerNoneMessage(AttackerMessageInternal):
    def __init__(self, being_atk_message, attacker = None, **kwargs):
        if not (attacker):
            pass
        self.being_atk_message = being_atk_message
        super().__init__(*(), **{'attacker': attacker, 'attacked': ([being_atk_message.trigger] if being_atk_message else []), **kwargs, **{'would_atk_message': (being_atk_message.would_atk_message if being_atk_message else None)}})
class AttackerNoneOldMessage(AttackerMessageInternal):
    def __init__(self, attacker, would_atk_message, **kwargs):
        super().__init__(*(), **{'attacker': attacker, 'would_atk_message': would_atk_message, **kwargs})
class AttackerMessage(AttackerMessageInternal):
    def __init__(self, attacker, attacked, would_atk_message, **kwargs):
        kwargs.pop('world', None)
        super().__init__(*(), **{'attacker': attacker, 'attacked': attacked, 'world': attacker.card.world, 'would_atk_message': would_atk_message, **kwargs})
    @property
    def attacker(self) -> 'Unit2':
        if not (self.attacker_internal):
            raise AssertionError
        return self.attacker_internal
class SchemerMessage(Message2):
    def __init__(self, schemer, **kwargs):
        self.schemer = schemer
        super().__init__(*(), **{**kwargs})
class ThwarterMessage(TargetsMessage):
    def __init__(self, thwarter, thwarted, **kwargs):
        self.thwarter = thwarter
        super().__init__(*(), **{'targets': thwarted, **kwargs})
    @property
    def thwarted_targets(self):
        from game.operate.filter import Filter
        from game.card.face.base import Scheme2
        return Filter.ByType(self.targets, Scheme2)
class DefenderNoneMessage(Message2):
    def __init__(self, defender, **kwargs):
        self.defender_internal = defender
        super().__init__(*(), **{**kwargs})
        self.AddRelatedFace(defender)
    @property
    def defender(self) -> 'Unit2|None':
        return self.defender_internal
class DefenderMessage(DefenderNoneMessage):
    def __init__(self, defender, **kwargs):
        super().__init__(*(defender,), **{**kwargs})
    @property
    def defender(self) -> 'Unit2':
        if not (self.defender_internal):
            raise AssertionError
        return self.defender_internal
class DamageMessage(Message2):
    def __init__(self, damage, **kwargs):
        self.damage_internal = damage
        super().__init__(*(), **{**kwargs})
    @property
    def will_take_damage(self):
        if not ((self.damage_internal != None)):
            raise AssertionError
        return self.damage_internal
    def UpdateDamageInternal(self, value):
        if not ((self.damage_internal != None)):
            raise AssertionError
        self.damage_internal = (self.damage_internal + value)
class CalculateMessage(NoSendResolve):
    def __init__(self, **kwargs):
        super().__init__(*(), **{**kwargs})
class CheckNoneMessage(NoSendResolve):
    def __init__(self, by_face, **kwargs):
        self.cause_by = []
        self.private_by_face = by_face
        super().__init__(*(), **{**kwargs})
        if (self.cause_by != []):
            if self.private_by_face:
                self.private_by_face.card.ui.unavailable.Add(*self.cause_by)
                return
                return
    def SetCauseBy(self, by_effect: 'Effect'):
        self.cause_by.append(by_effect)
class CheckIfMessage(CheckNoneMessage):
    def __init__(self, by_face, **kwargs):
        kwargs.pop('world', None)
        super().__init__(*(), **{'by_face': by_face, 'world': by_face.card.world, **kwargs})
        self.AddRelatedFace(by_face)
class GettingMessage(NoSendResolve):
    def __init__(self, **kwargs):
        self.return_value = None
        super().__init__(*(), **{**kwargs})
    def SetReturn(self, val):
        raise AssertionError(f'You need to override this function, self={self!r}')
class CanBeInstead(Message2):
    def __init__(self, **kwargs):
        self.be_instead_internal = False
        super().__init__(*(), **{**kwargs})
    def SilentInstead(self):
        if not (self.world.is_initializing):
            self.be_instead_internal = True
            return
    def SetBeInstead(self, by_effect: 'Effect'):
        from game.message import Message
        message = Message.WhenMessageBeInstead(self, by_effect)
        message.Send()
        self.SilentInstead()
    @property
    def is_be_instead(self):
        return self.be_instead_internal
class HasPreEventMessage(Message2):
    def __init__(self, pre_message, **kwargs):
        self.pre_message = pre_message
        pre_message.next_message = self
        kwargs.pop('world', None)
        super().__init__(*(), **{**kwargs, **{'world': pre_message.world}})
        if not (isinstance(self, pre_message.CastTo(HasEndEventMessage).end_event)):
            raise AssertionError
TMH = TypeVar('TMH', bound='HasPreEventMessage')
class HasEndEventMessage(Message2):
    def __init__(self, end_event, **kwargs):
        self
        self.end_event = end_event
        super().__init__(*(), **{**kwargs})
class DeckMessage(Message2):
    def __init__(self, deck: 'Deck'):
        self.deck = deck
        super().__init__(world=deck.world)
class CanGainValueMessage(Message2):
    def __init__(self, **kwargs):
        self.gain_atk = 0
        self.gain_thw = 0
        super().__init__(*(), **{**kwargs})
    def AddGainedATK(self, value):
        self.gain_atk = (self.gain_atk + value)
    def AddGainedTHW(self, value):
        self.gain_thw = (self.gain_thw + value)
class CardStateUpdatedMessage(TriggerFaceMessage):
    def __init__(self, trigger: 'CardFace'):
        self.updated_face = trigger
        super().__init__(trigger=trigger)
class InActivationMessage(Message2):
    def __init__(self, activate_message, **kwargs):
        self.activate_message = activate_message
        super().__init__(*(), **{**kwargs})
