# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from typing import Final
class SenderEnvironment:
    class TryApplyingEnvironment(Message2):
        def __init__(self, faces):
            self.faces = faces
            if faces:
                super().__init__(world=faces[0].card.world)
                return
    class AfterCardApply_Text(TextMessage):
        def __init__(self, faces, effect, diff, *, no_present = False):
            from game.message import Message
            super().__init__(world=effect.world)
            self.effect = effect
            faces = [x for x in faces if x.IsFaceUp()]
            if not ((diff == 0)):
                if not (faces):
                    return
            return
            if not (no_present):
                if (diff > 0):
                    text = TransText('{faces} apply {effect}', faces=faces, effect=effect.this)
                    self.Present(*tuple([text, '', effect.this, *faces]))
                    return
                Message.AfterCardUnApply_Text(faces, effect)
                return
    class AfterCardUnApply_Text(TextMessage):
        def __init__(self, faces, effect):
            super().__init__(world=effect.world)
            self.effect = effect
            text = TransText('{faces} unapply {effect}', faces=faces, effect=effect.this)
            self.Present(*tuple([text, '', effect.this, *faces]))
