# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing_extensions import NotRequired
from core import *
from game.card.face import *
from game.message import *
from game.effect import *
from game.world import *
from game.player import *
from game.object import Object
from engine.log import Log
from engine.lib import TransText
from game.ability.condition import *
CATEGORY_NAME = 'MESSAGE'
class Message2(Object):
    SOUND_NAMES = Literal[('', 'carddrop', 'activate', 'draw', 'damage', 'equip', 'set', 'negate', 'token', 'reveal', 'destroyed', 'flip', 'shuffle', 'addcounter', 'phase', 'nextturn', 'removecounter', 'gainlp', 'target', 'banished', 'directattack', 'cardpick')]
    class MessageKwargs(TypedDict):
        __annotations__ = {}
        world: 'World'
        send_resolve_message: NotRequired[bool]
    def __init__(self, **kwargs):
        from game.message.message_type import CheckNoneMessage
        world = kwargs.get('world', None)
        if not ((world != None)):
            raise AssertionError
        if isinstance(self, CheckNoneMessage):
            category = 'check_message'
        else:
            category = 'message'
        super().__init__(category, world)
        send_resolve_message = kwargs.get('send_resolve_message', True)
        self.once_per_event_effects = []
        self.send_resolve_message = send_resolve_message
        self.prompt = None
        self.related_faces = set()
        self.on_events = set()
        if (category == 'message'):
            Log.DebugSilent('MESSAGE', self)
            return
    def __repr__(self):
        return f'({self.object_id}) {self.name}'
    def AddRelatedFace(self, *faces: 'CardFace|Player|Effect|None'):
        from game.card.face.card_face import CardFace
        from game.effect import Effect
        from game.player import Player
        for face in faces:
            if isinstance(face, Player):
                self.related_faces.add(face.GetIdentity())
            if isinstance(face, Effect):
                self.related_faces.add(face.this)
            if isinstance(face, CardFace):
                self.related_faces.add(face)
    def TriggerOnEvent(self, on_event):
        self.on_events.add(on_event)
    def Send(self):
        from game.message.message_type import CardStateUpdatedMessage
        from game.message.message_type import CheckNoneMessage
        if not (self.world.is_game_over):
            if isinstance(self, CardStateUpdatedMessage):
                self.world.event_manager.StackMessage(self)
                return
            # RECOVER_TODO SETUP_FINALLY arg=9 target=72
            self.world.event_manager.BroadcastMessage(self)
            # RECOVER_TODO JUMP_IF_NOT_EXC_MATCH arg=69 target=138
            Exception
            exc = UNKNOWN
            # RECOVER_TODO SETUP_FINALLY arg=22 target=130
            info = Log.OnCrash(CATEGORY_NAME, exc, self.name, None)
            self.world.render.ErrorOccurred(info)
            # RECOVER_TODO POP_EXCEPT arg=0 target=0
            exc = None
            del exc
        from game.message.sender.sender import CanBeInstead
        if isinstance(self, CanBeInstead):
            self.SilentInstead()
            return
    def GetDisplayName(self):
        return f'"{self.name}"'
    def CastTo(self, message):
        return Cast(message, self)
    @property
    def name(self):
        return type(self).__name__
    @final
    def GetReplayText(self):
        return f'm{self.object_id} {self.name}'
    @final
    def Present(self, origin_info: TransText|None, sound_name: 'Message2.SOUND_NAMES', *faces: 'CardFace'):
        if not (self.world.is_game_over):
            self.PresentInternal(*tuple([origin_info, sound_name, self.name, *faces]))
            return
    @final
    def Present_Activate(self, origin_info: TransText|None, effect: 'Effect'):
        if not (self.world.is_game_over):
            self.PresentInternal(origin_info, 'activate', 'EffectActivate_Text', effect.this)
            return
    @final
    def Present_PointTo(self, origin_info: TransText|None, sound_name: 'Message2.SOUND_NAMES', face: 'CardFace', *faces: 'CardFace'):
        if not (self.world.is_game_over):
            self.PresentInternal(*tuple([origin_info, sound_name, 'EffectActivateTo_Text', face, *faces]))
            return
    @final
    def Present_ByEffect(self, origin_info: TransText|None, sound_name: 'Message2.SOUND_NAMES', face: 'CardFace', effect: 'CardFace'):
        return self.Present_PointTo(origin_info, sound_name, effect, face)
    @final
    def PresentGameOver(self, origin_info, sound_name, name, *faces):
        was_skipping = False
        if self.world.controller_manager.skip.SetIsSkipping(False):
            was_skipping = True
        self.PresentInternal(*tuple([origin_info, sound_name, name, *faces]))
        if was_skipping:
            self.world.render.PresentForceNoWait()
            return
    @final
    def PresentInternal(self, origin_info, sound_name, name, *faces):
        code_info = ''
        if (origin_info == None):
            origin_info = TransText('')
        self.prompt = origin_info
        self.world.render.Present(*tuple([origin_info, sound_name, name, *faces]), **{'code_info': code_info})
