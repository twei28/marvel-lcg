# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.test import Test
from engine import Engine
from engine.log import Log
from engine.log import Notify
from engine.profile import Coverage
from engine.profile import Profile
from engine.file import FileManager
from game.world import World
from engine.config import ConfigVariables
CATEGORY_NAME = 'COMMAND'
class Cheat:
    @staticmethod
    def TryPreDebugExec(input_command, world):
        # RECOVER_TODO SETUP_FINALLY arg=7 target=16
        return Cheat.PreDebugExec(input_command, world)
        # RECOVER_TODO JUMP_IF_NOT_EXC_MATCH arg=47 target=94
        Exception
        exc = UNKNOWN
        # RECOVER_TODO SETUP_FINALLY arg=28 target=86
        info = Log.FailedTrace(CATEGORY_NAME, exc)
        if world:
            world.render.ErrorOccurred(info)
            # RECOVER_TODO POP_EXCEPT arg=0 target=0
            exc = None
            del exc
            return False
        # RECOVER_TODO POP_EXCEPT arg=0 target=0
        exc = None
        del exc
        return False
        exc = None
        del exc
        # RECOVER_TODO RERAISE arg=1 target=1
        # RECOVER_TODO RERAISE arg=0 target=0
    @staticmethod
    def PreDebugExec(input_command, world):
        import re
        game = Engine.game
        def try_skip_to(step):
            if (step == 0):
                game.session.SkipTo(game.controller_manager.replay.current_step_id)
                return
            if (game.controller_manager.skip.skip_to >= game.controller_manager.replay.current_step_id):
                step = (step + game.controller_manager.replay.current_step_id)
                game.session.SkipTo(step)
                return
            if (game.controller_manager.replay.current_step_id < step):
                game.session.SkipTo(step)
                return
            step = (game.controller_manager.replay.current_step_id - step)
            game.session.Undo(step)
        command = input_command
        if not (command.startswith('/')):
            if FileManager.IsDrivePath(command):
                game.session.Load(command, None, 'Load')
                return True
            if not (command.startswith('debug')):
                if not (command.startswith('crash')):
                    if not (command.startswith('save')):
                        if not (command.startswith('./')):
                            if not (command.startswith('.\\')):
                                if not (command.endswith('.json')):
                                    if not (re.match('^\\[\\d+\\.\\d+\\.\\d+', command)):
                                        if re.match('.*\\.json\\:\\d+$', command):
                                            game.session.Load(command, None, 'Load')
                                            return True
            game.session.Load(command, None, 'Load')
            return True
            if command.isdigit():
                step = int(command)
                try_skip_to(step)
                return True
            if (command[0] == '-'):
                if command[1:].isdigit():
                    step = int(command[1:])
                    game.session.Undo(step)
                    return True
        def do_test(args = ''):
            if (args != ''):
                if (':' in args):
                    load_id = 0
                    category = None
                    skip_to = 0
                    splited_data = args.split(':')
                    if (len(splited_data) == 2):
                        if splited_data[0].isdigit():
                            load_id = int(splited_data[0])
                        else:
                            category = splited_data[0]
                        if splited_data[1].isdigit():
                            skip_to = int(splited_data[1])
                    else:
                        if (len(splited_data) == 3):
                            category = splited_data[0]
                            if splited_data[1].isdigit():
                                load_id = int(splited_data[1])
                            if splited_data[2].isdigit():
                                skip_to = int(splited_data[2])
            test_category = ''
            start_index = 0
            if (args == ''):
                pass
            else:
                if args.isdigit():
                    if (len(args) < 5):
                        start_index = int(args)
                    else:
                        test_category = args
                else:
                    test_category = args
            if world:
                world.game_over.SetExit()
            game.session.ExitWait()
            test_category = test_category.replace('?', '')
            Test.SetStart(start_index, test_category)
            game.controller_manager.replay.Clear()
            game.state.SetStartState('InTesting')
        def do_save(args = ''):
            name = game.scene.GetSaveFileName()
            if args:
                name = args
                ex_save_name = None
            else:
                name = None
                ex_save_name = './save.json'
            Engine.statistics.Save()
            if game.session.SaveScene(name=name, ex_save_name=ex_save_name, delete_old=False):
                return f'Save: {name}'
        def do_load(args):
            game.session.Load(args, None, 'Load')
        def do_restart(args = None):
            if (args != None):
                seed = int(args)
            else:
                seed = None
            game.Restart(seed)
        def do_comment(*args):
            game.scene.SetMetadataStr('comment', ' '.join(args))
            return f'Comment Update: {game.scene.comment}'
        def do_comment_by(args = '0'):
            index = int(args)
            return do_comment(game.scene.campaign.encounter_sets[index])
        def do_undo(args = '1'):
            if args:
                current_step_id = game.controller_manager.replay.current_step_id
                undo_count = (game.scene.step + [f'{current_step_id}_{args}'])
                game.scene.SetMetadataList('step', undo_count)
            step = 1
            if (args == 'auto'):
                last_step = game.controller_manager.undo.last_step
                if (last_step != 0):
                    try_skip_to(last_step)
                    return
            else:
                step = int(args)
            game.session.Undo(step)
        def do_goto(args):
            if args:
                current_step_id = game.controller_manager.replay.current_step_id
                goto_count = (game.scene.step + [f'{current_step_id}_{args}'])
                game.scene.SetMetadataList('step', goto_count)
            if (args == 'turn_begin'):
                try_skip_to(game.controller_manager.last_turn_start_step_id)
                return
            if (args == 'end'):
                step = len(game.controller_manager.replay.replay_inputs)
                game.session.SkipTo(step)
                return
            if args.isdigit():
                step = int(args)
                try_skip_to(step)
                return
        def do_step(args):
            step = int(args)
            if (game.controller_manager.skip.skip_to >= game.controller_manager.replay.current_step_id):
                step = (step + game.controller_manager.replay.current_step_id)
            game.session.StepTo(step)
        def do_skip(args):
            if (args == 'round'):
                game.session.SkipTo('Round')
                return
            if (args == 'turn'):
                game.session.SkipTo('Turn')
                return
            if (args == 'phase'):
                game.session.SkipTo('Phase')
                return
            step = int(args)
            try_skip_to(step)
        def do_update_replay(args):
            step = int(args)
            game.controller_manager.replay.UpdateReplayStepId(step)
        def do_coverage_report(args):
            text = ''
            if (args == ''):
                text = Coverage.Report()
                return text
            if (args == 'all'):
                text = Coverage.Report('All')
                return text
            if (args == 'uncall'):
                text = Coverage.Report('Uncall')
            return text
        def do_profile(name = 'Game', command = 'print'):
            ENABLE_PROFILE_CATEGORY = ConfigVariables.ListStr('enable_profile_category')
            if (name in ENABLE_PROFILE_CATEGORY.value):
                profiler = Profile.Get(name)
                text = ''
                if (command == 'print'):
                    text = profiler.Print()
                else:
                    if not ((command == 'start')):
                        if (command == 'enable'):
                            profiler.Start()
                        else:
                            if not ((command == 'end')):
                                if (command == 'disable'):
                                    profiler.End()
                            profiler.End()
                    profiler.Start()
                    if not ((command == 'end')):
                        if (command == 'disable'):
                            profiler.End()
                    profiler.End()
            Log.Print(Tracker.PrintStats())
            if not (world):
                raise AssertionError
            Log.Print(f'len(world.object_manager.card_dict)={len(world.object_manager.card_dict)!r}')
            Log.Print(f'len(world.object_manager.effect_dict)={len(world.object_manager.effect_dict)!r}')
            Log.Print(f'len(world.object_manager.paying_effect_dict)={len(world.object_manager.paying_effect_dict)!r}')
            Log.Print(f'len(world.object_manager.message_dict)={len(world.object_manager.message_dict)!r}')
            return ''
        actions = {'/test': do_test, '/T': do_test, '/save': do_save, '/load': do_load, '/restart': do_restart, '/comment': do_comment, '/C': do_comment, '/cs': do_comment_by, '/undo': do_undo, '/goto': do_goto, '/step': do_step, '/skip': do_skip, '/replay': do_update_replay, '/R': do_update_replay, '/call_log': do_coverage_report, '/CL': do_coverage_report, '/P': do_profile}
        if command.startswith('/'):
            parts = command.split()
            command = parts[0]
            args = parts[1:]
        else:
            return False
        if (command in actions):
            Log.Debug(CATEGORY_NAME, input_command)
            # RECOVER_TODO SETUP_FINALLY arg=29 target=778
            text = actions[command](*args)
            if (text == ''):
                text = command
            if (text != None):
                Notify.Command(text)
                return True
            return True
            # RECOVER_TODO JUMP_IF_NOT_EXC_MATCH arg=424 target=848
            Exception
            exc = UNKNOWN
            # RECOVER_TODO SETUP_FINALLY arg=23 target=840
            Log.Print(f'Error when running debug command: {command}')
            Log.FailedTrace(CATEGORY_NAME, exc, no_take_as_error=True)
            # RECOVER_TODO POP_EXCEPT arg=0 target=0
            exc = None
            del exc
            return True
            exc = None
            del exc
            # RECOVER_TODO RERAISE arg=1 target=1
            # RECOVER_TODO RERAISE arg=0 target=0
        return False
