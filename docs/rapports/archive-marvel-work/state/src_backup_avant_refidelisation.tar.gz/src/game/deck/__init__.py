# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.deck.deck import Deck
from game.deck.deck import Deck2
from game.deck.deck import DeckType
from game.deck.deck_aside import SetAsideDeck
Unused(Deck, Deck2, DeckType)
Unused(SetAsideDeck)
