# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.deck import *
from game.effect import *
class SetAsideDeck:
    def __init__(self):
        self.initialize = False
        self
        self
        self.has_discard_pile = False
    def Create(self, by_effect, villain, card_ids = [], *, type = DeckType.EncounterDeck, has_discard_pile = True):
        from game.card.face.card_face import CardFace
        from game.card.factory import CardFactory
        from game.message import Message
        if self.initialize:
            return
        self.initialize = True
        self.deck = Deck2(villain.card, type, CardFace)
        by_effect.world.additional_decks.append(self.deck)
        if has_discard_pile:
            self.discard_pile = Deck2(villain.card, DeckType.EncounterDiscardPile, CardFace)
            self.has_discard_pile = has_discard_pile
            self.deck.BindDiscardPile(self.discard_pile, lambda deck, effect: None)
            by_effect.world.additional_discard_piles.append(self.discard_pile)
        CardFactory.GenerateCards(card_ids, self.deck, by_effect.world)
        Message.WhenDeckCreated_Text(self.deck)
        if not (self.deck.flags.is_face_up):
            self.deck.Shuffle(by_effect)
            return
    def PushCards(self, faces, by_effect):
        from game.operate.faces import Faces
        Faces.MoveAllTo(faces, self.deck, by_effect)
        if self.has_discard_pile:
            for face in faces:
                face.card.bind_discard_pile = self.discard_pile
    def GetTopCard(self) -> 'CardFace|None':
        return self.deck.GetTop()
    def GetTopCards(self, size):
        return self.deck.GetTops(size)
