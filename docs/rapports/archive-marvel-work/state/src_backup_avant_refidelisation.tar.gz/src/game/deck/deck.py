# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from typing_extensions import Unpack
from game.card.face import *
from game.card import *
from game.player import *
from game.effect import *
from game.world.game_area import *
from game.object import Object
from game.deck.deck_type import DeckType
CardFaceType = 'CardFace'
CardFaceType: TypeAlias
@final
class Deck2(Generic[TC], Object):
    def __init__(self, owner, deck_type, card_type, *, related_player = None):
        from game.card import Card
        self.cards = []
        self.removed_cards = []
        self.deck_type = deck_type
        self.flags = deck_type.flags
        self.on_discards = False
        self.bind_card = None
        self
        self.card_type = card_type
        self.bind_discard_pile = None
        self.process_after_shuffle = lambda deck, effect: None
        self
        self.shuffle_with_discard_count = 0
        self.for_undo_shuffle = []
        if isinstance(owner, Card):
            self.bind_card = owner
            self.bind_owner = self.bind_card.GetOwner()
        else:
            self.bind_owner = owner
        if (related_player == None):
            if isinstance(self.bind_card, Player):
                self.play_area = self.bind_card
            else:
                self.play_area = related_player
        else:
            self.play_area = related_player
        world = self.bind_owner.world
        super().__init__('deck', world)
    def __repr__(self):
        if self.bind_card:
            return f"{self.bind_card.face}'s {self.deck_type.name}<{self.GetSize()}>"
        if self.GetOwner():
            if not (self.GetOwner().is_scenario):
                return f"{self.GetOwner()}'s {self.deck_type.name}<{self.GetSize()}>"
        return f'{self.deck_type.name}<{self.GetSize()}>'
    def GetIndex(self, face):
        return self.cards.index(face.card)
    def GetOwner(self) -> Player|Scenario:
        if self.bind_card:
            if self.bind_card.IsOnField():
                player = self.bind_card.GetController()
                if not ((player != None)):
                    raise AssertionError
                return player
            return self.bind_owner
        return self.bind_owner
    def GetOwnerPlayer(self) -> Player:
        owner = self.GetOwner()
        if not (isinstance(owner, Player)):
            raise AssertionError
        return owner
    def BindDiscardPile(self, deck, process_after_shuffle):
        if not (self.flags.is_deck):
            if not (self.flags.is_set_aside):
                raise AssertionError
        self.bind_discard_pile = deck
        self.process_after_shuffle = process_after_shuffle
    def Clear(self):
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        Faces.RemoveAllFromGame(self.Get(), GameRule(self.GetOwner().GetRoleCharacter()))
    def Destroy(self):
        for card in self.cards:
            card.Destroy()
        self.cards = []
    def MarkAsRemoved(self, card: 'Card'):
        self.removed_cards.append(card)
        self.cards.remove(card)
    def UnMarkAsRemoved(self, card: 'Card'):
        if (card in self.removed_cards):
            self.removed_cards.remove(card)
            self.cards.append(card)
            return
    def Remove(self, card: 'Card'):
        if (card in self.removed_cards):
            self.removed_cards.remove(card)
            return
        self.cards.remove(card)
    def Append(self, card: 'Card'):
        self.Insert(-1, card)
    def Insert(self, index, card, target_game_area = None):
        card.area = self
        if (index < 0):
            index = ((len(self.cards) + index) + 1)
        if (card.area == self):
            if (card in self.cards):
                self.cards.remove(card)
        self.cards.insert(index, card)
        if target_game_area:
            game_area = target_game_area
        else:
            if self.bind_card:
                game_area = self.bind_card.GetGameArea()
            else:
                if self.play_area:
                    game_area = self.play_area.GetIdentity().card.GetGameArea()
                else:
                    game_area = self.GetOwner().GetGameArea()
        if (card.GetGameArea() != game_area):
            game_area.AddCard(card)
        if not (self.flags.is_removed):
            if not (self.flags.is_place_card_area):
                if (card.state.is_face_up != self.flags.is_face_up):
                    if (card.back_faces == []):
                        card.state.is_face_up = self.flags.is_face_up
                        return
                        return
                        return
                        return
    def GetSize(self):
        return len(self.cards)
    def Sort(self):
        self.cards = sorted(self.cards, reverse=True)
    def CleanAllCardsStatuesInternal(self):
        for card in self.cards:
            card.can_state.Reset()
            card.is_apply_unique_rule = None
            card.visible.Clean()
    def UpdateAllCardsStatuesInternal(self):
        for card in self.cards:
            card.visible.Update()
    def Unshuffle(self, by_effect: Effect):
        self.cards = self.for_undo_shuffle[:]
    def ShuffleInternal(self, by_effect, only_for_most_top):
        from game.operate.rand import Rand
        from game.message import Message
        self.CleanAllCardsStatuesInternal()
        if (only_for_most_top != None):
            sublist = self.cards[(-only_for_most_top):]
            Rand.Shuffle(sublist, by_effect)
            self.cards[(-only_for_most_top):] = sublist
        else:
            Rand.Shuffle(self.cards, by_effect)
        self.UpdateAllCardsStatuesInternal()
        message = Message.AfterDeckShuffle(self, self.bind_discard_pile)
        message.Send()
    def Shuffle(self, by_effect, only_for_most_top = None):
        self.for_undo_shuffle = self.cards[:]
        if (len(self.cards) > 0):
            self.ShuffleInternal(by_effect, only_for_most_top)
            return
    def ShuffleWithDiscardPile(self, penalty, by_effect):
        from game.message import Message
        from game.operate.faces import Faces
        if self.bind_discard_pile:
            self.shuffle_with_discard_count = (self.shuffle_with_discard_count + 1)
            Faces.MoveAllTo(self.bind_discard_pile.Get(False), self, by_effect, by_shuffle=True)
            self.ShuffleInternal(by_effect, None)
            if penalty:
                if not (self.bind_discard_pile):
                    raise AssertionError
                self.process_after_shuffle(self, by_effect)
                reset_message = Message.AfterDeckReset(self)
                reset_message.Send()
                return
            return
        self.Shuffle(by_effect)
    def HasThisType(self, this):
        count = 0
        for face in self.Get():
            if face.IsName(this.name):
                count = (count + 1)
        return count
    def PopInternal(self, size, process, by_effect, *, continue_after_shuffle):
        if not (self.flags.is_deck):
            raise AssertionError
        faces = []
        left_size = size
        old_shuffle_with_discard_count = self.shuffle_with_discard_count
        world = self.world
        if left_size:
            if world.is_game_over:
                return faces
            if self.GetOwner().is_eliminated:
                return faces
            if (self.GetSize() > 0):
                face = self.Get(True)[0]
                process(face)
                faces.append(face)
                left_size = (left_size - 1)
            if not (continue_after_shuffle):
                if (self.shuffle_with_discard_count != old_shuffle_with_discard_count):
                    return faces
            if (self.GetSize() == 0):
                return faces
            if (left_size == 0):
                return faces
            # backward conditional jump to 36: left_size
        return faces
    def MoveToTopAndFlip(self, card, by_effect, *, ui_group = False):
        card.MoveToTop(self, by_effect)
        if not (card.IsFaceUp()):
            card.Flip(by_effect, ui_group=ui_group)
            return
    TCA = TypeVar('TCA', bound='CardFace')
    def FindCard(self, finder = None, *, name = None, trait = None, card_type = CardFaceType, **kwargs):
        faces = self.FindCards(*(), **{'finder': finder, 'name': name, 'trait': trait, 'card_type': card_type, 'max': 1, **kwargs})
        if (faces != []):
            return faces[0]
    def FindCards(self, finder = None, *, include_removed = False, name = None, trait = None, card_type = CardFaceType, max = Math.INT_INF, **kwargs):
        from game.operate.filter import Filter
        from game.card.card_finder import CardFinder
        if (max == 0):
            return []
        card_finder = (CardFinder(*(), **{'name': name, 'trait': trait, 'card_type': card_type, **kwargs}) & finder)
        faces = Filter.ByFinder(self.GetAll(include_removed=include_removed), card_finder, max=max)
        return faces
    def FindCardSizeOld(self, finder):
        from game.operate.faces import Faces
        return Faces.FindCardSizeOld(self.GetAll(), finder)
    def FindCardSize(self, finder = None):
        from game.operate.faces import Faces
        return Faces.FindCardSize(self.GetAll(), finder)
    def DiscardAll(self, by_effect):
        from game.operate.faces import Faces
        return len(Faces.DiscardAll(self.Get(True), by_effect))
    def Get(self, from_top = False):
        faces = self.GetAll(from_top, include_removed=False)
        return [x for x in faces if isinstance(x, self.card_type)]
    def GetAll(self, from_top = False, include_removed = True):
        faces = []
        if from_top:
            cards = reversed(self.cards)
        else:
            cards = self.cards
        faces = [x.face for x in cards]
        if include_removed:
            faces = (faces + [x.face for x in self.removed_cards])
        return faces
    def GetBottom(self) -> 'CardFace|None':
        if (len(self.cards) > 0):
            return self.cards[0].face
    def GetTop(self) -> 'CardFace|None':
        if (len(self.cards) > 0):
            return self.cards[-1].face
    def GetTops(self, size):
        faces = []
        for card in self.cards[(-size):]:
            faces.append(card.face)
        return faces
    def RevealTopCard(self, to_player: Player, by_effect: Effect) -> 'CardFace|None':
        faces = self.PopInternal(1, lambda face: face.Reveal(to_player, by_effect), by_effect, continue_after_shuffle=False)
        if faces:
            return faces[0]
    def DiscardCardsInternal(self, size, by_effect, *, continue_after_shuffle, each_time = None):
        def action(face: 'CardFace'):
            face.DiscardInternal(by_effect)
            if each_time:
                each_time(face)
                return
        faces = self.PopInternal(size, action, by_effect, continue_after_shuffle=continue_after_shuffle)
        from game.message import Message
        message = Message.AfterCardsMoved({x: self for x in faces}, by_discard=True)
        message.Send()
        return faces
    def DiscardUntil(self, by_effect, *, name, trait, card_type, **kwargs):
        if not (self.flags.is_deck):
            raise AssertionError
        from game.card.card_finder import CardFinder
        from game.card.face.card_face import CardFace
        if isinstance(card_type, CardFace):
            card_type2 = CardFace
        else:
            card_type2 = card_type
        finder = CardFinder(*(), **{'name': name, 'trait': trait, 'card_type': card_type2, **kwargs})
        found_face = None
        other_discard_faces = []
        for face in self.Get()[::-1]:
            face.DiscardInternal(by_effect)
            if finder:
                if finder.Check(face):
                    found_face = face
                else:
                    other_discard_faces.append(face)
            found_face = face
            other_discard_faces.append(face)
        moved_faces = ((other_discard_faces + [found_face]) if found_face else [])
        from game.message import Message
        message = Message.AfterCardsMoved({x: self for x in moved_faces}, by_discard=True)
        message.Send()
        if (self.GetSize() == 0):
            return (None, other_discard_faces)
        if (found_face != None):
            if not (isinstance(card_type, CardFace)):
                if (card_type == 'CardFace'):
                    return (Cast(Any, found_face), other_discard_faces)
            return (Cast(Any, found_face), other_discard_faces)
            if not (isinstance(found_face, card_type)):
                raise AssertionError
            return (found_face, other_discard_faces)
        return (None, other_discard_faces)
    def FindTopmost(self, card_finder: 'CardFinder2[TCA]') -> TCA|None:
        for face in self.Get(True):
            if card_finder.Check(face):
                face
                return
Deck = Deck2['CardFace']
