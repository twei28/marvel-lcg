# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.exceptions.exceptions import GameSignal
from game.exceptions.exceptions import GameSignal_InvalidMove
from game.exceptions.exceptions import GameSignal_UndoRequest
Unused(GameSignal)
Unused(GameSignal_InvalidMove)
Unused(GameSignal_UndoRequest)
