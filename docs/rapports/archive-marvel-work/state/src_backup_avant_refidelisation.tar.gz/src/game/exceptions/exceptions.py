# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from enum import Enum
class GameSignalType(Enum):
    INVALID_MOVE = 'InvalidMove'
    UNDO_REQUEST = 'UndoRequest'
    UNKNOWN = 'Unknown'
class GameSignal(Exception):
    __doc__ = 'Base class for non-fatal game flow signals (e.g., undo, invalid move).'
    def __init__(self, signal_type):
        self.signal_type = signal_type
        super().__init__(signal_type.value)
class GameSignal_UndoRequest(GameSignal):
    def __init__(self):
        super().__init__(GameSignalType.UNDO_REQUEST)
class GameSignal_InvalidMove(GameSignal):
    def __init__(self):
        super().__init__(GameSignalType.INVALID_MOVE)
