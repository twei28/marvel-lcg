# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryPlayer:
    @staticmethod
    def PlayersCannotPlayCardWhile(which_player, which_card = None, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.check_effect.initiator, effect)
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.check_effect.this, effect)
        return Ability(AbilityType.NonKeyword, Message.CheckEffectCondition, [lambda effect, message: message.check_effect.ability.is_play, check_which_player, check_which_card, *conditions], lambda effect, message: message.SetEffectInvalid(effect), is_local=(which_card == 'This'))
    @staticmethod
    def PlayersCannotMakeBasicAttack(which_player):
        from game.card.face.card_type import Identity
        def check_is_basic_atk(effect, message):
            ability = message.check_effect.ability
            return (ability.flags.ability_type.flags.is_basic_power and ('ATK' in ability.func_names))
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.check_effect.initiator, effect)
        return Ability(AbilityType.NonKeyword, Message.CheckEffectCondition, [lambda effect, message: Identity.IsType(message.check_effect.this), check_is_basic_atk, check_which_player], lambda effect, message: message.SetEffectInvalid(effect))
    @staticmethod
    def PlayersCannotChangeAdditionalForms(which_player, exclude = None):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.trigger.GetControlBy(), effect)
        def check_exclude(effect, message):
            if (exclude == None):
                return True
            return (not Condition.CheckWhichCard(exclude, message.by_effect.this, effect))
        return Ability(AbilityType.NonKeyword, Message.WhenUnitWouldChangeForm, [check_which_player, check_exclude, lambda effect, message: message.is_change_additional_form], lambda effect, message: message.SetBeInstead(effect))
    @staticmethod
    def PlayersCannotChangeForms(ability_type, which_player, *, from_form = None, to_form = None, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.trigger.GetControlBy(), effect)
        def check_from_form(effect, message):
            if (from_form == None):
                return True
            return from_form.IsType(message.from_form)
        def check_to_form(effect, message):
            if (to_form == None):
                return True
            return to_form.IsType(message.to_form)
        return Ability(ability_type, Message.WhenUnitWouldChangeForm, [lambda effect, message: (effect.this != message.by_effect.this), check_which_player, check_from_form, check_to_form, *conditions], lambda effect, message: message.SetBeInstead(effect))
    @staticmethod
    def PlayersCannotTriggerAbility(which_player, which_ability, *, label = None, on_which_card = None, during = None, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.check_effect.initiator, effect)
        def check_which_ability(effect, message):
            ability = message.check_effect.ability
            if ability.flags.is_forced:
                return False
            return Condition.CheckWhichAbility(which_ability, ability)
        def check_label(effect, message):
            if (label == None):
                return True
            ability = message.check_effect.ability
            return ability.IsLabel(label)
        def check_on_which_card(effect, message):
            return Condition.CheckWhichCard(on_which_card, message.check_effect.this, effect)
        def check_during(effect, message):
            if (during == None):
                return True
            if (during == 'YourTurn'):
                player = effect.world.GetCurrentPlayer()
                return Condition.ThisIsYou(effect, player)
        return Ability(AbilityType.NonKeyword, Message.CheckEffectCondition, [check_which_player, check_which_ability, check_label, check_on_which_card, check_during, *conditions], lambda effect, message: message.SetEffectInvalid(effect))
    @staticmethod
    def PlayersCannotReadyCardWhile(which_player, ready_what, control_by, *, by_effect_face = None):
        from game.ability.factory import AbilityFactory
        def check_which_player(effect, message):
            player = message.by_effect.initiator
            return Condition.CheckWhichPlayer(which_player, player, effect)
        return AbilityFactory.CardCannotReady(ready_what, control_by=control_by, by_effect_face=by_effect_face, conditions=[check_which_player])
    @staticmethod
    def PlayersCannotThwartWhile(which_player, which_scheme, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayerIncludeAllies(which_player, message, effect)
        def check_which_scheme(effect, message):
            return Condition.CheckWhichCard(which_scheme, message.scheme, effect)
        return Ability(AbilityType.NonKeyword, Message.CheckIfSchemeCanBeThwartBy, [check_which_player, check_which_scheme, *conditions], lambda effect, message: message.SetCannotBeThwart(effect))
    @staticmethod
    def PlayersCannotAttackWhile(which_player, which_target, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayerIncludeAllies(which_player, message, effect)
        def check_which_target(effect, message):
            return Condition.CheckWhichCard(which_target, message.being_attack, effect)
        return Ability(AbilityType.NonKeyword, Message.CheckIfUnitCanBeAttackBy, [check_which_player, check_which_target, *conditions], lambda effect, message: message.SetCannotBeAttack(effect))
    @staticmethod
    def PlayersCannotRemoveThreatFrom(which_player, which_scheme, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.by_effect.initiator, effect)
        def check_which_scheme(effect, message):
            return Condition.CheckWhichCard(which_scheme, message.trigger, effect)
        def cannot_be_removed(effect: Effect, message: Message.WhenSchemeWouldRemoveThreat):
            message.SetCannotBeRemoved(effect)
        return Ability(AbilityType.NonKeyword, Message.WhenSchemeWouldRemoveThreat, [check_which_scheme, check_which_player, *conditions], cannot_be_removed)
    @staticmethod
    def PlayersCannotDamageUnit(which_player, which_unit, *, unit_engaged_player = 'AnyPlayer', conditions = []):
        from game.card.face.card_type import Minion
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.by_effect.initiator, effect)
        def check_which_unit(effect, message):
            return Condition.CheckWhichCard(which_unit, message.trigger, effect)
        def check_unit_engaged_player(effect, message):
            if not (Minion.IsType(message.trigger)):
                return True
            return Condition.CheckWhichPlayer(unit_engaged_player, message.trigger.GetEngagedPlayer(), effect)
        def prevent_all_damage(effect: Effect, message: Message.WhenUnitWouldTakeDamage):
            message.PreventDamage('All', effect)
        return Ability(AbilityType.NonKeyword, Message.WhenUnitWouldTakeDamage, [check_which_player, check_which_unit, check_unit_engaged_player, *conditions], prevent_all_damage)
    @staticmethod
    def CardsEnterPlayExhausted(which_card, which_player = None):
        from game.ability.factory import AbilityFactory
        from game.operate.faces import Faces
        def exhaust(effect: Effect, message: Message.WhenCardEnterPlay):
            Faces.ExhaustAll([message.trigger], effect)
        def check_which_player(effect, message):
            if (which_player == None):
                return True
            return Condition.CheckWhichPlayer(which_player, message.trigger.GetControlBy(), effect)
        return AbilityFactory.WhenCardEnterPlay(AbilityType.NonKeyword, which_card, exhaust, conditions=[check_which_player])
    @staticmethod
    def WhenPlayerWouldDrawCard(ability_type, which_player, which_card, operation, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        return Ability(ability_type, Message.WhenPlayerWouldDrawCard, [check_which_player, check_which_card, *conditions], operation)
    @staticmethod
    def AfterPlayerDrewCards(ability_type, which_player, which_card, operation, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.drew_faces, effect)
        return Ability(ability_type, Message.AfterPlayerDrewCards, [check_which_player, check_which_card, *conditions], operation)
    @staticmethod
    def WhenPlayerWouldBeDealtEncounterCard(ability_type, operation, *, conditions = []):
        return Ability(ability_type, Message.WhenPlayerWouldBeDealtEncounterCard, [*conditions], operation)
    @staticmethod
    def AfterPlayerDealEncounterCard(ability_type, operation, *, conditions = []):
        return Ability(ability_type, Message.AfterPlayerDealEncounterCard, [*conditions], operation)
    @staticmethod
    def FirstPlayerControlThis() -> Ability:
        from game.ability.factory import AbilityFactory
        def when_this_valid(effect: Effect, message: Message.AfterCardsMoved|Message.AfterPlayersOrderChange):
            this = effect.this
            first_player = effect.world.GetFirstPlayer()
            this.PutIntoPlay(first_player, effect, under_control=True)
        return AbilityFactory.WhenEvent((Message.AfterCardsMoved | Message.AfterPlayersOrderChange), lambda effect, last_value: ((not effect.this.card.area.flags.is_place_card_area) and ((not effect.this.card.area.flags.is_upgrades) and (effect.this.IsInPlay() and (effect.this.GetControlBy() != effect.world.GetFirstPlayer())))), when_this_valid)
