# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityTokenFactory:
    @staticmethod
    def AfterCardPlacedToken(ability_type, which_card, token_name, operation, *, conditions = [], at_least = None):
        from game.operate.worlds import Worlds
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_token_name(effect, message):
            if token_name:
                return (message.token_name == token_name)
            return True
        def check_at_least(effect, message):
            from game.card.face.attribute.can_place_token import CanPlaceToken
            if at_least:
                this = effect.this.CastTo(CanPlaceToken)
                if isinstance(at_least, str):
                    size = Worlds.ConvertPerPlayerIconToInt(at_least, effect)
                else:
                    if isinstance(at_least, int):
                        size = at_least
                    else:
                        size = at_least(effect)
            return True
        return Ability(ability_type, Message.AfterCardPlacedToken, [Condition2.ThisIsTrigger, check_which_card, check_token_name, check_at_least, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhenCardWouldBePlacedToken(ability_type, to_where, counter_name, operation, *, conditions = []):
        def check_to_where(effect, message):
            return Condition.CheckWhichCard(to_where, message.trigger, effect)
        def check_counter_name(effect, message):
            if counter_name:
                return (message.token_name == counter_name)
            return True
        return Ability(ability_type, Message.WhenCardWouldBePlacedToken, [check_to_where, check_counter_name, *conditions], operation, is_local=(to_where == 'This'))
