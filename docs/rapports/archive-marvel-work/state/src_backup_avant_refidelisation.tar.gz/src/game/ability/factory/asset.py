# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryAsset:
    @staticmethod
    def GiveKeywordToAttached(card_finder = None, *, get_new_value = None, expert_mode_only = None, health = None, considered_at_least_hp = None, trait = None, attack = None, defense = None, thwart = None, scheme = None, retaliate = None, hand_size = None, stalwart = None, recover = None, guard = None, patrol = None, steady = None, treat_as_blank = None, target_threat = None, control_additional_restricted = None, attack_consequential_damage = None, thwart_consequential_damage = None, assault = None, have_res_icon = None, apply = None, ex_change_on_event = OnEvent.NONE):
        abilities = []
        def only_ignore_flip():
            return ((trait == None) and ((attack == None) and ((defense == None) and ((thwart == None) and ((scheme == None) and ((retaliate == None) and ((hand_size == None) and ((stalwart == None) and ((recover == None) and ((guard == None) and ((patrol == None) and ((steady == None) and ((treat_as_blank == None) and ((target_threat == None) and ((control_additional_restricted == None) and ((attack_consequential_damage == None) and ((thwart_consequential_damage == None) and ((assault == None) and ((have_res_icon == None) and ((apply == None) and ((health != None) or (considered_at_least_hp != None))))))))))))))))))))))
        from game.ability.factory.asset_helper import GiveKeywordToAttachWhenApplyThisInternal
        if not (only_ignore_flip()):
            abilities.append(GiveKeywordToAttachWhenApplyThisInternal(*(card_finder,), **{'ignore_flip': False, 'get_new_value': get_new_value, 'expert_mode_only': expert_mode_only, 'trait': trait, 'attack': attack, 'defense': defense, 'thwart': thwart, 'scheme': scheme, 'retaliate': retaliate, 'hand_size': hand_size, 'stalwart': stalwart, 'recover': recover, 'guard': guard, 'patrol': patrol, 'steady': steady, 'treat_as_blank': treat_as_blank, 'target_threat': target_threat, 'control_additional_restricted': control_additional_restricted, 'attack_consequential_damage': attack_consequential_damage, 'thwart_consequential_damage': thwart_consequential_damage, 'assault': assault, 'have_res_icon': have_res_icon, 'apply': apply, 'ex_change_on_event': ex_change_on_event}))
        if not ((health != None)):
            if (considered_at_least_hp != None):
                abilities.append(GiveKeywordToAttachWhenApplyThisInternal(card_finder, get_new_value=get_new_value, expert_mode_only=expert_mode_only, health=health, considered_at_least_hp=considered_at_least_hp, ignore_flip=True, ex_change_on_event=ex_change_on_event))
        abilities.append(GiveKeywordToAttachWhenApplyThisInternal(card_finder, get_new_value=get_new_value, expert_mode_only=expert_mode_only, health=health, considered_at_least_hp=considered_at_least_hp, ignore_flip=True, ex_change_on_event=ex_change_on_event))
        return abilities
    @staticmethod
    def WhenCardWouldAttachTo(ability_type, which_card, to_where, operation, *, conditions = []):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.upgrade, effect)
        def check_to_where(effect, message):
            return Condition.CheckWhichCard(to_where, message.to_face, effect)
        return Ability(ability_type, Message.WhenCardWouldAttachTo, [check_which_card, check_to_where, *conditions], operation)
    @staticmethod
    def AttachToFaceWhenPutIntoPlayInternal(selector, *, conditions = [], otherwise_selector = None, if_cannot_operation = None, when_attach_operation = None):
        from game.operate.filter import Filter
        def attach_to_card(effect: Effect, message: Message.WhenCardPutIntoPlay):
            from game.card.face.attribute.can_attach import CanAttach
            this = effect.this.CastTo(CanAttach)
            face = None
            targets = selector.GetAllLegalTargets(effect)
            if targets:
                face = Filter.One(targets, effect)
            else:
                if otherwise_selector:
                    targets = otherwise_selector.GetAllLegalTargets(effect)
                    face = Filter.One(targets, effect)
            if face:
                this.AttachTo2(face, effect)
                if when_attach_operation:
                    when_attach_operation(face, effect)
                    return
                return
            if if_cannot_operation:
                player = message.GetToPlayer()
                if_cannot_operation(effect, player)
                return
        return Ability(AbilityType.NonKeyword, Message.WhenCardPutIntoPlay, [lambda effect, message: (effect.this == message.trigger), *conditions], attach_to_card, is_local=True).NoOutOfPlayLimit().SetFuncName('AttachToWhenEnterPlay')
    @staticmethod
    def WhenThisBoostAttachTo(which_card, *, otherwise_attach_to = None, ex_operate = None):
        from game.operate.worlds import Worlds
        from game.operate.filter import Filter
        from game.ability.factory import AbilityFactory
        from game.card.face.attribute.can_attach import CanAttach
        def adamantium_claws_boost(effect: Effect, message: Message.WhenCardBecomeBoost):
            this = effect.this.CastTo(CanAttach)
            if (which_card == 'ActivatingEnemy'):
                face = message.activating_enemy
            else:
                if (which_card == 'Minion'):
                    face = Filter.One(Worlds.GetOnFieldMinions(effect), effect)
                else:
                    if (which_card == 'Villain'):
                        face = Worlds.FindVillain(effect)
                    else:
                        if (which_card == 'YouIdentity'):
                            face = message.GetToPlayer().GetIdentity()
                        else:
                            faces = Worlds.FindCardsOnField(effect, which_card)
                            face = Filter.One(faces, effect)
            if not (face):
                if otherwise_attach_to:
                    if isinstance(otherwise_attach_to, CardFinder):
                        otherwise_selector = otherwise_attach_to
                    else:
                        otherwise_selector = CardFinder(card_type=otherwise_attach_to)
            if face:
                this.AttachTo2(face, effect)
                if ex_operate:
                    ex_operate(face, effect)
                    return
                    return
        return AbilityFactory.WhenCardBecomeBoost('This', adamantium_claws_boost)
