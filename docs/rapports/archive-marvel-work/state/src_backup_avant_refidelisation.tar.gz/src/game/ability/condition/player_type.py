# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from game.ability import *
from game.player import *
from game.card.face import *
from game.message import *
class ConditionPlayerType:
    __annotations__ = {}
    PLAYER_TYPE = (((Literal[('This', 'AttachedPlayer', 'You', 'EngagedPlayer', 'Other')] | 'PlayerFinder') | 'Player') | Literal['AnyPlayer'])
    PLAYER_TYPE: TypeAlias
    @staticmethod
    def CheckAgainstPlayer(against_player, message, effect):
        if (against_player == 'AnyPlayer'):
            return True
        if (against_player == 'You'):
            if effect.context.ask_player:
                return (effect.context.ask_player == message.against_player)
            return (message.against_player != None)
        return ConditionPlayerType.CheckWhichPlayer(against_player, message.against_player, effect)
    @staticmethod
    def CheckWhichPlayerIncludeAllies(check_rule, message, from_effect):
        from game.card.face.card_type import Identity
        from game.card.face.card_type import Upgrade
        from game.card.face.card_type import Ally
        by_face = message.by_effect.this
        check_player = message.by_effect.initiator
        if (check_rule == 'You'):
            if Ally.IsType(by_face):
                return False
            if Upgrade.IsType(by_face):
                if not (Identity.IsType(by_face.GetBindFace())):
                    return False
        return ConditionPlayerType.CheckWhichPlayer(check_rule, check_player, from_effect)
    @staticmethod
    def CheckWhichPlayer(check_rule, check_player, from_effect):
        from game.player import Player
        from game.player.player_finder import PlayerFinder
        from game.card.face.card_type import Minion
        from game.ability.condition import Condition
        if (check_rule == 'AnyPlayer'):
            return True
        if (check_player == None):
            return False
        if not (isinstance(check_player, Player)):
            return False
        identity = check_player.GetIdentity()
        if isinstance(check_rule, Player):
            return (check_rule == check_player)
        if isinstance(check_rule, PlayerFinder):
            return check_rule.Check(check_player)
        if (check_rule == 'This'):
            return (from_effect.initiator == check_player)
        if (check_rule == 'AttachedPlayer'):
            return Condition.ThisAttachedTo(from_effect, identity)
        if (check_rule == 'You'):
            return Condition.ThisIsYou(from_effect, identity)
        if (check_rule == 'EngagedPlayer'):
            return (from_effect.this.CastTo(Minion).engaged_player == check_player)
        if (check_rule == 'Other'):
            return (not Condition.ThisIsYou(from_effect, check_player))
