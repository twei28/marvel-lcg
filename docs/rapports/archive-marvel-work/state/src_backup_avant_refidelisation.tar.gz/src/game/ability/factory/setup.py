# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactorySetup:
    @staticmethod
    def SetupPutIntoPlay(names, *, flip_to_trait = None, flip_to_name = None, operation = None):
        from game.card.factory import CardFactory
        from game.operate.run_at import RunAt
        def kitty_pride_setup(effect: Effect, message: Message.WhenPlayerSelectHero):
            this = effect.this
            Unused(this)
            initiator = effect.GetInitiator()
            cards = CardFactory.GenerateCards(names, initiator.additional_discard_pile, effect.world)
            faces = [x.face for x in cards]
            def action():
                put_faces = []
                for face in reversed(faces):
                    if not (flip_to_trait):
                        if flip_to_name:
                            face.FlipTo(effect, trait=flip_to_trait, name=flip_to_name)
                    face.FlipTo(effect, trait=flip_to_trait, name=flip_to_name)
                    this = face.card.face
                    if this.PutIntoPlay(initiator, effect, under_control=True):
                        put_faces.append(this)
                if operation:
                    if put_faces:
                        operation(effect, put_faces)
                from game.player.element.player_setup import HACK_HERO_ID
                if names[0].startswith(HACK_HERO_ID):
                    initiator.setup.SetupPlayerAbility(put_faces[0].card.back_faces[0])
                    return
            RunAt.WhenCardSetup(this, action)
        return AbilityFactorySetup.WhenPlayerSelectHero('This', kitty_pride_setup)
    @staticmethod
    def SetupWithSetAside(names):
        from game.card.factory import CardFactory
        def action(effect: Effect, message: Message.WhenPlayerSelectHero):
            initiator = effect.GetInitiator()
            CardFactory.GenerateCards(names, initiator.additional_discard_pile, effect.world)
        return AbilityFactorySetup.WhenPlayerSelectHero('This', action)
    @staticmethod
    def BeginGameWithSetAside(names, operation = None):
        from game.card.factory import CardFactory
        from game.operate.run_at import RunAt
        def action(effect: Effect, message: Message.WhenPlayerSelectHero):
            this = effect.this
            initiator = effect.GetInitiator()
            CardFactory.GenerateCards(names, initiator.additional_discard_pile, effect.world)
            if operation:
                def action():
                    if not (operation):
                        raise AssertionError
                    operation(effect, message)
                RunAt.WhenGameBeginSetup(this, action)
                return
        return AbilityFactorySetup.WhenPlayerSelectHero('This', action)
    @staticmethod
    def WhenPlayerSelectHero(which_hero, operation, *, conditions = []):
        def check_which_hero(effect: Effect, message: Message.WhenPlayerSelectHero):
            return Condition.CheckWhichCard(which_hero, message.trigger, effect)
        return Ability(AbilityType.Setup, Message.WhenPlayerSelectHero, [check_which_hero, *conditions], operation)
    @staticmethod
    def WhenGameBeginSetup(operation, *, conditions = []):
        return Ability(AbilityType.Setup, Message.WhenGameBeginSetup, conditions, operation)
    @staticmethod
    def SetModularSetsAside(max_sets_num):
        def when_game_begin(effect: Effect, message: Message.WhenGameBeginSetup):
            encounter_sets = []
            standard_encounter_sets = []
            for encounter_set in message.encounter_set_names:
                if not (encounter_set.startswith('standard')):
                    if encounter_set.startswith('expert'):
                        standard_encounter_sets.append(encounter_set)
                standard_encounter_sets.append(encounter_set)
                encounter_sets.append(encounter_set)
            if isinstance(max_sets_num, int):
                check_num = max_sets_num
            else:
                check_num = max_sets_num(effect)
            if max_sets_num:
                if not ((len(encounter_sets) >= check_num)):
                    raise AssertionError(f'You need {check_num} encounter sets to play this scenario')
                encounter_sets = encounter_sets[:check_num]
            message.encounter_set_names = standard_encounter_sets
            from game.card.factory import CardFactory
            card_ids = []
            for encounter_set in encounter_sets:
                card_ids = (card_ids + CardFactory.LoadEncounterSet(encounter_set))
            if not ((message.set_aside_modular_card_ids == [])):
                raise AssertionError
            message.set_aside_modular_card_ids = card_ids
        return AbilityFactorySetup.WhenGameBeginSetup(when_game_begin)
    @staticmethod
    def WhenGameInitialize(operation, *, conditions = []):
        return Ability(AbilityType.Setup, Message.WhenGameInitialize, conditions, operation)
    @staticmethod
    def WhenGameWouldBegin(operation, *, conditions = []):
        return Ability(AbilityType.Setup, Message.WhenGameWouldBegin, conditions, operation)
    @staticmethod
    def WhenCardSetup(which_card, operation):
        def check_who(effect, message):
            if (which_card == 'This'):
                return Condition2.ThisIsTrigger(effect, message)
            return (which_card == message.trigger)
        def is_before_put_setup_cards_into_play(effect, message):
            return (not message.before_put_setup_cards)
        return Ability(AbilityType.Setup, Message.WhenCardSetup, [check_who, is_before_put_setup_cards_into_play], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhenCardSetupBeforePutSetupCards(operation):
        def check_who(effect, message):
            return (effect.this == message.trigger)
        def is_before_put_setup_cards(effect, message):
            return message.before_put_setup_cards
        return Ability(AbilityType.Setup, Message.WhenCardSetup, [check_who, is_before_put_setup_cards], operation)
    @staticmethod
    def AfterGameSetup(operation):
        return AbilityFactorySetup.WhenGameWouldBegin(operation)
