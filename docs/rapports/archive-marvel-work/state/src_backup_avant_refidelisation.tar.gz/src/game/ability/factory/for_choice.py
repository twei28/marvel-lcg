# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryForChoice:
    @staticmethod
    def ForChoiceAbilityInternal(name, res, operation, *, conditions, targets_is_exhaust_cost = False):
        from game.ability.cost_func import CostFunc
        if (operation == None):
            def operation(targets, res, ability):
                pass
        def action(effect: Effect, message: Message.WhenPlayerChooseAbility):
            if targets_is_exhaust_cost:
                targets = effect.cost_func.Get(CostFunc.Exhaust).return_exhausted_cards
            else:
                targets = effect.targets
            operation(targets, effect.GetPaidResources(), effect)
        ability = Ability(AbilityType.ChooseAbility, Message.WhenPlayerChooseAbility, [*conditions], action).SetName(name).NoOutOfPlayLimit()
        if (res != None):
            ability.SetCost(res, is_choose_ability=True)
        return ability
    @staticmethod
    def ForChoiceAbility(name, operation = None, *, condition = True, targets_is_exhaust_cost = False):
        def check_condition(effect, message):
            return condition
        if (operation == None):
            def operation(targets):
                pass
        return AbilityFactoryForChoice.ForChoiceAbilityInternal(name, None, lambda targets, res, effect: operation(targets), conditions=[check_condition], targets_is_exhaust_cost=targets_is_exhaust_cost).SetDefault()
    @staticmethod
    def ForChoiceAbility3(name, operation = None, *, condition = True):
        def check_condition(effect, message):
            return condition
        if (operation == None):
            def operation(targets, effect):
                pass
        return AbilityFactoryForChoice.ForChoiceAbilityInternal(name, None, lambda targets, res, effect: operation(targets, effect), conditions=[check_condition]).SetDefault()
    @staticmethod
    def ForChoiceAbility2(name, operation = None, *, condition = True):
        def check_condition(effect, message):
            return condition
        if (operation == None):
            def operation(targets, ability):
                pass
        return AbilityFactoryForChoice.ForChoiceAbilityInternal(name, None, lambda targets, res, effect: operation(targets, effect.ability), conditions=[check_condition]).SetDefault()
    @staticmethod
    def Otherwise(operation):
        def add_otherwise(effect, message):
            effect.context.only_work_when_no_other_options = True
            return True
        return AbilityFactoryForChoice.ForChoiceAbilityInternal('Otherwise', None, lambda targets, res, effect: operation(targets), conditions=[add_otherwise]).SetDefault()
    @staticmethod
    def ForChoiceAbilityWithCost(cost, name = None, operation = None, *, conditions = []):
        if (operation == None):
            def operation(targets, res):
                pass
        if (name == None):
            name = f'Spend {cost.GetSpendText()}'
        return AbilityFactoryForChoice.ForChoiceAbilityInternal(name, cost, lambda targets, res, effect: operation(targets, res), conditions=conditions).SetFuncName('ForChoiceAbilityWithCost')
