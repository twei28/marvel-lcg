# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryReveal:
    @staticmethod
    def WhenCardWouldReveal(ability_type, reveal_to_player, which_card, operation, *, conditions = []):
        def check_who(effect, message):
            return Condition.CheckWhichPlayer(reveal_to_player, message.to_player, effect)
        def check_card_type(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        return Ability(ability_type, Message.WhenCardWouldReveal, [check_who, check_card_type, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhenPlayerRevealCard(ability_type, which_player, which_card, can_be_cancel, operation, *, from_encounter = None, conditions = []):
        def check_card_is_revealing(effect, message):
            face = message.trigger
            return face.CanResolveWhenRevealed()
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        def check_from_encounter(effect, message):
            if (from_encounter != None):
                if from_encounter:
                    return message.IsFromEncounterDeck()
                raise AssertionError(f'effect={effect!r}')
            return True
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_can_be_cancel(effect, message):
            if (can_be_cancel == 'Yes'):
                if message.cannot_be_cancel:
                    return False
                return True
            if can_be_cancel:
                return message.CanBeCancel(can_be_cancel, effect)
            return True
        return Ability(ability_type, Message.WhenPlayerRevealCard, [check_card_is_revealing, check_which_player, check_from_encounter, check_which_card, check_can_be_cancel, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhenCardRevealed(ability_type, which_card, operation, *, conditions = []):
        def check_which_card(effect, message):
            if (which_card == None):
                return True
            if (which_card == 'This'):
                return (effect.this == message.trigger)
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        return Ability(ability_type, Message.WhenCardRevealed, [check_which_card, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhenThisRevealed(condition, operation):
        def check_condition(effect, message):
            if (condition == 'Alter-Ego'):
                return message.GetToPlayer().IsAlterEgo()
            if (condition == 'Hero'):
                return message.GetToPlayer().IsHero()
            if (condition == None):
                return True
            return condition(effect, message)
        return AbilityFactoryReveal.WhenCardRevealed(AbilityType.WhenRevealed, 'This', operation, conditions=[Condition2.ThisIsTrigger, check_condition])
    @staticmethod
    def WhenThisObligationRevealed(operation):
        return Ability(AbilityType.WhenRevealed, Message.WhenCardRevealed, [Condition2.ThisIsTrigger], operation)
    @staticmethod
    def WhenThisObligationGiveToYou(operation):
        return Ability(AbilityType.NonKeyword, Message.WhenObligationGiveToPlayer, [Condition2.ThisIsTrigger], operation)
    @staticmethod
    def AfterYouResolveTreachery(ability_type, operation, *, conditions = []):
        from game.card.face.card_type import Treachery
        return Ability(ability_type, Message.AfterCardRevealed, [lambda effect, message: ((effect.GetInitiator() == message.GetToPlayer()) and Treachery.IsType(message.trigger)), *conditions], operation)
    @staticmethod
    def AfterPlayerRevealCard(ability_type, which_player, which_card, operation, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        return Ability(ability_type, Message.AfterCardRevealedEnd, [check_which_player, check_which_card, *conditions], operation, is_local=(which_card == 'This'))
