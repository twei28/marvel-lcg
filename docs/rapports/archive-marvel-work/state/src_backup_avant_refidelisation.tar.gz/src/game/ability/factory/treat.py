# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def TreatAsMinion(face, as_card_name, engage_player, effect, *, process = None):
    from game.ability.factory import AbilityFactory
    from game.card.factory import CardFactory
    from game.operate.effects import Effects
    from cards.database import CardsDB
    from game.card.face.card_type import Ally
    from game.card.face.card_type import Hero
    from game.card.face.card_type import Minion
    this = effect.this
    Unused(this)
    paper = CardFactory.FindCardPapers(as_card_name)[0]
    minion = CardFactory.CreateFace(paper, effect.world)
    if not (Ally.IsType(face)):
        if Hero.IsType(face):
            if Minion.IsType(minion):
                minion.pic_id = face.paper.card_id
                minion.ability.Add(*CardsDB.FindAbilities(paper.card_id, paper.pack, paper.set_name))
                minion.effect.face = minion
                CardFactory.FaceRegisterEffects(minion)
                minion = face.card.SwapCardFace(minion, effect)
                minion.printed_attack = face.printed_attack
                minion.printed_scheme = face.printed_thwart
                minion.ResetKeywords()
                if process:
                    process(minion, face, effect)
                minion.PutIntoPlay(engage_player, effect)
                effects = []
                def action(action_effect: 'Effect', action_message: 'Message2'):
                    Effects.UnRegister(effects)
                    minion.card.SwapCardFace(face, action_effect)
                    if face.IsInPlay():
                        if not (face.IsDefeated()):
                            face.PutIntoPlay(engage_player, effect)
                            return
                            return
                effects = [*minion.effect.RegisterTemp(AbilityFactory.AfterCardLeavePlay(AbilityType.Temp2, 'This', action), unregister_after_exec=False), *this.effect.RegisterTemp(AbilityFactory.WhenCardLeavePlay(AbilityType.Temp2, 'This', action, conditions=[lambda effect, message: (not minion.IsDefeated())]), AbilityFactory.WhenCardTreatAsIfBlank('This', action), unregister_after_exec=False)]
                return True
    if Minion.IsType(minion):
        minion.pic_id = face.paper.card_id
        minion.ability.Add(*CardsDB.FindAbilities(paper.card_id, paper.pack, paper.set_name))
        minion.effect.face = minion
        CardFactory.FaceRegisterEffects(minion)
        minion = face.card.SwapCardFace(minion, effect)
        minion.printed_attack = face.printed_attack
        minion.printed_scheme = face.printed_thwart
        minion.ResetKeywords()
        if process:
            process(minion, face, effect)
        minion.PutIntoPlay(engage_player, effect)
        effects = []
        def action(action_effect: 'Effect', action_message: 'Message2'):
            Effects.UnRegister(effects)
            minion.card.SwapCardFace(face, action_effect)
            if face.IsInPlay():
                if not (face.IsDefeated()):
                    face.PutIntoPlay(engage_player, effect)
                    return
                    return
        effects = [*minion.effect.RegisterTemp(AbilityFactory.AfterCardLeavePlay(AbilityType.Temp2, 'This', action), unregister_after_exec=False), *this.effect.RegisterTemp(AbilityFactory.WhenCardLeavePlay(AbilityType.Temp2, 'This', action, conditions=[lambda effect, message: (not minion.IsDefeated())]), AbilityFactory.WhenCardTreatAsIfBlank('This', action), unregister_after_exec=False)]
        return True
    return False
class AbilityFactoryTreat:
    @staticmethod
    def TakeControlOfAttachedMinion(as_card_name):
        from game.operate.faces import Faces
        from game.ability.factory import AbilityFactory
        from game.card.face.card_type import Minion
        def mind_control(effect: 'Effect', message: 'Message.AfterCardAttachTo'):
            initiator = effect.GetInitiator()
            minion = message.to_face.CastTo(Minion)
            Faces.TreatAsAlly(minion, as_card_name, initiator, effect)
        return AbilityFactory.AfterCardGainUpgrade(AbilityType.NonKeyword, 'This', Minion, mind_control)
    @staticmethod
    @deprecated('TreatAttachedCardAsMinion')
    def TreatAttachedCardAsMinionNew(as_card_name, process = None):
        from game.ability.factory import AbilityFactory
        from game.card.face.card_type import Ally
        def mind_control(effect: 'Effect', message: 'Message.AfterCardAttachTo') -> None:
            player = message.to_face.CastTo(Ally).GetControlByPlayer()
            TreatAsMinion(message.to_face, as_card_name, player, effect, process=process)
        return AbilityFactory.AfterCardGainUpgrade(AbilityType.NonKeyword, 'This', Ally, mind_control)
    @staticmethod
    @deprecated('TreatAttachedCardAsMinion')
    def TreatAttachedHeroAsMinionNew(as_card_name, process = None):
        from game.ability.factory import AbilityFactory
        from game.card.face.card_type import Hero
        def mind_control(effect: 'Effect', message: 'Message.AfterCardAttachTo') -> None:
            player = message.to_face.CastTo(Hero).GetControlByPlayer()
            TreatAsMinion(message.to_face, as_card_name, player, effect, process=process)
        return AbilityFactory.AfterCardGainUpgrade(AbilityType.NonKeyword, 'This', Hero, mind_control)
    TF_ = TypeVar('TF_', bound='Hero|Ally')
    @staticmethod
    def TreatAttachedCardAsMinion(which_card, as_card_name, process = None):
        def treat_attached_ally_as_minion(effect, face, diff):
            from game.card.factory import CardFactory
            from game.card.face.card_type import Minion
            from game.operate.faces import Faces
            from cards.database import CardsDB
            this = effect.this
            Unused(this)
            if (diff == 1):
                player = face.GetControlByPlayer()
                face = face.CastTo(which_card)
                paper = CardFactory.FindCardPapers(as_card_name)[0]
                minion = CardFactory.CreateFace(paper, effect.world)
                minion.pic_id = face.paper.card_id
                minion.SetName(face.printed_name)
                minion.SetSubtitle(face.printed_subtitle)
                if not (Minion.IsType(minion)):
                    raise AssertionError
                minion.printed_attack = face.printed_attack
                minion.printed_scheme = face.printed_thwart
                minion = face.card.SwapCardFace(minion, effect, no_detach=True)
                if not (minion.IsInPlay()):
                    return
                minion.ability.Add(*CardsDB.FindAbilities(paper.card_id, paper.pack, paper.set_name))
                minion.effect.face = minion
                CardFactory.FaceRegisterEffects(minion)
                minion.ResetKeywords()
                if process:
                    process(minion, face, effect)
                minion.PutIntoPlay(player, effect)
                return
            player = face.CastTo(Minion).GetEngagedPlayer()
            face = face.card.SwapBackToPrintedCard(effect)
            if face.IsInPlay():
                if not (face.IsDefeated()):
                    face.PutIntoPlay(player, effect)
                    return
            Faces.DiscardAll([face], effect)
        from game.ability.factory.asset_helper import GiveKeywordToAttachWhenApplyThisInternal
        return GiveKeywordToAttachWhenApplyThisInternal(apply=treat_attached_ally_as_minion, ignore_flip=False).SetFuncName('TreatAttachedCardAsMinion')
