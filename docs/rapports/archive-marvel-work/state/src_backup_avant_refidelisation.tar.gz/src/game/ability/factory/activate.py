# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryActivate:
    @staticmethod
    def WhenEnemyWouldActivate(ability_type, which_enemy, operation, *, conditions = [], power = None, during_villain_step = None):
        def check_which_enemy(effect, message):
            return Condition.CheckWhichCard(which_enemy, message.trigger, effect)
        def check_power(effect, message):
            if (power == None):
                return True
            return (power == message.power)
        def check_during_villain_step(effect, message):
            if not (during_villain_step):
                return True
            return message.world.phase.IsVillainPhaseStep(during_villain_step)
        return Ability(ability_type, Message.WhenEnemyWouldActivate, [check_which_enemy, check_power, check_during_villain_step, *conditions], operation, is_local=(which_enemy == 'This'))
    @staticmethod
    def WhenEnemyActivateAgainstYou(ability_type, which_enemy, operation, *, conditions = []):
        def check_which_enemy(effect, message):
            return Condition.CheckWhichCard(which_enemy, message.trigger, effect)
        return Ability(ability_type, Message.WhenEnemyActivateAgainstYou, [lambda effect, message: (message.to_player != None), check_which_enemy, *conditions], operation, is_local=(which_enemy == 'This'))
    @staticmethod
    def AfterEnemyActivatesAgainstYou(ability_type, which_enemy, operation, *, conditions = []):
        return AbilityFactoryActivate.AfterEnemyActivationEnd(ability_type, which_enemy, operation, conditions=conditions, is_against_you=True)
    @staticmethod
    def AfterEnemyActivationEnd(ability_type, which_enemy, operation, *, conditions = [], is_against_you = None):
        def check_which_enemy(effect, message):
            return Condition.CheckWhichCard(which_enemy, message.trigger, effect)
        def check_against_you(effect, message):
            if (is_against_you == None):
                return True
            return (is_against_you == Condition.AgainstYou(effect, message.activate_message))
        return Ability(ability_type, Message.AfterEnemyActivationEnd, [check_which_enemy, check_against_you, *conditions], operation, is_local=(which_enemy == 'This'))
