# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryCounter:
    @staticmethod
    def ThisEnterPlayWithCounters(counters, name):
        from game.card.face.attribute.can_place_counter import CanPlaceCounter
        from game.ability.factory import AbilityFactory
        from game.operate.faces import Faces
        from game.operate.worlds import Worlds
        def with_counters(effect: Effect, message: Message.AfterCardEnterPlay):
            this = effect.this.CastTo(CanPlaceCounter)
            if isinstance(counters, int):
                new_counters = counters
            else:
                new_counters = (int(counters.replace('*', '')) * Worlds.GetPlayerNumIcon(effect))
            Faces.PlaceCountersOn([this], new_counters, name, effect)
        return AbilityFactory.AfterCardEnterPlay(AbilityType.NonKeyword, 'This', with_counters)
    @staticmethod
    def AfterCardRemovedCounter(ability_type, which_card, counter_name, operation, *, is_last_counter = None, conditions = []):
        from game.card.face.attribute.can_place_counter import CanPlaceCounter
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_is_last_counter(effect, message):
            if (is_last_counter == None):
                return True
            left_counter = message.trigger.CastTo(CanPlaceCounter).GetCounters(message.counter_name)
            if is_last_counter:
                return (left_counter == 0)
            return (left_counter != 0)
        def check_counter_name(effect, message):
            if (counter_name == None):
                return True
            return (message.counter_name == counter_name)
        return Ability(ability_type, Message.AfterCardRemovedCounter, [check_which_card, check_is_last_counter, check_counter_name, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def IfThereIsNoCounterHere(counter_name, operation):
        return AbilityFactoryCounter.AfterCardRemovedCounter(AbilityType.NonKeyword, 'This', counter_name, operation, is_last_counter=True)
    @staticmethod
    def WhenTheLastCounterIsRemovedFromHere(ability_type, counter_name, operation):
        return AbilityFactoryCounter.AfterCardRemovedCounter(ability_type, 'This', counter_name, operation, is_last_counter=True)
    @staticmethod
    def AfterCounterPlacedOn(ability_type, which_card, counter_name, operation, *, conditions = [], at_least = None):
        from game.card.face.attribute.can_place_counter import CanPlaceCounter
        from game.operate.worlds import Worlds
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_token_name(effect, message):
            if counter_name:
                return (message.counter_name == counter_name)
            return True
        def check_at_least(effect, message):
            if at_least:
                this = message.trigger.CastTo(CanPlaceCounter)
                if isinstance(at_least, str):
                    counter = Worlds.ConvertPerPlayerIconToInt(at_least, effect)
                else:
                    if isinstance(at_least, int):
                        counter = at_least
                    else:
                        counter = at_least(effect)
            return True
        return Ability(ability_type, Message.AfterCardPlacedCounter, [check_which_card, check_token_name, check_at_least, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def IfThereAreAtLeastCounterHere(at_least, counter_name, operation, *, conditions = []):
        return AbilityFactoryCounter.AfterCounterPlacedOn(AbilityType.NonKeyword, 'This', counter_name, operation, conditions=conditions, at_least=at_least)
    @staticmethod
    def IfCardHasOrMoreCounters(which_card, at_least, counter_name, operation, *, conditions = []):
        return AbilityFactoryCounter.AfterCounterPlacedOn(AbilityType.NonKeyword, which_card, counter_name, operation, conditions=conditions, at_least=at_least)
    @staticmethod
    def WhenCardWouldBePlacedCounter(ability_type, which_face, counter_name, operation, *, conditions = []):
        def check_to_where(effect, message):
            if (which_face == None):
                return True
            if (which_face == 'Another'):
                return (effect.this != message.trigger)
            if (which_face == 'This'):
                return (effect.this == message.trigger)
            return which_face.Check(message.trigger)
        def check_counter_name(effect, message):
            if counter_name:
                return (message.counter_name == counter_name)
            return True
        return Ability(ability_type, Message.WhenCardWouldBePlacedCounter, [check_to_where, check_counter_name, *conditions], operation, is_local=(which_face == 'This'))
    @staticmethod
    def MaxCounterHere(size, counter_name, *, conditions = []):
        from game.ability.factory import AbilityFactory
        def action(effect, message):
            message.maximum = size
        return AbilityFactory.WhenCardWouldBePlacedCounter(AbilityType.NonKeyword, 'This', counter_name, action, conditions=conditions)
