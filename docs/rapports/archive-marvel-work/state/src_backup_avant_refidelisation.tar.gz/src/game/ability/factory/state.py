# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryState:
    @staticmethod
    def AfterCardFlipToThisSide(ability_type, operation, *, conditions = []):
        return AbilityFactoryState.AfterFlipToThisFace(ability_type, operation, conditions=conditions)
    @staticmethod
    def AfterFlipToThisFace(ability_type, operation, *, conditions = []):
        which_card = 'This'
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        return Ability(ability_type, Message.AfterCardFlip, [lambda effect, message: ((effect.this == message.to_face) and effect.this.card.IsOnField()), check_which_card, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhileThisStateUpdate(ability_type, operation, include_flip = True, include_set_as = True, include_advance = True, include_enter_play = False, conditions = []):
        which_card = 'This'
        events = Message.AfterCardLeavePlay
        if include_flip:
            events = (events | Message.WhenCardFlip)
        if include_set_as:
            events = (events | Message.WhenCardSetAs)
        if include_advance:
            events = (events | Message.WhenVillainAdvance)
        if include_enter_play:
            events = (events | Message.WhenCardEnterPlay)
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        return Ability(ability_type, events, [check_which_card, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhenCardFlip(ability_type, which_card, operation, *, conditions = []):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        ability = Ability(ability_type, Message.WhenCardFlip, [check_which_card, *conditions], operation, is_local=(which_card == 'This'))
        if (which_card == 'This'):
            ability.NoOutOfPlayLimit()
        return ability
    @staticmethod
    def WhenCardFlipToThisSide(ability_type, which_card, operation, *, conditions = []):
        return AbilityFactoryState.WhenCardFlip(ability_type, which_card, operation, conditions=[lambda effect, message: ((effect.this == message.to_face) and effect.this.card.IsOnField()), *conditions])
    @staticmethod
    def WhenCardFlipOrLeavePlay(ability_type, which_card, operation, *, conditions = []):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_was_in_play(effect, message):
            if isinstance(message, Message.AfterCardLeavePlay):
                return True
            return message.trigger.IsInPlay()
        def check_no_swapping(effect, message):
            return (not message.by_swapping)
        return Ability(ability_type, (Message.AfterCardLeavePlay | Message.WhenCardFlip), [check_which_card, check_was_in_play, check_no_swapping, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhenCardWouldReady(ability_type, which_card, operation, *, control_by = 'AnyPlayer', by_effect_face = None, conditions = []):
        from game.effect.rule import DebugRule
        def check_which_card(effect: Effect, message: Message.WhenCardWouldReady):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_control_by(effect: Effect, message: Message.WhenCardWouldReady):
            return Condition.CheckWhichPlayer(control_by, message.trigger.GetControlBy(), effect)
        def check_is_by_effect_face(effect, message):
            if (by_effect_face == None):
                return True
            if isinstance(message.by_effect, DebugRule):
                return False
            return by_effect_face.Check(message.by_effect.this)
        return Ability(ability_type, Message.WhenCardWouldReady, [check_which_card, check_control_by, check_is_by_effect_face, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def CardCannotReady(which_card, *, conditions = [], control_by = 'AnyPlayer', by_effect_face = None):
        def cannot_ready(effect: Effect, message: Message.WhenCardWouldReady):
            message.SetBeInstead(effect)
        return [AbilityFactoryState.WhenCardWouldReady(AbilityType.NonKeyword, which_card, cannot_ready, conditions=[*conditions], control_by=control_by, by_effect_face=by_effect_face)]
    @staticmethod
    def AfterCardReady(ability_type, which_card, operation, *, conditions = [], by_player):
        def check_which_card(effect: Effect, message: Message.AfterCardReady):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_by_player(effect: Effect, message: Message.AfterCardReady):
            return Condition.ThisIsYou(effect, message.by_effect.initiator)
        return Ability(ability_type, Message.AfterCardReady, [check_which_card, check_by_player, *conditions], operation, is_local=(which_card == 'This'))
