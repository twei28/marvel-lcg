# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryGet:
    @staticmethod
    def GetMainScheme(get_main_scheme, *, conditions = []):
        def set_mains_cheme(effect: Effect, message: Message.GettingMainScheme):
            scheme = get_main_scheme(effect, message)
            if scheme:
                message.SetReturn(scheme)
                return
        return Ability(AbilityType.NonKeyword, Message.GettingMainScheme, conditions, set_mains_cheme)
    @staticmethod
    def GetScenario(set_scenario, *, conditions = []):
        def get_scenario(effect: Effect, message: Message.GettingScenario):
            villain = set_scenario(effect, message)
            if villain:
                message.SetReturn(villain)
                return
        return Ability(AbilityType.NonKeyword, Message.GettingScenario, conditions, get_scenario)
    @staticmethod
    def GetVillain(set_villain, *, conditions = []):
        def get_villain(effect: Effect, message: Message.GettingVillain):
            villain = set_villain(effect, message)
            if villain:
                message.SetReturn(villain)
                return
        return Ability(AbilityType.NonKeyword, Message.GettingVillain, conditions, get_villain)
