# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryEnhanceSelf:
    @staticmethod
    def ThisGainTraitsOfEachCardInPlay(which_card: CardType) -> Ability:
        from game.ability.factory import AbilityFactory
        from game.operate.worlds import Worlds
        from game.operate.effects import Effects
        change_on_event = OnEvent.Trait(which_card)
        def process(effect, traits, diff):
            this = effect.this
            Unused(this)
            if traits:
                this.GainTraits(diff, traits, effect)
                return
        def when_this_valid(effect: Effect, message: Message2):
            this = effect.this
            class SaveTraits:
                def __init__(self):
                    self.last_face_traits = {}
                    self.curr_face_traits = {}
                    self.can_update = True
                def ShiftTraits(self):
                    self.last_face_traits = self.curr_face_traits.copy()
                    self.curr_face_traits = {}
                    self.can_update = True
                @property
                def curr_traits(self):
                    return [y for y in self.curr_face_traits]
                @property
                def last_traits(self):
                    return [y for y in self.last_face_traits]
                @property
                def gain_traits(self):
                    traits = []
                    for trait in self.curr_traits:
                        if (trait not in self.last_traits):
                            traits.append(trait)
                    return traits
                @property
                def lose_traits(self):
                    traits = []
                    for trait in self.last_traits:
                        if (trait not in self.curr_traits):
                            traits.append(trait)
                    return traits
            store = SaveTraits()
            effect.this.card.ui.ResetTempEffectBy(effect)
            for face in Worlds.GetOnFieldCards(effect):
                if Condition.CheckWhichCard(which_card, face, effect):
                    store.last_face_traits[face] = face.traits
                    effect.this.card.ui.SetTempEffectBy(effect, face)
                    process(effect, store.last_face_traits[face], 1)
            def update_valid():
                effect.this.card.ui.ResetTempEffectBy(effect)
                process(effect, store.lose_traits, -1)
                process(effect, store.gain_traits, 1)
                store.ShiftTraits()
            def try_update_valid(valid_effect: Effect, message: Message2):
                if not (isinstance(message, (((Message.AfterCardGainTrait | Message.AfterCardLoseTrait) | Message.AfterCardLeavePlay) | Message.AfterCardEnterPlay))):
                    raise AssertionError
                face = message.trigger
                if isinstance(message, Message.AfterCardLeavePlay):
                    traits = []
                else:
                    traits = face.traits
                if not (store.can_update):
                    raise AssertionError
                store.curr_face_traits[face] = traits
                for back_face in face.card.back_faces:
                    if (back_face in store.curr_face_traits):
                        store.curr_face_traits[back_face] = []
                if not ((face not in store.last_face_traits)):
                    if (store.last_face_traits[face] != store.curr_face_traits[face]):
                        store.can_update = False
                        update_valid()
                        return
                store.can_update = False
                update_valid()
                return
                store.can_update = True
            loop_check_effects = this.effect.Registers(*Condition.GetEventAbilities(change_on_event, AbilityType.Temp0, lambda effect, message: True, try_update_valid))
            def when_this_invalid(invalid_effect: Effect, message: Message2):
                Effects.UnRegister(loop_check_effects)
                effect.this.card.ui.ResetTempEffectBy(effect)
                store.last_face_traits = {}
                process(effect, store.curr_traits, -1)
            this.effect.RegisterTemp(AbilityFactory.WhileThisStateUpdate(AbilityType.Temp0, when_this_invalid), unregister_after_exec=True)
        return AbilityFactory.WhenCardEnterPlay(AbilityType.Temp0, 'This', when_this_valid)
    @staticmethod
    def ThisGainKeywordWhileFaceIsInPlay(while_face_is_in_play = None, *, patrol = None, health = None, quickstrike = None, amplify = None, crisis = None, hazard = None, change_on_event = OnEvent.NONE):
        from game.operate.worlds import Worlds
        if (change_on_event == OnEvent.NONE):
            change_on_event = OnEvent.CardInPlay(while_face_is_in_play)
        def check(effect, ui):
            face = Worlds.FindCardOnField(effect, while_face_is_in_play, game_area=effect.this.card.game_area)
            if face:
                ui.append(face)
                return 1
            return 0
        def process(effect, unit, diff, curr):
            unit.Gain(effect, diff, health=health, quickstrike=quickstrike, amplify=amplify, crisis=crisis, patrol=patrol, hazard=hazard)
        from game.ability.factory.enhance_self_helper import ThisGainKeywordInternal
        return ThisGainKeywordInternal(change_on_event, check, process)
    @staticmethod
    def IfCardIsNotInPlay(ability_type, while_face_is_not_in_play, operation):
        from game.operate.worlds import Worlds
        change_on_event = OnEvent.CardInPlay(while_face_is_not_in_play)
        if not ((ability_type == AbilityType.NonKeyword)):
            raise AssertionError
        def check(effect, ui):
            face = Worlds.FindCardOnField(effect, while_face_is_not_in_play, game_area=effect.this.card.game_area)
            if face:
                return 0
            return 1
        def process(effect, unit, diff, curr):
            if curr:
                operation(effect)
                return
        from game.ability.factory.enhance_self_helper import ThisGainKeywordInternal
        return ThisGainKeywordInternal(change_on_event, check, process)
    @staticmethod
    def ThisGainKeywordWhileFaceIsNotInPlay(while_face_is_not_in_play = None, *, acceleration_icon = None):
        from game.operate.worlds import Worlds
        change_on_event = OnEvent.CardInPlay(while_face_is_not_in_play)
        def check(effect, ui):
            face = Worlds.FindCardOnField(effect, while_face_is_not_in_play, game_area=effect.this.card.game_area)
            if face:
                return 0
            return 1
        def process(effect, unit, diff, curr):
            unit.Gain(effect, diff, acceleration_icon=acceleration_icon)
        from game.ability.factory.enhance_self_helper import ThisGainKeywordInternal
        return ThisGainKeywordInternal(change_on_event, check, process)
    @staticmethod
    def ThisGainKeywordWhileFaceIsInVictoryDisplay(while_face_is_in_victory_display = None, *, acceleration_icon = None, villainous = None):
        from game.operate.worlds import Worlds
        change_on_event = OnEvent.Victory(while_face_is_in_victory_display)
        def check(effect, ui):
            faces = Worlds.VictoryDisplay(effect).FindCards(while_face_is_in_victory_display)
            if faces:
                ui.extend(faces)
                return 1
            return 0
        def process(effect, unit, diff, curr):
            unit.Gain(effect, diff, acceleration_icon=acceleration_icon, villainous=villainous)
        from game.ability.factory.enhance_self_helper import ThisGainKeywordInternal
        return ThisGainKeywordInternal(change_on_event, check, process)
    @staticmethod
    def ThisGainKeywordForEachFaceInPlay(for_each_face_in_play = None, *, thwart = None, retaliate = None, attack = None, scheme = None, change_on_event = OnEvent.NONE):
        from game.operate.worlds import Worlds
        if (change_on_event == OnEvent.NONE):
            change_on_event = OnEvent.CardInPlay(for_each_face_in_play)
        def check(effect, ui):
            faces = Worlds.FindCardsOnField(effect, for_each_face_in_play, game_area=effect.this.card.game_area)
            if faces:
                ui.extend(faces)
                return len(faces)
            return 0
        def process(effect, unit, diff, curr):
            unit.Gain(effect, diff, thwart=thwart, retaliate=retaliate, attack=attack, scheme=scheme)
        from game.ability.factory.enhance_self_helper import ThisGainKeywordInternal
        return ThisGainKeywordInternal(change_on_event, check, process)
    @staticmethod
    def ThisGainIncite(check_fn = lambda effect: 1, *, incite = None, change_on_event = OnEvent.NONE):
        def operation(effect: Effect, message: Message.WhenCardResetKeyword):
            from game.card.face.base import EncounterNonVillainCard
            this = effect.this
            if not (EncounterNonVillainCard.IsType(this)):
                raise AssertionError
            if (incite != None):
                diff = check_fn(effect)
                this.GainIncite((diff * incite), effect)
                return
        return [Ability(AbilityType.NonKeyword, Message.WhenCardResetKeyword, [Condition2.ThisIsTrigger], operation).NoOutOfPlayLimit().NoGameAreaLimit()]
    @staticmethod
    def ThisGainKeyword(check_fn = lambda effect, ui: 1, *, attack = None, thwart = None, scheme = None, health = None, recover = None, trait = None, retaliate = None, restricted = None, hand_size = None, consider_as = None, quickstrike = None, stalwart = None, patrol = None, amplify = None, crisis = None, surge = None, hinder = None, target_threat = None, toughness = None, additional_cost_for_basic_attack = None, attack_consequential_damage = None, thwart_consequential_damage = None, acceleration_icon = None, hazard = None, control_additional_restricted = None, change_on_event = OnEvent.NONE):
        def process(effect, unit, diff, curr):
            unit.Gain(*(effect, diff), **{'attack': attack, 'thwart': thwart, 'health': health, 'recover': recover, 'trait': trait, 'retaliate': retaliate, 'restricted': restricted, 'hand_size': hand_size, 'scheme': scheme, 'consider_as': consider_as, 'quickstrike': quickstrike, 'stalwart': stalwart, 'amplify': amplify, 'crisis': crisis, 'patrol': patrol, 'surge': surge, 'hinder': hinder, 'target_threat': target_threat, 'toughness': toughness, 'additional_cost_for_basic_attack': additional_cost_for_basic_attack, 'attack_consequential_damage': attack_consequential_damage, 'thwart_consequential_damage': thwart_consequential_damage, 'acceleration_icon': acceleration_icon, 'hazard': hazard, 'control_additional_restricted': control_additional_restricted})
        from game.ability.factory.enhance_self_helper import ThisGainKeywordInternal
        return ThisGainKeywordInternal(change_on_event, check_fn, process)
    @staticmethod
    def ThisSetKeyword(check_fn = lambda effect, ui: (1, False), *, attack = None, scheme = None, change_on_event):
        def process(effect, unit, diff, curr):
            unit.FaceSet(effect, curr, attack=attack, scheme=scheme)
        from game.ability.factory.enhance_self_helper import ThisGainKeywordInternal
        return ThisGainKeywordInternal(change_on_event, check_fn, process)
