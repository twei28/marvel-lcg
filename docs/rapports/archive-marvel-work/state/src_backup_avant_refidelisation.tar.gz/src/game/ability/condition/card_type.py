# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from game.card.face import *
from game.effect import *
class ConditionCardType:
    __annotations__ = {}
    SINGLE_CARD_TYPE = Literal[('This', 'ThisFace', 'YouPlayer', 'Character', 'Player')]
    CARD_TYPE_PREFIX = Literal[('Another', 'YouControl')]
    CARD_TYPE_EX = Literal[('AnotherScheme', 'AnotherFriend', 'YourHero', 'YourIdentity', 'YourAlly', 'YouControlAlly', 'YouControlCharacter', 'AttachedIdentity', 'AttachedCard', 'AttachedHero', 'AttachedAlly', 'AttachedEnemy', 'AttachedMinion', 'AttachedVillain', 'AttachedScheme', 'AttachedCharacter', 'AttachedSideScheme', 'AttachedLeader', 'EngagedIdentity', 'EngagedMinion', 'AttackingEnemy', 'EnemyLeader')]
    CARD_TYPE = (((((((Tuple[(CARD_TYPE_PREFIX, 'CardFinder')] | CARD_TYPE_EX) | SINGLE_CARD_TYPE) | Type['CardFace']) | 'CardFace') | 'CardFinder') | None) | Sequence['CardFace'])
    CARD_TYPE: TypeAlias
    CARD_TYPE_MIN = ((((Literal[('YourIdentity', 'EngagedIdentity', 'EngagedMinion')] | Type['CardFace']) | 'CardFinder') | Literal[('This', 'Character', 'Player')]) | None)
    CARD_TYPE_MIN: TypeAlias
    @staticmethod
    def GetYouRule(check_rule, *, identity):
        if (check_rule != 'You'):
            return check_rule
        if identity:
            return 'YourIdentity'
        return 'YouPlayer'
    @staticmethod
    def CheckWhichCard(check_rule_param, check_faces, from_effect, check_status = False, size = 1):
        from game.card.face.card_face import CardFace
        from game.card.face.card_type import Hero
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Identity
        from game.card.face.card_type import Minion
        from game.card.face.card_type import Attachment
        from game.card.face.card_type import Upgrade
        from game.card.face.card_type import Leader
        from game.card.face.attribute.can_attach import CanAttach
        from game.card.card_finder import CardFinder
        from game.card.face.base import Villain
        from game.card.face.base import Enemy
        from game.card.face.base import Unit2
        from game.card.face.base import SchemeSide2
        from game.card.face.base import Scheme2
        from game.card.face.base import Friend
        from game.player import Player
        from game.ability.condition import Condition
        from game.operate.referential import Referential
        from game.operate.worlds import Worlds
        from game.selector import Select
        def is_sequence_of_card_face(x):
            if not (isinstance(x, list)):
                return False
            for element in x:
                if not (isinstance(element, CardFace)):
                    return False
            return True
        def invoke_check_card(check_rule, face):
            if (check_rule == None):
                return True
            if isinstance(check_rule, CardFinder):
                if check_rule:
                    return Referential.Check(check_rule, face, from_effect)
                return True
            if isinstance(check_rule, CardFace):
                if check_status:
                    return (check_rule.card == face.card)
                return (check_rule == face)
            if is_sequence_of_card_face(check_rule):
                return (face in check_rule)
            if (check_rule == 'This'):
                return (from_effect.this.card == face.card)
            if (check_rule == 'ThisFace'):
                return (from_effect.this == face)
            if (check_rule == 'YouPlayer'):
                return Condition.ThisIsYou(from_effect, face)
            if (check_rule == 'Character'):
                return Unit2.IsType(face)
            if (check_rule == 'Player'):
                return Player.IsType(face.GetControlByOrOwner())
            def check_you():
                if from_effect.this.card.area.flags.is_obligations_area:
                    return (face == from_effect.this.GetBindFace())
                if from_effect.initiator.IsScenario():
                    return Player.IsType(face.GetControlByOrOwner())
                return (Select.GetYou(from_effect) == face.GetControlByOrOwner())
            def check_another():
                if not (Upgrade.IsType(from_effect.this)):
                    if Attachment.IsType(from_effect.this):
                        return (from_effect.this.bind_face != face)
                return (from_effect.this.bind_face != face)
                return (from_effect.this != face)
            def check_attached():
                return Condition.ThisAttachedTo(from_effect, face)
            def check_engaged():
                if Minion.IsType(from_effect.this):
                    player = from_effect.this.GetEngagedPlayer()
                    return (player == face.GetControlByOrOwner())
                player = None
                if Attachment.IsType(from_effect.this):
                    player = from_effect.this.GetBindFace().GetControlByOrOwner()
                if Identity.IsType(from_effect.this):
                    player = from_effect.this.GetControlByPlayer()
                if isinstance(player, Player):
                    return (Minion.IsType(face) and (face.engaged_player == player))
                return False
            def check_attacking():
                from game.message.message_type import AttackerMessageInternal
                if isinstance(from_effect.bind_message, AttackerMessageInternal):
                    return (face == from_effect.bind_message.attacker)
                return False
            if (check_rule == 'AnotherScheme'):
                return (check_another() and Scheme2.IsType(face))
            if (check_rule == 'AnotherFriend'):
                return (check_another() and Friend.IsType(face))
            if (check_rule == 'YourHero'):
                return (check_you() and Hero.IsType(face))
            if (check_rule == 'YourIdentity'):
                return (check_you() and Identity.IsType(face))
            if (check_rule == 'YourAlly'):
                return (check_you() and Ally.IsType(face))
            if (check_rule == 'YouControlAlly'):
                return (check_you() and Ally.IsType(face))
            if (check_rule == 'YouControlCharacter'):
                return (check_you() and Unit2.IsType(face))
            if (check_rule == 'AttachedIdentity'):
                return (check_attached() and Identity.IsType(face))
            if (check_rule == 'AttachedCard'):
                return (check_attached() and CardFace.IsType(face))
            if (check_rule == 'AttachedHero'):
                return (check_attached() and Hero.IsType(face))
            if (check_rule == 'AttachedAlly'):
                return (check_attached() and Ally.IsType(face))
            if (check_rule == 'AttachedEnemy'):
                return (check_attached() and Enemy.IsType(face))
            if (check_rule == 'AttachedMinion'):
                return (check_attached() and Minion.IsType(face))
            if (check_rule == 'AttachedVillain'):
                if not (check_attached()):
                    return False
                if CanAttach.IsType(from_effect.this):
                    if from_effect.this.is_refers_to_the_villain_refers_to_attached:
                        return (from_effect.this.GetBindFace() == face)
                return Villain.IsType(face)
            if (check_rule == 'AttachedScheme'):
                return (check_attached() and Scheme2.IsType(face))
            if (check_rule == 'AttachedCharacter'):
                return (check_attached() and Unit2.IsType(face))
            if (check_rule == 'AttachedSideScheme'):
                return (check_attached() and SchemeSide2.IsType(face))
            if (check_rule == 'AttachedLeader'):
                return (check_attached() and Leader.IsType(face))
            if (check_rule == 'EngagedIdentity'):
                return (check_engaged() and Identity.IsType(face))
            if (check_rule == 'EngagedMinion'):
                return (check_engaged() and Minion.IsType(face))
            if (check_rule == 'AttackingEnemy'):
                return (check_attacking() and Enemy.IsType(face))
            if (check_rule == 'EnemyLeader'):
                return Leader.IsType(face)
            if isinstance(check_rule, tuple):
                if not (isinstance(check_rule, str)):
                    ex_prefix = check_rule[0]
                    ex_finder = check_rule[1]
                    def check_ex_rule():
                        if isinstance(ex_prefix, CardFace):
                            raise AssertionError
                        if (ex_prefix == 'Another'):
                            return check_another()
                        if not ((ex_prefix == 'YouControl')):
                            if (ex_prefix == 'Your'):
                                return check_you()
                        return check_you()
                        if (ex_prefix == 'Attached'):
                            return check_attached()
                        if (ex_prefix == 'Engaged'):
                            return check_engaged()
                        if (ex_prefix == 'Attacking'):
                            return check_attacking()
                        raise AssertionError
                    if not (check_ex_rule()):
                        return False
                    if (ex_finder == 'Character'):
                        return Unit2.IsType(face)
                    if isinstance(ex_finder, CardFace):
                        raise AssertionError
                    return ex_finder.Check(face)
            if isinstance(check_rule, Sequence):
                raise AssertionError
            if CanAttach.IsType(from_effect.this):
                if from_effect.this.is_refers_to_the_villain_refers_to_attached:
                    if (check_rule == Villain):
                        return True
            return check_rule.IsType(face)
        if (check_rule_param == None):
            return True
        if (check_faces == None):
            return False
        if isinstance(check_faces, CardFace):
            if not ((size == 1)):
                raise AssertionError
            return invoke_check_card(check_rule_param, check_faces)
        checked = 0
        if isinstance(size, str):
            size = Worlds.ConvertPerPlayerIconToInt(size, from_effect)
        for face in check_faces:
            if invoke_check_card(check_rule_param, face):
                checked = (checked + 1)
            if (checked >= size):
                return True
        return False
