# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.ability.ability_type import AbilityType
from game.ability.ability_type import TimingPriority
from game.ability.ability import Ability
Unused(AbilityType)
Unused(TimingPriority)
Unused(Ability)
from game.ability.cost_func import CostFunc
Unused(CostFunc)
