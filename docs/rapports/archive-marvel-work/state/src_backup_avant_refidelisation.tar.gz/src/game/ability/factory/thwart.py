# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryThwart:
    @staticmethod
    def WhenUnitThwartScheme(ability_type, who_make_thwart, operation, *, which_card_be_thwart = None, is_basic_thwart = None, conditions = []):
        def check_who_make_thwart(effect, message):
            return Condition.CheckWhichCard(who_make_thwart, message.trigger, effect)
        def check_which_card_be_thwart(effect, message):
            return Condition.CheckWhichCard(which_card_be_thwart, message.scheme, effect)
        def check_is_basic_thwart(effect, message):
            if (is_basic_thwart == None):
                return True
            return (is_basic_thwart == message.IsBasicThwart())
        return Ability(ability_type, Message.WhenSchemeBeingThwart, [check_which_card_be_thwart, check_is_basic_thwart, check_who_make_thwart, *conditions], operation, is_local=((who_make_thwart == 'This') or (which_card_be_thwart == 'This')))
    @staticmethod
    def WhenUnitWouldThwart(ability_type, who_make_thwart, operation, *, thwarted_scheme = None, is_basic_thwart = None, conditions = []):
        return AbilityFactoryThwart.WhenUnitMakeThwart(ability_type, who_make_thwart, operation=operation, against_scheme=thwarted_scheme, is_basic_thwart=is_basic_thwart, conditions=conditions)
    @staticmethod
    def WhenUnitMakeThwart(ability_type, who_make_thwart, against_scheme, operation, *, is_basic_thwart = None, conditions = []):
        def check_who_make_thwart(effect, message):
            rule = Condition.GetYouRule(who_make_thwart, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        def check_which_card_be_thwart(effect, message):
            return Condition.CheckWhichCard(against_scheme, message.schemes, effect)
        def check_is_basic_thwart(effect, message):
            if (is_basic_thwart == None):
                return True
            return (is_basic_thwart == message.IsBasicThwart())
        return Ability(ability_type, Message.WhenUnitWouldThwart, [check_who_make_thwart, check_which_card_be_thwart, check_is_basic_thwart, *conditions], operation, is_local=((who_make_thwart == 'This') or (against_scheme == 'This')))
    @staticmethod
    def AfterUnitThwartScheme(ability_type, who_thwart, target_scheme, operation, *, remove_threat = None, is_basic_thwart = None, conditions = []):
        def check_who(effect, message):
            return Condition.CheckWhichCard(who_thwart, message.trigger, effect)
        def check_target_scheme(effect, message):
            return Condition.CheckWhichCard(target_scheme, message.scheme, effect)
        def check_remove_threat(effect, message):
            if (remove_threat == None):
                return True
            return (message.remove_threat > 0)
        def check_is_basic_thwart(effect, message):
            if (is_basic_thwart == None):
                return True
            return (is_basic_thwart == message.IsBasicThwart())
        return Ability(ability_type, Message.AfterUnitThwartScheme, [check_who, check_target_scheme, check_remove_threat, check_is_basic_thwart, *conditions], operation, is_local=((who_thwart == 'This') or (target_scheme == 'This')))
    @staticmethod
    def AfterUnitMakeThwart(ability_type, who_thwart, operation, *, is_basic_thwart = None):
        return AbilityFactoryThwart.AfterUnitThwartEnd(ability_type, who_thwart, operation, is_basic_thwart=is_basic_thwart)
    @staticmethod
    def AfterUnitThwartAndRemoveLastThreat(ability_type, who_thwart, operation, *, is_basic_thwart = None, conditions = []):
        def check_remove_all_threat_from(effect, message):
            return message.remove_the_last_threat
        return AbilityFactoryThwart.AfterUnitThwartEnd(ability_type, who_thwart, operation, is_basic_thwart=is_basic_thwart, conditions=[check_remove_all_threat_from, *conditions])
    @staticmethod
    def AfterUnitThwartEnd(ability_type, who_thwart, operation, *, is_basic_thwart = None, conditions = []):
        def check_who(effect, message):
            rule = Condition.GetYouRule(who_thwart, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        def check_is_basic_thwart(effect, message):
            if (is_basic_thwart == None):
                return True
            return (is_basic_thwart == message.IsBasicThwart())
        return Ability(ability_type, Message.AfterUnitThwartEnd, [check_who, check_is_basic_thwart, *conditions], operation, is_local=(who_thwart == 'This'))
    @staticmethod
    def UnitCannotThwartTarget(who_thwart, *, cannot_thwart = None, can_only_thwart = None, cannot_trigger_thwart_ability = None, conditions = []):
        from game.ability.factory import AbilityFactory
        if (cannot_thwart == True):
            abilities = [Ability(AbilityType.NonKeyword, Message.CheckIfUnitCanThwart, [lambda effect, message: Condition.CheckWhichCard(who_thwart, message.check_unit, effect)], lambda effect, message: message.SetCannotThwart(effect), is_local=(who_thwart == 'This'))]
        else:
            def check_who_thwart(effect, message):
                return Condition.CheckWhichCard(who_thwart, message.who_thwart, effect)
            def check_which_scheme(effect, message):
                if (cannot_thwart == True):
                    return True
                return Condition.CheckWhichCard(cannot_thwart, message.scheme, effect)
            def check_can_only_thwart(effect, message):
                if (can_only_thwart == None):
                    return True
                return (not Condition.CheckWhichCard(can_only_thwart, message.scheme, effect))
            abilities = [Ability(AbilityType.NonKeyword, Message.CheckIfSchemeCanBeThwartBy, [check_who_thwart, check_which_scheme, check_can_only_thwart, *conditions], lambda effect, message: message.SetCannotBeThwart(effect), is_local=((who_thwart == 'This') or ((cannot_thwart == 'This') or (can_only_thwart == 'This'))))]
        if (who_thwart == 'AttachedIdentity'):
            if (cannot_trigger_thwart_ability != False):
                abilities.append(AbilityFactory.PlayersCannotTriggerAbility('AttachedPlayer', None, label='thwart'))
        return abilities
