# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GiveKeywordToAttachWhenApplyThisInternal(card_finder = None, *, ignore_flip, name = None, get_new_value = None, expert_mode_only = None, trait = None, attack = None, defense = None, thwart = None, scheme = None, retaliate = None, hand_size = None, stalwart = None, health = None, considered_at_least_hp = None, recover = None, guard = None, patrol = None, steady = None, treat_as_blank = None, target_threat = None, control_additional_restricted = None, attack_consequential_damage = None, thwart_consequential_damage = None, assault = None, have_res_icon = None, apply = None, ex_change_on_event = OnEvent.NONE):
    from game.ability.factory import AbilityFactory
    from game.operate.worlds import Worlds
    ex_change_on_event = Condition.AddEvent(ex_change_on_event, OnEvent.AssetEffect())
    def gain_keyword(effect, face, diff):
        face.Gain(*(effect, diff), **{'trait': trait, 'attack': attack, 'defense': defense, 'thwart': thwart, 'scheme': scheme, 'retaliate': retaliate, 'hand_size': hand_size, 'stalwart': stalwart, 'health': health, 'considered_at_least_hp': considered_at_least_hp, 'recover': recover, 'guard': guard, 'patrol': patrol, 'steady': steady, 'treat_as_blank': treat_as_blank, 'target_threat': target_threat, 'attack_consequential_damage': attack_consequential_damage, 'thwart_consequential_damage': thwart_consequential_damage, 'assault': assault, 'have_res_icon': have_res_icon, 'control_additional_restricted': control_additional_restricted, 'apply': apply})
    def when_unit_apply_this_asset(filter, apply):
        from game.card.face.attribute.can_attach import CanAttach
        def condition(effect, message):
            this = effect.this.CastTo(CanAttach)
            def check():
                if isinstance(message, (Message.AfterCardGainUpgradeAbility | Message.AfterCardLostUpgradeAbility)):
                    if (this != message.upgrade):
                        return False
                    if not (Condition.ThisAttachedTo(effect, message.trigger)):
                        return False
                    return True
                return True
            if check():
                return True
            return False
        def check_fn(effect, last_data):
            this = effect.this.CastTo(CanAttach)
            Unused(this)
            if not (this.bind_face):
                return 0
            new_data = last_data
            message = effect.bind_message
            if isinstance(message, (Message.AfterCardGainUpgradeAbility | Message.AfterCardLostUpgradeAbility)):
                unit = message.trigger
                if isinstance(message, Message.AfterCardLostUpgradeAbility):
                    new_data = 0
                else:
                    new_data = filter(effect, unit)
                    if isinstance(message, Message.WhenCardTreatAsIfBlank):
                        unit = this.GetBindFace()
                        new_data = filter(effect, unit)
                    else:
                        unit = this.GetBindFace()
                        new_data = filter(effect, unit)
            else:
                if isinstance(message, Message.WhenCardTreatAsIfBlank):
                    unit = this.GetBindFace()
                    new_data = filter(effect, unit)
                else:
                    unit = this.GetBindFace()
                    new_data = filter(effect, unit)
            if unit.card.state.is_flipping:
                if (this.GetBindFace() == unit):
                    if ignore_flip:
                        return last_data
                    return 0
            new_data = int(new_data)
            last_data = new_data
            return new_data
        def process_fn(effect, diff, curr):
            this = effect.this.CastTo(CanAttach)
            Unused(this)
            message = effect.bind_message
            if (type(message) is Message.AfterCardGainUpgradeAbility):
                unit = message.trigger
            else:
                if (type(message) is Message.AfterCardLostUpgradeAbility):
                    if not ((diff <= 0)):
                        raise AssertionError
                    unit = message.trigger
                else:
                    unit = this.bind_face
            if unit:
                if unit.IsInPlay():
                    if not (unit.card.state.is_discarding):
                        apply(effect, unit, diff)
                        Message.AfterCardApply_Text([unit], effect, diff)
                        return
                        return
                        return
        return AbilityFactory.WhileValid(ex_change_on_event, condition, check_fn, process_fn)
    from game.card.face.base import Unit2
    if (card_finder == None):
        new_card_finder = None
    else:
        if isinstance(card_finder, CardFinder):
            new_card_finder = card_finder
        else:
            if not (isinstance(card_finder, str)):
                new_card_finder = CardFinder(card_type=card_finder)
            else:
                if (card_finder == 'Character'):
                    new_card_finder = CardFinder(card_type=Unit2)
                else:
                    if (card_finder == 'You'):
                        new_card_finder = None
    def new_filter(effect, face):
        if (name != None):
            if not (face.IsName(name)):
                return 0
        from game.card.face.attribute.can_attach import CanAttach
        if CanAttach.IsType(effect.this):
            if effect.this.is_refers_to_the_villain_refers_to_attached:
                return 1
        if new_card_finder:
            if not (new_card_finder.Check(face)):
                return 0
        if expert_mode_only:
            if not (Worlds.IsExpert(effect)):
                return 0
        if get_new_value:
            faces = []
            value = get_new_value(effect, Cast(Any, face), faces)
            for face in faces:
                effect.this.card.ui.SetTempEffectBy(effect, face)
            return value
        return 1
    return when_unit_apply_this_asset(new_filter, gain_keyword)
