# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryExpert:
    @staticmethod
    def IfExpertModeThisCannotBeCanceled() -> Ability:
        from game.operate.worlds import Worlds
        return Ability(AbilityType.NonKeyword, Message.CheckIfEffectCanBeCancelBy, [lambda effect, message: (Worlds.IsExpert(effect) and (effect.this == message.check_effect.this))], lambda effect, message: message.SetCannotBeThwart(effect))
    @staticmethod
    def IfExpertModeThisGainKeyword(*, incite = None, surge = None, hinder = None):
        from game.operate.worlds import Worlds
        def operation(effect: Effect, message: Message.WhenCardResetKeyword):
            from game.card.face.card_type import Treachery
            from game.card.face.base import Scheme2
            diff = 1
            this = effect.this
            if (incite != None):
                if not (Treachery.IsType(this)):
                    raise AssertionError
                this.GainIncite((diff * incite), effect)
            if (surge != None):
                if not (Treachery.IsType(this)):
                    raise AssertionError
                this.GainSurge((diff * surge), effect)
            if (hinder != None):
                if not (Scheme2.IsType(this)):
                    raise AssertionError
                value = Worlds.ConvertPerPlayerIconToInt(hinder, effect)
                this.GainHinder(value, effect)
                return
        return Ability(AbilityType.NonKeyword, Message.WhenCardResetKeyword, [Condition2.ThisIsTrigger, lambda effect, message: Worlds.IsExpert(effect)], operation).NoOutOfPlayLimit().NoGameAreaLimit()
    @staticmethod
    def StandardModeOnly() -> Ability:
        from game.card.face.card_type import Environment
        from game.ability.factory import AbilityFactory
        from game.operate.worlds import Worlds
        def formidable_foe_setup(effect: Effect, message: Message.WhenCardEnterPlay):
            this = effect.this.CastTo(Environment)
            Unused(this)
            if Worlds.IsExpert(effect):
                this.card.Flip(effect)
                return
        return AbilityFactory.WhenCardEnterPlay(AbilityType.NonKeyword, 'This', formidable_foe_setup)
    @staticmethod
    def ExpertModeOnly() -> Ability:
        from game.card.face.card_type import Environment
        from game.ability.factory import AbilityFactory
        from game.operate.worlds import Worlds
        def formidable_foe_setup(effect: Effect, message: Message.WhenCardEnterPlay):
            this = effect.this.CastTo(Environment)
            Unused(this)
            if not (Worlds.IsExpert(effect)):
                this.card.Flip(effect)
                return
        return AbilityFactory.WhenCardEnterPlay(AbilityType.NonKeyword, 'This', formidable_foe_setup)
