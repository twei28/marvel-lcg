# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryDoScheme:
    @staticmethod
    def WhenUnitWouldScheme(ability_type, who_scheme, operation, *, against_player = 'AnyPlayer', by_effect = None, conditions = []):
        def check_who_scheme(effect, message):
            return Condition.CheckWhichCard(who_scheme, message.trigger, effect)
        def check_against_player(effect, message):
            return Condition.CheckAgainstPlayer(against_player, message, effect)
        def check_by_effect(effect, message):
            if (by_effect == None):
                return True
            return (by_effect == message.by_effect)
        return Ability(ability_type, Message.WhenUnitWouldScheme, [check_who_scheme, check_against_player, check_by_effect, *conditions], operation, is_local=(who_scheme == 'This'))
    @staticmethod
    def WhenUnitSchemeAgainst(ability_type, who_scheme, against_player, operation, *, conditions = []):
        return AbilityFactoryDoScheme.WhenUnitWouldScheme(ability_type, who_scheme, operation, against_player=against_player, conditions=conditions)
    @staticmethod
    def AfterUnitSchemeAgainst(ability_type, who_scheme, against_player, operation, conditions = []):
        return AbilityFactoryDoScheme.AfterUnitSchemeEnd(ability_type, who_scheme, operation, against_player=against_player, conditions=conditions)
    @staticmethod
    def AfterUnitSchemeEnd(ability_type, which_unit, operation, *, against_player = 'AnyPlayer', conditions = []):
        def check_which_unit(effect, message):
            return Condition.CheckWhichCard(which_unit, message.trigger, effect)
        def check_against_player(effect, message):
            return Condition.CheckAgainstPlayer(against_player, message, effect)
        return Ability(ability_type, Message.AfterUnitSchemeEnd, [check_which_unit, check_against_player, *conditions], operation, is_local=(which_unit == 'This'))
    @staticmethod
    def AfterEnemySchemeAndPlaceThreat(ability_type, which_unit, on_which_scheme, operation, *, conditions = []):
        from game.ability.factory import AbilityFactory
        def check_on_which_scheme(effect, message):
            return Condition.CheckWhichCard(on_which_scheme, message.target_scheme, effect)
        def check_placed_threat(effect, message):
            return (message.placed_threat > 0)
        return AbilityFactory.AfterUnitSchemeEnd(ability_type, which_unit, operation, conditions=[check_on_which_scheme, check_placed_threat])
    @staticmethod
    def WhenRecalculateSchemeValue(ability_type, operation, *, conditions = []):
        return Ability(ability_type, Message.WhenRecalculateSchemeValue, [*conditions], operation)
    @staticmethod
    def PlaceThreatOnCardWhenThisScheme(ability_type, which_scheme, if_able = None):
        from game.operate.worlds import Worlds
        from game.card.face.base import Scheme2
        from game.card.card_finder import CardFinder
        def check_this(effect, message):
            return Condition.CheckWhichCard('This', message.who_scheme, effect)
        def get_scheme(effect: Effect):
            if isinstance(which_scheme, CardFinder):
                scheme = Worlds.FindCardOnField(effect, which_scheme, card_type=Scheme2)
                return scheme
            scheme = which_scheme(effect)
            return scheme
        def action(effect: Effect, message: Message.GettingEnemySchemeTarget):
            scheme = get_scheme(effect)
            if scheme:
                message.SetSchemeTarget(scheme, effect)
                return
        return Ability(ability_type, Message.GettingEnemySchemeTarget, [check_this, lambda effect, message: (get_scheme(effect) != None)], action, is_local=True)
