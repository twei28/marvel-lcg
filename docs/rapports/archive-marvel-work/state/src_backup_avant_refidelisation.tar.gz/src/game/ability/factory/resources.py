# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryResources:
    @staticmethod
    def DoubleResourcesThisGenerates(for_card: CardFinder) -> Ability:
        def the_power_of_leadership(effect: Effect, message: Message.CheckPlayerCanPayCost) -> Resources|None:
            from game.card.face.card_type import Resource
            from game.card.face.attribute.has_cost import HasCost
            this = effect.this.CastTo(Resource)
            Unused(this)
            res = this.printed_resource
            paying_for_card = message.paying_for_card
            if (paying_for_card != None):
                if HasCost.IsType(paying_for_card):
                    if for_card.Check(paying_for_card):
                        if (res.val <= message.cost.val):
                            res = (res * 2)
            return res
        return AbilityFactoryResources.CheckThisCanDropPay(the_power_of_leadership)
    @staticmethod
    def CheckThisCanDropPay(resources_fn = None, for_card = None, *, spend_this_only_in_hero_form = None):
        from game.card.face.card_type import Event
        def check_can_pay(effect, message):
            this = effect.this
            if not (this.IsLikeInHand()):
                return False
            if Event.IsType(message.paying_for_effect.this):
                if message.paying_for_effect.this.alliance:
                    return True
            if effect.ability.CheckAnyPlayerCanTriggerThis(effect):
                return True
            if this.card.area.bind_card:
                if this.card.area.bind_card.face.IsName('53021'):
                    return True
            return (this.card.area == message.GetToPlayer().hand_cards)
        return AbilityFactoryResources.CheckThisCanPayCost(resources_fn, for_card, spend_this_only_in_hero_form=spend_this_only_in_hero_form, bind_ability=lambda face: face.effect.Find(func_name='DiscardPay')[0], conditions=[check_can_pay]).SetFuncName('CheckThisCanDropPay')
    @staticmethod
    def CheckThisCanPayCost(resources_fn = None, for_card = None, *, for_ability = None, spend_this_only_in_hero_form = None, for_card_from_hand = None, is_play_card = None, who_trigger_this_effect = None, bind_ability, conditions = []):
        from game.card.face.base import ClassCard
        from game.card.face.card_type import Identity
        if (resources_fn == None):
            def action(effect: Effect, message: Message2):
                if ClassCard.IsType(effect.this):
                    return effect.this.printed_resource
                return Resources('0')
            resources_fn = action
        else:
            if isinstance(resources_fn, Resources):
                res = resources_fn
                def resources_fn(effect, message):
                    return res
        def check_is_not_the_target(effect, messsage):
            if effect.this.IsInPlay():
                return True
            return (effect.this != messsage.paying_for_target)
        def check_spend_this_only_in_hero_form(effect, messsage):
            if (spend_this_only_in_hero_form == None):
                return True
            return effect.GetInitiator().IsHero()
        def check_for_card(effect, message):
            if (for_card == None):
                return True
            return for_card.Check(message.paying_for_effect.this)
        def check_for_ability(effect, message):
            if (for_ability == None):
                return True
            return (for_ability == message.paying_for_effect.ability.name)
        def check_for_card_from_hand(effect, message):
            if (for_card_from_hand == None):
                return True
            return (for_card_from_hand == message.paying_for_effect.this.IsLikeInHand())
        def check_is_play_card(effect, message):
            if (is_play_card == None):
                return True
            return (is_play_card == message.paying_for_effect.ability.is_play)
        def check_who_trigger_this_effect(effect, message):
            if (who_trigger_this_effect == None):
                return True
            if (who_trigger_this_effect == 'You'):
                return (effect.initiator == message.GetToPlayer())
        def check_generate_resources_type(effect: Effect, message: Message.CheckPlayerCanPayCost):
            if effect.ability.IsFunction('CanGenerateResources'):
                for condition in Ability.GetAbilityTypeCondition(effect.ability.second_type):
                    if not (condition(effect, message)):
                        return False
            return True
        def check_cannot_generate_self(effect: Effect, message: Message.CheckPlayerCanPayCost):
            this = effect.this
            if Identity.IsType(this):
                return True
            return (effect.this != message.paying_for_effect.this)
        def add_to_pay_list(effect: Effect, message: Message.CheckPlayerCanPayCost):
            this = effect.this
            if isinstance(message, Message.WhenPlayerInTurn):
                return
            target = (message.paying_for_targets[0] if (message.paying_for_targets != []) else None)
            need_cost = message.paying_for_effect.checker.cost_for_different_target.GetCost(target)
            if not (need_cost):
                raise AssertionError
            if need_cost:
                if need_cost.rule.from_hand:
                    if not (this.IsLikeInHand()):
                        return
            player = message.GetToPlayer()
            effect.context.initiator = player
            res = resources_fn(effect, message)
            if (res != None):
                res_message = Message.CheckEffectGeneratedResources(effect, message, res)
                res_message.Send()
                res = res_message.res
                if res.CanPayThisCost(need_cost):
                    if effect.checker.HasCostTargets():
                        bind_effect = bind_ability(effect.this)
                        def repeat():
                            if (effect.ability.available_times_fn == None):
                                return [bind_effect]
                            return ([bind_effect] * effect.ability.available_times_fn(effect, message))
                        found_effects = repeat()
                        for found_effect in found_effects:
                            message.AddPayment(found_effect, res, effect)
                return
        return Ability(AbilityType.CheckResource, Message.CheckPlayerCanPayCost, [check_cannot_generate_self, check_generate_resources_type, check_is_not_the_target, check_spend_this_only_in_hero_form, check_for_card, check_for_ability, check_for_card_from_hand, check_is_play_card, check_who_trigger_this_effect, *conditions], add_to_pay_list).SetFuncName('CheckPay')
    @staticmethod
    def CanGenerateResources(ability_type, resources = None, for_card = None, *, resources_fn = None, for_ability = None, from_hand = None, for_player_whose_identity_has_trait = None, is_play_card = None, who_trigger_this_effect = None, conditions = [], ex_operation = None):
        from game.card.face.card_type import Event
        if (resources_fn == None):
            if not ((resources != None)):
                raise AssertionError
            def resources_fn(effect, message):
                return resources
        def check_can_pay(effect, message):
            if not (effect.this.IsInPlay()):
                return False
            if Event.IsType(message.paying_for_effect.this):
                if message.paying_for_effect.this.alliance:
                    return True
            player = message.GetToPlayer()
            effect.context.initiator = player
            if effect.ability.CheckAnyPlayerCanTriggerThis(effect):
                return True
            if for_player_whose_identity_has_trait:
                return player.GetIdentity().HasTrait(for_player_whose_identity_has_trait)
            return (player == effect.this.GetControlBy())
        ability = AbilityFactoryResources.CheckThisCanPayCost(resources_fn, for_card, conditions=[check_can_pay, *conditions], for_ability=for_ability, for_card_from_hand=from_hand, is_play_card=is_play_card, who_trigger_this_effect=who_trigger_this_effect, bind_ability=lambda face: face.effect.Find(func_name='DoGenerateResources')[0]).SetFuncName('CanGenerateResources').SetSecondType(ability_type).SetGenerateResourcesExOperation(ex_operation)
        if for_player_whose_identity_has_trait:
            ability.AnyPlayerCanDoThis(player_identity_has_trait=for_player_whose_identity_has_trait)
        return ability
    @staticmethod
    def UpdateResourcesGeneratedWhilePlayingThis(*, color: Resources.RBYG, update_rule: Literal["Double"]|Resources) -> Ability:
        def UpdateGenerateResources(effect: Effect, message: Message.CheckEffectGeneratedResources):
            if (update_rule == 'Double'):
                message.SetResources((message.res + (Resources(color) * message.res.GetColor(color, convert_green_res=False))), effect)
                return
            message.SetResources((message.res + update_rule), effect)
        return Ability(AbilityType.NonKeyword, Message.CheckEffectGeneratedResources, [lambda effect, message: ((effect.this == message.for_effect.this) and message.res.HasColorPrinted(color))], lambda effect, message: UpdateGenerateResources(effect, message), is_local=True).CanWorkOnlyInHand()
    @staticmethod
    def DoDiscardThisToGenerateResources(ability_type, *, res_fn = None, ex_operation = None):
        def move_this_to_resources_area(targets, effect):
            from game.operate.faces import Faces
            this = effect.this
            area_resources = this.GetControlByPlayer().area_resources
            return (Faces.MoveAllTo([this], area_resources, effect) == [this])
        return AbilityFactoryResources.DoGenerateResources(ability_type, 'This', res_fn=res_fn, conditions=[lambda effect, message: (effect.this != message.for_effect.this)], ex_operation=ex_operation).SetFuncName('DiscardPay').SetCostFunc(CostFunc.Custom(None, move_this_to_resources_area))
    @staticmethod
    def DoGenerateResources(ability_type, which_card, *, res_fn = None, conditions = [], ex_operation = None):
        def generate_resource(effect: Effect, message: Message.WhenPlayerPayingResources):
            this = effect.this
            if res_fn:
                res = res_fn(effect, message)
            else:
                res = message.expected_res
            message.SetGenerateRes(res)
            for cost_func in message.cost_check_effect.cost_func.GetAll():
                if not (cost_func.PayCost(effect, effect.GetInitiator())):
                    if message.GetToPlayer().is_eliminated:
                        return
                    from game.exceptions.exceptions import GameSignal_UndoRequest
                    raise GameSignal_UndoRequest()
            if not ((res.val > 0)):
                if not ((res.reduce > 0)):
                    raise AssertionError(f'res={res!r}')
            message.GetToPlayer().res_pool.Gain(res, effect)
            res_message = Message.WhenCardBeSpendAsResource(this, res, message.for_effect, effect.GetInitiator())
            res_message.Send()
            if ex_operation:
                ex_operation(effect, message)
                return
        def check_which_card(effect, message):
            if (which_card == 'This'):
                return (effect == message.by_effect)
        return Ability(ability_type, Message.WhenPlayerPayingResources, [check_which_card, *conditions], generate_resource, is_local=(which_card == 'This')).SetFuncName('DoGenerateResources')
    @staticmethod
    def WhenCalculateEffectCost(ability_type, operation, *, conditions, is_local = None):
        def action_fn(effect: Effect, message: Message.WhenCalculateEffectCost):
            message.check_effect.this.card.ui.cost.Add(effect, effect.this)
            operation(effect, message)
        return Ability(ability_type, Message.WhenCalculateEffectCost, conditions, action_fn, is_local=is_local)
    @staticmethod
    def IgnoreThisCostIf(ability_type, your_identity_has_trait = None, *, conditions = []):
        def ignore_cost(effect: Effect, message: Message.WhenCalculateEffectCost):
            message.IgnoreResourceCost(effect)
        def check_your_identity_has_trait(effect, message):
            if (your_identity_has_trait == None):
                return True
            initiator = effect.GetInitiator()
            identity = initiator.GetIdentity()
            return identity.HasTrait(your_identity_has_trait)
        return AbilityFactoryResources.WhenCalculateEffectCost(ability_type, ignore_cost, conditions=[lambda effect, message: ((effect.this == message.check_effect.this) and message.is_play), check_your_identity_has_trait, *conditions]).NoOutOfPlayLimit()
    @staticmethod
    def EachCardYouPlayCostAdditionalResource(which_card, update_cost):
        def act_update_cost(effect: Effect, message: Message.WhenCalculateEffectCost):
            message.UpdateCost(update_cost, effect)
        def check_which_card(effect, message):
            if (which_card == None):
                return True
            return which_card.IsType(message.check_effect.this)
        return AbilityFactoryResources.WhenCalculateEffectCost(AbilityType.NonKeyword, act_update_cost, conditions=[lambda effect, message: ((effect.this.bind_face != None) and (message.is_play and (effect.this.GetBindFace().GetControlBy() == message.GetToPlayer()))), check_which_card]).NoOutOfPlayLimit()
    @staticmethod
    def AfterYouSpendThisCard(ability_type, operation, *, to_pay_card = None, conditions = [], is_in_hero_from = None, identity_has_trait = None):
        def check_which_card(effect, message):
            return (effect.this in message.faces)
        def check_is_in_hero_from(effect, message):
            if (is_in_hero_from == None):
                return True
            return Condition.YouAreInHeroFrom(effect, is_in_hero_from)
        def check_identity_has_trait(effect, message):
            if (identity_has_trait == None):
                return True
            return effect.GetInitiator().GetRoleCharacter().HasTrait(identity_has_trait)
        def check_to_pay_card(effect, message):
            if (to_pay_card == None):
                return True
            return ((message.pay_for_card != None) and to_pay_card.Check(message.pay_for_card))
        return Ability(ability_type, Message.AfterCardsBeSpendAsResource, [check_which_card, check_is_in_hero_from, check_identity_has_trait, check_to_pay_card, *conditions], operation, is_local=True).NoOutOfPlayLimit()
    @staticmethod
    def WhenYouSpendThisCardToPlay(ability_type, operation, to_pay_card = None):
        def check_played_card(effect, message):
            if (to_pay_card == None):
                return True
            return ((message.pay_for_card != None) and to_pay_card.Check(message.pay_for_card))
        return Ability(ability_type, Message.WhenCardBeSpendAsResource, [Condition2.ThisIsTrigger, check_played_card], operation).NoOutOfPlayLimit()
    @staticmethod
    def ReduceCostToPlayThis(update_cost_fn, *, which_effect = None, your_identity_has_traits = [], each_card_you_control = None, each_minion_engaged_with_you = False, conditions = []):
        def check_your_identity_has_traits(effect, message):
            if (your_identity_has_traits == []):
                return True
            identity = effect.GetInitiator().GetIdentity()
            return identity.HasTrait(*your_identity_has_traits)
        def check_each_card_you_control(effect, message):
            initiator = effect.GetInitiator()
            return Condition.CheckWhichCard(each_card_you_control, initiator.GetControlCards(), effect)
        def check_each_minion_engaged_with_you(effect, message):
            if not (each_minion_engaged_with_you):
                return True
            initiator = effect.GetInitiator()
            return (not (not initiator.GetEngagedMinions()))
        def update_cost(effect):
            base_val = 1
            if each_card_you_control:
                initiator = effect.GetInitiator()
                base_val = len(initiator.GetControlCards(each_card_you_control))
            if each_minion_engaged_with_you:
                initiator = effect.GetInitiator()
                base_val = len(initiator.GetEngagedMinions())
            if isinstance(update_cost_fn, int):
                value = (base_val * update_cost_fn)
                return value
            value = (base_val * update_cost_fn(effect))
            return value
        return AbilityFactoryResources.ReduceCostToPlayFaceWhen('This', update_cost, 'AnyPlayer', which_effect=which_effect, conditions=[check_your_identity_has_traits, check_each_card_you_control, check_each_minion_engaged_with_you, *conditions])
    @staticmethod
    def ReduceCostToPlayFaceWhen(which_card, update_cost_fn, which_player, *, which_effect = None, conditions = []):
        def update_cost(effect):
            base_val = 1
            if isinstance(update_cost_fn, int):
                value = (base_val * update_cost_fn)
                return (value * -1)
            value = (base_val * update_cost_fn(effect))
            return (value * -1)
        return AbilityFactoryResources.UpdateCostOfCardInternal(which_card, update_cost, which_player, which_effect=which_effect, is_play=True, conditions=conditions)
    @staticmethod
    def IncreaseResourceCostToPlay(which_card, value, which_player, *, conditions = []):
        return AbilityFactoryResources.UpdateCostOfCardInternal(which_card, value, which_player, is_play=True, conditions=conditions)
    @staticmethod
    def UpdateCostOfCardInternal(which_card, update_cost_fn, which_player, *, which_effect = None, is_play = None, conditions = []):
        from game.selector import Select
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.check_effect.this, effect)
        def check_which_effect(effect, message):
            if (which_effect == None):
                return True
            return (which_effect == message.check_effect)
        def check_which_player(effect, message):
            if (which_player == 'AnyPlayer'):
                return True
            if (which_player == 'EachPlayer'):
                return True
            if (which_player == 'Attached'):
                return (effect.this.GetBindFace() == message.GetToPlayer().GetIdentity())
            if (which_player == 'You'):
                return (Select.GetYou(effect) == message.to_player)
            return (which_player == message.to_player)
        def check_is_play(effect, message):
            if (is_play == None):
                return True
            return (is_play == message.is_play)
        def reduce_cost(effect: Effect, message: Message.WhenCalculateEffectCost):
            base_val = 1
            if isinstance(update_cost_fn, int):
                value = (base_val * update_cost_fn)
            else:
                value = (base_val * update_cost_fn(effect))
            message.UpdateCost(value, effect)
        ability = AbilityFactoryResources.WhenCalculateEffectCost(AbilityType.NonKeyword, reduce_cost, conditions=[check_which_card, check_which_effect, check_which_player, check_is_play, *conditions], is_local=(which_card == 'This'))
        if (which_card == 'This'):
            ability.NoOutOfPlayLimit()
        return ability
    @staticmethod
    def AfterGenerateResources(ability_type, which_player, operation, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.GetToPlayer(), effect)
        return Ability(ability_type, Message.WhenCardBeSpendAsResource, [check_which_player, *conditions], operation)
