# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.ability import *
from game.message import *
from game.player import *
from game.ability.condition.card_type import ConditionCardType
from game.ability.condition.player_type import ConditionPlayerType
from game.ability.condition.ability_type import ConditionAbilityType
from game.ability.condition.hero_form import ConditionHeroForm
from game.ability.condition.on_event import ConditionOnEventType
from game.ability.condition.once_per import ConditionOncePer
class Condition(ConditionCardType, ConditionPlayerType, ConditionAbilityType, ConditionOnEventType, ConditionHeroForm, ConditionOncePer):
    @staticmethod
    def ThisAttachedTo(effect, to_face):
        from game.card.face.attribute.can_attach import CanAttach
        from game.card.face.card_type import Obligation
        from game.card.face.card_type import StatusCard
        this = effect.this
        if Obligation.IsType(this):
            return (this.GetBindFace() == to_face)
        if CanAttach.IsType(this):
            return ((this.card.area.bind_card != None) and (this.card.area.bind_card == to_face.card))
        if StatusCard.IsType(this):
            if not (this.bind_face):
                return False
            return (this.bind_face.card == to_face.card)
        return False
    @staticmethod
    def ThisIsYou(effect, you):
        from game.player import Player
        from game.selector import Select
        from game.card.face.card_type import Identity
        from game.card.face.card_type import Upgrade
        from game.card.face.card_type import Event
        identity = None
        if isinstance(you, Player):
            identity = you.GetIdentity()
        else:
            if isinstance(you, User):
                pass
            else:
                if Identity.IsType(you):
                    identity = you
                else:
                    if Upgrade.IsType(you):
                        identity = you.GetBindFace()
                    else:
                        if Event.IsType(you):
                            pass
        if Identity.IsType(identity):
            if not (Player.IsType(identity.GetControlBy())):
                raise AssertionError
            return (Select.GetYou(effect).GetIdentity() == identity)
        return False
    @staticmethod
    def AgainstYou(effect: 'Effect', message: 'TriggerNonePlayerMessage|Player'):
        from game.player import Player
        if isinstance(message, Player):
            player = message
        else:
            player = message.to_player
        if effect.IsPlayerInitiator():
            return (effect.initiator == player)
        return (player != None)
    @staticmethod
    def FieldHasNotThisUniqueType(face, effect):
        if not (face.IsUnique()):
            return True
        return (not effect.world.IsThisUniqueInPlay(face))
    @staticmethod
    def CheckBasicPower(powers, message):
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Hero
        from game.card.face.card_type import AlterEgo
        from game.card.face.card_type import Minion
        from game.card.face.base import Villain
        if (powers == None):
            if Ally.IsType(message.trigger):
                basic_powers = ['ATK', 'THW']
            else:
                if AlterEgo.IsType(message.trigger):
                    basic_powers = ['REC']
                else:
                    if Hero.IsType(message.trigger):
                        basic_powers = [*('ATK', 'THW', 'DEF')]
                    else:
                        if not (Villain.IsType(message.trigger)):
                            if Minion.IsType(message.trigger):
                                basic_powers = ['ATK', 'SCH']
                            else:
                                basic_powers = []
                                basic_powers = powers
                        basic_powers = ['ATK', 'SCH']
                        basic_powers = []
                        basic_powers = powers
        else:
            basic_powers = powers
        for name in basic_powers:
            if (name == message.power):
                return True
        return False
