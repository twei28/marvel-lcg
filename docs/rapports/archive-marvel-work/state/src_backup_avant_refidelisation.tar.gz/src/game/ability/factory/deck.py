# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryDeck:
    @staticmethod
    def AfterDeckShuffle(ability_type, deck, operation, *, conditions = []):
        def check_deck(effect, message):
            the_deck = deck(effect)
            if isinstance(the_deck, list):
                return (message.deck in the_deck)
            return (the_deck == message.deck)
        return Ability(ability_type, Message.AfterDeckShuffle, [check_deck, *conditions], operation)
    @staticmethod
    def AfterDeckRunOut(ability_type, deck, operation, *, conditions = []):
        def check_deck(effect, message):
            return (deck(effect) == message.deck)
        return Ability(ability_type, Message.AfterDeckRunOut, [check_deck, *conditions], operation)
    @staticmethod
    def AfterDeckReset(ability_type, deck, operation, *, conditions = [], is_player_deck = None):
        def check_deck(effect, message):
            if (deck == None):
                return True
            return (deck(effect) == message.deck)
        def check_is_player_deck(effect, message):
            if (is_player_deck == None):
                return True
            return (is_player_deck == message.deck.flags.is_player_deck)
        return Ability(ability_type, Message.AfterDeckReset, [check_deck, check_is_player_deck, *conditions], operation)
    @staticmethod
    def PlayWithTopCardOfDeckFaceup(which_deck, *, ex_operation = None, only_during_player_phase = False):
        from game.ability.factory import AbilityFactory
        from game.card.face.card_type import Hero
        def check_only_during_player_phase(effect, message):
            if (only_during_player_phase == False):
                return True
            if not ((ex_operation == None)):
                raise AssertionError
            return effect.world.phase.IsPlayerPhase('AnyPlayer')
        def magik(effect: Effect, message: Message.AfterCardsMoved|Message.AfterDeckShuffle|Message.AfterUnitChangeForm|Message.WhenUnitWouldChangeForm|Message.WhenPhaseBegin):
            this = effect.this.CastTo(Hero)
            Unused(this)
            for deck in which_deck(effect):
                face = deck.GetTop()
                if face:
                    face.FlipTo(effect, face_up=True, ui_look_at=True)
                    if ex_operation:
                        ex_operation(face, effect)
        abilities = []
        if only_during_player_phase:
            abilities.append(AbilityFactory.WhenPlayerPhaseBegin(AbilityType.NonKeyword, magik))
        return [*abilities, AbilityFactory.AfterCardsMoved(AbilityType.NonKeyword, None, magik, by_shuffle=False, conditions=[check_only_during_player_phase]), AbilityFactory.AfterDeckShuffle(AbilityType.NonKeyword, which_deck, magik, conditions=[check_only_during_player_phase]), AbilityFactory.AfterUnitChangeForm(AbilityType.NonKeyword, 'This', magik, to_this_form=True, conditions=[check_only_during_player_phase]), AbilityFactory.WhenUnitWouldChangeForm(AbilityType.NonKeyword, 'This', magik, conditions=[check_only_during_player_phase])]
