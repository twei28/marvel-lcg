# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryAttachment:
    @staticmethod
    def PlayerActionToDiscardThis(ability_type, *, conditions = [], ex_operation = lambda effect, message: 'None'):
        from game.ability.factory import AbilityFactory
        from game.operate.faces import Faces
        def action_to_discard(effect: 'Effect', message: 'Message.WhenPlayerInTurn'):
            ex_operation(effect, message)
            this = effect.this
            Faces.DiscardAll([this], effect)
        return AbilityFactory.WhenInYourPlayTurn(ability_type, action_to_discard, conditions=conditions)
    @staticmethod
    def PlayerActionToRemoveThisFromGame(ability_type, *, conditions = []):
        from game.ability.factory import AbilityFactory
        def remove_this_from_game(effect: 'Effect', message: 'Message.WhenPlayerInTurn'):
            this = effect.this
            from game.operate.faces import Faces
            Faces.RemoveAllFromGame([this], effect)
        return AbilityFactory.WhenInYourPlayTurn(ability_type, remove_this_from_game, conditions=conditions)
    @staticmethod
    def AttachToFaceWhenPutIntoPlay(target, *, highest_printed_hp = False, fewest_remaining_hp = False, most_remaining_hp = False, lowest_atk = False, highest_atk = False, highest_sch = False, lowest_sch = False, most_traits = False, highest_printed_atk = False, lowest_order = False, highest_order = False, corresponding = None, conditions = [], without_another_copy = None, otherwise_attach_to = None, if_cannot_attach_to = None, if_cannot_gain_surge = False, if_cannot_operation = None, when_attach_operation = None, when_attach_exhaust_attached = None):
        from game.operate.faces import Faces
        from game.ability.factory import AbilityFactory
        from game.card.card_finder import CardFinder
        def check_condition(effect, unit):
            from game.card.face.card_type import Attachment
            from game.card.face.base import Asset2
            this = effect.this.CastTo(Attachment)
            def check_without_another_copy():
                if (without_another_copy == None):
                    return True
                if (unit.GetInventoryDeck().FindCard(name=effect.this.name, card_type=type(effect.this)) == None):
                    return True
                return False
            return (check_without_another_copy() and this.CastTo(Asset2).CanAttachTo(unit))
        if (if_cannot_attach_to == None):
            if (otherwise_attach_to != None):
                if_cannot_attach_to = otherwise_attach_to
        if (if_cannot_attach_to == None):
            otherwise_selector = None
        else:
            if isinstance(if_cannot_attach_to, Selector):
                otherwise_selector = if_cannot_attach_to
            else:
                if (if_cannot_attach_to == 'EnemyLeader'):
                    otherwise_selector = Select.From('EnemyLeader')
                else:
                    if (if_cannot_attach_to == 'YourHero'):
                        otherwise_selector = Select.From('YourHero')
                    else:
                        otherwise_selector = Select.From(CardFinder(card_type=if_cannot_attach_to))
        if (target == 'YourIdentity'):
            selector = Select.From('YourIdentity')
        else:
            if (target == 'YourHero'):
                selector = Select.From('YourHero')
            else:
                if (target == 'YourAlly'):
                    selector = Select.From('YourAlly')
                else:
                    if (target == 'Leader|Minion'):
                        selector = Select.From('Leader|Minion')
                    else:
                        if (target == 'YourLeader'):
                            selector = Select.From('YourLeader')
                        else:
                            if (target == 'EnemyLeader'):
                                selector = Select.From('EnemyLeader')
                            else:
                                if isinstance(target, type):
                                    finder = CardFinder(card_type=target)
                                else:
                                    finder = target
                                selector = Select.From(finder, highest_printed_hp=highest_printed_hp, fewest_remaining_hp=fewest_remaining_hp, most_remaining_hp=most_remaining_hp, lowest_atk=lowest_atk, highest_atk=highest_atk, highest_sch=highest_sch, lowest_sch=lowest_sch, most_traits=most_traits, highest_printed_atk=highest_printed_atk, lowest_order=lowest_order, highest_order=highest_order, corresponding=corresponding)
        selector.selector_filter.AddParameter(check_effect_fn=check_condition)
        selector.selector_range.SetRange('All')
        if otherwise_selector:
            otherwise_selector.selector_range.SetRange('All')
        def if_cannot_action(effect: 'Effect', player: 'Player'):
            from cards.pack import ThisCardGainSurge
            if if_cannot_operation:
                if_cannot_operation(effect, player)
            if if_cannot_gain_surge:
                ThisCardGainSurge(effect)
                return
        def when_attach_action(face: 'CardFace', effect: 'Effect'):
            if when_attach_operation:
                when_attach_operation(face, effect)
            if when_attach_exhaust_attached:
                Faces.ExhaustAll([face], effect)
                return
        return AbilityFactory.AttachToFaceWhenPutIntoPlayInternal(selector, conditions=[Condition2.ThisIsTrigger, lambda effect, message: (not effect.this.card.area.flags.is_upgrades), *conditions], otherwise_selector=otherwise_selector, if_cannot_operation=if_cannot_action, when_attach_operation=when_attach_action)
