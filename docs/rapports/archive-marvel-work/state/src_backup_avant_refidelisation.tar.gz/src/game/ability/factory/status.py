# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryStatus:
    @staticmethod
    def AfterStatusCardPlaceOn(ability_type, place_on_who, status, operation, *, conditions = []):
        def check_place_on_who(effect, message):
            return Condition.CheckWhichCard(place_on_who, message.trigger, effect)
        def check_status(effect, message):
            if (status == None):
                return True
            if not (isinstance(status, list)):
                check_status = [status]
            else:
                check_status = status
            return (message.status.name in check_status)
        return Ability(ability_type, Message.AfterStatusCardPlaceOn, [check_place_on_who, check_status, *conditions], operation, is_local=(place_on_who == 'This'))
    @staticmethod
    def AfterStatusDiscardFrom(ability_type, from_who, status, operation, *, conditions = []):
        def check_from_who(effect, message):
            if message.trigger.card.state.is_flipping:
                return False
            return Condition.CheckWhichCard(from_who, message.trigger, effect, check_status=True)
        def check_status(effect, message):
            if status:
                return (message.status.name == status)
            return True
        return Ability(ability_type, Message.AfterStatusDiscardFrom, [check_from_who, check_status, *conditions], operation, is_local=(from_who == 'This'))
    @staticmethod
    def ThisCanHaveAdditionalTough(num):
        from game.ability.factory import AbilityFactory
        from game.operate.effects import Effects
        from game.card.face.base import Unit2
        from game.card.face.card_type import StatusCard
        def action(effect, diff, curr):
            this = effect.this.CastTo(Unit2)
            if (curr > 0):
                this.effect.RegisterTemp(Ability(AbilityType.NonKeyword, Message.GettingUnitAdditionalTough, [Condition2.ThisIsTrigger], lambda effect, message: message.SetReturn(num)).SetName('ThisCanHaveAdditionalTough'), unregister_after_exec=False)
                return
            effects = this.effect.Find(name='ThisCanHaveAdditionalTough')
            Effects.UnRegister(effects)
            exceed = (this.tough - this.tough_max)
            if (exceed > 0):
                this.DiscardTough(effect, rule=exceed)
                return
        return AbilityFactory.WhileValid(OnEvent.CardInPlay(StatusCard), lambda effect, message: True, lambda effect, last_value: effect.this.IsInPlay(), action)
    @staticmethod
    def UnitCannotBeConfused(which_unit):
        from game.ability.factory import AbilityFactory
        from game.buff.buff import BuffCannotBeConfused
        return AbilityFactory.GiveBuffToInPlayWhenApplyThis(which_unit, buffs=[BuffCannotBeConfused])
    @staticmethod
    def UnitCannotBeStunned(which_unit):
        from game.ability.factory import AbilityFactory
        from game.buff.buff import BuffCannotBeStunned
        return AbilityFactory.GiveBuffToInPlayWhenApplyThis(which_unit, buffs=[BuffCannotBeStunned])
    @staticmethod
    def WhenUnitWouldBeStatus(ability_type, which_unit, what_status, operation, *, conditions = []):
        def check_which_unit(effect, message):
            return Condition.CheckWhichCard(which_unit, message.trigger, effect)
        def check_what_status(effect, message):
            return (message.status_name in what_status)
        return Ability(ability_type, Message.WhenStatusWouldCardPlaceOn, [check_which_unit, check_what_status, *conditions], operation)
