# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GiveKeywordToInPlayWhenApplyThisInternal(card_finder = None, *, ignore_flip = False, control_by = None, get_new_value = None, condition = None, if_each_of_your_characters_has_trait = None, if_each_of_your_allies_has_trait = None, works_for_all_cards = False, works_in_the_victory_display = False, expert_mode_only = None, trait = None, teamwork = None, attack = None, defense = None, thwart = None, scheme = None, retaliate = None, hand_size = None, stalwart = None, health = None, recover = None, guard = None, steady = None, treat_as_blank = None, quickstrike = None, attack_consequential_damage = None, thwart_consequential_damage = None, patrol = None, surge = None, incite = None, acceleration_icon = None, hazard = None, toughness = None, not_include_this = False, ally_limit = None, flag = None, peril = None, temporary = None, permanent = None, villainous = None, target_threat = None, additional_cost_for_basic_attack = None, additional_cost_for_basic_thwart = None, additional_cost_for_basic_defend = None, base_sch = None, base_atk = None, base_health = None, abilities = None, buffs = None, apply = None, incite_only = False, change_on_event):
    from game.operate.faces import Faces
    from game.card.card_finder import CardFinder
    from game.card.card_finder import CardFinder2
    from game.operate.worlds import Worlds
    if works_in_the_victory_display:
        change_on_event = Condition.AddEvent(change_on_event, OnEvent.Victory('This'))
    if isinstance(card_finder, CardFinder):
        change_on_event = Condition.AddEvent(change_on_event, OnEvent.EnterPlayWhen(card_finder))
    else:
        if isinstance(card_finder, type):
            change_on_event = Condition.AddEvent(change_on_event, OnEvent.EnterPlayWhen(card_finder))
        else:
            change_on_event = Condition.AddEvent(change_on_event, OnEvent.EnterPlayWhen(card_finder))
    if control_by:
        change_on_event = Condition.AddEvent(change_on_event, OnEvent.PlayAreaCard(card_finder))
    def new_condition(effect):
        if works_in_the_victory_display:
            if not (effect.this.card.area.flags.is_victory_display):
                return False
        if (condition != None):
            if not (condition(effect)):
                return False
        if if_each_of_your_characters_has_trait:
            if not (Faces.EachOfAre(effect.GetInitiator().GetControlCharacters(), CardFinder2(if_each_of_your_characters_has_trait))):
                return False
        if if_each_of_your_allies_has_trait:
            if not (Faces.EachOfAre(effect.GetInitiator().GetControlAllies(), CardFinder2(if_each_of_your_allies_has_trait))):
                return False
        if expert_mode_only:
            if not (Worlds.IsExpert(effect)):
                return False
        return True
    from game.ability.factory.environment_helper2 import StoreValue
    from game.ability.factory.environment_helper2 import StoreValueDiff
    def gain_keyword(effect, unit, diff, is_apply):
        if not_include_this:
            if (effect.this == unit):
                return
        if not ((trait == 1)):
            if (teamwork == 1):
                if (is_apply == True):
                    the_list = diff.lst_add
                    diff_val = 1
                else:
                    the_list = diff.lst_del
                    diff_val = -1
                unit.Gain(effect=effect, diff=diff_val, trait=(the_list if trait else None), teamwork=(the_list if teamwork else None))
            else:
                diff_val = diff.diff
                unit.Gain(*(), **{'effect': effect, 'diff': diff_val, 'trait': trait, 'teamwork': teamwork, 'thwart': thwart, 'attack': attack, 'defense': defense, 'scheme': scheme, 'retaliate': retaliate, 'hand_size': hand_size, 'stalwart': stalwart, 'health': health, 'recover': recover, 'guard': guard, 'steady': steady, 'treat_as_blank': treat_as_blank, 'quickstrike': quickstrike, 'attack_consequential_damage': attack_consequential_damage, 'thwart_consequential_damage': thwart_consequential_damage, 'patrol': patrol, 'surge': surge, 'incite': incite, 'acceleration_icon': acceleration_icon, 'hazard': hazard, 'toughness': toughness, 'ally_limit': ally_limit, 'flag': flag, 'peril': peril, 'temporary': temporary, 'permanent': permanent, 'villainous': villainous, 'target_threat': target_threat, 'additional_cost_for_basic_attack': additional_cost_for_basic_attack, 'additional_cost_for_basic_thwart': additional_cost_for_basic_thwart, 'additional_cost_for_basic_defend': additional_cost_for_basic_defend, 'base_sch': base_sch, 'base_atk': base_atk, 'base_health': base_health, 'abilities': abilities, 'buffs': buffs, 'apply': apply})
        if (is_apply == True):
            the_list = diff.lst_add
            diff_val = 1
        else:
            the_list = diff.lst_del
            diff_val = -1
        unit.Gain(effect=effect, diff=diff_val, trait=(the_list if trait else None), teamwork=(the_list if teamwork else None))
        diff_val = diff.diff
        unit.Gain(*(), **{'effect': effect, 'diff': diff_val, 'trait': trait, 'teamwork': teamwork, 'thwart': thwart, 'attack': attack, 'defense': defense, 'scheme': scheme, 'retaliate': retaliate, 'hand_size': hand_size, 'stalwart': stalwart, 'health': health, 'recover': recover, 'guard': guard, 'steady': steady, 'treat_as_blank': treat_as_blank, 'quickstrike': quickstrike, 'attack_consequential_damage': attack_consequential_damage, 'thwart_consequential_damage': thwart_consequential_damage, 'patrol': patrol, 'surge': surge, 'incite': incite, 'acceleration_icon': acceleration_icon, 'hazard': hazard, 'toughness': toughness, 'ally_limit': ally_limit, 'flag': flag, 'peril': peril, 'temporary': temporary, 'permanent': permanent, 'villainous': villainous, 'target_threat': target_threat, 'additional_cost_for_basic_attack': additional_cost_for_basic_attack, 'additional_cost_for_basic_thwart': additional_cost_for_basic_thwart, 'additional_cost_for_basic_defend': additional_cost_for_basic_defend, 'base_sch': base_sch, 'base_atk': base_atk, 'base_health': base_health, 'abilities': abilities, 'buffs': buffs, 'apply': apply})
        Message.AfterCardApply_Text([unit], effect, diff_val, no_present=True)
    def new_get_value(effect: 'Effect', face: 'CardFace') -> 'StoreValue':
        from game.card.face.card_type import Minion
        from game.ability.condition import Condition
        if (card_finder == None):
            pass
        if not (Condition.CheckWhichCard(card_finder, face, effect)):
            return StoreValue(0, [])
        if (control_by == 'You'):
            if effect.this.IsInPlay():
                if (Select.GetYou(effect) != face.GetControlBy()):
                    return StoreValue(0, [])
        else:
            if (control_by == 'EngagedPlayer'):
                if (effect.this.CastTo(Minion).engaged_player != face.GetControlBy()):
                    return StoreValue(0, [])
        if get_new_value:
            ret_val = get_new_value(effect, face)
            if isinstance(ret_val, int):
                return StoreValue(ret_val, [])
            return StoreValue(0, ret_val)
        return StoreValue(1, [])
    from game.ability.factory.environment_helper2 import WhenFaceApplyThisInternal
    return WhenFaceApplyThisInternal(card_finder, new_condition, new_get_value, gain_keyword, ignore_flip, change_on_event, works_for_all_cards=works_for_all_cards, works_in_the_victory_display=works_in_the_victory_display, incite_only=incite_only, abilities=abilities, buffs=buffs)
