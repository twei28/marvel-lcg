# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryEnemy:
    @staticmethod
    def EnemyCannotActivate(ability_type, which_unit, *, conditions = []):
        def check_which_unit(effect, message):
            return Condition.CheckWhichCard(which_unit, message.trigger, effect)
        def action(effect: Effect, message: Message.WhenEnemyWouldActivate|Message.WhenUnitWouldAttack|Message.WhenUnitWouldScheme):
            message.SetBeInstead(effect)
        return Ability(ability_type, ((Message.WhenEnemyWouldActivate | Message.WhenUnitWouldAttack) | Message.WhenUnitWouldScheme), [check_which_unit, *conditions], action, is_local=(which_unit == 'This'))
