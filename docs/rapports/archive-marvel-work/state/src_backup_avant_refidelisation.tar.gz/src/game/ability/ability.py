# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

import types
from typing import Final
from typing import TypeAlias
from core import *
from game.card.face import *
from game.effect import *
from game.selector import *
from game.message import *
from game.player import *
from cards.paper import Paper
from game.element.cost import Cost
from game.element.resources import Resources
from game.ability.condition import Condition
from game.ability.condition import Condition2
TARGET_TYPE = ((((Type['CardFace'] | Sequence['CardFace']) | 'SELECT.HELPER_TYPE') | 'CardFinder') | None)
TARGET_TYPE: TypeAlias
class Ability:
    __annotations__ = {}
    LABEL = Literal[('attack', 'thwart', 'defense')]
    FUNCTION_NAME = 'Literal["", "Change Form", "DiscardPay", "Ask", "CheckPay", "Play", "CheckThisCanDropPay", "CanGenerateResources", "DoGenerateResources", "AttachToWhenEnterPlay", "ForChoiceAbilityWithCost", "TreatAttachedCardAsMinion", "CheckAllyLimit"]|CardFace.BASIC_POWER'
    FUNCTION_NAME: TypeAlias
    def __init__(self, ability_type, when, conditions, operation, *, is_local = None):
        self.is_initialized = False
        self.name = ''
        self.func_names = set()
        from game.ability.ability_ignore import AbilityIgnore
        self.type = ability_type
        self.flags = ability_type.flags
        self.second_type_internal = None
        self.priority = self.flags.GetPriority()
        self.ignore = AbilityIgnore(self)
        self.can_work_also_in_hand = False
        self.can_work_only_in_hand = False
        self.any_player_can_trigger_this_when = []
        self.labels = []
        self.when = when
        self.is_choose = (self.when == Message.WhenPlayerChooseAbility)
        self.is_paying = (self.when == Message.WhenPlayerPayingResources)
        self.paper = None
        self.cannot_be_cancel = False
        self.cost_fn = None
        self.play_cost = None
        self.default_choose = False
        self.selectors = []
        self.cost_funcs = []
        self.const_condition = conditions
        self.conditions = conditions
        if (is_local == None):
            is_local = False
            for condition in conditions:
                if (condition == Condition2.ThisIsTrigger):
                    is_local = True
        self.operation = operation
        self.available_times_fn = None
        from build import Build
        if not (Build.release):
            if (ability_type == AbilityType.PlayTurnOption):
                if not ((when == Message.WhenPlayerInTurn)):
                    raise AssertionError(f'when={when!r}')
            if (ability_type in (AbilityType.Action, AbilityType.AlterEgoAction, AbilityType.HeroAction, AbilityType.FirstPlayerAction)):
                pass
        if not (Build.release):
            pass
        self.is_local = is_local
        self.on_event = None
        self.SetName('')
    @property
    def second_type(self):
        if not ((self.second_type_internal != None)):
            raise AssertionError
        return self.second_type_internal
    @staticmethod
    def GetAbilityTypeCondition(ability_type: AbilityType) -> ConditionsType[Message2]:
        from game.card.face.card_type import Event
        conditions = []
        ability_type_flags = ability_type.flags
        if ability_type_flags.is_hero_type:
            def player_is_hero(effect, message):
                return effect.GetInitiator().IsHero()
            conditions.append(player_is_hero)
        if ability_type_flags.is_first_player_type:
            def is_first_player(effect, message):
                return effect.GetInitiator().IsFirstPlayer()
            conditions.append(is_first_player)
        if ability_type_flags.is_alterego_type:
            def player_is_alter_ego(effect, message):
                return effect.GetInitiator().IsAlterEgo()
            conditions.append(player_is_alter_ego)
        if ability_type_flags.is_delay_ability:
            def is_in_play_or_hand_or_temp_or_delay(effect, message):
                if effect.is_temp:
                    return True
                if effect.ability.flags.is_delay_ability:
                    if effect.is_local:
                        if effect.ability.ignore.out_of_play:
                            return True
                this = effect.this
                if Event.IsType(this):
                    if effect.this.IsLikeInHand():
                        return True
                    if not (this.card.IsOnField()):
                        return True
                    return False
                if this.IsInPlay():
                    pass
                return this.IsInProcessingArea()
            conditions.append(is_in_play_or_hand_or_temp_or_delay)
        return conditions
    def Initialize(self, this: 'CardFace'):
        from game.selector import Select
        from game.card.face.base import Enemy
        from game.card.face.card_type import Event
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Hero
        from game.card.face.card_type import Upgrade
        if self.is_initialized:
            return
        self.is_initialized = True
        when = self.when
        conditions = []
        if Enemy.IsType(this):
            if not ((self.selectors == [])):
                raise AssertionError(f'this={this!r}')
        def check_sub_type(labels, func_names):
            for label in self.labels:
                if not ((label in labels)):
                    raise AssertionError(f'label={label!r} self={self!r} this={this!r}')
            for func_name in self.func_names:
                if not ((func_name in func_names)):
                    raise AssertionError(f'self.func_names={self.func_names!r} self={self!r} this={this!r}')
            return True
        from build import Build
        if not (Build.release):
            if not (self.flags.is_choose_ability):
                if self.flags.is_special:
                    check_sub_type(['attack', 'thwart'], [])
                else:
                    if self.flags.is_discard_pay:
                        check_sub_type([], ['DiscardPay', 'DoGenerateResources'])
                    else:
                        if self.flags.is_ask:
                            check_sub_type([], ['Ask'])
                        else:
                            if self.flags.is_play_turn_option:
                                check_sub_type([], ['Change Form', 'Play'])
                            else:
                                if self.flags.is_basic_power:
                                    check_sub_type([], [*('REC', 'ATK', 'THW', 'DEF')])
                                else:
                                    if self.flags.IsType(AbilityType.HeroAction):
                                        check_sub_type(['attack', 'thwart'], ['Play'])
                                    else:
                                        if self.flags.IsType(AbilityType.Action):
                                            check_sub_type(['thwart', 'attack'], ['Play'])
                                        else:
                                            if self.flags.IsType(AbilityType.HeroInterrupt):
                                                check_sub_type([*('attack', 'defense', 'thwart')], ['Play'])
                                            else:
                                                if self.flags.IsType(AbilityType.Interrupt):
                                                    check_sub_type(['defense', 'thwart'], [*('Play', 'DoGenerateResources', 'DiscardPay')])
                                                else:
                                                    if self.flags.IsType(AbilityType.Response):
                                                        check_sub_type(['thwart', 'attack'], ['Play'])
                                                    else:
                                                        if self.flags.is_choose_ability:
                                                            check_sub_type(['attack', 'thwart'], [])
                                                        else:
                                                            if self.flags.IsType(AbilityType.HeroResponse):
                                                                check_sub_type([*('attack', 'thwart', 'defense')], ['Play'])
                                                            else:
                                                                if self.flags.IsType(AbilityType.DelayAbility):
                                                                    pass
                                                                else:
                                                                    if self.flags.is_resource:
                                                                        check_sub_type([], ['DoGenerateResources'])
                                                                    else:
                                                                        if self.flags.IsType(AbilityType.CheckResource):
                                                                            check_sub_type([], [*('CheckPay', 'CheckThisCanDropPay', 'CanGenerateResources')])
                                                                        else:
                                                                            if self.flags.IsType(AbilityType.AlterEgoAction):
                                                                                check_sub_type(['thwart'], ['Play'])
                                                                            else:
                                                                                if self.is_play:
                                                                                    check_sub_type([], ['Play'])
                                                                                else:
                                                                                    if (self.when == Message.WhenCardPutIntoPlay):
                                                                                        check_sub_type([], ['AttachToWhenEnterPlay'])
                                                                                    else:
                                                                                        if (self.when == Message.WhenCardEnterPlay):
                                                                                            check_sub_type([], ['TreatAttachedCardAsMinion'])
                                                                                        else:
                                                                                            if (self.when == Message.CheckIfAllyCountLimit):
                                                                                                check_sub_type([], ['CheckAllyLimit'])
                                                                                            else:
                                                                                                check_sub_type([], [])
        if self.is_play:
            def is_like_in_hand(effect, message):
                return (effect.ability.flags.is_delay_ability or effect.this.IsLikeInHand())
            conditions.append(is_like_in_hand)
        conditions = (conditions + Ability.GetAbilityTypeCondition(self.flags.ability_type))
        from game.message import TriggerPlayerMessage
        from game.message import TriggerMessage
        if not (self.ignore.game_area):
            if not (isinstance(self.on_event, OnEvent.GameArea)):
                def check_game_area(effect, message):
                    if isinstance(message, TriggerPlayerMessage):
                        if (message.to_player != None):
                            return ((effect.this.card.GetGameArea() == message.GetToPlayer().GetGameArea()) or effect.this.card.area.flags.is_removed)
                    if isinstance(message, TriggerMessage):
                        return (effect.this.card.GetGameArea() == message.trigger.card.GetGameArea())
                    if isinstance(message, Message.CheckEffectCondition):
                        return (effect.this.card.GetGameArea() == message.check_effect.this.card.GetGameArea())
                    return True
                conditions = ([check_game_area] + conditions)
        if (self.when == Message.WhenPlayerRevealCard):
            def check_peril(effect, message):
                if isinstance(message, TriggerMessage):
                    if isinstance(message, TriggerPlayerMessage):
                        face = message.trigger
                        from game.card.face.base import EncounterNonVillainCard
                        if EncounterNonVillainCard.IsType(face):
                            if face.IsPeril():
                                return (effect.initiator == message.to_player)
                return True
            conditions = ([check_peril] + conditions)
        if self.is_like_defense:
            def can_defense_attack(effect, message):
                if isinstance(message, AttackerMessage):
                    attacker = message.attacker
                    if not (attacker):
                        return True
                    this = effect.this
                    if Event.IsType(this):
                        unit = effect.GetInitiator().GetIdentity()
                    else:
                        if Upgrade.IsType(this):
                            unit = this.GetBindFace()
                            if Enemy.IsType(unit):
                                unit = this.GetOwner().GetRoleCharacter()
                        else:
                            unit = this
                return True
            conditions = ([can_defense_attack] + conditions)
        self.conditions = (conditions + self.conditions)
        if (self.selectors == []):
            if not (self.default_choose):
                if not (self.flags.is_forced):
                    if not (self.flags.is_choose_ability):
                        if not (self.flags.is_action):
                            if not (self.is_play):
                                if not (self.IsFunction('Change Form', 'REC')):
                                    if (self.cost_fn == None):
                                        self.selectors.append(Select.From('This', not_move=True, not_shuffle=True))
        self.code_action = f'{self.operation.__code__.co_filename}:{self.operation.__code__.co_firstlineno}'
        self.code_conditions = [f'{x.__code__.co_filename}:{x.__code__.co_firstlineno}' for x in self.conditions]
    def SetSecondType(self, ability_type: AbilityType) -> 'Ability':
        if not ((self.flags.ability_type in (AbilityType.CheckResource, AbilityType.DelayAbility))):
            raise AssertionError
        self.second_type_internal = ability_type
        return self
    def SetGenerateResourcesExOperation(self, operation = None):
        self.generate_resources_ex_operation = operation
        return self
    def SetCost(self, res, *, is_choose_ability = False):
        if not (is_choose_ability):
            if self.flags.is_choose_ability:
                raise AssertionError('Call `ForChoiceAbilityWithCost` instead')
        if not ((res != 0)):
            raise AssertionError
        if isinstance(res, Cost):
            self.cost_fn = lambda effect, face: res
            return self
        self.cost_fn = res
        return self
    def SetPlayCost(self, cost: Cost) -> 'Ability':
        self.play_cost = cost
        return self
    def GetCost(self, effect, targets):
        if self.flags.is_delay_ability:
            return Cost('0')
        if self.cost_fn:
            if self.play_cost:
                return (self.cost_fn(effect, targets) + self.play_cost)
        if self.play_cost:
            return self.play_cost
        if self.cost_fn:
            return self.cost_fn(effect, targets)
        raise AssertionError('Please set `SetCost` `SetPlayCost`')
    def NeedCost(self):
        if self.flags.is_delay_ability:
            return False
        return ((self.cost_fn != None) or (self.play_cost != None))
    def CheckAnyPlayerCanTriggerThis(self, effect):
        if self.any_player_can_trigger_this_when:
            for condition in self.any_player_can_trigger_this_when:
                if not (condition(effect)):
                    return False
            return True
        return False
    @property
    def is_play(self):
        return self.IsFunction('Play')
    def SetLabel(self, *labels: 'Ability.LABEL') -> 'Ability':
        if not ((self.selectors == [])):
            raise AssertionError('Please call this before SetTarget')
        if not ((self.labels == [])):
            raise AssertionError
        self.labels = list(labels)
        return self
    def IsOneOfLabel(self, label):
        if isinstance(label, list):
            labels = label
        else:
            labels = [label]
        for check_label in labels:
            if (check_label in self.labels):
                return True
        return False
    def IsLabel(self, label):
        return (label in self.labels)
    def SetName(self, name: str) -> 'Ability':
        self.name = name
        return self
    def SetFuncName(self, name: 'Ability.FUNCTION_NAME') -> 'Ability':
        if (name not in self.func_names):
            self.func_names.add(name)
            if (name == 'DiscardPay'):
                self.CanWorkOnlyInHand()
            if (name == 'CheckPay'):
                self.CanWorkAlsoInHand()
        return self
    def IsFunction(self, *func_names):
        for func_name in func_names:
            if (func_name in self.func_names):
                return True
        return False
    @property
    def is_like_attack(self):
        return (self.is_label_attack or self.IsFunction('ATK'))
    @property
    def is_like_thwart(self):
        return (self.is_label_thwart or self.IsFunction('THW'))
    @property
    def is_like_defense(self):
        return (self.is_label_defense or self.IsFunction('DEF'))
    @property
    def is_label_attack(self):
        return self.IsLabel('attack')
    @property
    def is_label_thwart(self):
        return self.IsLabel('thwart')
    @property
    def is_label_defense(self):
        return self.IsLabel('defense')
    def SetIgnoreKeyword(self, *keywords, condition = lambda effect: True):
        for keyword in keywords:
            self.ignore.keyword[keyword] = condition
        return self
    def SetCondition(self, *, only_if_your_identity_has_trait = None, only_if_your_hero_has_trait = None, hero_form_only = False, alter_ego_form_only = False, only_if_your_identity_has_at_least_printed_hp = None, only_if_you_control_trait = None, only_if_you_control_3_character_with_trait = None, only_if_you_control_face = None, only_if_your_identity_has_one_of_traits = None, you_have_played_another_card_this_phase = None, only_if_there_is_side_scheme_in_victory = None, only_if_you_are_in_additional_from = None, only_if_you_are_the_player = None, each_your_characters_has_trait = None):
        from game.card.card_finder import CardFinder2
        if (only_if_your_identity_has_trait == None):
            if (hero_form_only == False):
                if (alter_ego_form_only == False):
                    if (only_if_your_identity_has_at_least_printed_hp == None):
                        if (only_if_you_control_trait == None):
                            if (only_if_your_identity_has_one_of_traits == []):
                                if not ((self.selectors == [])):
                                    raise AssertionError('Please call this before SetTarget')
        if only_if_your_identity_has_trait:
            def check_only_if_your_identity_has_trait(effect, message):
                initiator = effect.GetInitiator()
                identity = initiator.GetIdentity()
                return identity.HasTrait(only_if_your_identity_has_trait)
            self.conditions = ([check_only_if_your_identity_has_trait] + self.conditions)
        if only_if_your_hero_has_trait:
            def check_only_if_your_hero_has_trait(effect, message):
                initiator = effect.GetInitiator()
                if not (initiator.IsHero()):
                    return False
                identity = initiator.GetIdentity()
                return identity.HasTrait(only_if_your_hero_has_trait)
            self.conditions = ([check_only_if_your_hero_has_trait] + self.conditions)
        if hero_form_only:
            def check_hero_form_only(effect, message):
                initiator = effect.GetInitiator()
                return initiator.IsHero()
            self.conditions = ([check_hero_form_only] + self.conditions)
        if alter_ego_form_only:
            def check_alter_ego_form_only(effect, message):
                initiator = effect.GetInitiator()
                return initiator.IsAlterEgo()
            self.conditions = ([check_alter_ego_form_only] + self.conditions)
        if only_if_your_identity_has_at_least_printed_hp:
            def check_your_identity_has_at_least_printed_hp(effect, message):
                initiator = effect.GetInitiator()
                printed_health = initiator.GetIdentity().printed_health
                return (printed_health >= only_if_your_identity_has_at_least_printed_hp)
            self.conditions = ([check_your_identity_has_at_least_printed_hp] + self.conditions)
        if only_if_you_control_trait:
            def check_if_you_control_one_of_traits(effect, message):
                if not (only_if_you_control_trait):
                    raise AssertionError
                initiator = effect.GetInitiator()
                return initiator.IsControl(CardFinder2(only_if_you_control_trait))
            self.conditions = ([check_if_you_control_one_of_traits] + self.conditions)
        if only_if_you_control_3_character_with_trait:
            def check_only_if_you_control_3_character_with_trait(effect, message):
                initiator = effect.GetInitiator()
                return (len(initiator.GetControlCards2(CardFinder2(only_if_you_control_3_character_with_trait))) >= 3)
            self.conditions = ([check_only_if_you_control_3_character_with_trait] + self.conditions)
        if only_if_you_control_face:
            def check_only_if_you_control_face(effect, message):
                initiator = effect.GetInitiator()
                return (initiator.GetIdentity().GetInventoryDeck().FindCard(only_if_you_control_face) != None)
            self.conditions = ([check_only_if_you_control_face] + self.conditions)
        if (only_if_your_identity_has_one_of_traits != None):
            def check_if_your_identity_has_one_of_traits(effect, message):
                initiator = effect.GetInitiator()
                identity = initiator.GetIdentity()
                for trait in only_if_your_identity_has_one_of_traits:
                    if identity.HasTrait(trait):
                        return True
                return False
            self.conditions = ([check_if_your_identity_has_one_of_traits] + self.conditions)
        if (you_have_played_another_card_this_phase != None):
            def check_you_have_played_another_card_this_phase(effect, message):
                initiator = effect.GetInitiator()
                first_played_card = initiator.stat.GetThisPhasePlayedCard(0)
                if you_have_played_another_card_this_phase:
                    return (first_played_card != None)
                return (first_played_card == None)
            self.conditions = ([check_you_have_played_another_card_this_phase] + self.conditions)
        if (only_if_there_is_side_scheme_in_victory != None):
            def check_only_if_there_is_side_scheme_in_victory(effect, message):
                from game.card.face.base import SchemeSide2
                side_scheme = effect.world.victory_display.FindCard(card_type=SchemeSide2)
                if only_if_there_is_side_scheme_in_victory:
                    return (side_scheme != None)
                return (side_scheme == None)
            self.conditions = ([check_only_if_there_is_side_scheme_in_victory] + self.conditions)
        if (only_if_you_are_in_additional_from != None):
            def check_only_if_you_are_in_additionnal_from(effect, message):
                initiator = effect.GetInitiator()
                return initiator.form.IsFormInternal(only_if_you_are_in_additional_from)
            self.conditions = ([check_only_if_you_are_in_additionnal_from] + self.conditions)
        if (only_if_you_are_the_player != None):
            def check_only_if_you_are_the_player(effect, message):
                initiator = effect.GetInitiator()
                return initiator.IsName(*only_if_you_are_the_player)
            self.conditions = ([check_only_if_you_are_the_player] + self.conditions)
        if (each_your_characters_has_trait != None):
            def check_each_your_characters_has_trait(effect, message):
                initiator = effect.GetInitiator()
                if not ((each_your_characters_has_trait != None)):
                    raise AssertionError
                return all((x.HasTrait(each_your_characters_has_trait) for x in initiator.GetControlCharacters()))
            self.conditions = ([check_each_your_characters_has_trait] + self.conditions)
        return self
    def SetPlay(self, *, only_if_your_identity_has_trait = None, only_if_your_hero_has_trait = None, hero_form_only = False, alter_ego_form_only = False, only_if_your_identity_has_at_least_printed_hp = None, only_if_you_control_trait = None, only_if_you_control_3_character_with_trait = None, only_if_you_control_face = None, only_if_your_identity_has_one_of_traits = None, you_have_played_another_card_this_phase = None, only_if_there_is_side_scheme_in_victory = None, only_if_you_are_in_additional_from = None, only_if_you_are_the_player = None):
        self.SetFuncName('Play')
        self.SetCondition(only_if_your_identity_has_trait=only_if_your_identity_has_trait, only_if_your_hero_has_trait=only_if_your_hero_has_trait, hero_form_only=hero_form_only, alter_ego_form_only=alter_ego_form_only, only_if_your_identity_has_at_least_printed_hp=only_if_your_identity_has_at_least_printed_hp, only_if_you_control_trait=only_if_you_control_trait, only_if_you_control_3_character_with_trait=only_if_you_control_3_character_with_trait, only_if_you_control_face=only_if_you_control_face, only_if_your_identity_has_one_of_traits=only_if_your_identity_has_one_of_traits, you_have_played_another_card_this_phase=you_have_played_another_card_this_phase, only_if_there_is_side_scheme_in_victory=only_if_there_is_side_scheme_in_victory, only_if_you_are_in_additional_from=only_if_you_are_in_additional_from, only_if_you_are_the_player=only_if_you_are_the_player)
        return self
    def NoOutOfPlayLimit(self) -> 'Ability':
        self.ignore.out_of_play = True
        return self
    def CanWorkAlsoInHand(self) -> 'Ability':
        self.can_work_also_in_hand = True
        return self
    def CanWorkOnlyInHand(self) -> 'Ability':
        self.can_work_only_in_hand = True
        return self
    @property
    def is_ignore_out_of_play(self):
        return (self.flags.is_ignore_game_area or self.ignore.out_of_play)
    def SetHasNoTargetEffect(self) -> 'Ability':
        return self.SetTarget2('This')
    def SetNoTarget(self, *, select_this = False):
        if not ((self.selectors == [])):
            raise AssertionError
        if select_this:
            return self.SetTarget('This')
        return self.SetTarget(from_where=[])
    def SetTarget2(self, target = None, is_optional = True, condition = None, *args, **kwargs):
        if (self.selectors == []):
            self.SetNoTarget()
        return self.SetTarget(*args, **{'target': target, 'is_second_internal': True, 'is_optional': is_optional, 'condition': condition, **kwargs})
    def SetTarget3(self, target = None, is_optional = True, *args, **kwargs):
        if (self.selectors == []):
            self.SetNoTarget()
        return self.SetTarget(*args, **{'target': target, 'is_second_internal': True, 'is_optional': is_optional, **kwargs})
    def SetTarget(self, target = None, *, card_type = None, finder = None, trait = None, traits = None, non_trait = None, card_class = None, form = None, deck_building_class = None, has_printed_res = None, canbe_heal = None, sustained = None, canbe_stunned = None, canbe_tough = None, canbe_confused = None, canbe_ready = None, canbe_exhaust = None, canbe_play = None, is_confused = None, is_stunned = None, has_counter = None, has_threat = None, can_place_threat = None, has_non_health = None, canbe_discard = None, canbe_flip = None, with_texts = None, with_attach = None, not_with_attach = None, has_status = None, canbe_status = None, name = None, names = None, non_name = None, bind_to = None, engaged_with = None, canbe_attach_by = None, exclude = [], another = None, highest_cost = False, least_threat = False, share_trait_with_your_hero = False, share_trait_with_your_identity = False, fewest_remaining_hp = False, highest_atk = False, highest_thw = False, cost_equal_or_greater = None, range = 'Default', from_where = ['Default'], combined_printed_cost = None, combined_resource_icons = None, select_rule = '', repeat_rules = [], check_fn = None, by_search = False, not_move = False, not_shuffle = False, check_again_fn = None, is_second_internal = False, is_optional = True, condition = None):
        from game.selector import Select
        from game.card.card_finder import CardFinder
        from game.card.face.base import SchemeSide2
        from game.card.face.base import Scheme2
        from game.card.face.base import Friend
        from game.card.face.base import Villain
        from game.card.face.card_type import Minion
        from game.card.face.card_type import EncounterSideScheme
        from game.card.face.card_type import MainScheme
        from game.card.face.card_type import PlayerSideScheme
        from game.card.face.card_type import Upgrade
        from game.card.face.card_type import Support
        from game.card.face.card_type import Attachment
        from game.card.face.card_type import Environment
        from game.card.face.card_type import Obligation
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Hero
        from game.card.face.card_type import AlterEgo
        from game.card.face.card_type import StatusCard
        if (card_type == 'Ally|Support'):
            card_type = (Ally | Support)
        if (from_where == ['Default']):
            if (target == Minion):
                target = 'Minion'
            if (target == Villain):
                target = 'Villain'
            if (target == EncounterSideScheme):
                target = 'EncounterSideScheme'
            if (target == MainScheme):
                target = 'MainScheme'
            if (target == PlayerSideScheme):
                target = 'PlayerSideScheme'
            if (target == Upgrade):
                target = 'Upgrade'
            if (target == Support):
                target = 'Support'
            if (target == Attachment):
                target = 'Attachment'
            if (target == Environment):
                target = 'Environment'
            if (target == Obligation):
                target = 'Obligation'
            if (target == Ally):
                target = 'Ally'
            if (target == Hero):
                target = 'Hero'
            if (target == AlterEgo):
                target = 'AlterEgo'
            if (target == StatusCard):
                target = 'StatusCard'
            if (target == Friend):
                target = 'Friend'
            if (target == Scheme2):
                target = 'Scheme2'
            if names:
                if not (('Confused' in names)):
                    if not (('Stunned' in names)):
                        if ('Tough' in names):
                            target = 'StatusCard'
                target = 'StatusCard'
            if (name in ('Confused', 'Stunned', 'Tough')):
                target = 'StatusCard'
        select_target = None
        faces = None
        if not (isinstance(target, type)):
            if isinstance(target, types.UnionType):
                card_type = Cast(Type, target)
            else:
                if isinstance(target, str):
                    select_target = Cast(SELECT.HELPER_TYPE, target)
                else:
                    if not (isinstance(target, list)):
                        if isinstance(target, Sequence):
                            faces = target
                        else:
                            if isinstance(target, CardFinder):
                                finder = target
                            else:
                                if isinstance(target, Callable):
                                    select_target = target
                    faces = target
                    if isinstance(target, CardFinder):
                        finder = target
                    else:
                        if isinstance(target, Callable):
                            select_target = target
        card_type = Cast(Type, target)
        if isinstance(target, str):
            select_target = Cast(SELECT.HELPER_TYPE, target)
        else:
            if not (isinstance(target, list)):
                if isinstance(target, Sequence):
                    faces = target
                else:
                    if isinstance(target, CardFinder):
                        finder = target
                    else:
                        if isinstance(target, Callable):
                            select_target = target
            faces = target
            if isinstance(target, CardFinder):
                finder = target
            else:
                if isinstance(target, Callable):
                    select_target = target
        if can_place_threat:
            has_threat = None
        else:
            if not ((card_type == EncounterSideScheme)):
                if not ((card_type == PlayerSideScheme)):
                    if not ((card_type == MainScheme)):
                        if not ((card_type == Scheme2)):
                            if not ((card_type == SchemeSide2)):
                                if not ((target == 'EncounterSideScheme')):
                                    if not ((target == 'PlayerSideScheme')):
                                        if not ((target == 'MainScheme')):
                                            if not ((target == 'Scheme2')):
                                                if (target == 'SchemeSide2'):
                                                    has_threat = True
            has_threat = True
        if not (finder):
            kwargs = {'card_type': card_type, 'name': name, 'names': names, 'non_name': non_name, 'trait': trait, 'traits': traits, 'non_trait': non_trait, 'card_class': card_class, 'form': form, 'deck_building_class': deck_building_class, 'has_printed_res': has_printed_res, 'canbe_heal': canbe_heal, 'sustained': sustained, 'canbe_stunned': canbe_stunned, 'canbe_tough': canbe_tough, 'canbe_confused': canbe_confused, 'is_confused': is_confused, **{'is_stunned': is_stunned, 'has_counter': has_counter, 'with_texts': with_texts, 'canbe_ready': canbe_ready, 'canbe_exhaust': canbe_exhaust, 'canbe_play': canbe_play, 'has_threat': has_threat, 'has_non_health': has_non_health, 'canbe_discard': canbe_discard, 'canbe_flip': canbe_flip, 'with_attach': with_attach, 'not_with_attach': not_with_attach, 'has_status': has_status, 'canbe_status': canbe_status, 'bind_to': bind_to, 'engaged_with': engaged_with, 'canbe_attach_by': canbe_attach_by}, **{'cost_equal_or_greater': cost_equal_or_greater, 'check_effect_fn': check_fn}}
            if [x for x in kwargs.values() if (x != None)]:
                finder = CardFinder(*(), **{**kwargs})
        if not (is_second_internal):
            if not ((self.selectors == [])):
                raise AssertionError
        selector = None
        selector = Select.From(*(select_target,), **{'faces': faces, 'finder': finder, 'exclude': exclude, 'another': another, 'highest_cost': highest_cost, 'least_threat': least_threat, 'share_trait_with_your_hero': share_trait_with_your_hero, 'share_trait_with_your_identity': share_trait_with_your_identity, 'fewest_remaining_hp': fewest_remaining_hp, 'highest_atk': highest_atk, 'highest_thw': highest_thw, 'range': range, 'from_where': from_where, 'combined_printed_cost': combined_printed_cost, 'combined_resource_icons': combined_resource_icons, 'select_rule': select_rule, 'repeat_rules': repeat_rules, 'by_search': by_search, 'not_move': not_move, 'not_shuffle': not_shuffle, 'check_again_fn': check_again_fn})
        selector.is_optional = is_optional
        if (is_optional == False):
            if is_second_internal:
                if not (self.selectors[0]):
                    raise AssertionError
                self.selectors[0].is_optional = False
        selector.condition = condition
        self.SetTargetInternal(selector)
        return self
    def SetTargetInternal(self, selector: Selector) -> 'Ability':
        from game.card.face.base import Scheme2
        from game.card.face.base import Unit2
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Event
        from game.card.face.card_type import Hero
        from game.card.face.card_type import AlterEgo
        from game.card.face.card_type import Upgrade
        self.selectors.append(selector)
        if (len(self.selectors) != 1):
            return self
        last_selector = self.selectors[-1]
        if not (last_selector):
            raise AssertionError
        if (last_selector.target_text == 'TeamUp'):
            return self
        if self.is_like_attack:
            def can_be_attack_units(effect, target):
                if Unit2.IsType(target):
                    if target.IsDefeated():
                        return False
                    this = effect.this
                    if not (Unit2.IsType(this)):
                        if not (Event.IsType(this)):
                            if not (Upgrade.IsType(this)):
                                raise AssertionError(f'type(this)={type(this)!r}')
                    if target.IsConsiderAs(card_type=Unit2):
                        return True
                    return target.CanBeAttackBy(effect)
                return True
            last_selector.selector_filter.AddParameter(check_effect_fn=can_be_attack_units)
        if self.is_like_thwart:
            def can_be_thwart_schemes(effect, target):
                if Scheme2.IsType(target):
                    if not ((target.threat <= 0)):
                        if target.IsDefeated():
                            return False
                    return False
                    this = effect.this
                    if isinstance(this, ((Ally | Hero) | AlterEgo)):
                        return target.CanBeThwartBy(effect)
                    if not (Event.IsType(this)):
                        if not (Upgrade.IsType(this)):
                            raise AssertionError(f'type(this)={type(this)!r}')
                    return target.CanBeThwartBy(effect)
                return True
            last_selector.selector_filter.AddParameter(check_effect_fn=can_be_thwart_schemes)
        if self.is_play:
            def filter_training_upgrade_per_ally(effect, face):
                from game.card.card_finder import CardFinder2
                this = effect.this
                if Upgrade.IsType(this):
                    if not (Ally.IsType(face)):
                        return True
                    if not (effect.this.HasTrait('TRAINING')):
                        return True
                    return (face.GetInventoryDeck().FindCardSize(CardFinder2('TRAINING', Upgrade)) == 0)
                return True
            last_selector.selector_filter.AddParameter(check_effect_fn=filter_training_upgrade_per_ally)
        return self
    def SetCostFunc(self, cost_func: 'CostFunc.Base') -> 'Ability':
        self.cost_funcs.append(cost_func)
        return self
    def SetDefault(self) -> 'Ability':
        if not (self.is_choose):
            raise AssertionError(f'self.when={self.when!r}')
        if not (self.flags.is_choose_ability):
            raise AssertionError(f'self.flags={self.flags!r}')
        self.default_choose = True
        return self
    def LimitOncePerRound(self) -> 'Ability':
        self.conditions = ([Condition.LimitOncePerRound] + self.conditions)
        return self
    def MaxOnePerRound(self):
        return self.LimitOncePerRound()
    def MaxOnePerPhase(self):
        return self.LimitOncePerPhase()
    def LimitOncePerRoundPerPlayer(self) -> 'Ability':
        self.conditions = ([Condition.LimitOncePerRoundPerPlayer] + self.conditions)
        return self
    def LimitOncePerPhasePerPlayer(self) -> 'Ability':
        self.conditions = ([Condition.LimitOncePerPhasePerPlayer] + self.conditions)
        return self
    def LimitOncePerPhase(self) -> 'Ability':
        self.conditions = ([Condition.LimitOncePerPhase] + self.conditions)
        return self
    def LimitOncePerEvent(self) -> 'Ability':
        self.conditions = ([Condition.LimitOncePerEvent] + self.conditions)
        return self
    def LimitCardNameOncePerEvent(self) -> 'Ability':
        self.conditions = ([Condition.LimitOnceCardNamePerEvent] + self.conditions)
        return self
    def NoGameAreaLimit(self) -> 'Ability':
        self.ignore.game_area = True
        return self
    def AnyPlayerCanDoThis(self, *, owner_has_trait: 'CardFace.TRAITS|None'= None, player_identity_has_trait: 'CardFace.TRAITS|None'= None, player_alter_ego_has_trait: 'CardFace.TRAITS|None'= None) -> 'Ability':
        if player_identity_has_trait:
            def check_trigger_has_trait(effect):
                return effect.GetInitiator().GetIdentity().HasTrait(player_identity_has_trait)
            self.any_player_can_trigger_this_when.append(check_trigger_has_trait)
        if player_alter_ego_has_trait:
            def check_trigger_has_trait(effect):
                return effect.GetInitiator().GetIdentity().GetAlterEgoFace().HasTrait(player_alter_ego_has_trait)
            self.any_player_can_trigger_this_when.append(check_trigger_has_trait)
            return self
        if owner_has_trait:
            def check_owner_has_trait(effect):
                return effect.this.GetOwner().GetRoleCharacter().HasTrait(owner_has_trait)
            self.any_player_can_trigger_this_when.append(check_owner_has_trait)
            return self
        def return_true(effect):
            return True
        self.any_player_can_trigger_this_when.append(return_true)
        return self
    def SetToAvailableTimesFn(self, tiems_fn):
        self.available_times_fn = tiems_fn
        return self
    def SetCannotBeCancel(self) -> 'Ability':
        self.cannot_be_cancel = True
        return self
    def __repr__(self):
        return self.GetName(True)
    def GetName(self, debug):
        text = f'({self.flags.ability_type}'
        if self.func_names:
            text = (text + f",{','.join(self.func_names)}")
        if self.labels:
            text = (text + f",{','.join(self.labels)}")
        text = (text + ')')
        if self.name:
            text = (text + f' "{self.name}"')
        if debug:
            if self.paper:
                text = (text + f' [{self.paper.card_id}]')
            if (type(self.when) is types.UnionType):
                for name in get_args(type(self.when)):
                    text = (text + f' {name.__name__}')
                return text
            text = (text + f' {self.when.__name__}')
        return text
    def CopyFromDelayEffect(self, effect: Effect):
        if not (effect.ability.flags.is_delay_ability):
            raise AssertionError
        if not (self.flags.is_interrupt):
            if not (self.flags.is_response):
                if not (self.flags.is_when_defeated):
                    if not (self.flags.is_temp):
                        if not (self.flags.is_nonkeyword):
                            if not (self.flags.is_action):
                                if not (self.flags.is_rule):
                                    if not (self.flags.is_challenge):
                                        raise AssertionError
        for cost_func in effect.ability.cost_funcs:
            self.SetCostFunc(cost_func)
        if effect.ability.play_cost:
            self.SetPlayCost(effect.ability.play_cost)
        if effect.ability.cost_fn:
            self.SetCost(effect.ability.cost_fn)
        self.available_times_fn = effect.ability.available_times_fn
        self.any_player_can_trigger_this_when = effect.ability.any_player_can_trigger_this_when[:]
        self.labels = effect.ability.labels[:]
        self.func_names = set(effect.ability.func_names)
        for condition in (Condition.LimitOncePerRound, Condition.LimitOncePerRoundPerPlayer, Condition.LimitOncePerPhase, Condition.LimitOncePerEvent, Condition.LimitOnceCardNamePerEvent):
            if (condition in effect.ability.conditions):
                self.conditions.append(condition)
        self.selectors = [x for x in effect.ability.selectors]
        effect.delay_ability = self
