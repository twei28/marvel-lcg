# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryRecovery:
    @staticmethod
    def WhenUnitMakeRecovery(ability_type, which_unit, operation, *, conditions = [], is_basic_recovery = None):
        def check_which_unit(effect, message):
            return Condition.CheckWhichCard(which_unit, message.trigger, effect)
        return Ability(ability_type, Message.WhenUnitWouldRecovery, [check_which_unit, *conditions], operation, is_local=(which_unit == 'This'))
    @staticmethod
    def AfterUnitRecovery(ability_type, which_unit, operation, *, conditions = [], is_basic_recovery = None):
        def check_which_unit(effect, message):
            rule = Condition.GetYouRule(which_unit, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        return Ability(ability_type, Message.AfterUnitRecovery, [check_which_unit, *conditions], operation, is_local=(which_unit == 'This'))
    @staticmethod
    def AfterUnitMakeRecovery(ability_type, which_unit, operation, *, conditions = [], is_basic_recovery = None):
        return AbilityFactoryRecovery.AfterUnitRecovery(ability_type, which_unit, operation, conditions=conditions, is_basic_recovery=is_basic_recovery)
    @staticmethod
    def UnitCannotRecover(which_unit, *, cannot_trigger_recover_ability = None, conditions = []):
        def check_which_unit(effect, message):
            return Condition.CheckWhichCard(which_unit, message.check_identity, effect)
        abilities = [Ability(AbilityType.NonKeyword, Message.CheckIfUnitCanRecover, [check_which_unit, *conditions], lambda effect, message: message.SetCannotRecover(effect), is_local=(which_unit == 'This'))]
        return abilities
