# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from game.ability import *
from game.message import *
class ConditionOnEventType:
    __annotations__ = {}
    ON_EVENT = 'OnEvent.Base'
    ON_EVENT: TypeAlias
    EVENT_TYPE = (List[ON_EVENT] | ON_EVENT)
    EVENT_TYPE: TypeAlias
    @staticmethod
    def AddEvent(change_on_event, one_event):
        from game.message import OnEvent
        if (change_on_event == OnEvent.NONE):
            return [one_event]
        if isinstance(change_on_event, list):
            return (change_on_event + [one_event])
        return [change_on_event, one_event]
    @staticmethod
    def GetEventAbilities(change_on_event, ability_type, condition, operation):
        change_on_events = []
        if isinstance(change_on_event, list):
            change_on_events = change_on_event
        else:
            change_on_events = [change_on_event]
        abilities = []
        for on_event in change_on_events:
            abilities = (abilities + on_event.GenerateAbilities2(ability_type, condition, operation))
        return abilities
