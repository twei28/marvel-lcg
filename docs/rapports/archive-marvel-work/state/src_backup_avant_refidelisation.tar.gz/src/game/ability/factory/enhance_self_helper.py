# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def ThisGainKeywordInternal(change_on_event, check_fn, process_fn):
    from game.card.face.base import Unit2
    from game.card.face.base import Scheme2
    from game.card.face.card_type import Support
    from game.card.face.card_type import Upgrade
    from game.card.face.card_type import Attachment
    def process(effect, diff, curr):
        unit = effect.this
        if not (Unit2.IsType(unit)):
            if not (Scheme2.IsType(unit)):
                if not (Support.IsType(unit)):
                    if not (Upgrade.IsType(unit)):
                        if not (Attachment.IsType(unit)):
                            raise AssertionError
        process_fn(effect, unit, diff, curr)
        Message.AfterCardApply_Text([unit], effect, diff)
    def check(effect, last_value):
        faces = []
        value = check_fn(effect, faces)
        for face in faces:
            effect.this.card.ui.SetTempEffectBy(effect, face)
        return value
    from game.ability.factory import AbilityFactory
    return AbilityFactory.WhileValid(change_on_event, lambda effect, message: True, check, process)
