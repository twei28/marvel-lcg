# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryForm:
    @staticmethod
    def AfterUnitChangeFormInternal(ability_type, which_unit, operation, *, to_this_form = None, to_form = None, to_this_additional_form = None, is_change_additional_form = None, conditions = []):
        def check_which_unit(effect, message):
            rule = Condition.GetYouRule(which_unit, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        def check_to_this_form(effect, message):
            if (to_this_form == None):
                return True
            return ((effect.this == message.trigger) and (message.to_additional_form == None))
        def check_to_this_additional_form(effect, message):
            if (to_this_additional_form == None):
                return True
            return (effect.this == message.to_additional_form)
        def check_is_change_additional_form(effect, message):
            if (is_change_additional_form == None):
                return True
            return (is_change_additional_form == (message.to_additional_form != None))
        def check_to_form(effect, message):
            if (to_form == None):
                return True
            if Condition.CheckWhichCard(to_form, message.would_change_message.from_form, effect):
                return False
            return Condition.CheckWhichCard(to_form, message.trigger.GetControlByPlayer().GetIdentity(), effect)
        return Ability(ability_type, Message.AfterUnitChangeForm, [check_which_unit, check_to_this_form, check_to_this_additional_form, check_to_form, check_is_change_additional_form, *conditions], operation, is_local=(True if to_this_form == True else None))
    @staticmethod
    def AfterUnitChangeForm(ability_type, which_unit, operation, *, to_form = None, to_this_form = None, to_this_additional_form = None, is_change_additional_form = None, from_form = None, conditions = []):
        def action(effect: 'Effect', message: 'Message.WhenUnitWouldChangeForm'):
            this = effect.this
            ability = AbilityFactoryForm.AfterUnitChangeFormInternal(ability_type, which_unit, operation, to_this_form=to_this_form, to_form=to_form, to_this_additional_form=to_this_additional_form, is_change_additional_form=is_change_additional_form, conditions=conditions)
            ability.CopyFromDelayEffect(effect)
            this.effect.RegisterTemp(ability, unregister_after_exec=False, until_event_end=message)
        if (from_form != None):
            return AbilityFactoryForm.WhenUnitWouldChangeForm(AbilityType.DelayAbility, which_unit, action, from_form=from_form, to_form=to_form)
        return AbilityFactoryForm.AfterUnitChangeFormInternal(ability_type, which_unit, operation=operation, to_this_form=to_this_form, to_form=to_form, to_this_additional_form=to_this_additional_form, is_change_additional_form=is_change_additional_form, conditions=conditions)
    @staticmethod
    def WhenUnitWouldChangeForm(ability_type, which_unit, operation, *, to_form = None, from_form = None, during_your_turn = None, conditions = []):
        def check_from_form(effect, message):
            return Condition.CheckWhichCard(from_form, message.trigger, effect)
        def check_which_unit(effect, message):
            rule = Condition.GetYouRule(which_unit, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        def check_to_hero_form(effect, message):
            if (to_form == None):
                return True
            if Condition.CheckWhichCard(to_form, message.from_form, effect):
                return False
            return Condition.CheckWhichCard(to_form, message.to_form, effect)
        def check_during_your_turn(effect, message):
            if (during_your_turn == None):
                return True
            return effect.world.phase.IsPlayerPhase(message.trigger.GetControlByPlayer())
        return Ability(ability_type, Message.WhenUnitWouldChangeForm, [check_from_form, check_which_unit, check_to_hero_form, check_during_your_turn, *conditions], operation, is_local=(which_unit == 'This'))
