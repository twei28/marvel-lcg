# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryTurnPhase:
    @staticmethod
    def WhenInYourPlayTurn(ability_type, operation, *, conditions = []):
        return Ability(ability_type, Message.WhenPlayerInTurn, [lambda effect, message: (effect.initiator == message.to_player), *conditions], operation)
    @staticmethod
    def WhenPlayerTurnBegin(ability_type, which_player, operation, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        return Ability(ability_type, Message.WhenPlayerTurnBegin, [check_which_player, *conditions], operation)
    @staticmethod
    def AfterPlayerTurnBegin(ability_type, which_player, operation, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        return Ability(ability_type, Message.AfterPlayerTurnBegin, [check_which_player, *conditions], operation)
    @staticmethod
    def AfterPlayerTurnEnd(ability_type, which_player, operation, *, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        return Ability(ability_type, Message.AfterPlayerTurnEnd, [check_which_player, *conditions], operation)
    @staticmethod
    def WhenPlayerTurnEnd(ability_type, which_player, operation, *, round_id = None, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        def check_turn_id(effect, message):
            if not (round_id):
                return True
            return (round_id == message.round_id)
        return Ability(ability_type, Message.WhenPlayerTurnEnd, [check_which_player, check_turn_id, *conditions], operation)
    @staticmethod
    def WhenMainSchemePhaseEnd(ability_type, operation, *, conditions = []):
        return Ability(ability_type, Message.WhenMainSchemePhaseEnd, conditions, operation)
    @staticmethod
    def WhenPhaseBegin(ability_type, phase_name, operation, *, round_id = None, conditions = []):
        def check_phase_name(effect, message):
            if (phase_name == None):
                return True
            if (phase_name == 'Player'):
                return (phase_name == message.phase_name)
            if (phase_name == 'Villain'):
                return (phase_name == message.phase_name)
            return (phase_name == message.phase_id)
        def check_round_id(effect, message):
            if (round_id == None):
                return True
            return (round_id == message.round_id)
        return Ability(ability_type, Message.WhenPhaseBegin, [check_phase_name, check_round_id, *conditions], operation)
    @staticmethod
    def WhenPlayerPhaseBegin(ability_type, operation, *, conditions = []):
        return AbilityFactoryTurnPhase.WhenPhaseBegin(ability_type, 'Player', operation, conditions=conditions)
    @staticmethod
    def WhenVillainPhaseBegin(ability_type, operation, *, conditions = []):
        return AbilityFactoryTurnPhase.WhenPhaseBegin(ability_type, 'Villain', operation, conditions=conditions)
    @staticmethod
    def AfterPhaseBegin(ability_type, phase_name, operation, *, conditions = []):
        def check_phase_name(effect, message):
            if (phase_name == 'Player'):
                return (phase_name == message.phase_name)
            if (phase_name == 'Villain'):
                return (phase_name == message.phase_name)
            if (phase_name == None):
                return True
            return (phase_name == message.phase_id)
        return Ability(ability_type, Message.AfterPhaseBegin, [check_phase_name, *conditions], operation)
    @staticmethod
    def AfterPlayerPhaseBegin(ability_type, operation, *, conditions = []):
        return AbilityFactoryTurnPhase.AfterPhaseBegin(ability_type, 'Player', operation, conditions=conditions)
    @staticmethod
    def WhenPhaseEnd(ability_type, phase_name, operation, *, conditions = []):
        def check_phase_name(effect, message):
            if (phase_name == 'Player'):
                return (phase_name == message.phase_name)
            if (phase_name == 'Villain'):
                return (phase_name == message.phase_name)
            if (phase_name == None):
                return True
            return (phase_name == message.phase_id)
        return Ability(ability_type, Message.WhenPhaseEnd, [check_phase_name, *conditions], operation)
    @staticmethod
    def WhenPlayerPhaseEnd(ability_type, operation, *, conditions = []):
        return AbilityFactoryTurnPhase.WhenPhaseEnd(ability_type, 'Player', operation, conditions=conditions)
    @staticmethod
    def WhenVillainPhaseEnd(ability_type, operation, *, conditions = []):
        return AbilityFactoryTurnPhase.WhenPhaseEnd(ability_type, 'Villain', operation, conditions=conditions)
    @staticmethod
    def WhenRoundEnd(ability_type, round_id, operation, conditions = []):
        def check_round_id(effect, message):
            if (round_id == None):
                return True
            return (round_id == message.round_id)
        return Ability(ability_type, Message.WhenRoundEnd, [check_round_id, *conditions], operation)
    @staticmethod
    def AfterPhaseEnd(ability_type, phase_name, operation, *, conditions = []):
        def check_phase_name(effect, message):
            if (phase_name == 'Player'):
                return (phase_name == message.phase_name)
            if (phase_name == 'Villain'):
                return (phase_name == message.phase_name)
            if (phase_name == None):
                return True
            return (phase_name == message.phase_id)
        return Ability(ability_type, Message.AfterPhaseEnd, [check_phase_name, *conditions], operation)
    @staticmethod
    def AfterRoundEnd(ability_type, operation, *, conditions = []):
        return Ability(ability_type, Message.AfterRoundEnd, conditions, operation)
    @staticmethod
    def AfterResolveVillainPhaseStep(ability_type, step, operation, *, conditions = []):
        return Ability(ability_type, Message.AfterResolveVillainPhaseStep, [lambda effect, message: (message.step == step), *conditions], operation)
    @staticmethod
    def WhenVillainPhaseStepStart(ability_type, step, operation):
        return Ability(ability_type, Message.WhenVillainPhaseStepStart, [lambda effect, message: (message.step == step)], operation)
