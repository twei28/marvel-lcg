# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryDoThwart:
    @staticmethod
    def WhenAttachedPlayerWouldThwart(ability_type, attacker, operation):
        from game.ability.factory import AbilityFactory
        return [AbilityFactory.WhenUnitWouldAttack(ability_type, attacker, operation), AbilityFactory.WhenPlayerWouldPlayCard(ability_type, 'AttachedPlayer', None, operation, conditions=[lambda effect, message: message.play_effect.ability.is_label_thwart])]
