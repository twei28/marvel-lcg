# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryDoAttack:
    @staticmethod
    def WhenAttachedPlayerWouldAttack(ability_type, attacker, operation):
        from game.ability.factory import AbilityFactory
        return [AbilityFactory.WhenUnitWouldAttack(ability_type, attacker, operation), AbilityFactory.WhenPlayerWouldPlayCard(ability_type, 'AttachedPlayer', None, operation, conditions=[lambda effect, message: message.play_effect.ability.is_label_attack])]
    @staticmethod
    def WhenUnitWouldAttack(ability_type, attacker, operation, *, against_player = 'AnyPlayer', attack_targets = None, is_basic_attack = None, by_effect = None, conditions = []):
        def check_attacker(effect, message):
            rule = Condition.GetYouRule(attacker, identity=True)
            return Condition.CheckWhichCard(rule, message.attacker, effect)
        def check_against_player(effect, message):
            return Condition.CheckAgainstPlayer(against_player, message, effect)
        def check_who_be_attacked(effect, message):
            return Condition.CheckWhichCard(attack_targets, message.attacked_targets, effect)
        def check_is_basic_attack(effect, message):
            if (is_basic_attack == None):
                return True
            return (is_basic_attack == message.IsBasicAttack())
        def check_by_effect(effect, message):
            if (by_effect == None):
                return True
            return (by_effect == message.by_effect)
        return Ability(ability_type, Message.WhenUnitWouldAttack, [check_attacker, check_against_player, check_is_basic_attack, check_who_be_attacked, check_by_effect, *conditions], operation, is_local=(attacker == 'This'))
    @staticmethod
    def WhenUnitMakeAttack(ability_type, attacker, operation, *, is_basic_attack = None, conditions = []):
        return AbilityFactoryDoAttack.WhenUnitWouldAttack(ability_type, attacker, operation, is_basic_attack=is_basic_attack, conditions=conditions)
    @staticmethod
    def WhenUnitMakeKeyWordAttack(ability_type, attacker, operation, *, is_basic_attack = None, has_keyword = 'Any', conditions = []):
        def check_attacker(effect, message):
            rule = Condition.GetYouRule(attacker, identity=True)
            return Condition.CheckWhichCard(rule, message.attacker, effect)
        def check_is_basic_attack(effect, message):
            if (is_basic_attack == None):
                return True
            return (is_basic_attack == message.IsBasicAttack())
        def check_has_keyword(effect, message):
            if (has_keyword == 'Any'):
                return message.would_atk_unit_message.HasKeywords()
            if (has_keyword == 'Ranged'):
                if not (message.would_atk_unit_message.IsRanged()):
                    return False
            if (has_keyword == 'Piercing'):
                if not (message.would_atk_unit_message.IsPiercing()):
                    return False
            if (has_keyword == 'Overkill'):
                if not (message.would_atk_unit_message.IsOverKill()):
                    return False
            return True
        return Ability(ability_type, Message.WhenUnitMakeKeyWordAttack, [check_attacker, check_is_basic_attack, check_has_keyword, *conditions], operation, is_local=(attacker == 'This'))
    @staticmethod
    def WhenUnitInitiatesAttackAgainst(ability_type, attacker, against_player, operation, conditions = []):
        return AbilityFactoryDoAttack.WhenUnitWouldAttack(ability_type, attacker, operation, against_player=against_player, conditions=conditions)
    @staticmethod
    def WhenUnitAttackYou(ability_type, attacker, operation, conditions = []):
        return AbilityFactoryDoAttack.WhenUnitInitiatesAttackAgainst(ability_type, attacker, 'You', operation, conditions=conditions)
    @staticmethod
    def WhenUnitWouldAttackUnit(ability_type, attacker, who_be_attacked, operation, *, is_basic_attack = None, conditions = []):
        def check_attacker(effect, message):
            rule = Condition.GetYouRule(attacker, identity=True)
            return Condition.CheckWhichCard(rule, message.attacker, effect)
        def check_who_be_attack(effect, message):
            return Condition.CheckWhichCard(who_be_attacked, message.target, effect)
        def check_is_basic_attack(effect, message):
            if (is_basic_attack == None):
                return True
            return (is_basic_attack == message.IsBasicAttack())
        return Ability(ability_type, Message.WhenUnitWouldAttackUnit, [check_attacker, check_who_be_attack, check_is_basic_attack, *conditions], operation, is_local=((attacker == 'This') or (who_be_attacked == 'This')))
    @staticmethod
    def WhenUnitDefendAgainstAttack(ability_type, who_defense, operation, *, against_who = None, is_basic_defense = None, conditions = []):
        from game.card.face.card_type import Hero
        def check_who_defense(effect, message):
            if (who_defense == 'You'):
                return (Condition.ThisIsYou(effect, message.trigger) and (effect.GetInitiator().GetIdentity() == message.trigger))
            if (who_defense == 'YourHero'):
                return (Condition.ThisIsYou(effect, message.trigger) and (Hero.IsType(message.trigger) and (effect.GetInitiator().GetIdentity() == message.trigger)))
            return Condition.CheckWhichCard(who_defense, message.trigger, effect)
        def check_against_who(effect, message):
            return Condition.CheckWhichCard(against_who, message.attacker, effect)
        def check_is_basic_defense(effect, message):
            if (is_basic_defense == None):
                return True
            return (is_basic_defense == message.IsBasicDefense())
        return Ability(ability_type, Message.WhenUnitWouldDefend, [check_who_defense, check_against_who, check_is_basic_defense, *conditions], operation, is_local=((who_defense == 'This') or (against_who == 'This')))
    @staticmethod
    def AfterUnitDefendEnd(ability_type, who_defense, operation, *, conditions = []):
        return AbilityFactoryDoAttack.AfterUnitDefendAgainstAttack(ability_type, who_defense, operation, conditions=conditions)
    @staticmethod
    def AfterUnitDefendAgainstAttack(ability_type, who_defense, operation, *, attacker = None, against_which_attack = None, take_no_damage = None, conditions = []):
        def check_who_defense(effect, message):
            rule = Condition.GetYouRule(who_defense, identity=True)
            return Condition.CheckWhichCard(rule, message.defender, effect)
        def check_attacker(effect, message):
            return Condition.CheckWhichCard(attacker, message.attacker, effect)
        def check_against_attack(effect, message):
            if (against_which_attack == None):
                return True
            return (against_which_attack == message.would_atk_message)
        def check_take_no_damage(effect, message):
            if (take_no_damage == None):
                return True
            return (message.taken_damage == 0)
        return Ability(ability_type, Message.AfterUnitDefendEnd, [check_who_defense, check_attacker, check_against_attack, check_take_no_damage, *conditions], operation, is_local=((who_defense == 'This') or (attacker == 'This')))
    @staticmethod
    def WhenUnitAttackDealExcessDamage(ability_type, who_deal, operation, *, conditions = []):
        def check_who_deal(effect, message):
            rule = Condition.GetYouRule(who_deal, identity=True)
            return Condition.CheckWhichCard(rule, message.attacker, effect)
        return Ability(ability_type, Message.WhenCalcDealExcessDamage, [check_who_deal, *conditions], operation, is_local=(who_deal == 'This'))
    @staticmethod
    def AfterUnitAttackUnitInternal(ability_type, attacker, who_be_attacked, operation, *, atk_message = None, use_atk = None, dealt_damage = None, dealt_more_than_damage = None, target_took_damage = None, is_undefended_attack = None, who_is_target = None, conditions = []):
        from game.card.face.card_type import Identity
        from game.card.face.base import ClassCard
        def check_attacker(effect, message):
            rule = Condition.GetYouRule(attacker, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        def check_atk_message(effect, message):
            if (atk_message == None):
                return True
            return (atk_message == message.would_atk_unit_message)
        def check_who_be_attacked(effect, message):
            from game.card.face.base import EncounterCard
            if (who_be_attacked == 'You'):
                if dealt_damage:
                    if ClassCard.IsType(effect.this):
                        return ((message.to_player != None) and (effect.initiator == message.to_player))
                    return ((message.to_player != None) and ((message.attacked.GetControlBy() == message.to_player) and Identity.IsType(message.attacked)))
                if (message.attacked_you == None):
                    return False
                if EncounterCard.IsType(effect.this):
                    return True
                return Condition.ThisIsYou(effect, message.attacked_you)
            return Condition.CheckWhichCard(who_be_attacked, message.attacked, effect)
        def check_use_atk(effect, message):
            if (use_atk == None):
                return True
            return (use_atk == message.would_atk_message.IsBasicAttack())
        def check_dealt_damage(effect, message):
            if (dealt_damage == None):
                return True
            return (message.dealt_damage > 0)
        def check_dealt_more_than_damage(effect, message):
            if (dealt_more_than_damage == None):
                return True
            return (message.dealt_damage >= dealt_more_than_damage)
        def check_target_took_damage(effect, message):
            if (target_took_damage == None):
                return True
            rule = Condition.GetYouRule(who_be_attacked, identity=True)
            return (Condition.CheckWhichCard(rule, message.attacked, effect) and (message.taken_damage > 0))
        def check_is_undefended_attack(effect, message):
            if (is_undefended_attack == None):
                return True
            if is_undefended_attack:
                return (message.defender == None)
            return (message.defender != None)
        def check_who_is_target(effect, message):
            if (who_is_target == None):
                return True
            return (who_is_target.card.face == message.attacked)
        return Ability(ability_type, Message.AfterUnitAttackUnit, [check_dealt_damage, check_attacker, check_atk_message, check_who_be_attacked, check_use_atk, check_dealt_more_than_damage, check_target_took_damage, check_is_undefended_attack, check_who_is_target, *conditions], operation, is_local=((attacker == 'This') or (who_be_attacked == 'This')))
    @staticmethod
    def AfterUnitAttackAndDamageUnit(ability_type, attacker, who_be_attacked, operation, *, target_in_play = None, use_atk = None, dealt_more_than_damage = None, conditions = []):
        def check_target_in_play(effect, message):
            if (target_in_play == None):
                return True
            return message.attacked.IsInPlay()
        return AbilityFactoryDoAttack.AfterUnitAttackUnit(ability_type, attacker, who_be_attacked, operation, use_atk=use_atk, target_took_damage=True, dealt_more_than_damage=dealt_more_than_damage, conditions=[check_target_in_play, *conditions])
    @staticmethod
    def AfterUnitDealsDamageWithSingleAttack(ability_type, attacker, who_be_damaged, operation, *, dealt_more_than_damage = None):
        from game.ability.factory import AbilityFactory
        return [AbilityFactory.AfterFaceDealDamage(ability_type, attacker, who_be_damaged, operation, is_from_attack=True, dealt_more_than_damage=dealt_more_than_damage), AbilityFactory.AfterUnitAttackUnit(AbilityType.ForcedResponse, attacker, who_be_damaged, operation, dealt_more_than_damage=dealt_more_than_damage)]
    @staticmethod
    def AfterUnitAttackUnit(ability_type, attacker, who_be_attacked, operation, *, use_atk = None, dealt_damage = None, target_took_damage = None, dealt_more_than_damage = None, is_undefended_attack = None, conditions = []):
        from game.card.card_finder import CardFinder
        from game.player import Player
        if not (isinstance(who_be_attacked, CardFinder)):
            if (who_be_attacked != 'YouControlCharacter'):
                return AbilityFactoryDoAttack.AfterUnitAttackUnitInternal(ability_type, attacker, who_be_attacked, operation, use_atk=use_atk, dealt_damage=dealt_damage, target_took_damage=target_took_damage, dealt_more_than_damage=dealt_more_than_damage, is_undefended_attack=is_undefended_attack, conditions=conditions)
        def action(effect: Effect, message: Message.WhenUnitWouldAttackUnit):
            this = effect.this
            target = message.target
            if (who_be_attacked == 'YouControlCharacter'):
                finder = None
                Player.IsType(message.target.GetControlBy())
            else:
                if not ((who_be_attacked == None)):
                    if not (isinstance(who_be_attacked, CardFinder)):
                        raise AssertionError
                finder = who_be_attacked
            if finder:
                if finder.Check(target):
                    ability = AbilityFactoryDoAttack.AfterUnitAttackUnitInternal(ability_type, attacker, None, operation, use_atk=use_atk, dealt_damage=dealt_damage, target_took_damage=target_took_damage, dealt_more_than_damage=dealt_more_than_damage, is_undefended_attack=is_undefended_attack, who_is_target=target, conditions=conditions)
                    ability.CopyFromDelayEffect(effect)
                    this.effect.RegisterTemp(ability, unregister_after_exec=True, until_event_end=message)
                    return
            ability = AbilityFactoryDoAttack.AfterUnitAttackUnitInternal(ability_type, attacker, None, operation, use_atk=use_atk, dealt_damage=dealt_damage, target_took_damage=target_took_damage, dealt_more_than_damage=dealt_more_than_damage, is_undefended_attack=is_undefended_attack, who_is_target=target, conditions=conditions)
            ability.CopyFromDelayEffect(effect)
            this.effect.RegisterTemp(ability, unregister_after_exec=True, until_event_end=message)
        return AbilityFactoryDoAttack.WhenUnitWouldAttackUnit(AbilityType.DelayAbility, attacker, None, action)
    @staticmethod
    def AfterUnitAttackEnd(ability_type, attacker, operation, *, is_basic_attack = None, damaged_who = None, against_who = None, conditions = [], would_atk_message = None):
        def check_is_basic_attack(effect, message):
            if (is_basic_attack == None):
                return True
            return (is_basic_attack == message.IsBasicAttack())
        def check_against_who(effect, message):
            if (against_who == None):
                return True
            if (against_who == 'You'):
                against_player = message.GetAgainstPlayer()
                if against_who:
                    return (against_player != None)
                return (against_player == None)
            return Condition.CheckWhichCard(against_who, message.attacked_targets, effect)
        def check_damage_who(effect, message):
            if (damaged_who == None):
                return True
            return Condition.CheckWhichCard(damaged_who, message.damaged_targets, effect)
        def check_attacker(effect, message):
            rule = Condition.GetYouRule(attacker, identity=True)
            return Condition.CheckWhichCard(rule, message.attacker, effect)
        def check_would_atk_message(effect, message):
            if (would_atk_message == None):
                return True
            return (would_atk_message in message.would_atk_messages)
        return Ability(ability_type, Message.AfterUnitAttackEnd, [check_attacker, check_is_basic_attack, check_against_who, check_damage_who, check_would_atk_message, *conditions], operation, is_local=((attacker == 'This') or ((damaged_who == 'This') or (against_who == 'This'))))
    @staticmethod
    def AfterUnitAttackYou(ability_type, attacker, operation, *, conditions = []):
        return AbilityFactoryDoAttack.AfterUnitAttackEnd(ability_type, attacker, operation, conditions=conditions, against_who='You')
    @staticmethod
    def AfterUnitMakeBasicAttack(ability_type, attacker, operation, *, damage_who = None, against_who = None):
        return AbilityFactoryDoAttack.AfterUnitAttackEnd(ability_type, attacker, operation, against_who=against_who, damaged_who=damage_who, is_basic_attack=True)
    @staticmethod
    def UnitGetATKWhileAttacking(ability_type, which_card, target, calc_fn, *, is_undefended_attack = None):
        from game.ability.factory import AbilityFactory
        def check_player(effect, message):
            return Condition.CheckWhichCard(which_card, message.GetToPlayer().GetIdentity(), effect)
        def gain_attack_damage(effect: Effect, message: Message.WhenEffectWouldResolve):
            if not (isinstance(calc_fn, int)):
                raise AssertionError
            value = calc_fn
            message.effect.initiator.GetRoleCharacter().TemporaryGain(effect, message, attack=value)
        return [AbilityFactory.WhenCardWouldResolveAbility(ability_type, None, None, gain_attack_damage, label='attack', trigger_player='You', conditions=[check_player]), AbilityFactoryDoAttack.UnitGetATKWhileAttackingInternal(ability_type, which_card, target, calc_fn, is_undefended_attack=is_undefended_attack)]
    @staticmethod
    def UnitGetATKWhileAttackingInternal(ability_type, which_card, target, calc_fn, *, is_undefended_attack = None):
        def gain_attack_damage(effect: Effect, message: Message.WhenRecalculateAttackDamage):
            if isinstance(calc_fn, int):
                value = calc_fn
            else:
                value = calc_fn(effect, message)
            message.IncreaseDamage(value, effect)
        def check_this(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_target(effect, message):
            if (target == None):
                return True
            return Condition.CheckWhichCard(target, message.target, effect)
        def check_is_basic_attack(effect, message):
            return message.would_atk_message.IsBasicAttack()
        def check_is_undefended_attack(effect, message):
            if (is_undefended_attack == None):
                return True
            return (is_undefended_attack == (message.would_atk_message.GetDefender() == None))
        return Ability(ability_type, Message.WhenRecalculateAttackDamage, [check_is_basic_attack, check_target, check_this, check_is_undefended_attack], gain_attack_damage)
    @staticmethod
    def UnitAttackGainKeyword(attacker, target = None, *, is_basic_attack = None, conditions = [], overkill = False, ranged = False, piercing = False, indirect_damage = False, ignore_retaliate = False, lost_piercing = False):
        def gain(effect: Effect, message: Message.CheckIfAttackMessageHasKeyword):
            if overkill:
                message.GainOverKill(effect)
            if ranged:
                message.GainRanged(effect)
            if piercing:
                message.GainPiercing(effect)
            if indirect_damage:
                message.SetDealIndirectDamage(effect)
            if ignore_retaliate:
                message.SetIgnoreRetaliate(effect)
            if lost_piercing:
                message.SetLostPiercing(effect)
                return
        def check_attacker(effect, message):
            rule = Condition.GetYouRule(attacker, identity=True)
            return Condition.CheckWhichCard(rule, message.attacker, effect)
        def check_target(effect, message):
            return Condition.CheckWhichCard(target, message.targets, effect)
        def check_is_basic_attack(effect, message):
            if (is_basic_attack == None):
                return True
            return (is_basic_attack == message.IsBasicAttack())
        return Ability(AbilityType.NonKeyword, Message.CheckIfAttackMessageHasKeyword, [check_attacker, check_target, check_is_basic_attack, *conditions], gain, is_local=(attacker == 'This'))
    @staticmethod
    def WhenUnitWouldBeAttacked(ability_type, who_be_attacked, operation, *, conditions = []):
        from game.card.face.card_type import Upgrade
        from game.card.face.card_type import Attachment
        def check_who_be_attacked(effect, message):
            if (who_be_attacked == 'Attached'):
                return (isinstance(effect.this, (Attachment | Upgrade)) and ((effect.this.bind_face != None) and message.HasTarget(effect.this.bind_face)))
            return Condition.CheckWhichCard(who_be_attacked, message.attacked_targets, effect)
        return Ability(ability_type, Message.WhenUnitWouldAttack, [check_who_be_attacked, *conditions], operation, is_local=(who_be_attacked == 'This'))
    @staticmethod
    def AfterUnitBeAttacked(ability_type, who_be_attacked, operation, *, attacker = None, conditions = []):
        def check_who_be_attacked(effect, message):
            return Condition.CheckWhichCard(who_be_attacked, message.attacked, effect)
        def check_attacker(effect, message):
            return Condition.CheckWhichCard(attacker, message.attacker, effect)
        return Ability(ability_type, Message.AfterUnitAttackUnit, [check_who_be_attacked, check_attacker, *conditions], operation, is_local=((attacker == 'This') or (who_be_attacked == 'This')))
    @staticmethod
    def WhenUnitBeingAttack(ability_type, who_be_attacked, attacker, operation, *, has_defender = None, is_basic_attack = None, would_atk_message = None, conditions = []):
        def check_who_be_attacked(effect, message):
            rule = Condition.GetYouRule(who_be_attacked, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        def check_attacker(effect, message):
            return Condition.CheckWhichCard(attacker, message.attacker, effect)
        def check_has_defender(effect, message):
            if (has_defender == None):
                return True
            return (has_defender == (message.defender != None))
        def check_is_basic_attack(effect, message):
            if (is_basic_attack == None):
                return True
            return (is_basic_attack == message.IsBasicAttack())
        def check_atk_message(effect, message):
            if (would_atk_message == None):
                return True
            return (would_atk_message == message.would_atk_message)
        return Ability(ability_type, Message.WhenUnitBeingAttack, [check_who_be_attacked, check_attacker, check_has_defender, check_is_basic_attack, check_atk_message, *conditions], operation, is_local=((who_be_attacked == 'This') or (attacker == 'This')))
    @staticmethod
    def UnitCannotBeAttacked(which_unit, *, conditions = []):
        def check_which_unit(effect, message):
            return Condition.CheckWhichCard(which_unit, message.being_attack, effect)
        return Ability(AbilityType.NonKeyword, Message.CheckIfUnitCanBeAttackBy, [check_which_unit, *conditions], lambda effect, message: message.SetCannotBeAttack(effect), is_local=(which_unit == 'This'))
    @staticmethod
    def UnitCannotAttackTarget(attacker, *, cannot_attack = None, can_only_attack = None, cannot_trigger_attack_ability = None, conditions = []):
        from game.ability.factory import AbilityFactory
        def check_attacker(effect, message):
            return Condition.CheckWhichCard(attacker, message.attacker, effect)
        def check_cannot_attack(effect, message):
            if (cannot_attack == True):
                return True
            return Condition.CheckWhichCard(cannot_attack, message.being_attack, effect)
        def check_can_only_attack(effect, message):
            if (can_only_attack == None):
                return True
            return (not Condition.CheckWhichCard(can_only_attack, message.being_attack, effect))
        if (cannot_attack == True):
            abilities = [Ability(AbilityType.NonKeyword, Message.CheckIfUnitCanAttack, [lambda effect, message: Condition.CheckWhichCard(attacker, message.check_unit, effect)], lambda effect, message: message.SetCannotAttack(effect), is_local=(attacker == 'This'))]
        else:
            abilities = [Ability(AbilityType.NonKeyword, Message.CheckIfUnitCanBeAttackBy, [check_attacker, check_cannot_attack, check_can_only_attack, *conditions], lambda effect, message: message.SetCannotBeAttack(effect), is_local=((attacker == 'This') or (cannot_attack == 'This')))]
        if (attacker == 'AttachedIdentity'):
            if (cannot_trigger_attack_ability != False):
                abilities.append(AbilityFactory.PlayersCannotTriggerAbility('AttachedPlayer', None, label='attack'))
        return abilities
    @staticmethod
    def UnitCannotMakeBasicDefense(which_unit, who_attacker, *, conditions = []):
        return AbilityFactoryDoAttack.UnitCannotDefend(which_unit, who_attacker, cannot_trigger_defense_ability=False, conditions=conditions)
    @staticmethod
    def UnitCannotDefend(which_unit, who_attacker, *, cannot_trigger_defense_ability, conditions = []):
        from game.ability.factory import AbilityFactory
        def check_which_unit(effect, message):
            return Condition.CheckWhichCard(which_unit, message.check_unit, effect)
        def check_attacker(effect, message):
            return Condition.CheckWhichCard(who_attacker, message.attacker, effect)
        abilities = [Ability(AbilityType.NonKeyword, Message.CheckIfUnitCanDefendAgainstAttack, [check_which_unit, check_attacker, *conditions], lambda effect, message: message.SetCannotDefend(effect), is_local=((which_unit == 'This') or (who_attacker == 'This')))]
        if (cannot_trigger_defense_ability != False):
            # (restauration : la version récupérée avait perdu check_attacker2 et
            # l'append PlayersCannotTriggerAbility présents dans le bytecode original)
            on_which_card = None
            if (cannot_trigger_defense_ability == True) and (which_unit == 'Attached'):
                check_player = 'AttachedPlayer'
            elif isinstance(which_unit, str) and which_unit.startswith('Attached'):
                # CORRECTIF (bug du jeu original) : 'AttachedIdentity'/'AttachedAlly'
                # levaient AssertionError (cartes 32150, 32055, 55062).
                check_player = 'AttachedPlayer'
            elif which_unit:
                if isinstance(which_unit, CardFinder):
                    check_player = PlayerFinder(which_unit)
                else:
                    # CORRECTIF (bug du jeu original) : un type de carte ('Character',
                    # Unit2, Ally...) levait AssertionError (cartes 28030, 27152, 55061).
                    # On bloque les capacités label='defense' portées par ces cartes.
                    check_player = 'AnyPlayer'
                    on_which_card = which_unit
            else:
                check_player = 'AnyPlayer'
            def check_attacker2(effect, message):
                return Condition.CheckWhichCard(who_attacker, message.GetAttacker(), effect)
            abilities.append(AbilityFactory.PlayersCannotTriggerAbility(check_player, None, label='defense', on_which_card=on_which_card, conditions=[check_attacker2]))
        return abilities
    @staticmethod
    def AfterUnitAttackOrThwart(ability_type, attacker, operation, *, is_basic_power = None, conditions = []):
        def check_is_basic_power(effect, message):
            if (is_basic_power == None):
                return True
            if isinstance(message, Message.AfterUnitAttackEnd):
                return (is_basic_power == message.IsBasicAttack())
            return (is_basic_power == message.IsBasicThwart())
        def check_trigger(effect, message):
            return Condition.CheckWhichCard(attacker, message.trigger, effect)
        return Ability(ability_type, (Message.AfterUnitAttackEnd | Message.AfterUnitThwartEnd), [check_trigger, check_is_basic_power, *conditions], operation, is_local=(attacker == 'This'))
    @staticmethod
    def AfterUnitAttackOrDefend(ability_type, which_unit, operation, *, is_basic_power = None, conditions = []):
        def check_is_basic_power(effect, message):
            if (is_basic_power == None):
                return True
            if isinstance(message, Message.AfterUnitAttackEnd):
                return (is_basic_power == message.IsBasicAttack())
            for would_def_message in message.would_def_messages:
                if (is_basic_power == would_def_message.IsBasicDefense()):
                    return True
            return False
        def check_trigger(effect, message):
            rule = Condition.GetYouRule(which_unit, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        return Ability(ability_type, (Message.AfterUnitAttackEnd | Message.AfterUnitDefendEnd), [check_trigger, check_is_basic_power, *conditions], operation, is_local=(which_unit == 'This'))
    @staticmethod
    def WhenUnitWouldAttackOrThwart(ability_type, attacker, operation, *, is_basic_power = None, conditions = []):
        def check_is_basic_power(effect, message):
            if (is_basic_power == None):
                return True
            if isinstance(message, Message.WhenUnitWouldAttack):
                return (is_basic_power == message.IsBasicAttack())
            return (is_basic_power == message.IsBasicThwart())
        def check_trigger(effect, message):
            return Condition.CheckWhichCard(attacker, message.trigger, effect)
        return Ability(ability_type, (Message.WhenUnitWouldAttack | Message.WhenUnitWouldThwart), [check_trigger, check_is_basic_power, *conditions], operation, is_local=(attacker == 'This'))
    @staticmethod
    def AfterUnitBecomeDefender(ability_type, operation, *, by_effect_face = None, conditions = []):
        def check_by_face(effect, message):
            if (by_effect_face == None):
                return True
            return Condition.CheckWhichCard(by_effect_face, message.by_effect.this, effect)
        return Ability(ability_type, Message.AfterUnitBecomeDefender, [check_by_face, *conditions], operation, is_local=(by_effect_face == 'This'))
