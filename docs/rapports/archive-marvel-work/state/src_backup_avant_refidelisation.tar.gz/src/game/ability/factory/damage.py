# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryDamage:
    @staticmethod
    def WhenUnitWouldTakeDamage(ability_type, who_take_damage, operation, *, is_from_attack = None, is_consequential_damage = None, while_defending = None, control_by = None, who_deal_damage = None, at_least_damage = 1, more_than_damage = 0, not_include_this_effect = None, conditions = []):
        def check_who_take_damage(effect, message):
            rule = Condition.GetYouRule(who_take_damage, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        def check_is_from_attack(effect, message):
            if (is_from_attack == None):
                return True
            if isinstance(is_from_attack, Message2):
                return (is_from_attack == message.would_atk_message)
            return (is_from_attack == message.IsFromAttack())
        def check_is_consequential_damage(effect, message):
            if (is_consequential_damage == None):
                return True
            from game.effect.rule import Consequential
            return (type(message.would_deal_damage_message.by_effect) is Consequential)
        def check_while_defending(effect, message):
            if (while_defending == None):
                return True
            if (while_defending == True):
                return ((message.being_atk_message != None) and (message.trigger == message.being_atk_message.defender))
            return ((message.being_atk_message == None) or (message.trigger != message.being_atk_message.defender))
        def check_control_by(effect, message):
            if (control_by == None):
                return True
            return (control_by == message.trigger.GetControlBy())
        def check_not_include_this_effect(effect, message):
            if (not_include_this_effect == None):
                return True
            if not ((not_include_this_effect == True)):
                raise AssertionError
            return (effect != message.by_effect)
        def check_who_deal_damage(effect, message):
            return Condition.CheckWhichCard(who_deal_damage, message.source, effect)
        return Ability(ability_type, Message.WhenUnitWouldTakeDamage, [lambda effect, message: ((not message.IsBePrevent()) and ((message.will_take_damage >= at_least_damage) and (message.will_take_damage > more_than_damage))), check_who_take_damage, check_is_from_attack, check_while_defending, check_who_deal_damage, check_is_consequential_damage, check_control_by, check_not_include_this_effect, *conditions], operation, is_local=((who_take_damage == 'This') or (who_deal_damage == 'This')))
    @staticmethod
    def AfterUnitTookDamage(ability_type, who_took_damage, operation, *, is_from_attack = None, is_indirect_damage = None, who_dealt_damage = None, conditions = []):
        def check_who_took_damage(effect, message):
            rule = Condition.GetYouRule(who_took_damage, identity=True)
            return Condition.CheckWhichCard(rule, message.trigger, effect)
        def check_is_from_attack(effect, message):
            if (is_from_attack == None):
                return True
            if isinstance(is_from_attack, Message2):
                return (is_from_attack == message.would_atk_message)
            return (is_from_attack == message.IsFromAttack())
        def check_who_dealt_damage(effect, message):
            return Condition.CheckWhichCard(who_dealt_damage, message.source, effect)
        def check_is_indirect_damage(effect, message):
            if (is_indirect_damage == None):
                return True
            return (is_indirect_damage == message.IsIndirectDamage())
        return Ability(ability_type, Message.AfterUnitTookDamage, [lambda effect, message: (message.took_damage > 0), check_who_took_damage, check_is_from_attack, check_who_dealt_damage, check_is_indirect_damage, *conditions], operation, is_local=((who_took_damage == 'This') or (who_dealt_damage == 'This')))
    @staticmethod
    def AfterYouDealDamage(ability_type, dealt_to_who, operation, *, conditions = []):
        return AbilityFactoryDamage.AfterFaceDealDamage(ability_type, 'YourIdentity', dealt_to_who, operation, conditions=conditions)
    @staticmethod
    def AfterUnitDealExcessDamage(ability_type, which_card, operation, *, to_target = None, by_effect = None, conditions = []):
        def check_who(effect, message):
            rule = Condition.GetYouRule(which_card, identity=True)
            return Condition.CheckWhichCard(rule, message.killer, effect)
        def check_to_target(effect, message):
            return Condition.CheckWhichCard(to_target, message.target, effect)
        def check_by_effect(effect, message):
            if by_effect:
                return (by_effect == message.by_effect)
            return True
        return Ability(ability_type, Message.AfterUnitDefeatedUnit, [lambda effect, message: (message.excess_damage > 0), check_who, check_to_target, check_by_effect, *conditions], operation, is_local=((which_card == 'This') or (to_target == 'This')))
    @staticmethod
    def UnitCannotTakeMoreDamageEachPhase(ability_type, which_card, cannot_take_more_than_damage):
        from game.operate.effects import Effects
        from game.ability.factory import AbilityFactory
        def nimrod(effect: Effect, message: Message2):
            this = effect.this
            damage = 0
            temp_effects = []
            def reset_damage(effect: Effect, message: Message2):
                damage = 0
            temp_effects = (temp_effects + this.effect.RegisterTemp(AbilityFactory.WhenPhaseBegin(AbilityType.NonKeyword, None, reset_damage), unregister_after_exec=False))
            def add_damage(effect: Effect, message: Message.AfterUnitTookDamage):
                damage = (damage + message.took_damage)
            temp_effects = (temp_effects + this.effect.RegisterTemp(AbilityFactory.AfterUnitTookDamage(AbilityType.Temp0, 'This', add_damage), unregister_after_exec=False))
            temp_effects = (temp_effects + this.effect.RegisterTemp(AbilityFactory.UnitCannotTakeDamageWhile(AbilityType.NonKeyword, 'This', cannot_take_more_than_damage=lambda effect: (cannot_take_more_than_damage - damage)), unregister_after_exec=False))
            def clean(effect: Effect, message: Message2):
                Effects.UnRegister(temp_effects)
            this.effect.RegisterTemp(AbilityFactory.WhenCardLeavePlay(AbilityType.NonKeyword, 'This', clean), unregister_after_exec=True)
        return AbilityFactory.AfterCardEnterPlay(ability_type, which_card, nimrod)
    @staticmethod
    def UnitCannotTakeDamage(which_card):
        return AbilityFactory.GiveBuffToInPlayWhenApplyThis(which_card, buffs=[BuffCannotTakeDamage])
    @staticmethod
    def UnitCannotTakeDamageWhile(ability_type, which_card, *, conditions = [], is_damage_more_than = None, is_from_attack = None, cannot_take_more_than_damage = None, while_face_is_in_play = None, damage_from = None):
        from game.operate.worlds import Worlds
        if cannot_take_more_than_damage:
            if not ((is_damage_more_than == None)):
                raise AssertionError
            is_damage_more_than = cannot_take_more_than_damage
        def cannot_take_damage(effect: Effect, message: Message.WhenUnitWouldTakeDamage):
            if (cannot_take_more_than_damage != None):
                if isinstance(cannot_take_more_than_damage, int):
                    value = cannot_take_more_than_damage
                else:
                    value = cannot_take_more_than_damage(effect)
            message.PreventDamage('All', effect)
        def check_while_face_is_in_play(effect, message):
            if (while_face_is_in_play == None):
                return True
            for face in Worlds.GetOnFieldCards(effect):
                if while_face_is_in_play.Check(face):
                    return True
            return False
        def check_is_damage_more_than(effect, message):
            if (is_damage_more_than == None):
                return True
            if isinstance(is_damage_more_than, int):
                value = is_damage_more_than
            else:
                value = is_damage_more_than(effect)
            return (message.will_take_damage > value)
        def check_damage_from(effect, message):
            if (damage_from == None):
                return True
            return Condition.CheckWhichCard(damage_from, message.by_effect.this, effect)
        return AbilityFactoryDamage.WhenUnitWouldTakeDamage(ability_type, which_card, cannot_take_damage, is_from_attack=is_from_attack, conditions=[check_is_damage_more_than, check_damage_from, check_while_face_is_in_play, *conditions])
    @staticmethod
    def UnitCannotHaveMoreThanSustainedDamage(which_card, *, more_than_sustained_damage, conditions = []):
        from game.operate.worlds import Worlds
        def cannot_take_damage(effect: Effect, message: Message.WhenUnitWouldTakeDamage):
            if isinstance(more_than_sustained_damage, str):
                damage = Worlds.ConvertPerPlayerIconToInt(more_than_sustained_damage, effect)
            else:
                damage = more_than_sustained_damage(effect)
            message.SetCannotHaveMoreThanSustained(damage, effect)
        return AbilityFactoryDamage.WhenUnitWouldTakeDamage(AbilityType.NonKeyword, which_card, cannot_take_damage, conditions=conditions)
    @staticmethod
    def PreventAllDamageTo(which_card, *, conditions = []):
        def action(effect: Effect, message: Message.WhenUnitWouldTakeDamage):
            message.PreventDamage('All', effect)
        return AbilityFactoryDamage.WhenUnitWouldTakeDamage(AbilityType.NonKeyword, which_card, action, conditions=conditions)
    @staticmethod
    def ReduceCharacterTakeDamageBy(who_take_damage, num, *, this_attached_unit_only = None, from_each_attack = None, who_deal_damage = None, conditions = []):
        def check_attached_unit_only(effect, message):
            if (this_attached_unit_only == None):
                return True
            return Condition.ThisAttachedTo(effect, message.trigger)
        return AbilityFactoryDamage.WhenUnitWouldTakeDamage(AbilityType.NonKeyword, who_take_damage, lambda effect, message: message.ReduceDamage(num, effect), is_from_attack=from_each_attack, who_deal_damage=who_deal_damage, conditions=[check_attached_unit_only, *conditions])
    @staticmethod
    def UnitTakeAdditionalDamageFromCards(which_card, update_rule, by_face = None):
        from game.card.face.base import ClassCard
        def action(effect: Effect, message: Message.WhenUnitWouldTakeDamage):
            if isinstance(update_rule, int):
                if (update_rule > 0):
                    message.IncreaseDamage(update_rule, effect)
                    return
                raise AssertionError
            if (update_rule == 'Double'):
                message.IncreaseDamage(message.will_take_damage, effect)
                return
            if (update_rule == 'Prevent'):
                message.PreventDamage('All', effect)
                return
        def condition(effect, message):
            if ClassCard.IsType(message.by_effect.this):
                if (by_face == None):
                    return True
                return by_face.Check(message.by_effect.this)
            return False
        return AbilityFactoryDamage.WhenUnitWouldTakeDamage(AbilityType.NonKeyword, which_card, action, conditions=[condition])
    @staticmethod
    def UpdateAttacksDealDamage(*, deal_damage_from = None, with_piercing = None, deal_damage_to = None, update_damage_rule = 0):
        def check_with_piercing(effect, message):
            if (with_piercing != None):
                return (with_piercing == message.would_atk_message.property.piercing)
            return True
        def check_deal_damage_from(effect, message):
            return Condition.CheckWhichCard(deal_damage_from, message.attacker, effect)
        def check_deal_damage_to(effect, message):
            return Condition.CheckWhichCard(deal_damage_to, message.target, effect)
        def gain_attack_damage(effect: Effect, message: Message.WhenRecalculateAttackDamage):
            if (update_damage_rule == 'Double'):
                damage = message.will_take_damage
                return message.IncreaseDamage(damage, effect)
            if not ((update_damage_rule > 0)):
                raise AssertionError
            return message.IncreaseDamage(update_damage_rule, effect)
        return Ability(AbilityType.NonKeyword, Message.WhenRecalculateAttackDamage, [check_deal_damage_from, check_deal_damage_to, check_with_piercing], gain_attack_damage, is_local=((deal_damage_to == 'This') or (deal_damage_from == 'This')))
    @staticmethod
    def WhenDamageWouldBeDealtTo(ability_type, who_take_damage, operation, *, who_deal_damage = None, conditions = [], by_which_effect = None, by_play_card = None, allow_zero_damage = False, is_undefended_attack = None):
        return AbilityFactoryDamage.WhenFaceWouldDealDamage(ability_type, who_deal_damage, operation, who_take_damage=who_take_damage, from_attack=None, include_overkill=True, conditions=conditions, by_which_effect=by_which_effect, by_play_card=by_play_card, allow_zero_damage=allow_zero_damage, is_undefended_attack=is_undefended_attack)
    @staticmethod
    def WhenFaceWouldDealDamage(ability_type, who_deal_damage, operation, *, who_take_damage = None, from_attack = None, include_overkill = False, conditions = [], by_which_effect = None, by_play_card = None, allow_zero_damage = False, is_undefended_attack = None):
        def check_who_deal_damage(effect, message):
            rule = Condition.GetYouRule(who_deal_damage, identity=True)
            return Condition.CheckWhichCard(rule, message.attacker, effect)
        def check_who_take_damage(effect, message):
            rule = Condition.GetYouRule(who_take_damage, identity=True)
            return Condition.CheckWhichCard(rule, message.target, effect)
        def check_is_from_attack(effect, message):
            if (from_attack == None):
                return check_is_from_overkill(effect, message)
            return (from_attack == (message.would_atk_message != None))
        def check_by_which_effect(effect, message):
            if (by_which_effect == None):
                return True
            return (by_which_effect == message.by_effect)
        def check_is_from_overkill(effect, message):
            if (include_overkill == True):
                return True
            if not ((include_overkill == False)):
                raise AssertionError
            return (not message.IsOverkill())
        def check_by_play_card(effect, message):
            if (by_play_card == None):
                return True
            if message.by_effect.is_rule:
                return False
            if not (message.by_effect.ability.is_play):
                return False
            if message.IsBasicAttack():
                return False
            return Condition.CheckWhichCard(by_play_card, message.by_effect.this, effect)
        def check_allow_zero_damage(effect, message):
            if allow_zero_damage:
                return True
            return (message.damage > 0)
        def check_is_undefended_attack(effect, message):
            if (is_undefended_attack == None):
                return True
            if (message.would_atk_message == None):
                return False
            return (is_undefended_attack == (message.would_atk_message.defender == None))
        return Ability(ability_type, Message.WhenFaceWouldDealDamage, [check_allow_zero_damage, check_who_deal_damage, check_who_take_damage, check_is_from_attack, check_by_which_effect, check_by_play_card, check_is_undefended_attack, *conditions], operation, is_local=((who_deal_damage == 'This') or ((who_take_damage == 'This') or (by_play_card == 'This'))))
    @staticmethod
    def AfterFaceDealDamage(ability_type, which_face_dealt_damage, dealt_to_who, operation, *, dealt_more_than_damage = None, is_from_attack = None, conditions = []):
        def check_is_from_attack(effect, message):
            if (is_from_attack == None):
                return True
            return (is_from_attack == message.IsFromAttack())
        def check_who(effect, message):
            if (which_face_dealt_damage == None):
                return True
            return Condition.CheckWhichCard(which_face_dealt_damage, message.trigger, effect)
        def check_dealt_to_who(effect, message):
            if (dealt_to_who == None):
                return True
            return Condition.CheckWhichCard(dealt_to_who, message.who_took_damage, effect)
        def check_dealt_more_than_damage(effect, message):
            if (dealt_more_than_damage == None):
                return True
            return (message.dealt_damage >= dealt_more_than_damage)
        return Ability(ability_type, Message.AfterFaceDealDamage, [lambda effect, message: (message.dealt_damage > 0), check_who, check_dealt_to_who, check_is_from_attack, check_dealt_more_than_damage, *conditions], operation)
    @staticmethod
    def AfterFaceBeDealtDamage(ability_type, which_face, operation, *, conditions = []):
        return AbilityFactoryDamage.WhenUnitWouldTakeDamage(ability_type, which_face, operation, conditions=conditions, not_include_this_effect=True)
    @staticmethod
    def ThisCannotTakeDamageWhile(*, conditions):
        if (conditions == True):
            conditions = [lambda effect, message: True]
        return AbilityFactoryDamage.UnitCannotTakeDamageWhile(AbilityType.NonKeyword, 'This', conditions=conditions)
    @staticmethod
    def AfterDamageBePrevented(ability_type, operation, *, who_not_take_damage = None, prevent_by = None, is_from_attack = None, damage_more_than = None, conditions = []):
        def check_is_from_attack(effect, message):
            if (is_from_attack == None):
                return True
            return (is_from_attack == message.IsFromAttack())
        def check_who_not_take_damage(effect, message):
            return Condition.CheckWhichCard(who_not_take_damage, message.trigger, effect)
        def check_prevent_by(effect, message):
            return Condition.CheckWhichCard(prevent_by, message.prevent_by_effect.this, effect)
        def check_damage_more_than(effect, message):
            if (damage_more_than == None):
                return True
            return (message.prevent_damage >= damage_more_than)
        return Ability(ability_type, Message.AfterDamageBePrevented, [*conditions, check_who_not_take_damage, check_prevent_by, check_damage_more_than, check_is_from_attack], operation)
