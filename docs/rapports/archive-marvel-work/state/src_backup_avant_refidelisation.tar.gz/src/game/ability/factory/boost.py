# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryBoost:
    @staticmethod
    def WhenCardBecomeBoost(which_card, operation, *, during_scheme = False, during_attack = False, is_undefended_attack = None, attacker = None, activating_enemy = None, you_are_in_hero_from = None, conditions = []):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_undefended_attack(effect, message):
            if (is_undefended_attack != None):
                if not (isinstance(message.being_message, Message.WhenUnitBeingAttack)):
                    return False
                return (is_undefended_attack == (message.being_message.would_atk_message.GetDefender() == None))
            return True
        def check_attacker(effect, message):
            if attacker:
                if not (isinstance(message.being_message, Message.WhenUnitBeingAttack)):
                    return False
                if not (message.being_message.attacker):
                    return False
                return attacker.IsType(message.being_message.attacker)
            return True
        def check_activating_enemy(effect, message):
            return Condition.CheckWhichCard(activating_enemy, message.activating_enemy, effect)
        def check_you_are_in_hero_from(effect, message):
            if (you_are_in_hero_from != None):
                player = message.GetToPlayer()
                if you_are_in_hero_from:
                    return player.IsHero()
                return (not player.IsHero())
            return True
        return Ability(AbilityType.Boost, Message.WhenCardBecomeBoost, [lambda effect, message: (not message.is_cancel_boost_ability), check_which_card, check_undefended_attack, check_attacker, check_activating_enemy, lambda effect, message: ((not during_scheme) or message.being_message.IsScheme()), check_you_are_in_hero_from, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def AfterCardBecomeBoost(ability_type, which_card, operation, *, conditions = []):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        return Ability(ability_type, Message.AfterCardBecomeBoost, [check_which_card, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def AfterEnemyGivenBoostCard(ability_type, which_enemy, operation, *, conditions = []):
        def check_which_enemy(effect, message):
            return Condition.CheckWhichCard(which_enemy, message.trigger, effect)
        return Ability(ability_type, Message.AfterEnemyGivenBoostCard, [check_which_enemy, *conditions], operation, is_local=(which_enemy == 'This'))
    @staticmethod
    def BoostIfThisActivationDealsDamage(to_who, operation):
        from game.card.face.card_type import Identity
        def when_this_boost(effect: Effect, message: Message.WhenCardBecomeBoost):
            boost_for_message = message.being_message
            trigger = boost_for_message.trigger
            this = effect.this
            Unused(this)
            def check_who(damage_effect, damage_message):
                if (to_who == 'You'):
                    return ((damage_message.trigger.GetControlBy() == message.to_player) and Identity.IsType(damage_message.trigger))
                return Condition.CheckWhichCard(to_who, damage_message.trigger, damage_effect)
            trigger.effect.RegisterTemp(Ability(AbilityType.Temp0, Message.AfterUnitTookDamage, [lambda damage_effect, damage_message: ((damage_message.would_atk_message == boost_for_message.would_message) and (damage_message.deal_damage > 0)), check_who], lambda damage_effect, damage_message: operation(effect, damage_message)), unregister_after_exec=True, until_turn_end=True)
        return AbilityFactoryBoost.WhenCardBecomeBoost('This', when_this_boost)
    @staticmethod
    def WhenBoostShuffleThisIntoEncounterDeckAfterActivationEnd() -> Ability:
        from cards.pack import ShuffleThisCardIntoEncounter
        def action(effect: Effect, message: Message.WhenCardBecomeBoost):
            this = effect.this
            Unused(this)
            message.AfterThisActivation(effect, lambda : ShuffleThisCardIntoEncounter(effect, message))
        return AbilityFactoryBoost.WhenCardBecomeBoost('This', action)
    @staticmethod
    def WhenBoostIconsWouldBeCount(ability_type, operation, *, conditions = []):
        return Ability(ability_type, Message.WhenBoostIconsWouldBeCount, conditions, operation)
    @staticmethod
    def WhenBoostCardWouldTurnedFaceUp(ability_type, operation, *, while_attack = None, while_scheme = None, boost_for_card = None, activate_target = None, conditions = []):
        def check_while_attack(effect, message):
            if (while_attack == None):
                return True
            return (while_attack == message.being_message.IsAttack())
        def check_while_scheme(effect, message):
            if (while_scheme == None):
                return True
            return (while_scheme == message.being_message.IsScheme())
        def check_boost_for_card(effect, message):
            return Condition.CheckWhichCard(boost_for_card, message.would_message.trigger, effect)
        def check_activate_target(effect, message):
            if not (activate_target):
                return True
            rule = Condition.GetYouRule(activate_target, identity=True)
            if isinstance(message.would_message, AttackerMessageInternal):
                targets = message.would_message.attacked_targets
            else:
                raise AssertionError
            return Condition.CheckWhichCard(rule, targets, effect)
        return Ability(ability_type, Message.WhenBoostCardWouldTurnedFaceUp, [check_while_attack, check_while_scheme, check_boost_for_card, check_activate_target, *conditions], operation)
    @staticmethod
    def WhenBoostCardTurnedFaceUp(ability_type, canbe_cancel, operation, *, while_attack = None, while_scheme = None, boost_for_card = None, activate_target = None, activate_message = None, conditions = []):
        def check_while_attack(effect, message):
            if (while_attack == None):
                return True
            return (while_attack == message.being_message.IsAttack())
        def check_while_scheme(effect, message):
            if (while_scheme == None):
                return True
            return (while_scheme == message.being_message.IsScheme())
        def check_boost_for_card(effect, message):
            return Condition.CheckWhichCard(boost_for_card, message.would_message.trigger, effect)
        def check_activate_target(effect, message):
            if not (activate_target):
                return True
            if isinstance(message.would_message, AttackerMessageInternal):
                targets = message.would_message.attacked_targets
            else:
                raise AssertionError
            return Condition.CheckWhichCard(activate_target, targets, effect)
        def check_activate_message(effect, message):
            if (activate_message == None):
                return True
            return (activate_message == message.would_message)
        def check_canbe_cancel(effect, message):
            if (canbe_cancel == None):
                return True
            if (canbe_cancel == 'BoostIcons'):
                return ((not message.cancel_boost_icons) and (message.boost_icons > 0))
            if (canbe_cancel == 'Ability'):
                if not (message.trigger.effect.Find(type=AbilityType.Boost)):
                    return False
                return (not message.cancel_boost_ability)
        return Ability(ability_type, Message.WhenBoostCardTurnedFaceUp, [check_while_attack, check_while_scheme, check_boost_for_card, check_activate_target, check_canbe_cancel, check_activate_message, *conditions], operation)
    @staticmethod
    def IncreaseBoostIconsOnEncounterCard(*, conditions = []):
        def operation(effect: Effect, message: Message.WhenBoostIconsWouldBeCount):
            message.UpdateBoostIcon(1, effect)
        return Ability(AbilityType.NonKeyword, Message.WhenBoostIconsWouldBeCount, conditions, operation)
