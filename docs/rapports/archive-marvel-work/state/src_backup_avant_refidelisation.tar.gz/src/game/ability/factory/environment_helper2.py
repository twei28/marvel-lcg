# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
CardTypeMin = Condition.CARD_TYPE_MIN
class StoreValueDiff:
    def __init__(self, diff = 0, lst_add = [], lst_del = []):
        self.diff = diff
        self.lst_add = list(lst_add)
        self.lst_del = list(lst_del)
    def is_empty(self):
        return ((self.diff == 0) and ((not self.lst_add) and (not self.lst_del)))
    def is_lt_0(self):
        return ((self.diff < 0) or bool(self.lst_del))
    def __mul__(self, num):
        if (num == 1):
            return StoreValueDiff(self.diff, self.lst_add, self.lst_del)
        if (num == -1):
            return StoreValueDiff((-1 * self.diff), self.lst_del, self.lst_add)
        raise AssertionError
    def __repr__(self):
        return f'{self.diff}, {self.lst_add}, {self.lst_del}'
class StoreValue:
    def __init__(self, num = 0, lst = []):
        self.num = num
        self.lst = list(lst)
    def clear(self):
        self.num = 0
        self.lst.clear()
    def update(self, diff, lst_add, lst_del):
        def update_list(main_list, list_to_add, list_to_remove):
            remove_set = set(list_to_remove)
            main_list[:] = [item for item in main_list if (item not in remove_set)]
            main_list.extend(list_to_add)
        self.num = (self.num + diff)
        update_list(self.lst, lst_add, lst_del)
    def __eq__(self, other):
        if isinstance(other, StoreValue):
            return ((self.num == other.num) and (set(self.lst) == set(other.lst)))
        return False
    def __ne__(self, other):
        return (not self.__eq__(other))
    def add(self, other: StoreValueDiff):
        self.update(other.diff, other.lst_del, other.lst_add)
    def __sub__(self, other: 'StoreValue') -> StoreValueDiff:
        def list_diff(list1, list2):
            set1 = set(list1)
            set2 = set(list2)
            to_add = list((set1 - set2))
            to_remove = list((set2 - set1))
            return (to_add, to_remove)
        return StoreValueDiff(*tuple([(self.num - other.num), *list_diff(self.lst, other.lst)]))
    def __mul__(self, num):
        if (num == 1):
            return StoreValueDiff(self.num, self.lst, [])
        if (num == -1):
            return StoreValueDiff((-1 * self.num), [], self.lst)
        raise AssertionError
    def __repr__(self):
        return f'{self.num}, {self.lst}'
def WhenFaceApplyThisInternal(card_finder, condition, get_new_value, apply, ignore_flip, change_on_event, works_for_all_cards = False, works_in_the_victory_display = False, incite_only = None, abilities = None, buffs = None):
    from game.ability.factory import AbilityFactory
    from game.operate.worlds import Worlds
    from game.operate.effects import Effects
    from game.card.face.card_type import Treachery
    def when_this_in_play(effect, message):
        this = effect.this
        apply_faces = {}
        unapply_effects = {}
        def get_old_value(face: CardFace) -> 'StoreValue':
            if ignore_flip:
                for check_face in ([face] + face.card.back_faces):
                    if (check_face in apply_faces):
                        apply_faces[check_face]
                        return
                return StoreValue()
            if (face not in apply_faces):
                return StoreValue()
            return apply_faces[face]
        def unapply_environment(face, diff):
            unapply_environment_internal(face, diff)
            Message.AfterCardApply_Text([face], effect, -1)
        def unapply_environment_internal(face, diff):
            if diff.is_empty():
                return
            if not (diff.is_lt_0()):
                raise AssertionError
            Effects.UnRegister(unapply_effects[face])
            unapply_effects[face] = []
            apply_faces[face].update(diff.diff, [], diff.lst_del)
            if not (face.IsThisFaceUp()):
                if ignore_flip:
                    apply(effect, face, diff, False)
                    return
            apply(effect, face, diff, False)
        def apply_environment_internal(face, diff):
            if diff.is_empty():
                return
            if (face not in apply_faces):
                apply_faces[face] = StoreValue()
            apply_faces[face].update(diff.diff, diff.lst_add, [])
            apply(effect, face, (diff * 1), True)
            if (face in unapply_effects):
                Effects.UnRegister(unapply_effects[face])
            unapply_effects[face] = []
            if ignore_flip:
                unapply_effect = face.effect.Registers(AbilityFactory.WhenCardLeavePlay(AbilityType.Temp0, 'This', lambda check_effect, check_message: unapply_environment(check_message.trigger, (diff * -1))))
            else:
                unapply_effect = face.effect.Registers(AbilityFactory.WhileThisStateUpdate(AbilityType.Temp0, lambda check_effect, check_message: unapply_environment(check_message.trigger, (diff * -1))))
            unapply_effects[face] = (unapply_effects[face] + unapply_effect)
        def try_apply_environment(face: CardFace|Literal["All"], message: Message2):
            apply_face = []
            unapply_face = []
            def process(face: CardFace):
                if face.card.state.is_leaving_play:
                    return
                if face.card.state.is_flipping:
                    return
                if face.card.state.is_setting_as:
                    return
                new_val = get_new_value(effect, face)
                old_val = get_old_value(face)
                if (new_val != old_val):
                    diff = (new_val - old_val)
                    if not ((diff.diff < 0)):
                        if diff.lst_del:
                            unapply_environment_internal(face, diff)
                            unapply_face.append(face)
                    unapply_environment_internal(face, diff)
                    unapply_face.append(face)
                    if not ((diff.diff > 0)):
                        if diff.lst_add:
                            apply_environment_internal(face, diff)
                            apply_face.append(face)
                    apply_environment_internal(face, diff)
                    apply_face.append(face)
            if (abilities != None):
                if (OnEvent.Faceup in message.on_events):
                    if not (isinstance(message, TriggerMessage)):
                        raise AssertionError
                    process(message.trigger)
            else:
                if incite_only:
                    if (OnEvent.Reveal in message.on_events):
                        if not (isinstance(message, TriggerMessage)):
                            raise AssertionError
                        if Treachery.IsType(message.trigger):
                            if message.trigger.card.area.flags.is_revealing:
                                diff = (get_new_value(effect, message.trigger) - StoreValue())
                                apply(effect, message.trigger, diff, True)
                                message.trigger.effect.RegisterTemp(AbilityFactory.AfterCardsMoved(AbilityType.Temp0, message.trigger, lambda moved_effect, moved_message: apply(effect, message.trigger, (diff * -1), False)), unregister_after_exec=True)
                else:
                    if (face == 'All'):
                        if works_for_all_cards:
                            faces = [x.face for x in this.card.world.object_manager.card_dict.values()]
                        else:
                            faces = ([x for x in unapply_effects if (len(unapply_effects[x]) > 0)] + [x for x in Worlds.GetOnFieldCards(effect) if Condition.CheckWhichCard(card_finder, x, effect)])
                            faces = [x for x in faces if x.IsThisFaceUp() if x.IsInPlay()]
                        for face in Types.RemoveDuplicates(faces):
                            process(face)
                    else:
                        process(face)
            if apply_face:
                Message.AfterCardApply_Text(apply_face, effect, 1)
            if unapply_face:
                Message.AfterCardApply_Text(unapply_face, effect, -1)
                return
        if condition(effect):
            if not (this.is_treat_as_if_blank):
                try_apply_environment('All', message)
        def check_this_is_in_play():
            if works_in_the_victory_display:
                return this.card.area.flags.is_victory_display
            return this.IsInPlay()
        def new_condition(check_effect: Effect, message: Message2):
            return ((not this.is_treat_as_if_blank) and (check_this_is_in_play() and condition(check_effect)))
        try_apply_all_effects = this.effect.Registers(*Condition.GetEventAbilities(change_on_event, AbilityType.Temp0, new_condition, lambda check_effect, message: try_apply_environment('All', message)))
        def unapply_all_environment():
            update_faces = []
            for face in list(apply_faces.keys()):
                diff = apply_faces[face]
                if (diff != 0):
                    unapply_environment_internal(face, (diff * -1))
                    update_faces.append(face)
            if update_faces:
                Message.AfterCardApply_Text(update_faces, effect, -1)
                return
        undo_apply_effects = this.effect.Registers(*Condition.GetEventAbilities(change_on_event, AbilityType.Temp0, lambda check_effect, message: (not condition(check_effect)), lambda check_effect, message: unapply_all_environment()))
        def process_when_treat_as_blank(effect: Effect, message: Message.WhenCardTreatAsIfBlank):
            if not (effect.this.is_treat_as_if_blank):
                if not (effect.this.IsFaceUp()):
                    unapply_all_environment()
                    return
            unapply_all_environment()
            return
            if condition(effect):
                try_apply_environment('All', message)
                return
        check_blank_effects = this.effect.Registers(AbilityFactory.WhenCardTreatAsIfBlank('This', process_when_treat_as_blank))
        def when_this_leave_play():
            Effects.UnRegister(undo_apply_effects, try_apply_all_effects, check_blank_effects)
            unapply_all_environment()
        if works_in_the_victory_display:
            this.effect.RegisterTemp(AbilityFactory.WhileThisStateUpdate(AbilityType.Temp0, lambda effect, message: when_this_leave_play(), conditions=[lambda effect, message: (not this.card.area.flags.is_victory_display)], include_enter_play=True), unregister_after_exec=True)
            return
        this.effect.RegisterTemp(AbilityFactory.WhileThisStateUpdate(AbilityType.Temp0, lambda effect, message: when_this_leave_play()), unregister_after_exec=True)
    return AbilityFactory.WhenCardEnterPlay(AbilityType.NonKeyword, 'This', when_this_in_play)
