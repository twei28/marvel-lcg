# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryDefeated:
    @staticmethod
    def WhenUnitWouldBeDefeated(ability_type, which_unit, operation, *, by_consequential_damage = None, conditions = []):
        def check_which_unit(effect, message):
            check_unit = Condition.GetYouRule(which_unit, identity=True)
            return Condition.CheckWhichCard(check_unit, message.trigger, effect)
        def check_by_consequential_damage(effect, message):
            if (by_consequential_damage == None):
                return True
            return (by_consequential_damage == message.IsByConsequentialDamage())
        return Ability(ability_type, Message.WhenUnitWouldBeDefeated, [check_which_unit, check_by_consequential_damage, *conditions], operation, is_local=(which_unit == 'This'))
    @staticmethod
    def WhenUnitBeDefeatedInternal(ability_type, which_unit, operation, *, has_defeating_player = None, by_attack = None, by_source = None, by_consequential = None, took_excess_damage = None, conditions = []):
        def check_no_ignore_when_defeated(effect, message):
            if not (effect.ability.type.flags.is_when_defeated):
                return True
            return (not message.ignore_when_defeated)
        def check_which_unit(effect, message):
            return Condition.CheckWhichCard(which_unit, message.trigger, effect)
        def check_has_defeated_player(effect, message):
            if (has_defeating_player == None):
                return True
            return (has_defeating_player == (message.defeating_player != None))
        def check_by_attack(effect, message):
            if (by_attack == None):
                return True
            if isinstance(by_attack, Message.WhenUnitWouldAttack):
                return (message.would_atk_message == by_attack)
            if isinstance(by_attack, Message.WhenUnitBeingAttack):
                return (message.being_atk_message == by_attack)
            if by_attack:
                return (message.being_atk_message != None)
            return (message.being_atk_message == None)
        def check_by_source(effect, message):
            return Condition.CheckWhichCard(by_source, message.killer, effect)
        def check_by_onsequential(effect, message):
            if (by_consequential == None):
                return True
            return (message.IsByConsequential() == by_consequential)
        def check_excess_damage_more_than_zero(effect, message):
            if (took_excess_damage == None):
                return True
            return (took_excess_damage == bool((message.excess_damage > 0)))
        return Ability(ability_type, Message.WhenUnitBeDefeated, [check_no_ignore_when_defeated, check_which_unit, check_has_defeated_player, check_by_attack, check_by_source, check_by_onsequential, check_excess_damage_more_than_zero, *conditions], operation, is_local=((which_unit == 'This') or (by_source == 'This')))
    @staticmethod
    def WhenUnitBeDefeated(ability_type, which_unit, operation, *, has_defeating_player = None, by_attack = None, attacker = None, by_consequential = None, took_excess_damage = None, without_excess_damage = None, conditions = []):
        if (took_excess_damage == None):
            if (without_excess_damage != None):
                if not (without_excess_damage):
                    took_excess_damage = True
                else:
                    took_excess_damage = False
        if not ((ability_type in (AbilityType.Rule, AbilityType.Temp0, AbilityType.Scenario, AbilityType.Campaign, AbilityType.Challenge, AbilityType.NonKeyword))):
            if (which_unit == 'This'):
                return AbilityFactoryDefeated.WhenUnitBeDefeatedInternal(ability_type, which_unit, operation, has_defeating_player=has_defeating_player, by_attack=by_attack, by_source=attacker, by_consequential=by_consequential, took_excess_damage=took_excess_damage, conditions=conditions)
        return AbilityFactoryDefeated.WhenUnitBeDefeatedInternal(ability_type, which_unit, operation, has_defeating_player=has_defeating_player, by_attack=by_attack, by_source=attacker, by_consequential=by_consequential, took_excess_damage=took_excess_damage, conditions=conditions)
        def action(effect: Effect, message: Message.WhenUnitWouldBeDefeated):
            this = effect.this
            if Condition.CheckWhichCard(which_unit, message.trigger, effect):
                ability = AbilityFactoryDefeated.WhenUnitBeDefeatedInternal(ability_type, message.trigger, operation, by_attack=by_attack, by_source=attacker, by_consequential=by_consequential, took_excess_damage=took_excess_damage, conditions=conditions)
                ability.CopyFromDelayEffect(effect)
                this.effect.RegisterTemp(ability, unregister_after_exec=True, until_event_end=message)
                return
        return AbilityFactoryDefeated.WhenUnitWouldBeDefeated(AbilityType.DelayAbility, which_unit, action, by_consequential_damage=by_consequential).SetSecondType(ability_type)
    @staticmethod
    def WhenUnitAttackAndDefeatUnit(ability_type, attacker, who_be_defeated, operation, *, conditions = []):
        def check_attacker(effect, message):
            rule = Condition.GetYouRule(attacker, identity=True)
            return Condition.CheckWhichCard(rule, message.attacker, effect)
        def check_who_be_defeated(effect, message):
            return Condition.CheckWhichCard(who_be_defeated, message.trigger, effect)
        def check_is_from_attack(effect, message):
            return message.IsFromAttack()
        return Ability(ability_type, Message.WhenUnitBeDefeated, [check_attacker, check_who_be_defeated, check_is_from_attack, *conditions], operation, is_local=((attacker == 'This') or (who_be_defeated == 'This')))
    @staticmethod
    def AfterUnitAttackAndDefeatUnit(ability_type, attacker, who_be_defeated, operation, *, has_excess_damage = None, conditions = []):
        return AbilityFactoryDefeated.AfterUnitDefeatedUnit(ability_type, attacker, who_be_defeated, operation, is_from_attack=True, has_excess_damage=has_excess_damage, conditions=conditions)
    @staticmethod
    def AfterUnitDefeatedUnitInternal(ability_type, who_killer, who_be_defeated, operation, *, would_message = None, is_from_attack = None, has_excess_damage = None, conditions = []):
        def check_who_killer(effect, message):
            return Condition.CheckWhichCard(who_killer, message.killer, effect)
        def check_who_be_defeated(effect, message):
            return Condition.CheckWhichCard(who_be_defeated, message.target, effect)
        def check_would_message(effect, message):
            if (would_message == None):
                return True
            return (would_message.would_atk_message == message.would_atk_message)
        def check_is_from_attack(effect, message):
            if (is_from_attack == None):
                return True
            return (is_from_attack == message.IsFromAttack())
        def check_has_excess_damage(effect, message):
            if (has_excess_damage == None):
                return True
            return (has_excess_damage == bool((message.excess_damage > 0)))
        return Ability(ability_type, Message.AfterUnitDefeatedUnit, [check_who_killer, check_would_message, check_who_be_defeated, check_is_from_attack, check_has_excess_damage, *conditions], operation, is_local=((who_killer == 'This') or (who_be_defeated == 'This')))
    @staticmethod
    def AfterUnitDefeatedUnit(ability_type, who_killer, who_be_defeated, operation, *, is_from_attack = None, is_basic_attack = None, has_excess_damage = None, conditions = []):
        from game.ability.factory import AbilityFactory
        def action(effect: Effect, message: Message.WhenUnitWouldAttackUnit|Message.WhenFaceWouldDealDamage):
            this = effect.this
            target = message.target
            if Condition.CheckWhichCard(who_be_defeated, target, effect):
                ability = AbilityFactoryDefeated.AfterUnitDefeatedUnitInternal(ability_type, message.attacker, target, operation, would_message=message, has_excess_damage=has_excess_damage, conditions=conditions)
                if (effect.this in target.GetInventoryDeck().Get()):
                    ability.NoOutOfPlayLimit()
                ability.CopyFromDelayEffect(effect)
                this.effect.RegisterTemp(ability, unregister_after_exec=True, until_event_end=message)
                return
        if not ((is_from_attack == True)):
            if (is_basic_attack == True):
                return AbilityFactory.WhenUnitWouldAttackUnit(AbilityType.DelayAbility, who_killer, None, action, is_basic_attack=is_basic_attack)
        return AbilityFactory.WhenUnitWouldAttackUnit(AbilityType.DelayAbility, who_killer, None, action, is_basic_attack=is_basic_attack)
        return AbilityFactory.WhenFaceWouldDealDamage(AbilityType.DelayAbility, who_killer, action, include_overkill=True)
    @staticmethod
    def AfterUnitBeDefeatedInternal(ability_type, who_be_defeated, operation, *, attacker = None, by_attack = None, by_consequential = None, conditions = []):
        from game.card.face.card_face import CardFace
        def check_who_be_defeated(effect, message):
            if isinstance(who_be_defeated, CardFace):
                return (who_be_defeated == message.trigger)
            return Condition.CheckWhichCard(who_be_defeated, message.trigger, effect)
        def check_by_consequential(effect, message):
            if (by_consequential == None):
                return True
            return (message.IsByConsequential() == by_consequential)
        def check_attacker(effect, message):
            if (attacker == None):
                return True
            return Condition.CheckWhichCard(attacker, message.attacker, effect)
        def check_by_attack(effect, message):
            if (by_attack == None):
                return True
            return (by_attack == (message.would_atk_message != None))
        return Ability(ability_type, Message.AfterUnitBeDefeated, [check_who_be_defeated, check_by_consequential, check_attacker, check_by_attack, *conditions], operation, is_local=((who_be_defeated == 'This') or (attacker == 'This')))
    @staticmethod
    def AfterUnitBeDefeated(ability_type, who_be_defeated, operation, *, attacker = None, by_attack = None, by_consequential = None, conditions = []):
        if isinstance(who_be_defeated, tuple):
            if not ((who_be_defeated[0] == 'YouControl')):
                if (who_be_defeated != 'YouControlAlly'):
                    return AbilityFactoryDefeated.AfterUnitBeDefeatedInternal(ability_type, who_be_defeated, operation, attacker=attacker, by_attack=by_attack, by_consequential=by_consequential, conditions=conditions)
        if (who_be_defeated != 'YouControlAlly'):
            return AbilityFactoryDefeated.AfterUnitBeDefeatedInternal(ability_type, who_be_defeated, operation, attacker=attacker, by_attack=by_attack, by_consequential=by_consequential, conditions=conditions)
        def action(effect: Effect, message: Message.WhenUnitWouldBeDefeated):
            this = effect.this
            if Condition.CheckWhichCard(who_be_defeated, message.trigger, effect):
                ability = AbilityFactoryDefeated.AfterUnitBeDefeatedInternal(ability_type, message.trigger, operation, attacker=attacker, by_attack=by_attack, by_consequential=by_consequential, conditions=conditions)
                ability.CopyFromDelayEffect(effect)
                this.effect.RegisterTemp(ability, unregister_after_exec=True, until_event_end=message)
                return
        return AbilityFactoryDefeated.WhenUnitWouldBeDefeated(AbilityType.DelayAbility, who_be_defeated, action, by_consequential_damage=by_consequential).SetSecondType(ability_type)
    @staticmethod
    def WhenSchemeBeDefeated(ability_type, which_scheme, operation, *, has_defeating_player = None, conditions = []):
        def check_no_ignore_when_defeated(effect, message):
            if not (effect.ability.type.flags.is_when_defeated):
                return True
            return (not message.ignore_when_defeated)
        def check_which_scheme(effect, message):
            return Condition.CheckWhichCard(which_scheme, message.trigger, effect)
        def check_has_defeated_player(effect, message):
            if (has_defeating_player == None):
                return True
            return (has_defeating_player == (message.defeating_player != None))
        return Ability(ability_type, Message.WhenSchemeBeDefeated, [check_no_ignore_when_defeated, check_which_scheme, check_has_defeated_player, *conditions], operation, is_local=(which_scheme == 'This'))
    @staticmethod
    def CardCannotLeavePlayWhile(ability_type, which_card, *, while_card_is_in_play = None, unless_card_in_victory_display = None, conditions = []):
        from game.operate.worlds import Worlds
        def cannot_leave_play(effect: Effect, message: Message.WhenSchemeWouldBeDefeated|Message.WhenUnitWouldBeDefeated):
            this = effect.this
            Unused(this)
            message.SetBeInstead(effect)
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_while_card_is_in_play(effect, message):
            return Condition.CheckWhichCard(while_card_is_in_play, Worlds.GetOnFieldCards(effect), effect)
        def check_unless_card_in_victory_display(effect, message):
            if not (unless_card_in_victory_display):
                return True
            size = unless_card_in_victory_display[0]
            rule = unless_card_in_victory_display[1]
            return (not Condition.CheckWhichCard(rule, Worlds.VictoryDisplay(effect).GetAll(), effect, size=size))
        def check_condition(effect, message):
            for condition in conditions:
                if not (condition(effect, Cast(Any, message))):
                    return False
            return True
        return Ability(ability_type, (Message.WhenSchemeWouldBeDefeated | Message.WhenUnitWouldBeDefeated), [check_which_card, check_while_card_is_in_play, check_unless_card_in_victory_display, check_condition], cannot_leave_play, is_local=(which_card == 'This'))
    @staticmethod
    def UnitCannotBeDefeatedWhile(ability_type, which_card, *, unless_card_in_victory_display = None, while_card_is_in_play = None, condition = None, change_on_event = OnEvent.NONE):
        from game.ability.factory import AbilityFactory
        from game.card.face.base import Unit2
        from game.operate.worlds import Worlds
        if (condition == None):
            def condition(effect):
                return True
        def while_this_be_defeated(effect: Effect, message: Message2):
            this = effect.this
            Unused(this)
            if (which_card == 'This'):
                target = effect.this.CastTo(Unit2)
            else:
                target = Worlds.FindCardOnField(effect, which_card, card_type=Unit2)
            if target:
                if (target.health <= 0):
                    target.Defeated(None, effect)
                    return
                    return
        abilities = [AbilityFactoryDefeated.CardCannotLeavePlayWhile(ability_type, which_card, while_card_is_in_play=while_card_is_in_play, unless_card_in_victory_display=unless_card_in_victory_display, conditions=[lambda effect, message: condition(effect)])]
        if unless_card_in_victory_display:
            if (change_on_event == OnEvent.NONE):
                _ = unless_card_in_victory_display[0]
                rule = unless_card_in_victory_display[1]
                change_on_event = OnEvent.Victory(rule)
        if (change_on_event != OnEvent.NONE):
            def new_condition(effect, message):
                if not (condition(effect)):
                    return False
                if (while_card_is_in_play == None):
                    return True
                return (not Condition.CheckWhichCard(while_card_is_in_play, Worlds.GetOnFieldCards(effect), effect))
            abilities = (abilities + Condition.GetEventAbilities(change_on_event, AbilityType.NonKeyword, new_condition, while_this_be_defeated))
        if (which_card != 'This'):
            abilities.append(AbilityFactory.AfterCardLeavePlay(AbilityType.Temp0, 'This', while_this_be_defeated))
        return abilities
    @staticmethod
    def SchemeCannotLeavlPlayWhile(which_card, *, while_card_is_in_play = None, conditions = []):
        return AbilityFactoryDefeated.CardCannotLeavePlayWhile(AbilityType.NonKeyword, which_card, while_card_is_in_play=while_card_is_in_play, conditions=conditions)
