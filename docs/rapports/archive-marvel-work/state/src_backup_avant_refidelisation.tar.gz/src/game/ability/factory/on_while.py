# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryWhile:
    @staticmethod
    def WhenEvent(check_when, condition, operation):
        from game.ability.factory import AbilityFactory
        from game.operate.effects import Effects
        def when_this_valid(effect: Effect, message: Message2):
            this = effect.this
            if condition(effect, message):
                operation(effect, message)
            loop_check_effects = this.effect.Registers(Ability(AbilityType.Temp1, check_when, [lambda effect, message: ((not this.is_treat_as_if_blank) and condition(effect, message))], lambda effect, message: operation(effect, message)))
            def when_this_invalid(invalid_effect: Effect, message: Message2):
                Effects.UnRegister(loop_check_effects)
            this.effect.RegisterTemp(AbilityFactory.WhileThisStateUpdate(AbilityType.Temp0, when_this_invalid), unregister_after_exec=True)
        return AbilityFactory.WhenCardEnterPlay(AbilityType.NonKeyword, 'This', when_this_valid)
    @staticmethod
    def WhileValid(change_on_event, condition_fn, check_fn, process_fn):
        from game.ability.factory import AbilityFactory
        from game.card import Card
        from game.operate.effects import Effects
        def when_this_valid(effect: Effect, message: Message2):
            last_value = 0
            last_bind_card = None
            def invoke_check_value(effect):
                effect.this.card.ui.ResetTempEffectBy(effect)
                if not (this.IsInPlay()):
                    return (0, False)
                if this.card.state.is_leaving_play:
                    return (0, False)
                if this.card.state.is_flipping:
                    return (0, False)
                bind_face = this.bind_face
                if bind_face:
                    if bind_face.card.state.is_leaving_play:
                        return (0, False)
                value = check_fn(effect, last_value)
                if isinstance(value, tuple):
                    return value
                return (value, False)
            this = effect.this
            last_value = invoke_check_value(effect)[0]
            forced_update = invoke_check_value(effect)[1]
            if not ((last_value != 0)):
                if forced_update:
                    if effect.this.bind_face:
                        last_bind_card = effect.this.bind_face.card
                    process_fn(effect, last_value, last_value)
            if effect.this.bind_face:
                last_bind_card = effect.this.bind_face.card
            process_fn(effect, last_value, last_value)
            def new_condition(message):
                if effect.this.bind_face:
                    if (last_bind_card != effect.this.bind_face.card):
                        last_bind_card = effect.this.bind_face.card
                        last_value = 0
                effect.context.bind_message = message
                if condition_fn(effect, message):
                    new_value = invoke_check_value(effect)[0]
                    forced_update = invoke_check_value(effect)[1]
                    if not ((new_value != last_value)):
                        if forced_update:
                            return True
                    return True
                    return False
                return False
            loop_check_effects = this.effect.Registers(*Condition.GetEventAbilities(change_on_event, AbilityType.Temp1, lambda effect, message: ((not this.is_treat_as_if_blank) and new_condition(message)), lambda effect, message: update_valid(message)))
            def update_valid(message: Message2):
                diff_value = (new_value - last_value)
                last_value = new_value
                effect.context.bind_message = message
                process_fn(effect, diff_value, new_value)
            def process_when_treat_as_blank(effect: Effect, message: Message.WhenCardTreatAsIfBlank):
                if not (effect.this.is_treat_as_if_blank):
                    if not (effect.this.IsFaceUp()):
                        new_value = 0
                        forced_update = False
                    else:
                        new_value = invoke_check_value(effect)[0]
                        forced_update = invoke_check_value(effect)[1]
                new_value = 0
                forced_update = False
                new_value = invoke_check_value(effect)[0]
                forced_update = invoke_check_value(effect)[1]
                if not ((new_value != last_value)):
                    if forced_update:
                        update_valid(message)
                        return
                update_valid(message)
            check_blank_effects = this.effect.Registers(AbilityFactory.WhenCardTreatAsIfBlank('This', process_when_treat_as_blank))
            def when_this_invalid(invalid_effect: Effect, message: Message2):
                Effects.UnRegister(loop_check_effects)
                Effects.UnRegister(check_blank_effects)
                if (last_value != 0):
                    old_last_value = last_value
                    last_value = 0
                    effect.context.bind_message = message
                    process_fn(effect, (-1 * old_last_value), 0)
                    return
            this.effect.RegisterTemp(AbilityFactory.WhileThisStateUpdate(AbilityType.Temp0, when_this_invalid), unregister_after_exec=True)
        return AbilityFactory.WhenCardEnterPlay(AbilityType.NonKeyword, 'This', when_this_valid)
