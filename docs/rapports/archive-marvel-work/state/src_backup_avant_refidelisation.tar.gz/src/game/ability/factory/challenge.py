# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryChallenge:
    @staticmethod
    def UsingOnlyHeroes(names = [], has_traits = None, title_has = '', has_or_can_gain_the_trait = None, alter_ego_has_traits = None, solo = False):
        from game.ability.factory import AbilityFactory
        def check_heros(effect: Effect, message: Message.WhenGameBeginSetup):
            pass
        return AbilityFactory.WhenGameBeginSetup(check_heros)
    @staticmethod
    def WhenScenarioEnd(condition):
        def set_lost(effect: Effect, message: Message.WhenGameOver):
            message.SetPlayerLost(effect)
        def check_condition(effect: Effect, message: Message.WhenGameOver):
            if (condition == False):
                return False
            res = condition(effect, message)
            if (res == False):
                return True
            return False
        return Ability(AbilityType.Challenge, Message.WhenGameOver, [lambda effect, message: (message.players_won == True), check_condition], set_lost)
    @staticmethod
    def TheFinalBlowCanOnlyBeDealtBy(which_card):
        from game.ability.factory import AbilityFactory
        from game.card.face.base import Villain
        from game.card.face.card_type import Hero
        def is_final_blow(effect, message):
            if message.trigger.CastTo(Villain).IsFinalStage(effect):
                def is_1_health_hero():
                    if not (message.attacker):
                        return False
                    if (message.attacker.health != 1):
                        return False
                    if not (Hero.IsType(message.attacker)):
                        return False
                    return True
                return (not is_1_health_hero())
            return False
        def health(effect: Effect, message: Message.WhenUnitWouldBeDefeated):
            message.trigger.SetHealth(1, effect)
            message.SetBeInstead(effect)
        return AbilityFactory.WhenUnitWouldBeDefeated(AbilityType.Challenge, Villain, health, conditions=[is_final_blow])
