# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from game.card.face import *
from game.ability import *
from game.message import *
from game.player import *
def GetForDelayAbility(effect: 'Effect') -> 'Ability|None':
    return effect.ability
class ConditionOncePer:
    @staticmethod
    def LimitOncePerRound(effect, message):
        world = effect.world
        ability = GetForDelayAbility(effect)
        return world.stat.IsOncePerRound(ability)
    @staticmethod
    def LimitOncePerRoundPerPlayer(effect, message):
        from game.message.sender.sender import TriggerNonePlayerMessage
        if not (isinstance(message, TriggerNonePlayerMessage)):
            raise AssertionError
        world = effect.world
        player = message.GetToPlayer()
        ability = GetForDelayAbility(effect)
        return world.stat.IsOncePerRoundPerPlayer(ability, player)
    @staticmethod
    def LimitOncePerPhasePerPlayer(effect, message):
        from game.message.sender.sender import TriggerNonePlayerMessage
        if not (isinstance(message, TriggerNonePlayerMessage)):
            raise AssertionError
        world = effect.world
        player = message.GetToPlayer()
        ability = GetForDelayAbility(effect)
        return world.stat.IsOncePerPhasePerPlayer(ability, player)
    @staticmethod
    def LimitOncePerPhase(effect, message):
        world = effect.world
        ability = GetForDelayAbility(effect)
        return world.stat.IsOncePerPhase(ability)
    @staticmethod
    def LimitOncePerEvent(effect, message):
        ability = GetForDelayAbility(effect)
        return (ability not in [x.ability for x in message.once_per_event_effects])
    @staticmethod
    def LimitOnceCardNamePerEvent(effect, message):
        ability = GetForDelayAbility(effect)
        if (ability == None):
            return True
        return (ability.paper not in [x.ability.paper for x in message.once_per_event_effects])
