# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.ability.condition.condition import Condition
from game.ability.condition.condition2 import Condition2
Unused(Condition)
Unused(Condition2)
