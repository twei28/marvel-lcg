# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryPlay:
    @staticmethod
    def CanPlayThisSupportCard(*, under_any_players_control = False, conditions = []):
        if under_any_players_control:
            selector = Select.From('Players')
        else:
            selector = Select.From('YourIdentity')
        return AbilityFactoryPlay.CanPlayThisSupportCardSelect(selector, conditions=conditions)
    @staticmethod
    def CanPlayThisSupportCardSelect(selector = None, *, conditions = []):
        from game.selector import Select
        from game.card.face.card_type import Support
        from game.ability.factory import AbilityFactory
        from game.player import Player
        if (selector == None):
            selector = Select.From('YourIdentity')
        def max_per_unit(effect, target):
            this = effect.this.CastTo(Support)
            if not (Player.IsType(target.GetControlBy())):
                return False
            return (this.max_per_unit > target.GetControlByPlayer().supports.HasThisType(this))
        selector.selector_filter.AddParameter(check_effect_fn=max_per_unit)
        def move_this_card(effect: Effect, message: Message.WhenPlayerInTurn):
            this = effect.this.CastTo(Support)
            target = effect.targets[0]
            this.PutIntoPlay(target.GetControlByPlayer(), effect)
        return AbilityFactory.WhenInYourPlayTurn(AbilityType.PlayTurnOption, move_this_card, conditions=[lambda effect, message: Condition.FieldHasNotThisUniqueType(effect.this, effect), *conditions]).SetPlay().SetTargetInternal(selector)
    @staticmethod
    def CanPlayThisUpgradeCard(target = None, conditions = [], replaced_operation = None):
        from game.selector import Select
        from game.card.card_finder import CardFinder
        from game.ability.factory import AbilityFactory
        from game.card.face.card_type import Upgrade
        if (target == None):
            selector = None
        else:
            if isinstance(target, type):
                selector = Select.From(CardFinder(card_type=target))
            else:
                if isinstance(target, CardFinder):
                    selector = Select.From(target)
                else:
                    if isinstance(target, Selector):
                        selector = target
                    else:
                        selector = Select.From(target)
        def attach_to_target(effect: Effect, message: Message.WhenPlayerInTurn):
            from game.card.face.base import Asset2
            from game.operate.faces import Faces
            from game.operate.worlds import Worlds
            this = effect.this.CastTo(Asset2)
            if not (replaced_operation):
                do_attached = False
                if effect.targets:
                    player = Worlds.GetFirstPlayer(effect)
                    target = player.AskChooseFace(effect.targets, effect)
                    if target:
                        this.AttachTo2(target, effect)
                        do_attached = True
                if not (do_attached):
                    Faces.DiscardAll([this], effect)
                    return
                return
            replaced_operation(effect, message)
        if (selector == None):
            selector = Select.From('YourIdentity')
        def max_per_unit(effect, target):
            this = effect.this.CastTo(Upgrade)
            return (this.max_per_unit > target.GetInventoryDeck().HasThisType(this))
        selector.selector_filter.AddParameter(check_effect_fn=max_per_unit)
        return AbilityFactory.WhenInYourPlayTurn(AbilityType.PlayTurnOption, attach_to_target, conditions=[lambda effect, message: Condition.FieldHasNotThisUniqueType(effect.this, effect), *conditions]).SetPlay().SetTargetInternal(selector)
    @staticmethod
    def CanPlayThisAllyCard() -> Ability:
        from game.card.face.card_type import Ally
        from game.ability.factory import AbilityFactory
        def put_into_play(effect: Effect, message: Message.WhenPlayerInTurn):
            this = effect.this.CastTo(Ally)
            target = effect.targets[0]
            this.PutIntoPlay(target.GetControlByPlayer(), effect)
        return AbilityFactory.WhenInYourPlayTurn(AbilityType.PlayTurnOption, put_into_play, conditions=[lambda effect, message: Condition.FieldHasNotThisUniqueType(effect.this, effect)]).SetPlay().SetTarget('YourIdentity')
    @staticmethod
    def CanPlayThisSchemeCard(*, conditions = []):
        from game.card.face.card_type import PlayerSideScheme
        from game.ability.factory import AbilityFactory
        def put_into_play(effect: Effect, message: Message.WhenPlayerInTurn):
            this = effect.this.CastTo(PlayerSideScheme)
            initiator = effect.GetInitiator()
            game_area = initiator.GetGameArea()
            this.PutIntoPlay(initiator, effect, target_game_area=game_area)
        return AbilityFactory.WhenInYourPlayTurn(AbilityType.PlayTurnOption, put_into_play, conditions=[lambda effect, message: Condition.FieldHasNotThisUniqueType(effect.this, effect), *conditions]).SetPlay()
    @staticmethod
    def WhenPlayerWouldPlayCard(ability_type, which_player, which_card, operation, *, label = None, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.play_face, effect)
        def check_label(effect, message):
            if not (label):
                return True
            return message.play_effect.ability.IsLabel(label)
        return Ability(ability_type, Message.WhenPlayerWouldPlayCard, [check_which_player, check_which_card, check_label, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhenPlayerPlayCard(ability_type, which_player, played_card, operation, *, label = None, targets = None, using_res = None, conditions = []):
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        def check_played_card(effect, message):
            if (played_card == None):
                return True
            return played_card.Check(message.played_face)
        def check_label(effect, message):
            if not (label):
                return True
            return message.played_effect.ability.IsLabel(label)
        def check_targets(effect, message):
            if (targets == None):
                return True
            return Condition.CheckWhichCard(targets, message.played_effect.targets, effect)
        def check_using_res(effect, message):
            if (using_res == None):
                return True
            return message.paid_resources.HasColor(using_res)
        return Ability(ability_type, Message.WhenPlayerPlayCard, [check_which_player, check_played_card, check_label, check_targets, check_using_res, *conditions], operation)
    @staticmethod
    def AfterPlayerPlayedCard(ability_type, which_player, which_card, operation, *, from_hand = False, conditions = []):
        def invoke_operation(effect: Effect, message: Message.AfterPlayerPlayedCard):
            if not (message.play_effect.ability.is_play):
                raise AssertionError
            operation(effect, message)
        def check_which_player(effect, message):
            return Condition.CheckWhichPlayer(which_player, message.to_player, effect)
        def check_which_card(effect, message):
            if isinstance(which_card, Message.WhenPlayerPlayCard):
                return (message.play_message == which_card)
            return Condition.CheckWhichCard(which_card, message.played_face, effect)
        def check_from_hand(effect, message):
            if from_hand:
                return message.is_like_from_hand
            return True
        return Ability(ability_type, Message.AfterPlayerPlayedCard, [check_which_card, check_which_player, check_from_hand, *conditions], invoke_operation, is_local=(which_card == 'This'))
    @staticmethod
    def AfterYouPlayThisFromHand(ability_type, operation, *, conditions = []):
        return AbilityFactoryPlay.AfterPlayerPlayedCard(ability_type, 'You', 'This', operation, from_hand=True, conditions=conditions)
    @staticmethod
    def AttachedCardCanPlayLikeInHand(card_finder = None):
        return AbilityFactoryPlay.YouMayPlayCardLikeInHand(AbilityType.NonKeyword, card_finder, from_where='ThisPlacedCard', during=None)
    @staticmethod
    def YouMayPlayCardLikeInHand(ability_type, which_card = None, *, from_where = None, during = None, conditions = []):
        from game.ability.factory import AbilityFactory
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.which_face, effect)
        def check_from_where(effect, message):
            if (from_where == None):
                return True
            face = message.which_face
            if (from_where == 'ThisPlacedCard'):
                return (effect.this.GetPlacedCardArea() == face.card.area)
            if (from_where == 'YourDiscardPile'):
                return face.card.area.flags.is_discards
            if (from_where == 'YourDeckTop'):
                return (face.card.area.flags.is_player_deck and (face.card.area.GetTop() == face))
            return False
        def check_during(effect, message):
            if (during == None):
                return True
            if (during == 'YourTurn'):
                return (effect.GetInitiator() == effect.world.GetTurnPlayer())
            return False
        def set_like_in_hand(effect: Effect, message: Message.CheckIfFaceIsLikeInHand):
            message.SetIsLikeInHand(effect)
        abilty = Ability(ability_type, Message.CheckIfFaceIsLikeInHand, [check_which_card, check_from_where, check_during, *conditions], set_like_in_hand, is_local=(which_card == 'This'))
        if (which_card == 'This'):
            abilty.NoOutOfPlayLimit()
        abilties = [abilty]
        if (during == 'YourTurn'):
            if not ((which_card == 'This')):
                raise AssertionError
            def reset_is_like_in_hand_state(effect: Effect, message: Message.WhenPlayerTurnBegin):
                effect.this.card.can_state.is_like_in_hand = None
            reset_ability = AbilityFactory.WhenPlayerTurnBegin(AbilityType.Rule, 'AnyPlayer', reset_is_like_in_hand_state)
            abilties.append(reset_ability)
        return abilties
    @staticmethod
    def UnitIgnoreKeywordIcons(which_unit, guard = False, patrol = False, crisis = False, while_use_basic_thw = None, conditions = []):
        from game.card.face.card_type import Event
        from game.card.face import Upgrade
        keywords = []
        if guard:
            keywords.append('Guard')
        if patrol:
            keywords.append('Patrol')
        if crisis:
            keywords.append('Crisis')
        def check_which_unit(effect, message):
            by_effect = message.effect
            if Event.IsType(by_effect.this):
                by_face = message.effect.this.GetControlByOrOwner().GetRoleCharacter()
            else:
                if Upgrade.IsType(by_effect.this):
                    by_face = by_effect.this.GetBindFace()
                else:
                    by_face = by_effect.this
            if (which_unit == 'You'):
                check_unit = 'This'
            else:
                check_unit = which_unit
            return Condition.CheckWhichCard(check_unit, by_face, effect)
        return Ability(AbilityType.NonKeyword, Message.CheckIfEffectIsIgnoreKeyWord, [lambda effect, message: (message.keyword in keywords), check_which_unit, *conditions], lambda effect, message: message.SetIgnore(), is_local=(which_unit == 'This'))
