# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryResolve:
    @staticmethod
    def WhenResolveSpecialAbility(which_card, operation, *, conditions = []):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.face, effect)
        def check_ability_name(effect, message):
            if (message.ability_name == ''):
                return True
            return (effect.ability.name == message.ability_name)
        return Ability(AbilityType.Special, Message.WhenResolveSpecialAbility, [check_which_card, check_ability_name, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def WhenCardWouldResolveAbility(ability_type, which_abilities, which_card, operation, *, label = None, ability_name = None, card_control_by = 'AnyPlayer', trigger_player = 'AnyPlayer', conditions = []):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_trigger_player(effect, message):
            return Condition.CheckWhichPlayer(trigger_player, message.effect.initiator, effect)
        def check_card_control_by(effect, message):
            return Condition.CheckWhichPlayer(card_control_by, message.control_by, effect)
        def check_ability_name(effect, message):
            if (ability_name == None):
                return True
            return (ability_name == message.effect.ability.name)
        def check_which_ability(effect, message):
            ability = message.effect.ability
            if ability.flags.is_nonkeyword:
                return False
            if (which_abilities == None):
                return True
            return Condition.CheckWhichAbility(which_abilities, ability)
        def check_label(effect, message):
            if (label == None):
                return True
            return message.effect.ability.IsOneOfLabel(label)
        return Ability(ability_type, Message.WhenEffectWouldResolve, [check_which_card, check_which_ability, check_ability_name, check_trigger_player, check_card_control_by, check_label, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def AfterCardResolveAbility(ability_type, which_abilities, which_card, operation, *, conditions = [], card_control_by = 'AnyPlayer', trigger_player = 'AnyPlayer', which_effect = None, ability_name = None):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_card_control_by(effect, message):
            return Condition.CheckWhichPlayer(card_control_by, message.control_by, effect)
        def check_trigger_player(effect, message):
            return Condition.CheckWhichPlayer(trigger_player, message.to_player, effect)
        def check_which_ability(effect, message):
            ability = message.effect.ability
            if ability.flags.is_nonkeyword:
                return False
            if (which_abilities == None):
                return True
            return Condition.CheckWhichAbility(which_abilities, ability)
        def check_ability_name(effect, message):
            if (ability_name == None):
                return True
            ability = message.effect.ability
            return (ability.name == ability_name)
        def check_which_effect(effect, message):
            if (which_effect == None):
                return True
            return (message.effect == which_effect)
        return Ability(ability_type, Message.AfterEffectResolved, [check_which_card, check_card_control_by, check_trigger_player, check_which_ability, check_ability_name, check_which_effect, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def AfterPlayerTriggerAbility(ability_type, trigger_player, which_card, operation, *, label = None, card_control_by = 'AnyPlayer', conditions = []):
        def check_is_not_temp(effect, message):
            return (not message.effect.ability.flags.is_temp)
        return AbilityFactoryResolve.WhenCardWouldResolveAbility(ability_type, None, which_card, operation, label=label, card_control_by=card_control_by, trigger_player=trigger_player, conditions=[check_is_not_temp, *conditions])
    @staticmethod
    def AfterPlayerResolveAbility(ability_type, trigger_player, which_card, operation, *, conditions = [], which_abilities = None, ability_name = None, control_by_you = None):
        return AbilityFactoryResolve.AfterCardResolveAbility(ability_type, which_abilities, which_card, operation, trigger_player=trigger_player, ability_name=ability_name, conditions=conditions, card_control_by=('You' if control_by_you else 'AnyPlayer'))
    @staticmethod
    def WhenSurgeWouldBeResolved(ability_type, which_card, operation, *, conditions = []):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        return Ability(ability_type, Message.WhenSurgeWouldBeResolved, [check_which_card, *conditions], operation, is_local=(which_card == 'This'))
