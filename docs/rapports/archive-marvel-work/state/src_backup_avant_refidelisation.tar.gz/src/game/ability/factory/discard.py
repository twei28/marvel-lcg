# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
class AbilityFactoryDiscard:
    @staticmethod
    def WhenCardWouldDiscard(ability_type, which_card, operation, *, from_player_deck = None, conditions = []):
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_from_player_deck(effect, message):
            if (from_player_deck == None):
                return True
            controller = message.trigger.card.GetController()
            return ((message.trigger.card.area.flags.is_player_deck == from_player_deck) and ((controller == None) or (not controller.is_eliminated)))
        return Ability(ability_type, Message.WhenCardWouldDiscard, [check_which_card, check_from_player_deck, *conditions], operation, is_local=(which_card == 'This'))
    @staticmethod
    def AfterCardDiscardInternal(ability_type, which_card, operation, *, from_where = None, by_effect_face = None, conditions = []):
        from game.card.face.card_type import Identity
        def check_which_card(effect, message):
            return Condition.CheckWhichCard(which_card, message.trigger, effect)
        def check_from_where(effect, message):
            if (from_where == None):
                return True
            from_area = message.from_area
            if (from_where == 'PlayerDeckTop'):
                return from_area.flags.is_player_deck
            if (from_where == 'PlayerArea'):
                return (from_area.play_area != None)
            if (from_where == 'UnderIdentity'):
                return (from_area.flags.is_place_card_area and ((from_area.bind_card != None) and Identity.IsType(from_area.bind_card.face)))
            if (from_where == 'EncounterDeckTop'):
                return (from_area.flags.is_encounter_deck and message.discard_message.is_top)
            raise AssertionError
        def check_by_effect_face(effect, message):
            if not (by_effect_face):
                return True
            return Condition.CheckWhichCard(by_effect_face, message.by_effect.this, effect)
        ability = Ability(ability_type, Message.AfterCardDiscard, [check_which_card, check_from_where, check_by_effect_face, *conditions], operation, is_local=(which_card == 'This'))
        if (from_where in ('PlayerDeckTop', 'UnderIdentity')):
            return ability.NoOutOfPlayLimit()
        return ability
    @staticmethod
    def AfterCardDiscard(ability_type, which_card, operation, *, from_where = None, control_by_player = 'AnyPlayer', conditions = []):
        def check_control_by_player(effect, message):
            if (control_by_player == 'AnyPlayer'):
                return True
            if not (message.trigger.card.area.flags.is_in_play):
                return False
            return Condition.CheckWhichPlayer(control_by_player, message.trigger.GetControlBy(), effect)
        def action(effect: Effect, message: Message.WhenCardWouldDiscard):
            this = effect.this
            if Condition.CheckWhichCard(which_card, message.trigger, effect):
                if check_control_by_player(effect, message):
                    ability = AbilityFactoryDiscard.AfterCardDiscardInternal(ability_type, message.trigger, operation, from_where=from_where, conditions=conditions)
                    ability.CopyFromDelayEffect(effect)
                    this.effect.RegisterTemp(ability, unregister_after_exec=True, until_event_end=message)
                    return
                    return
        ability = AbilityFactoryDiscard.WhenCardWouldDiscard(AbilityType.DelayAbility, which_card, action).SetSecondType(ability_type)
        if (from_where == 'PlayerDeckTop'):
            return ability.NoOutOfPlayLimit()
        return ability
