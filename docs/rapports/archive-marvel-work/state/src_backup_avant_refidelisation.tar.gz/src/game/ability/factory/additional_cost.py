# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
from game.message.sender.sender import CanBeInstead
def CostFunction(effect: Effect, trigger: 'CardFace', message: CanBeInstead, cost_func: CostFunc.Base):
    from game.player import Player
    if not (Player.IsType(trigger.GetControlBy())):
        return
    player = trigger.GetControlByPlayer()
    if not (cost_func.PayCost(effect, player)):
        message.SetBeInstead(effect)
        return
class AbilityFactoryAdditionalCost:
    @staticmethod
    def AdditionalCostToThwartThisScheme(who_thwart, cost_func):
        from game.ability.factory import AbilityFactory
        def cost(effect: Effect, message: Message.WhenUnitWouldThwart):
            CostFunction(effect, message.trigger, message, cost_func)
        return AbilityFactory.WhenUnitWouldThwart(AbilityType.NonKeyword, who_thwart, cost, thwarted_scheme='This')
    @staticmethod
    def AdditionalCostToChangeForm(which_unit, cost_func, to_form = None, during_your_turn = None):
        from game.ability.factory import AbilityFactory
        def cost(effect: Effect, message: Message.WhenUnitWouldChangeForm):
            CostFunction(effect, message.trigger, message, cost_func)
        return AbilityFactory.WhenUnitWouldChangeForm(AbilityType.NonKeyword, which_unit, cost, to_form=to_form, during_your_turn=during_your_turn)
    @staticmethod
    def AdditionalCostToAttack(which_unit, cost_func, is_basic_attack = True):
        from game.ability.factory import AbilityFactory
        abilities = AbilityFactory.GiveKeywordToInPlayWhenApplyThis(which_unit, additional_cost_for_basic_attack=cost_func)
        if not ((len(abilities) == 1)):
            raise AssertionError
        return abilities[0]
    @staticmethod
    def AdditionalCostToThwart(which_unit, cost_func):
        from game.ability.factory import AbilityFactory
        abilities = AbilityFactory.GiveKeywordToInPlayWhenApplyThis(which_unit, additional_cost_for_basic_thwart=cost_func)
        if not ((len(abilities) == 1)):
            raise AssertionError
        return abilities[0]
    @staticmethod
    def AdditionalCostToDefense(which_unit, cost_func):
        from game.ability.factory import AbilityFactory
        abilities = AbilityFactory.GiveKeywordToInPlayWhenApplyThis(which_unit, additional_cost_for_basic_defend=cost_func)
        if not ((len(abilities) == 1)):
            raise AssertionError
        return abilities[0]
    @staticmethod
    def AdditionalCostToReady(which_card, cost_func, control_by = 'AnyPlayer'):
        from game.ability.factory import AbilityFactory
        def cost(effect: Effect, message: Message.WhenCardWouldReady):
            CostFunction(effect, message.trigger, message, cost_func)
        return AbilityFactory.WhenCardWouldReady(AbilityType.NonKeyword, which_card, cost, control_by=control_by)
