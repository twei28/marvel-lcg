# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from typing import TypeAlias
from core import *
from game.ability import *
from game.message import *
from game.player import *
from game.card.face import *
from engine.job import JobManager
from engine.log import DebugLog
from engine.log import Log
from game.world import *
from game.event.counter import EventCounter
from engine.config import ConfigVariables
from game.message.message_type import CardStateUpdatedMessage
from engine.controller.module.undo import UndoModule
FastUndoHandle = (UndoModule.UndoHandle | None)
FILE_BASED_FAST_UNDO = ConfigVariables.Bool('file_based_fast_undo', False)
CACHE_BASED_FAST_UNDO = ConfigVariables.Bool('cache_based_fast_undo', False)
class EventManager:
    __annotations__ = {}
    CATEGORY = Literal[('Statistics', 'Rule', 'Paying', 'Forced', 'Optional')]
    CATEGORY: TypeAlias
    CATEGORY_LIST = [*('Statistics', 'Rule', 'Paying', 'Forced', 'Optional')]
    CATEGORY_LIST: List['EventManager.CATEGORY']
    def __init__(self, world: World):
        self.effects = {'Statistics': {}, 'Rule': {}, 'Paying': {}, 'Forced': {}, 'Optional': {}}
        self.registered_message_type = {}
        self.event_size = EventCounter()
        self.world = world
        self.new_effect_created = False
        self.debug_log = DebugLog('NoSendResolve')
        self.debug_log_both = DebugLog('Both')
        self.debug_log_only_local = DebugLog('Only Local')
        self.debug_log_only_global = DebugLog('Only Global')
        self.stack_message = []
    def GetEffectCategory(self, effect, event):
        from game.message import Message
        if effect.ability.flags.is_statistics:
            return 'Statistics'
        if effect.is_nonkeyword:
            return 'Rule'
        if (event is Message.WhenPlayerPayingResources):
            return 'Paying'
        if effect.is_rule:
            return 'Rule'
        if effect.ability.flags.is_temp:
            return 'Rule'
        if effect.is_forced:
            return 'Forced'
        return 'Optional'
    def AddEffectsList(self, category, event, priority, add_effect):
        found_dict = self.effects[category]
        if (event not in found_dict):
            found_dict[event] = {}
        if (priority not in found_dict[event]):
            found_dict[event][priority] = []
        found_dict[event][priority].append(add_effect)
    def FindEffectsList(self, category, event, priority):
        found_dict = self.effects[category]
        if (event not in found_dict):
            return []
        if (priority not in found_dict[event]):
            return []
        return found_dict[event][priority]
    def HasRegisteredEvent(self, event):
        if (event in self.registered_message_type):
            return self.registered_message_type[event]
        return 0
    def RegisterEffect(self, effect: 'Effect'):
        effect.is_unregister = False
        self.new_effect_created = True
        if effect.is_local:
            events = Types.UnionTypeExtract(effect.ability.when)
            for event in events:
                category = self.GetEffectCategory(effect, event)
                if not ((category in ('Forced', 'Paying', 'Rule', 'Optional'))):
                    raise AssertionError
            return
        events = Types.UnionTypeExtract(effect.ability.when)
        for event in events:
            if (event in self.registered_message_type):
                self.registered_message_type[event] = (self.registered_message_type[event] + 1)
            else:
                self.registered_message_type[event] = 1
            self.event_size.Add(event)
            category = self.GetEffectCategory(effect, event)
            if not ((category != 'Paying')):
                raise AssertionError
            self.AddEffectsList(category, event, effect.ability.priority, effect)
    def UnRegisterEffect(self, effect: 'Effect'):
        effect.is_unregister = True
        events = Types.UnionTypeExtract(effect.ability.when)
        for event in events:
            self.registered_message_type[event] = (self.registered_message_type[event] - 1)
            category = self.GetEffectCategory(effect, event)
            effects_list = self.FindEffectsList(category, event, effect.ability.priority)
            if effect.is_local:
                if not ((effect not in effects_list)):
                    raise AssertionError
            effects_list.remove(effect)
    def RegisterPlayRule(self):
        from game.rule.gameplay import GetGamePlayRules
        from game.rule.statistics import GetStatisticsRule
        from game.rule.achievement import GetPlayAchievement
        from game.card.factory import CardFactory
        from game.effect.rule import GameRule
        world = self.world
        insert = CardFactory.GenerateCard('rule_a,rule_b', world.area_insert, world).face.CastTo(Insert)
        world.insert = insert
        for ability in GetGamePlayRules():
            insert.effect.Registers(ability)
        from engine import Engine
        if Engine.statistics.CanRegisterAbility():
            for ability in GetStatisticsRule():
                insert.effect.Registers(ability)
            for ability in GetPlayAchievement():
                insert.effect.Registers(ability)
        effect = GameRule(insert)
        for challenge in world.scene.campaign.challenges:
            challenge = CardFactory.GenerateCard(challenge, world.area_insert, world).face
            challenge.PutIntoPlay('FirstPlayer', effect)
    def ProcessEffect(self, effect: 'Effect', message: Message2, priority: TimingPriority):
        from game.player import Player
        from game.message.sender.sender import TriggerNonePlayerMessage
        processed = False
        if effect.ability.selectors:
            owner = effect.this.GetOwner()
            player = None
            if isinstance(owner, Player):
                player = owner
            else:
                if isinstance(message, TriggerNonePlayerMessage):
                    player = message.to_player
            if player:
                cheat = True
                if cheat:
                    _ = player.ChoiceAndSpellEffect([effect], message, priority, forced=True)[0]
                    cheat = player.ChoiceAndSpellEffect([effect], message, priority, forced=True)[1]
                    # backward conditional jump to 94: cheat
                processed = True
            else:
                if not (effect.is_forced):
                    raise AssertionError(f'effect={effect!r}')
                if not ((effect.context.target_range[0] == effect.context.target_range[1])):
                    raise AssertionError(f'effect.context.target_range={effect.context.target_range!r}')
                if not ((len(effect.context.all_legal_targets) == effect.context.target_range[1])):
                    raise AssertionError(f'effect.context.all_legal_targets={effect.context.all_legal_targets!r}')
                effect.context.targets_internal = effect.context.all_legal_targets[:]
        if not (processed):
            effect.ResolveSelf(message, effect)
            return
    def ProcessRuleEffect(self, message, rule_effects, priority, undo_handle):
        for effect in rule_effects:
            if EventManager.FilterAvailableEffects(message, [effect], None, self.world, undo_handle):
                self.ProcessEffect(effect, message, priority)
            if self.world.is_game_over:
                return self.world.is_game_over
        return self.world.is_game_over
    def ProcessPayingEffect(self, message: Message.WhenPlayerPayingResources, resources_effect: 'Effect', priority: TimingPriority) -> GAME_OVER:
        resources_effects = EventManager.FilterAvailableEffects(message, [resources_effect], message.to_player, self.world, None)
        if not ((len(resources_effects) == 1)):
            raise AssertionError
        self.ProcessEffect(resources_effects[0], message, priority)
        return self.world.is_game_over
    def ProcessOptionalEffect(self, message, optional_effects, local_optional_effects, priority):
        from game.message import Message
        from game.effect.effect_failure import EffectFailure
        is_play_turn = (type(message) == Message.WhenPlayerInTurn)
        players = self.world.const_players[:]
        def process_player(player: Player):
            processed_effects = []
            if is_play_turn:
                self.new_effect_created = False
            if self.world.is_game_over:
                return
            def fast_undo():
                controller_manager = self.world.controller_manager
                if controller_manager.undo.DoNotCheckFastUndo():
                    Log.DebugSilent('MESSAGE', {'------------------------------'})
                    Log.DebugSilent('MESSAGE', f'len(self.world.object_manager.message_dict)={len(self.world.object_manager.message_dict)!r}')
                    Log.DebugSilent('MESSAGE', {'------------------------------'})
                    return optional_effects
                step_id = controller_manager.replay.current_step_id
                from game.scene.replay import CommandDescriptor
                is_puzzle = message.world.scene.is_puzzle
                found_effects = optional_effects[:]
                operation = controller_manager.replay.GetReplayOperation(is_puzzle, check_crc=False)[0]
                read_ok = controller_manager.replay.GetReplayOperation(is_puzzle, check_crc=False)[1]
                replay_id = None
                fast_undo_result = ''
                if read_ok:
                    if operation:
                        from colorama import Fore
                        replay_id = f'{Fore.BLUE}{operation.effect.id}{Fore.RESET}'
                        if operation.effect.id.startswith(':'):
                            fast_undo_result = f'Skip debug command {replay_id}'
                        else:
                            if (operation.effect.id != ''):
                                effect_ids = CommandDescriptor.FindNewEffectIdInternal(operation.effect.id, optional_effects)
                                if effect_ids:
                                    found_effects.clear()
                                    for effect_id in effect_ids:
                                        for effect in optional_effects:
                                            if (effect.object_id == effect_id):
                                                found_effects.append(effect)
                                            else:
                                                pass
                                    if not (found_effects):
                                        raise AssertionError
                                    fast_undo_result = f'{replay_id}, {len(optional_effects)} -> {len(found_effects)}'
                                else:
                                    fast_undo_result = f'{replay_id}, {len(optional_effects)} ->'
                                    fast_undo_result = f'{replay_id}, {len(optional_effects)} -> Input Cancel'
                            else:
                                fast_undo_result = f'{replay_id}, {len(optional_effects)} -> Input Cancel'
                Log.DebugSilent('FAST_UNDO', f'{step_id}, {fast_undo_result}')
                return found_effects
            if not (FILE_BASED_FAST_UNDO.value):
                filtered_effects = EventManager.FilterAvailableEffects(message, optional_effects, player, self.world, None)
            else:
                fast_undo_effects = fast_undo()
                if not (fast_undo_effects):
                    return
                filtered_effects = EventManager.FilterAvailableEffects(message, fast_undo_effects, player, self.world, None)
            for effect in filtered_effects[:]:
                if (effect in processed_effects):
                    filtered_effects.remove(effect)
                    effect.failures.Set(player, EffectFailure.AlreadyProcessed)
            if (filtered_effects == []):
                return
            from game.message import Message
            Message.PlayerOnEvent_Text(player, message)
            filtered_effects = sorted(filtered_effects, key=lambda e: e.object_id)
            forced = ('Forced_Action' if any((effect.ability.flags.is_forced_action for effect in filtered_effects)) else False)
            effect = player.ChoiceAndSpellEffect(filtered_effects, message, priority, forced)[0]
            is_cheating = player.ChoiceAndSpellEffect(filtered_effects, message, priority, forced)[1]
            if not (is_cheating):
                if not (effect):
                    return
            if not (is_cheating):
                if self.new_effect_created:
                    if is_play_turn:
                        self.new_effect_created = False
                    if (type(message) in self.effects['Optional']):
                        if (priority in self.effects['Optional'][type(message)]):
                            optional_effects = ([x for x in self.effects['Optional'][type(message)][priority] if (x.ability.priority == priority)] + local_optional_effects)
                            optional_effects = Types.RemoveDuplicates(optional_effects)
                    if is_cheating:
                        if not ((effect == None)):
                            raise AssertionError(f'effect={effect!r}')
            if is_play_turn:
                self.new_effect_created = False
            if (type(message) in self.effects['Optional']):
                if (priority in self.effects['Optional'][type(message)]):
                    optional_effects = ([x for x in self.effects['Optional'][type(message)][priority] if (x.ability.priority == priority)] + local_optional_effects)
                    optional_effects = Types.RemoveDuplicates(optional_effects)
            if is_cheating:
                if not ((effect == None)):
                    raise AssertionError(f'effect={effect!r}')
            if not (is_play_turn):
                if effect:
                    if not (Event.IsType(effect.this)):
                        processed_effects.append(effect)
        JobManager.Simultaneous(process_player, players)
        return self.world.is_game_over
    def ProcessForcedEffect(self, message, forced_effects, priority, undo_handle):
        from game.message.sender.sender import CanBeInstead
        from game.effect.rule import Ties
        from game.ability.ability import TimingPriority
        from game.message import Message
        forced_effects = EventManager.FilterAvailableEffects(message, forced_effects, None, self.world, undo_handle)
        if (forced_effects == []):
            pass
        else:
            if self.world.is_game_over:
                pass
            else:
                if isinstance(message, CanBeInstead):
                    if message.is_be_instead:
                        pass
                    else:
                        def check_is_resources(forced_effect: 'Effect'):
                            if forced_effect.ability.flags.is_resource:
                                raise AssertionError
                            if forced_effect.ability.flags.is_discard_pay:
                                raise AssertionError
                            return forced_effect.ability.flags.is_check_pay
                        first_effect = forced_effects[0]
                        if (first_effect.ability.priority != TimingPriority.Status):
                            if not (isinstance(message, Message.WhenGameBeginSetup)):
                                if not (check_is_resources(first_effect)):
                                    if not (first_effect.ability.flags.is_delay_ability):
                                        first_player = self.world.GetFirstPlayer()
                                        faces = [x.this for x in forced_effects if not (x.ability.flags.is_delay_ability)]
                                        is_on_the_same_card = all(((x.card == faces[0].card) for x in faces))
                                        if is_on_the_same_card:
                                            face = faces[0]
                                        else:
                                            face = first_player.AskChooseFace(faces, Ties('Forced abilities would initiate at the same moment', world=self.world), forced=True)
                                            if (face == None):
                                                face = faces[0]
                                        if not (face):
                                            raise AssertionError
                                        effect = forced_effects[faces.index(face)]
                                    else:
                                        effect = first_effect
                                else:
                                    effect = first_effect
                            else:
                                effect = first_effect
                        else:
                            effect = first_effect
                        forced_effects.remove(effect)
                        effect.context.targets_internal = []
                        if effect.IsPlayerInitiator():
                            if (len(effect.context.all_legal_targets) > 0):
                                initiator = effect.GetInitiator()
                                _ = initiator.ChoiceAndSpellEffect([effect], message, priority, True)[0]
                                is_cheating = initiator.ChoiceAndSpellEffect([effect], message, priority, True)[1]
                                if is_cheating:
                                    forced_effects.append(effect)
                            else:
                                self.ProcessEffect(effect, message, priority)
                        else:
                            self.ProcessEffect(effect, message, priority)
                else:
                    def check_is_resources(forced_effect: 'Effect'):
                        if forced_effect.ability.flags.is_resource:
                            raise AssertionError
                        if forced_effect.ability.flags.is_discard_pay:
                            raise AssertionError
                        return forced_effect.ability.flags.is_check_pay
                    first_effect = forced_effects[0]
                    if (first_effect.ability.priority != TimingPriority.Status):
                        if not (isinstance(message, Message.WhenGameBeginSetup)):
                            if not (check_is_resources(first_effect)):
                                if not (first_effect.ability.flags.is_delay_ability):
                                    first_player = self.world.GetFirstPlayer()
                                    faces = [x.this for x in forced_effects if not (x.ability.flags.is_delay_ability)]
                                    is_on_the_same_card = all(((x.card == faces[0].card) for x in faces))
                                    if is_on_the_same_card:
                                        face = faces[0]
                                    else:
                                        face = first_player.AskChooseFace(faces, Ties('Forced abilities would initiate at the same moment', world=self.world), forced=True)
                                        if (face == None):
                                            face = faces[0]
                                    if not (face):
                                        raise AssertionError
                                    effect = forced_effects[faces.index(face)]
                                else:
                                    effect = first_effect
                            else:
                                effect = first_effect
                        else:
                            effect = first_effect
                    else:
                        effect = first_effect
                    forced_effects.remove(effect)
                    effect.context.targets_internal = []
                    if effect.IsPlayerInitiator():
                        if (len(effect.context.all_legal_targets) > 0):
                            initiator = effect.GetInitiator()
                            _ = initiator.ChoiceAndSpellEffect([effect], message, priority, True)[0]
                            is_cheating = initiator.ChoiceAndSpellEffect([effect], message, priority, True)[1]
                            if is_cheating:
                                forced_effects.append(effect)
                        else:
                            self.ProcessEffect(effect, message, priority)
                    else:
                        self.ProcessEffect(effect, message, priority)
        if self.world.is_game_over:
            return True
        if isinstance(message, CanBeInstead):
            if message.is_be_instead:
                return True
        return False
    @staticmethod
    def SimpleCheckEffects(message, effects, asked_player, world, undo_handle):
        from game.card.face.base import Unit2
        from game.card.face.base import Scheme2
        from game.card.face.card_type import Upgrade
        from game.card.face.card_type import Minion
        from game.card.face.card_type import Support
        from game.card.face.card_type import Attachment
        from game.card.face.card_type import Environment
        from game.card.face.card_type import Resource
        from game.card.face.card_type import Event
        from game.card.face.card_type import Obligation
        from game.effect.effect import EffectFailure
        from game.message import Message
        from game.message import TriggerPlayerMessage
        if CACHE_BASED_FAST_UNDO.value:
            if undo_handle:
                check_effects_list = undo_handle.GetAvailableEffects(effects)
                step_id = undo_handle.step_id
                if (check_effects_list != None):
                    if check_effects_list:
                        if (len(effects) != len(check_effects_list)):
                            Log.DebugSilent('UNDO_HANDLE', f'{step_id} {message}: {len(effects)} -> {len(check_effects_list)}')
                    effects = check_effects_list
        effects_list = []
        for effect in effects:
            if effect.is_unregister:
                pass
            if not (isinstance(message, effect.ability.when)):
                raise AssertionError(f'message={message!r} effect.ability.when={effect.ability.when!r}')
            if effect.this.is_treat_as_if_blank:
                if not (effect.ability.ignore.treat_as_if_blank):
                    if not (isinstance(message, Message.WhenCardTreatAsIfBlank)):
                        effect.failures.Set(asked_player, EffectFailure.TreatAsBlank)
            if effect.this.card.area.flags.is_removed:
                if not (effect.ability.ignore.be_removed):
                    if (type(message) is not Message.WhenPlayerLikeInTurn):
                        effect.failures.Set(asked_player, EffectFailure.IsRemoved)
            def check_initiator():
                this = effect.this
                current_player = world.GetCurrentPlayer()
                check_player = None
                if not (effect.ability.flags.is_resource):
                    if effect.ability.flags.is_discard_pay:
                        check_player = message.CastTo(Message.WhenPlayerPayingResources).GetToPlayer()
                    else:
                        if effect.ability.any_player_can_trigger_this_when:
                            if isinstance(message, TriggerPlayerMessage):
                                check_player = message.to_player
                            else:
                                check_player = current_player
                                if isinstance(message, Message.WhenPlayerPayingResources):
                                    if Event.IsType(message.for_effect.this):
                                        if message.for_effect.this.alliance:
                                            check_player = message.to_player
                                        else:
                                            check_player = message.to_player
                                            if isinstance(message, Message.WhenCardBeSpendAsResource):
                                                check_player = message.to_player
                                            else:
                                                if effect.ability.is_choose:
                                                    return (True, '')
                                                if Obligation.IsType(this):
                                                    if this.card.area.flags.is_obligations_area:
                                                        check_player = this.GetGaveToPlayer()
                                                    else:
                                                        check_player = current_player
                                                        if Attachment.IsType(this):
                                                            if not (Identity.IsType(this.bind_face)):
                                                                check_player = current_player
                                                            else:
                                                                if Minion.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if Scheme2.IsType(this):
                                                                        check_player = current_player
                                                                    else:
                                                                        if Environment.IsType(this):
                                                                            check_player = current_player
                                                                        else:
                                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                                if not (effect.ability.flags.is_basic_power):
                                                                                    if not (effect.ability.flags.is_interrupt):
                                                                                        if not (effect.ability.flags.is_response):
                                                                                            if not (effect.ability.flags.is_resource):
                                                                                                if not (effect.ability.flags.is_action):
                                                                                                    if not (effect.ability.flags.is_ask):
                                                                                                        if not (effect.ability.is_play):
                                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                                if this.IsInPlay():
                                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                                else:
                                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                                    if Event.IsType(this):
                                                                                                                        raise AssertionError({effect})
                                                                                                                    if Resource.IsType(this):
                                                                                                                        raise AssertionError({effect})
                                                                                                                    if Support.IsType(this):
                                                                                                                        raise AssertionError({effect})
                                                                                                                    if Upgrade.IsType(this):
                                                                                                                        raise AssertionError({effect})
                                                                                                                    if Unit2.IsType(this):
                                                                                                                        raise AssertionError({effect})
                                                                                                                    if this.card.area.flags.is_processing:
                                                                                                                        raise AssertionError({effect})
                                                                                                                    if (asked_player == None):
                                                                                                                        return (True, '')
                                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                                            else:
                                                                                                                if Event.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Resource.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Support.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Upgrade.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Unit2.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if this.card.area.flags.is_processing:
                                                                                                                    raise AssertionError({effect})
                                                                                                                if (asked_player == None):
                                                                                                                    return (True, '')
                                                                                                                raise AssertionError(f'this={this!r}')
                                                                            if this.IsInPlay():
                                                                                check_player = this.GetControlByOrOwner()
                                                                            else:
                                                                                check_player = this.card.area.GetOwner()
                                                                                if Event.IsType(this):
                                                                                    raise AssertionError({effect})
                                                                                if Resource.IsType(this):
                                                                                    raise AssertionError({effect})
                                                                                if Support.IsType(this):
                                                                                    raise AssertionError({effect})
                                                                                if Upgrade.IsType(this):
                                                                                    raise AssertionError({effect})
                                                                                if Unit2.IsType(this):
                                                                                    raise AssertionError({effect})
                                                                                if this.card.area.flags.is_processing:
                                                                                    raise AssertionError({effect})
                                                                                if (asked_player == None):
                                                                                    return (True, '')
                                                                                raise AssertionError(f'this={this!r}')
                                                        else:
                                                            if Minion.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Scheme2.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if Environment.IsType(this):
                                                                        check_player = current_player
                                                                    else:
                                                                        if not (effect.ability.flags.is_play_turn_option):
                                                                            if not (effect.ability.flags.is_basic_power):
                                                                                if not (effect.ability.flags.is_interrupt):
                                                                                    if not (effect.ability.flags.is_response):
                                                                                        if not (effect.ability.flags.is_resource):
                                                                                            if not (effect.ability.flags.is_action):
                                                                                                if not (effect.ability.flags.is_ask):
                                                                                                    if not (effect.ability.is_play):
                                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                                            if this.IsInPlay():
                                                                                                                check_player = this.GetControlByOrOwner()
                                                                                                            else:
                                                                                                                check_player = this.card.area.GetOwner()
                                                                                                                if Event.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Resource.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Support.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Upgrade.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Unit2.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if this.card.area.flags.is_processing:
                                                                                                                    raise AssertionError({effect})
                                                                                                                if (asked_player == None):
                                                                                                                    return (True, '')
                                                                                                                raise AssertionError(f'this={this!r}')
                                                                                                        else:
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                        if this.IsInPlay():
                                                                            check_player = this.GetControlByOrOwner()
                                                                        else:
                                                                            check_player = this.card.area.GetOwner()
                                                                            if Event.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Resource.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Support.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Upgrade.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Unit2.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if this.card.area.flags.is_processing:
                                                                                raise AssertionError({effect})
                                                                            if (asked_player == None):
                                                                                return (True, '')
                                                                            raise AssertionError(f'this={this!r}')
                                                else:
                                                    if Attachment.IsType(this):
                                                        if not (Identity.IsType(this.bind_face)):
                                                            check_player = current_player
                                                        else:
                                                            if Minion.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Scheme2.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if Environment.IsType(this):
                                                                        check_player = current_player
                                                                    else:
                                                                        if not (effect.ability.flags.is_play_turn_option):
                                                                            if not (effect.ability.flags.is_basic_power):
                                                                                if not (effect.ability.flags.is_interrupt):
                                                                                    if not (effect.ability.flags.is_response):
                                                                                        if not (effect.ability.flags.is_resource):
                                                                                            if not (effect.ability.flags.is_action):
                                                                                                if not (effect.ability.flags.is_ask):
                                                                                                    if not (effect.ability.is_play):
                                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                                            if this.IsInPlay():
                                                                                                                check_player = this.GetControlByOrOwner()
                                                                                                            else:
                                                                                                                check_player = this.card.area.GetOwner()
                                                                                                                if Event.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Resource.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Support.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Upgrade.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Unit2.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if this.card.area.flags.is_processing:
                                                                                                                    raise AssertionError({effect})
                                                                                                                if (asked_player == None):
                                                                                                                    return (True, '')
                                                                                                                raise AssertionError(f'this={this!r}')
                                                                                                        else:
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                        if this.IsInPlay():
                                                                            check_player = this.GetControlByOrOwner()
                                                                        else:
                                                                            check_player = this.card.area.GetOwner()
                                                                            if Event.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Resource.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Support.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Upgrade.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Unit2.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if this.card.area.flags.is_processing:
                                                                                raise AssertionError({effect})
                                                                            if (asked_player == None):
                                                                                return (True, '')
                                                                            raise AssertionError(f'this={this!r}')
                                                    else:
                                                        if Minion.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Scheme2.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Environment.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if not (effect.ability.flags.is_play_turn_option):
                                                                        if not (effect.ability.flags.is_basic_power):
                                                                            if not (effect.ability.flags.is_interrupt):
                                                                                if not (effect.ability.flags.is_response):
                                                                                    if not (effect.ability.flags.is_resource):
                                                                                        if not (effect.ability.flags.is_action):
                                                                                            if not (effect.ability.flags.is_ask):
                                                                                                if not (effect.ability.is_play):
                                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                                        if this.IsInPlay():
                                                                                                            check_player = this.GetControlByOrOwner()
                                                                                                        else:
                                                                                                            check_player = this.card.area.GetOwner()
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                                                    else:
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                    if this.IsInPlay():
                                                                        check_player = this.GetControlByOrOwner()
                                                                    else:
                                                                        check_player = this.card.area.GetOwner()
                                                                        if Event.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Resource.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Support.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Upgrade.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Unit2.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if this.card.area.flags.is_processing:
                                                                            raise AssertionError({effect})
                                                                        if (asked_player == None):
                                                                            return (True, '')
                                                                        raise AssertionError(f'this={this!r}')
                                    else:
                                        check_player = message.to_player
                                        if isinstance(message, Message.WhenCardBeSpendAsResource):
                                            check_player = message.to_player
                                        else:
                                            if effect.ability.is_choose:
                                                return (True, '')
                                            if Obligation.IsType(this):
                                                if this.card.area.flags.is_obligations_area:
                                                    check_player = this.GetGaveToPlayer()
                                                else:
                                                    check_player = current_player
                                                    if Attachment.IsType(this):
                                                        if not (Identity.IsType(this.bind_face)):
                                                            check_player = current_player
                                                        else:
                                                            if Minion.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Scheme2.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if Environment.IsType(this):
                                                                        check_player = current_player
                                                                    else:
                                                                        if not (effect.ability.flags.is_play_turn_option):
                                                                            if not (effect.ability.flags.is_basic_power):
                                                                                if not (effect.ability.flags.is_interrupt):
                                                                                    if not (effect.ability.flags.is_response):
                                                                                        if not (effect.ability.flags.is_resource):
                                                                                            if not (effect.ability.flags.is_action):
                                                                                                if not (effect.ability.flags.is_ask):
                                                                                                    if not (effect.ability.is_play):
                                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                                            if this.IsInPlay():
                                                                                                                check_player = this.GetControlByOrOwner()
                                                                                                            else:
                                                                                                                check_player = this.card.area.GetOwner()
                                                                                                                if Event.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Resource.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Support.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Upgrade.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Unit2.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if this.card.area.flags.is_processing:
                                                                                                                    raise AssertionError({effect})
                                                                                                                if (asked_player == None):
                                                                                                                    return (True, '')
                                                                                                                raise AssertionError(f'this={this!r}')
                                                                                                        else:
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                        if this.IsInPlay():
                                                                            check_player = this.GetControlByOrOwner()
                                                                        else:
                                                                            check_player = this.card.area.GetOwner()
                                                                            if Event.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Resource.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Support.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Upgrade.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Unit2.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if this.card.area.flags.is_processing:
                                                                                raise AssertionError({effect})
                                                                            if (asked_player == None):
                                                                                return (True, '')
                                                                            raise AssertionError(f'this={this!r}')
                                                    else:
                                                        if Minion.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Scheme2.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Environment.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if not (effect.ability.flags.is_play_turn_option):
                                                                        if not (effect.ability.flags.is_basic_power):
                                                                            if not (effect.ability.flags.is_interrupt):
                                                                                if not (effect.ability.flags.is_response):
                                                                                    if not (effect.ability.flags.is_resource):
                                                                                        if not (effect.ability.flags.is_action):
                                                                                            if not (effect.ability.flags.is_ask):
                                                                                                if not (effect.ability.is_play):
                                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                                        if this.IsInPlay():
                                                                                                            check_player = this.GetControlByOrOwner()
                                                                                                        else:
                                                                                                            check_player = this.card.area.GetOwner()
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                                                    else:
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                    if this.IsInPlay():
                                                                        check_player = this.GetControlByOrOwner()
                                                                    else:
                                                                        check_player = this.card.area.GetOwner()
                                                                        if Event.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Resource.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Support.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Upgrade.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Unit2.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if this.card.area.flags.is_processing:
                                                                            raise AssertionError({effect})
                                                                        if (asked_player == None):
                                                                            return (True, '')
                                                                        raise AssertionError(f'this={this!r}')
                                            else:
                                                if Attachment.IsType(this):
                                                    if not (Identity.IsType(this.bind_face)):
                                                        check_player = current_player
                                                    else:
                                                        if Minion.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Scheme2.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Environment.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if not (effect.ability.flags.is_play_turn_option):
                                                                        if not (effect.ability.flags.is_basic_power):
                                                                            if not (effect.ability.flags.is_interrupt):
                                                                                if not (effect.ability.flags.is_response):
                                                                                    if not (effect.ability.flags.is_resource):
                                                                                        if not (effect.ability.flags.is_action):
                                                                                            if not (effect.ability.flags.is_ask):
                                                                                                if not (effect.ability.is_play):
                                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                                        if this.IsInPlay():
                                                                                                            check_player = this.GetControlByOrOwner()
                                                                                                        else:
                                                                                                            check_player = this.card.area.GetOwner()
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                                                    else:
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                    if this.IsInPlay():
                                                                        check_player = this.GetControlByOrOwner()
                                                                    else:
                                                                        check_player = this.card.area.GetOwner()
                                                                        if Event.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Resource.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Support.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Upgrade.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Unit2.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if this.card.area.flags.is_processing:
                                                                            raise AssertionError({effect})
                                                                        if (asked_player == None):
                                                                            return (True, '')
                                                                        raise AssertionError(f'this={this!r}')
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                else:
                                    if isinstance(message, Message.WhenCardBeSpendAsResource):
                                        check_player = message.to_player
                                    else:
                                        if effect.ability.is_choose:
                                            return (True, '')
                                        if Obligation.IsType(this):
                                            if this.card.area.flags.is_obligations_area:
                                                check_player = this.GetGaveToPlayer()
                                            else:
                                                check_player = current_player
                                                if Attachment.IsType(this):
                                                    if not (Identity.IsType(this.bind_face)):
                                                        check_player = current_player
                                                    else:
                                                        if Minion.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Scheme2.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Environment.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if not (effect.ability.flags.is_play_turn_option):
                                                                        if not (effect.ability.flags.is_basic_power):
                                                                            if not (effect.ability.flags.is_interrupt):
                                                                                if not (effect.ability.flags.is_response):
                                                                                    if not (effect.ability.flags.is_resource):
                                                                                        if not (effect.ability.flags.is_action):
                                                                                            if not (effect.ability.flags.is_ask):
                                                                                                if not (effect.ability.is_play):
                                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                                        if this.IsInPlay():
                                                                                                            check_player = this.GetControlByOrOwner()
                                                                                                        else:
                                                                                                            check_player = this.card.area.GetOwner()
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                                                    else:
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                    if this.IsInPlay():
                                                                        check_player = this.GetControlByOrOwner()
                                                                    else:
                                                                        check_player = this.card.area.GetOwner()
                                                                        if Event.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Resource.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Support.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Upgrade.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Unit2.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if this.card.area.flags.is_processing:
                                                                            raise AssertionError({effect})
                                                                        if (asked_player == None):
                                                                            return (True, '')
                                                                        raise AssertionError(f'this={this!r}')
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                        else:
                                            if Attachment.IsType(this):
                                                if not (Identity.IsType(this.bind_face)):
                                                    check_player = current_player
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                        else:
                            if isinstance(message, Message.WhenPlayerPayingResources):
                                if Event.IsType(message.for_effect.this):
                                    if message.for_effect.this.alliance:
                                        check_player = message.to_player
                                    else:
                                        check_player = message.to_player
                                        if isinstance(message, Message.WhenCardBeSpendAsResource):
                                            check_player = message.to_player
                                        else:
                                            if effect.ability.is_choose:
                                                return (True, '')
                                            if Obligation.IsType(this):
                                                if this.card.area.flags.is_obligations_area:
                                                    check_player = this.GetGaveToPlayer()
                                                else:
                                                    check_player = current_player
                                                    if Attachment.IsType(this):
                                                        if not (Identity.IsType(this.bind_face)):
                                                            check_player = current_player
                                                        else:
                                                            if Minion.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Scheme2.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if Environment.IsType(this):
                                                                        check_player = current_player
                                                                    else:
                                                                        if not (effect.ability.flags.is_play_turn_option):
                                                                            if not (effect.ability.flags.is_basic_power):
                                                                                if not (effect.ability.flags.is_interrupt):
                                                                                    if not (effect.ability.flags.is_response):
                                                                                        if not (effect.ability.flags.is_resource):
                                                                                            if not (effect.ability.flags.is_action):
                                                                                                if not (effect.ability.flags.is_ask):
                                                                                                    if not (effect.ability.is_play):
                                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                                            if this.IsInPlay():
                                                                                                                check_player = this.GetControlByOrOwner()
                                                                                                            else:
                                                                                                                check_player = this.card.area.GetOwner()
                                                                                                                if Event.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Resource.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Support.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Upgrade.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if Unit2.IsType(this):
                                                                                                                    raise AssertionError({effect})
                                                                                                                if this.card.area.flags.is_processing:
                                                                                                                    raise AssertionError({effect})
                                                                                                                if (asked_player == None):
                                                                                                                    return (True, '')
                                                                                                                raise AssertionError(f'this={this!r}')
                                                                                                        else:
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                        if this.IsInPlay():
                                                                            check_player = this.GetControlByOrOwner()
                                                                        else:
                                                                            check_player = this.card.area.GetOwner()
                                                                            if Event.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Resource.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Support.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Upgrade.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if Unit2.IsType(this):
                                                                                raise AssertionError({effect})
                                                                            if this.card.area.flags.is_processing:
                                                                                raise AssertionError({effect})
                                                                            if (asked_player == None):
                                                                                return (True, '')
                                                                            raise AssertionError(f'this={this!r}')
                                                    else:
                                                        if Minion.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Scheme2.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Environment.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if not (effect.ability.flags.is_play_turn_option):
                                                                        if not (effect.ability.flags.is_basic_power):
                                                                            if not (effect.ability.flags.is_interrupt):
                                                                                if not (effect.ability.flags.is_response):
                                                                                    if not (effect.ability.flags.is_resource):
                                                                                        if not (effect.ability.flags.is_action):
                                                                                            if not (effect.ability.flags.is_ask):
                                                                                                if not (effect.ability.is_play):
                                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                                        if this.IsInPlay():
                                                                                                            check_player = this.GetControlByOrOwner()
                                                                                                        else:
                                                                                                            check_player = this.card.area.GetOwner()
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                                                    else:
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                    if this.IsInPlay():
                                                                        check_player = this.GetControlByOrOwner()
                                                                    else:
                                                                        check_player = this.card.area.GetOwner()
                                                                        if Event.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Resource.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Support.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Upgrade.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Unit2.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if this.card.area.flags.is_processing:
                                                                            raise AssertionError({effect})
                                                                        if (asked_player == None):
                                                                            return (True, '')
                                                                        raise AssertionError(f'this={this!r}')
                                            else:
                                                if Attachment.IsType(this):
                                                    if not (Identity.IsType(this.bind_face)):
                                                        check_player = current_player
                                                    else:
                                                        if Minion.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Scheme2.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Environment.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if not (effect.ability.flags.is_play_turn_option):
                                                                        if not (effect.ability.flags.is_basic_power):
                                                                            if not (effect.ability.flags.is_interrupt):
                                                                                if not (effect.ability.flags.is_response):
                                                                                    if not (effect.ability.flags.is_resource):
                                                                                        if not (effect.ability.flags.is_action):
                                                                                            if not (effect.ability.flags.is_ask):
                                                                                                if not (effect.ability.is_play):
                                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                                        if this.IsInPlay():
                                                                                                            check_player = this.GetControlByOrOwner()
                                                                                                        else:
                                                                                                            check_player = this.card.area.GetOwner()
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                                                    else:
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                    if this.IsInPlay():
                                                                        check_player = this.GetControlByOrOwner()
                                                                    else:
                                                                        check_player = this.card.area.GetOwner()
                                                                        if Event.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Resource.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Support.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Upgrade.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Unit2.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if this.card.area.flags.is_processing:
                                                                            raise AssertionError({effect})
                                                                        if (asked_player == None):
                                                                            return (True, '')
                                                                        raise AssertionError(f'this={this!r}')
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                else:
                                    check_player = message.to_player
                                    if isinstance(message, Message.WhenCardBeSpendAsResource):
                                        check_player = message.to_player
                                    else:
                                        if effect.ability.is_choose:
                                            return (True, '')
                                        if Obligation.IsType(this):
                                            if this.card.area.flags.is_obligations_area:
                                                check_player = this.GetGaveToPlayer()
                                            else:
                                                check_player = current_player
                                                if Attachment.IsType(this):
                                                    if not (Identity.IsType(this.bind_face)):
                                                        check_player = current_player
                                                    else:
                                                        if Minion.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Scheme2.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Environment.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if not (effect.ability.flags.is_play_turn_option):
                                                                        if not (effect.ability.flags.is_basic_power):
                                                                            if not (effect.ability.flags.is_interrupt):
                                                                                if not (effect.ability.flags.is_response):
                                                                                    if not (effect.ability.flags.is_resource):
                                                                                        if not (effect.ability.flags.is_action):
                                                                                            if not (effect.ability.flags.is_ask):
                                                                                                if not (effect.ability.is_play):
                                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                                        if this.IsInPlay():
                                                                                                            check_player = this.GetControlByOrOwner()
                                                                                                        else:
                                                                                                            check_player = this.card.area.GetOwner()
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                                                    else:
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                    if this.IsInPlay():
                                                                        check_player = this.GetControlByOrOwner()
                                                                    else:
                                                                        check_player = this.card.area.GetOwner()
                                                                        if Event.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Resource.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Support.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Upgrade.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Unit2.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if this.card.area.flags.is_processing:
                                                                            raise AssertionError({effect})
                                                                        if (asked_player == None):
                                                                            return (True, '')
                                                                        raise AssertionError(f'this={this!r}')
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                        else:
                                            if Attachment.IsType(this):
                                                if not (Identity.IsType(this.bind_face)):
                                                    check_player = current_player
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                            else:
                                if isinstance(message, Message.WhenCardBeSpendAsResource):
                                    check_player = message.to_player
                                else:
                                    if effect.ability.is_choose:
                                        return (True, '')
                                    if Obligation.IsType(this):
                                        if this.card.area.flags.is_obligations_area:
                                            check_player = this.GetGaveToPlayer()
                                        else:
                                            check_player = current_player
                                            if Attachment.IsType(this):
                                                if not (Identity.IsType(this.bind_face)):
                                                    check_player = current_player
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                                    else:
                                        if Attachment.IsType(this):
                                            if not (Identity.IsType(this.bind_face)):
                                                check_player = current_player
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                                        else:
                                            if Minion.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Scheme2.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Environment.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if not (effect.ability.flags.is_play_turn_option):
                                                            if not (effect.ability.flags.is_basic_power):
                                                                if not (effect.ability.flags.is_interrupt):
                                                                    if not (effect.ability.flags.is_response):
                                                                        if not (effect.ability.flags.is_resource):
                                                                            if not (effect.ability.flags.is_action):
                                                                                if not (effect.ability.flags.is_ask):
                                                                                    if not (effect.ability.is_play):
                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                            if this.IsInPlay():
                                                                                                check_player = this.GetControlByOrOwner()
                                                                                            else:
                                                                                                check_player = this.card.area.GetOwner()
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                                                        else:
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                        if this.IsInPlay():
                                                            check_player = this.GetControlByOrOwner()
                                                        else:
                                                            check_player = this.card.area.GetOwner()
                                                            if Event.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Resource.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Support.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Upgrade.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Unit2.IsType(this):
                                                                raise AssertionError({effect})
                                                            if this.card.area.flags.is_processing:
                                                                raise AssertionError({effect})
                                                            if (asked_player == None):
                                                                return (True, '')
                                                            raise AssertionError(f'this={this!r}')
                check_player = message.CastTo(Message.WhenPlayerPayingResources).GetToPlayer()
                if effect.ability.any_player_can_trigger_this_when:
                    if isinstance(message, TriggerPlayerMessage):
                        check_player = message.to_player
                    else:
                        check_player = current_player
                        if isinstance(message, Message.WhenPlayerPayingResources):
                            if Event.IsType(message.for_effect.this):
                                if message.for_effect.this.alliance:
                                    check_player = message.to_player
                                else:
                                    check_player = message.to_player
                                    if isinstance(message, Message.WhenCardBeSpendAsResource):
                                        check_player = message.to_player
                                    else:
                                        if effect.ability.is_choose:
                                            return (True, '')
                                        if Obligation.IsType(this):
                                            if this.card.area.flags.is_obligations_area:
                                                check_player = this.GetGaveToPlayer()
                                            else:
                                                check_player = current_player
                                                if Attachment.IsType(this):
                                                    if not (Identity.IsType(this.bind_face)):
                                                        check_player = current_player
                                                    else:
                                                        if Minion.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Scheme2.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if Environment.IsType(this):
                                                                    check_player = current_player
                                                                else:
                                                                    if not (effect.ability.flags.is_play_turn_option):
                                                                        if not (effect.ability.flags.is_basic_power):
                                                                            if not (effect.ability.flags.is_interrupt):
                                                                                if not (effect.ability.flags.is_response):
                                                                                    if not (effect.ability.flags.is_resource):
                                                                                        if not (effect.ability.flags.is_action):
                                                                                            if not (effect.ability.flags.is_ask):
                                                                                                if not (effect.ability.is_play):
                                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                                        if this.IsInPlay():
                                                                                                            check_player = this.GetControlByOrOwner()
                                                                                                        else:
                                                                                                            check_player = this.card.area.GetOwner()
                                                                                                            if Event.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Resource.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Support.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Upgrade.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if Unit2.IsType(this):
                                                                                                                raise AssertionError({effect})
                                                                                                            if this.card.area.flags.is_processing:
                                                                                                                raise AssertionError({effect})
                                                                                                            if (asked_player == None):
                                                                                                                return (True, '')
                                                                                                            raise AssertionError(f'this={this!r}')
                                                                                                    else:
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                    if this.IsInPlay():
                                                                        check_player = this.GetControlByOrOwner()
                                                                    else:
                                                                        check_player = this.card.area.GetOwner()
                                                                        if Event.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Resource.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Support.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Upgrade.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if Unit2.IsType(this):
                                                                            raise AssertionError({effect})
                                                                        if this.card.area.flags.is_processing:
                                                                            raise AssertionError({effect})
                                                                        if (asked_player == None):
                                                                            return (True, '')
                                                                        raise AssertionError(f'this={this!r}')
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                        else:
                                            if Attachment.IsType(this):
                                                if not (Identity.IsType(this.bind_face)):
                                                    check_player = current_player
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                            else:
                                check_player = message.to_player
                                if isinstance(message, Message.WhenCardBeSpendAsResource):
                                    check_player = message.to_player
                                else:
                                    if effect.ability.is_choose:
                                        return (True, '')
                                    if Obligation.IsType(this):
                                        if this.card.area.flags.is_obligations_area:
                                            check_player = this.GetGaveToPlayer()
                                        else:
                                            check_player = current_player
                                            if Attachment.IsType(this):
                                                if not (Identity.IsType(this.bind_face)):
                                                    check_player = current_player
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                                    else:
                                        if Attachment.IsType(this):
                                            if not (Identity.IsType(this.bind_face)):
                                                check_player = current_player
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                                        else:
                                            if Minion.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Scheme2.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Environment.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if not (effect.ability.flags.is_play_turn_option):
                                                            if not (effect.ability.flags.is_basic_power):
                                                                if not (effect.ability.flags.is_interrupt):
                                                                    if not (effect.ability.flags.is_response):
                                                                        if not (effect.ability.flags.is_resource):
                                                                            if not (effect.ability.flags.is_action):
                                                                                if not (effect.ability.flags.is_ask):
                                                                                    if not (effect.ability.is_play):
                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                            if this.IsInPlay():
                                                                                                check_player = this.GetControlByOrOwner()
                                                                                            else:
                                                                                                check_player = this.card.area.GetOwner()
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                                                        else:
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                        if this.IsInPlay():
                                                            check_player = this.GetControlByOrOwner()
                                                        else:
                                                            check_player = this.card.area.GetOwner()
                                                            if Event.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Resource.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Support.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Upgrade.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Unit2.IsType(this):
                                                                raise AssertionError({effect})
                                                            if this.card.area.flags.is_processing:
                                                                raise AssertionError({effect})
                                                            if (asked_player == None):
                                                                return (True, '')
                                                            raise AssertionError(f'this={this!r}')
                        else:
                            if isinstance(message, Message.WhenCardBeSpendAsResource):
                                check_player = message.to_player
                            else:
                                if effect.ability.is_choose:
                                    return (True, '')
                                if Obligation.IsType(this):
                                    if this.card.area.flags.is_obligations_area:
                                        check_player = this.GetGaveToPlayer()
                                    else:
                                        check_player = current_player
                                        if Attachment.IsType(this):
                                            if not (Identity.IsType(this.bind_face)):
                                                check_player = current_player
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                                        else:
                                            if Minion.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Scheme2.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Environment.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if not (effect.ability.flags.is_play_turn_option):
                                                            if not (effect.ability.flags.is_basic_power):
                                                                if not (effect.ability.flags.is_interrupt):
                                                                    if not (effect.ability.flags.is_response):
                                                                        if not (effect.ability.flags.is_resource):
                                                                            if not (effect.ability.flags.is_action):
                                                                                if not (effect.ability.flags.is_ask):
                                                                                    if not (effect.ability.is_play):
                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                            if this.IsInPlay():
                                                                                                check_player = this.GetControlByOrOwner()
                                                                                            else:
                                                                                                check_player = this.card.area.GetOwner()
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                                                        else:
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                        if this.IsInPlay():
                                                            check_player = this.GetControlByOrOwner()
                                                        else:
                                                            check_player = this.card.area.GetOwner()
                                                            if Event.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Resource.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Support.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Upgrade.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Unit2.IsType(this):
                                                                raise AssertionError({effect})
                                                            if this.card.area.flags.is_processing:
                                                                raise AssertionError({effect})
                                                            if (asked_player == None):
                                                                return (True, '')
                                                            raise AssertionError(f'this={this!r}')
                                else:
                                    if Attachment.IsType(this):
                                        if not (Identity.IsType(this.bind_face)):
                                            check_player = current_player
                                        else:
                                            if Minion.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Scheme2.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Environment.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if not (effect.ability.flags.is_play_turn_option):
                                                            if not (effect.ability.flags.is_basic_power):
                                                                if not (effect.ability.flags.is_interrupt):
                                                                    if not (effect.ability.flags.is_response):
                                                                        if not (effect.ability.flags.is_resource):
                                                                            if not (effect.ability.flags.is_action):
                                                                                if not (effect.ability.flags.is_ask):
                                                                                    if not (effect.ability.is_play):
                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                            if this.IsInPlay():
                                                                                                check_player = this.GetControlByOrOwner()
                                                                                            else:
                                                                                                check_player = this.card.area.GetOwner()
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                                                        else:
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                        if this.IsInPlay():
                                                            check_player = this.GetControlByOrOwner()
                                                        else:
                                                            check_player = this.card.area.GetOwner()
                                                            if Event.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Resource.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Support.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Upgrade.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Unit2.IsType(this):
                                                                raise AssertionError({effect})
                                                            if this.card.area.flags.is_processing:
                                                                raise AssertionError({effect})
                                                            if (asked_player == None):
                                                                return (True, '')
                                                            raise AssertionError(f'this={this!r}')
                                    else:
                                        if Minion.IsType(this):
                                            check_player = current_player
                                        else:
                                            if Scheme2.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Environment.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if not (effect.ability.flags.is_play_turn_option):
                                                        if not (effect.ability.flags.is_basic_power):
                                                            if not (effect.ability.flags.is_interrupt):
                                                                if not (effect.ability.flags.is_response):
                                                                    if not (effect.ability.flags.is_resource):
                                                                        if not (effect.ability.flags.is_action):
                                                                            if not (effect.ability.flags.is_ask):
                                                                                if not (effect.ability.is_play):
                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                        if this.IsInPlay():
                                                                                            check_player = this.GetControlByOrOwner()
                                                                                        else:
                                                                                            check_player = this.card.area.GetOwner()
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                                                    else:
                                                                                        if Event.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Resource.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Support.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Upgrade.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Unit2.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if this.card.area.flags.is_processing:
                                                                                            raise AssertionError({effect})
                                                                                        if (asked_player == None):
                                                                                            return (True, '')
                                                                                        raise AssertionError(f'this={this!r}')
                                                    if this.IsInPlay():
                                                        check_player = this.GetControlByOrOwner()
                                                    else:
                                                        check_player = this.card.area.GetOwner()
                                                        if Event.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Resource.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Support.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Upgrade.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Unit2.IsType(this):
                                                            raise AssertionError({effect})
                                                        if this.card.area.flags.is_processing:
                                                            raise AssertionError({effect})
                                                        if (asked_player == None):
                                                            return (True, '')
                                                        raise AssertionError(f'this={this!r}')
                else:
                    if isinstance(message, Message.WhenPlayerPayingResources):
                        if Event.IsType(message.for_effect.this):
                            if message.for_effect.this.alliance:
                                check_player = message.to_player
                            else:
                                check_player = message.to_player
                                if isinstance(message, Message.WhenCardBeSpendAsResource):
                                    check_player = message.to_player
                                else:
                                    if effect.ability.is_choose:
                                        return (True, '')
                                    if Obligation.IsType(this):
                                        if this.card.area.flags.is_obligations_area:
                                            check_player = this.GetGaveToPlayer()
                                        else:
                                            check_player = current_player
                                            if Attachment.IsType(this):
                                                if not (Identity.IsType(this.bind_face)):
                                                    check_player = current_player
                                                else:
                                                    if Minion.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Scheme2.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if Environment.IsType(this):
                                                                check_player = current_player
                                                            else:
                                                                if not (effect.ability.flags.is_play_turn_option):
                                                                    if not (effect.ability.flags.is_basic_power):
                                                                        if not (effect.ability.flags.is_interrupt):
                                                                            if not (effect.ability.flags.is_response):
                                                                                if not (effect.ability.flags.is_resource):
                                                                                    if not (effect.ability.flags.is_action):
                                                                                        if not (effect.ability.flags.is_ask):
                                                                                            if not (effect.ability.is_play):
                                                                                                if effect.ability.flags.is_discard_pay:
                                                                                                    if this.IsInPlay():
                                                                                                        check_player = this.GetControlByOrOwner()
                                                                                                    else:
                                                                                                        check_player = this.card.area.GetOwner()
                                                                                                        if Event.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Resource.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Support.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Upgrade.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if Unit2.IsType(this):
                                                                                                            raise AssertionError({effect})
                                                                                                        if this.card.area.flags.is_processing:
                                                                                                            raise AssertionError({effect})
                                                                                                        if (asked_player == None):
                                                                                                            return (True, '')
                                                                                                        raise AssertionError(f'this={this!r}')
                                                                                                else:
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                if this.IsInPlay():
                                                                    check_player = this.GetControlByOrOwner()
                                                                else:
                                                                    check_player = this.card.area.GetOwner()
                                                                    if Event.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Resource.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Support.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Upgrade.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if Unit2.IsType(this):
                                                                        raise AssertionError({effect})
                                                                    if this.card.area.flags.is_processing:
                                                                        raise AssertionError({effect})
                                                                    if (asked_player == None):
                                                                        return (True, '')
                                                                    raise AssertionError(f'this={this!r}')
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                                    else:
                                        if Attachment.IsType(this):
                                            if not (Identity.IsType(this.bind_face)):
                                                check_player = current_player
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                                        else:
                                            if Minion.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Scheme2.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Environment.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if not (effect.ability.flags.is_play_turn_option):
                                                            if not (effect.ability.flags.is_basic_power):
                                                                if not (effect.ability.flags.is_interrupt):
                                                                    if not (effect.ability.flags.is_response):
                                                                        if not (effect.ability.flags.is_resource):
                                                                            if not (effect.ability.flags.is_action):
                                                                                if not (effect.ability.flags.is_ask):
                                                                                    if not (effect.ability.is_play):
                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                            if this.IsInPlay():
                                                                                                check_player = this.GetControlByOrOwner()
                                                                                            else:
                                                                                                check_player = this.card.area.GetOwner()
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                                                        else:
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                        if this.IsInPlay():
                                                            check_player = this.GetControlByOrOwner()
                                                        else:
                                                            check_player = this.card.area.GetOwner()
                                                            if Event.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Resource.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Support.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Upgrade.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Unit2.IsType(this):
                                                                raise AssertionError({effect})
                                                            if this.card.area.flags.is_processing:
                                                                raise AssertionError({effect})
                                                            if (asked_player == None):
                                                                return (True, '')
                                                            raise AssertionError(f'this={this!r}')
                        else:
                            check_player = message.to_player
                            if isinstance(message, Message.WhenCardBeSpendAsResource):
                                check_player = message.to_player
                            else:
                                if effect.ability.is_choose:
                                    return (True, '')
                                if Obligation.IsType(this):
                                    if this.card.area.flags.is_obligations_area:
                                        check_player = this.GetGaveToPlayer()
                                    else:
                                        check_player = current_player
                                        if Attachment.IsType(this):
                                            if not (Identity.IsType(this.bind_face)):
                                                check_player = current_player
                                            else:
                                                if Minion.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Scheme2.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if Environment.IsType(this):
                                                            check_player = current_player
                                                        else:
                                                            if not (effect.ability.flags.is_play_turn_option):
                                                                if not (effect.ability.flags.is_basic_power):
                                                                    if not (effect.ability.flags.is_interrupt):
                                                                        if not (effect.ability.flags.is_response):
                                                                            if not (effect.ability.flags.is_resource):
                                                                                if not (effect.ability.flags.is_action):
                                                                                    if not (effect.ability.flags.is_ask):
                                                                                        if not (effect.ability.is_play):
                                                                                            if effect.ability.flags.is_discard_pay:
                                                                                                if this.IsInPlay():
                                                                                                    check_player = this.GetControlByOrOwner()
                                                                                                else:
                                                                                                    check_player = this.card.area.GetOwner()
                                                                                                    if Event.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Resource.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Support.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Upgrade.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if Unit2.IsType(this):
                                                                                                        raise AssertionError({effect})
                                                                                                    if this.card.area.flags.is_processing:
                                                                                                        raise AssertionError({effect})
                                                                                                    if (asked_player == None):
                                                                                                        return (True, '')
                                                                                                    raise AssertionError(f'this={this!r}')
                                                                                            else:
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                            if this.IsInPlay():
                                                                check_player = this.GetControlByOrOwner()
                                                            else:
                                                                check_player = this.card.area.GetOwner()
                                                                if Event.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Resource.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Support.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Upgrade.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if Unit2.IsType(this):
                                                                    raise AssertionError({effect})
                                                                if this.card.area.flags.is_processing:
                                                                    raise AssertionError({effect})
                                                                if (asked_player == None):
                                                                    return (True, '')
                                                                raise AssertionError(f'this={this!r}')
                                        else:
                                            if Minion.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Scheme2.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Environment.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if not (effect.ability.flags.is_play_turn_option):
                                                            if not (effect.ability.flags.is_basic_power):
                                                                if not (effect.ability.flags.is_interrupt):
                                                                    if not (effect.ability.flags.is_response):
                                                                        if not (effect.ability.flags.is_resource):
                                                                            if not (effect.ability.flags.is_action):
                                                                                if not (effect.ability.flags.is_ask):
                                                                                    if not (effect.ability.is_play):
                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                            if this.IsInPlay():
                                                                                                check_player = this.GetControlByOrOwner()
                                                                                            else:
                                                                                                check_player = this.card.area.GetOwner()
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                                                        else:
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                        if this.IsInPlay():
                                                            check_player = this.GetControlByOrOwner()
                                                        else:
                                                            check_player = this.card.area.GetOwner()
                                                            if Event.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Resource.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Support.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Upgrade.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Unit2.IsType(this):
                                                                raise AssertionError({effect})
                                                            if this.card.area.flags.is_processing:
                                                                raise AssertionError({effect})
                                                            if (asked_player == None):
                                                                return (True, '')
                                                            raise AssertionError(f'this={this!r}')
                                else:
                                    if Attachment.IsType(this):
                                        if not (Identity.IsType(this.bind_face)):
                                            check_player = current_player
                                        else:
                                            if Minion.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Scheme2.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Environment.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if not (effect.ability.flags.is_play_turn_option):
                                                            if not (effect.ability.flags.is_basic_power):
                                                                if not (effect.ability.flags.is_interrupt):
                                                                    if not (effect.ability.flags.is_response):
                                                                        if not (effect.ability.flags.is_resource):
                                                                            if not (effect.ability.flags.is_action):
                                                                                if not (effect.ability.flags.is_ask):
                                                                                    if not (effect.ability.is_play):
                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                            if this.IsInPlay():
                                                                                                check_player = this.GetControlByOrOwner()
                                                                                            else:
                                                                                                check_player = this.card.area.GetOwner()
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                                                        else:
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                        if this.IsInPlay():
                                                            check_player = this.GetControlByOrOwner()
                                                        else:
                                                            check_player = this.card.area.GetOwner()
                                                            if Event.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Resource.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Support.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Upgrade.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Unit2.IsType(this):
                                                                raise AssertionError({effect})
                                                            if this.card.area.flags.is_processing:
                                                                raise AssertionError({effect})
                                                            if (asked_player == None):
                                                                return (True, '')
                                                            raise AssertionError(f'this={this!r}')
                                    else:
                                        if Minion.IsType(this):
                                            check_player = current_player
                                        else:
                                            if Scheme2.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Environment.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if not (effect.ability.flags.is_play_turn_option):
                                                        if not (effect.ability.flags.is_basic_power):
                                                            if not (effect.ability.flags.is_interrupt):
                                                                if not (effect.ability.flags.is_response):
                                                                    if not (effect.ability.flags.is_resource):
                                                                        if not (effect.ability.flags.is_action):
                                                                            if not (effect.ability.flags.is_ask):
                                                                                if not (effect.ability.is_play):
                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                        if this.IsInPlay():
                                                                                            check_player = this.GetControlByOrOwner()
                                                                                        else:
                                                                                            check_player = this.card.area.GetOwner()
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                                                    else:
                                                                                        if Event.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Resource.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Support.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Upgrade.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Unit2.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if this.card.area.flags.is_processing:
                                                                                            raise AssertionError({effect})
                                                                                        if (asked_player == None):
                                                                                            return (True, '')
                                                                                        raise AssertionError(f'this={this!r}')
                                                    if this.IsInPlay():
                                                        check_player = this.GetControlByOrOwner()
                                                    else:
                                                        check_player = this.card.area.GetOwner()
                                                        if Event.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Resource.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Support.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Upgrade.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Unit2.IsType(this):
                                                            raise AssertionError({effect})
                                                        if this.card.area.flags.is_processing:
                                                            raise AssertionError({effect})
                                                        if (asked_player == None):
                                                            return (True, '')
                                                        raise AssertionError(f'this={this!r}')
                    else:
                        if isinstance(message, Message.WhenCardBeSpendAsResource):
                            check_player = message.to_player
                        else:
                            if effect.ability.is_choose:
                                return (True, '')
                            if Obligation.IsType(this):
                                if this.card.area.flags.is_obligations_area:
                                    check_player = this.GetGaveToPlayer()
                                else:
                                    check_player = current_player
                                    if Attachment.IsType(this):
                                        if not (Identity.IsType(this.bind_face)):
                                            check_player = current_player
                                        else:
                                            if Minion.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Scheme2.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if Environment.IsType(this):
                                                        check_player = current_player
                                                    else:
                                                        if not (effect.ability.flags.is_play_turn_option):
                                                            if not (effect.ability.flags.is_basic_power):
                                                                if not (effect.ability.flags.is_interrupt):
                                                                    if not (effect.ability.flags.is_response):
                                                                        if not (effect.ability.flags.is_resource):
                                                                            if not (effect.ability.flags.is_action):
                                                                                if not (effect.ability.flags.is_ask):
                                                                                    if not (effect.ability.is_play):
                                                                                        if effect.ability.flags.is_discard_pay:
                                                                                            if this.IsInPlay():
                                                                                                check_player = this.GetControlByOrOwner()
                                                                                            else:
                                                                                                check_player = this.card.area.GetOwner()
                                                                                                if Event.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Resource.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Support.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Upgrade.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if Unit2.IsType(this):
                                                                                                    raise AssertionError({effect})
                                                                                                if this.card.area.flags.is_processing:
                                                                                                    raise AssertionError({effect})
                                                                                                if (asked_player == None):
                                                                                                    return (True, '')
                                                                                                raise AssertionError(f'this={this!r}')
                                                                                        else:
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                        if this.IsInPlay():
                                                            check_player = this.GetControlByOrOwner()
                                                        else:
                                                            check_player = this.card.area.GetOwner()
                                                            if Event.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Resource.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Support.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Upgrade.IsType(this):
                                                                raise AssertionError({effect})
                                                            if Unit2.IsType(this):
                                                                raise AssertionError({effect})
                                                            if this.card.area.flags.is_processing:
                                                                raise AssertionError({effect})
                                                            if (asked_player == None):
                                                                return (True, '')
                                                            raise AssertionError(f'this={this!r}')
                                    else:
                                        if Minion.IsType(this):
                                            check_player = current_player
                                        else:
                                            if Scheme2.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Environment.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if not (effect.ability.flags.is_play_turn_option):
                                                        if not (effect.ability.flags.is_basic_power):
                                                            if not (effect.ability.flags.is_interrupt):
                                                                if not (effect.ability.flags.is_response):
                                                                    if not (effect.ability.flags.is_resource):
                                                                        if not (effect.ability.flags.is_action):
                                                                            if not (effect.ability.flags.is_ask):
                                                                                if not (effect.ability.is_play):
                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                        if this.IsInPlay():
                                                                                            check_player = this.GetControlByOrOwner()
                                                                                        else:
                                                                                            check_player = this.card.area.GetOwner()
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                                                    else:
                                                                                        if Event.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Resource.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Support.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Upgrade.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Unit2.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if this.card.area.flags.is_processing:
                                                                                            raise AssertionError({effect})
                                                                                        if (asked_player == None):
                                                                                            return (True, '')
                                                                                        raise AssertionError(f'this={this!r}')
                                                    if this.IsInPlay():
                                                        check_player = this.GetControlByOrOwner()
                                                    else:
                                                        check_player = this.card.area.GetOwner()
                                                        if Event.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Resource.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Support.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Upgrade.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Unit2.IsType(this):
                                                            raise AssertionError({effect})
                                                        if this.card.area.flags.is_processing:
                                                            raise AssertionError({effect})
                                                        if (asked_player == None):
                                                            return (True, '')
                                                        raise AssertionError(f'this={this!r}')
                            else:
                                if Attachment.IsType(this):
                                    if not (Identity.IsType(this.bind_face)):
                                        check_player = current_player
                                    else:
                                        if Minion.IsType(this):
                                            check_player = current_player
                                        else:
                                            if Scheme2.IsType(this):
                                                check_player = current_player
                                            else:
                                                if Environment.IsType(this):
                                                    check_player = current_player
                                                else:
                                                    if not (effect.ability.flags.is_play_turn_option):
                                                        if not (effect.ability.flags.is_basic_power):
                                                            if not (effect.ability.flags.is_interrupt):
                                                                if not (effect.ability.flags.is_response):
                                                                    if not (effect.ability.flags.is_resource):
                                                                        if not (effect.ability.flags.is_action):
                                                                            if not (effect.ability.flags.is_ask):
                                                                                if not (effect.ability.is_play):
                                                                                    if effect.ability.flags.is_discard_pay:
                                                                                        if this.IsInPlay():
                                                                                            check_player = this.GetControlByOrOwner()
                                                                                        else:
                                                                                            check_player = this.card.area.GetOwner()
                                                                                            if Event.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Resource.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Support.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Upgrade.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if Unit2.IsType(this):
                                                                                                raise AssertionError({effect})
                                                                                            if this.card.area.flags.is_processing:
                                                                                                raise AssertionError({effect})
                                                                                            if (asked_player == None):
                                                                                                return (True, '')
                                                                                            raise AssertionError(f'this={this!r}')
                                                                                    else:
                                                                                        if Event.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Resource.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Support.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Upgrade.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Unit2.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if this.card.area.flags.is_processing:
                                                                                            raise AssertionError({effect})
                                                                                        if (asked_player == None):
                                                                                            return (True, '')
                                                                                        raise AssertionError(f'this={this!r}')
                                                    if this.IsInPlay():
                                                        check_player = this.GetControlByOrOwner()
                                                    else:
                                                        check_player = this.card.area.GetOwner()
                                                        if Event.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Resource.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Support.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Upgrade.IsType(this):
                                                            raise AssertionError({effect})
                                                        if Unit2.IsType(this):
                                                            raise AssertionError({effect})
                                                        if this.card.area.flags.is_processing:
                                                            raise AssertionError({effect})
                                                        if (asked_player == None):
                                                            return (True, '')
                                                        raise AssertionError(f'this={this!r}')
                                else:
                                    if Minion.IsType(this):
                                        check_player = current_player
                                    else:
                                        if Scheme2.IsType(this):
                                            check_player = current_player
                                        else:
                                            if Environment.IsType(this):
                                                check_player = current_player
                                            else:
                                                if not (effect.ability.flags.is_play_turn_option):
                                                    if not (effect.ability.flags.is_basic_power):
                                                        if not (effect.ability.flags.is_interrupt):
                                                            if not (effect.ability.flags.is_response):
                                                                if not (effect.ability.flags.is_resource):
                                                                    if not (effect.ability.flags.is_action):
                                                                        if not (effect.ability.flags.is_ask):
                                                                            if not (effect.ability.is_play):
                                                                                if effect.ability.flags.is_discard_pay:
                                                                                    if this.IsInPlay():
                                                                                        check_player = this.GetControlByOrOwner()
                                                                                    else:
                                                                                        check_player = this.card.area.GetOwner()
                                                                                        if Event.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Resource.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Support.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Upgrade.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if Unit2.IsType(this):
                                                                                            raise AssertionError({effect})
                                                                                        if this.card.area.flags.is_processing:
                                                                                            raise AssertionError({effect})
                                                                                        if (asked_player == None):
                                                                                            return (True, '')
                                                                                        raise AssertionError(f'this={this!r}')
                                                                                else:
                                                                                    if Event.IsType(this):
                                                                                        raise AssertionError({effect})
                                                                                    if Resource.IsType(this):
                                                                                        raise AssertionError({effect})
                                                                                    if Support.IsType(this):
                                                                                        raise AssertionError({effect})
                                                                                    if Upgrade.IsType(this):
                                                                                        raise AssertionError({effect})
                                                                                    if Unit2.IsType(this):
                                                                                        raise AssertionError({effect})
                                                                                    if this.card.area.flags.is_processing:
                                                                                        raise AssertionError({effect})
                                                                                    if (asked_player == None):
                                                                                        return (True, '')
                                                                                    raise AssertionError(f'this={this!r}')
                                                if this.IsInPlay():
                                                    check_player = this.GetControlByOrOwner()
                                                else:
                                                    check_player = this.card.area.GetOwner()
                                                    if Event.IsType(this):
                                                        raise AssertionError({effect})
                                                    if Resource.IsType(this):
                                                        raise AssertionError({effect})
                                                    if Support.IsType(this):
                                                        raise AssertionError({effect})
                                                    if Upgrade.IsType(this):
                                                        raise AssertionError({effect})
                                                    if Unit2.IsType(this):
                                                        raise AssertionError({effect})
                                                    if this.card.area.flags.is_processing:
                                                        raise AssertionError({effect})
                                                    if (asked_player == None):
                                                        return (True, '')
                                                    raise AssertionError(f'this={this!r}')
                return ((check_player == asked_player), {check_player})
            if not (effect.is_forced):
                ok = check_initiator()[0]
                error = check_initiator()[1]
                if not (ok):
                    effect.failures.SetText(asked_player, f'initiator error, check: {error}, ask: {asked_player}')
            effects_list.append(effect)
        return effects_list
    @staticmethod
    def FilterAvailableEffects(message, effects, asked_player, world, undo_handle):
        from game.message.sender.sender import CanBeInstead
        from game.message import Message
        from game.player import Player
        if isinstance(message, CanBeInstead):
            if message.is_be_instead:
                return []
        checked_effects = EventManager.SimpleCheckEffects(message, effects, asked_player, world, undo_handle)
        for effect in checked_effects:
            effect.this.card.ui.unavailable.Reset()
        def check():
            effects_list = []
            for effect in checked_effects:
                effect.context.bind_message = message
                if (asked_player != None):
                    effect.context.initiator = asked_player
                else:
                    effect.context.initiator = effect.this.GetControlByOrOwner()
                effect.context.ask_player = asked_player
                effect.context.ResetBeforeCondition()
                if (asked_player == None):
                    if isinstance(effect.initiator, Player):
                        effect.context.ask_player = effect.initiator
                    else:
                        effect.context.ask_player = asked_player
                else:
                    effect.context.ask_player = asked_player
                if not (effect.checker.CheckCondition(message, effect.context.ask_player)):
                    if (effect.ability.when is Message.WhenPlayerChooseAbility):
                        if effect.ability.selectors:
                            if effect.ability.selectors[0]:
                                effect.ability.selectors[0].IfSelectTargetFailure(effect)
                effects_list.append(effect)
            return effects_list
        effects_list = check()
        if CACHE_BASED_FAST_UNDO.value:
            if undo_handle:
                controller_manager = message.world.controller_manager
                controller_manager.undo.PushFastUndo(message, effects_list)
        return effects_list
    def StackMessage(self, message: CardStateUpdatedMessage):
        self.stack_message.append(message)
    def BroadcastStackMessage(self):
        if self.stack_message:
            messages = self.stack_message[:]
            self.stack_message.clear()
            for message in messages:
                self.BroadcastMessage(message)
    def BroadcastMessage(self, message: Message2):
        from game.ability.ability import TimingPriority
        from game.message import Message
        from game.message.message_type import NoSendResolve
        if self.world.is_game_over:
            from game.message.sender.sender import CanBeInstead
            if isinstance(message, CanBeInstead):
                message.SilentInstead()
            return
        is_playing_res = isinstance(message, Message.WhenPlayerPayingResources)
        def find_local_effects():
            if isinstance(message, Message.WhenPlayerPayingResources):
                return [message.by_effect]
            local_effects = []
            for face in message.related_faces:
                for check_effect in face.effect.local_effects:
                    if isinstance(message, check_effect.ability.when):
                        local_effects.append(check_effect)
            return local_effects
        local_effects = find_local_effects()
        has_registered_event = self.HasRegisteredEvent(type(message))
        if not (has_registered_event):
            if not (local_effects):
                return
        if CACHE_BASED_FAST_UNDO.value:
            controller_manager = message.world.controller_manager
            undo_handle = controller_manager.undo.GetFastUndoHandle(message)
            if undo_handle:
                if not (undo_handle.card_ids):
                    return
                step_id = undo_handle.step_id
                Log.DebugSilent('UNDO_HANDLE', f'{step_id} {message}: {undo_handle.card_ids}')
        else:
            undo_handle = None
        if isinstance(message, NoSendResolve):
            priorities = [TimingPriority.Rule, TimingPriority.Constant, TimingPriority.ForcedInterrupt]
            if not (has_registered_event):
                if local_effects:
                    check_in_play_and_hand = False
                    check_face_up_or_hand = True
                    check_only_in_play = True
                    checked = False
                    catogories = ['Rule', 'Forced']
                    if has_registered_event:
                        if isinstance(message, Message.CheckPlayerCanPayCost):
                            check_in_play_and_hand = True
                            checked = True
                            priorities = [TimingPriority.Constant]
                            catogories = ['Forced']
                        else:
                            if isinstance(message, Message.CheckIfAttackMessageHasKeyword):
                                checked = True
                                priorities = [TimingPriority.Constant]
                                catogories = ['Rule']
                            else:
                                if isinstance(message, Message.WhenRecalculateAttackDamage):
                                    checked = True
                                    priorities = [TimingPriority.Constant, TimingPriority.ForcedInterrupt]
                                    catogories = ['Rule', 'Forced']
                                else:
                                    if isinstance(message, Message.WhenCalculateEffectCost):
                                        checked = True
                                        priorities = [TimingPriority.Rule, TimingPriority.Constant]
                                        catogories = ['Rule']
                                    else:
                                        if isinstance(message, Message.CheckIfAllyCountLimit):
                                            checked = True
                                            priorities = [TimingPriority.Constant]
                                            catogories = ['Rule']
                                        else:
                                            if isinstance(message, Message.CheckIfFaceIsLikeInHand):
                                                checked = True
                                                priorities = [TimingPriority.Constant]
                                                catogories = ['Rule']
                                            else:
                                                if isinstance(message, (Message.CheckIfUnitCanBeAttackBy, Message.CheckIfSchemeCanBeThwartBy, Message.CheckIfEffectIsIgnoreKeyWord)):
                                                    checked = True
                                                    priorities = [TimingPriority.Constant]
                                                    catogories = ['Rule']
                    for priority in priorities:
                        if has_registered_event:
                            for category in catogories:
                                found_global_effects = self.FindEffectsList(category, type(message), priority)
                                def check_is_in_hand(face: CardFace):
                                    if isinstance(message, Message.CheckIfFaceIsLikeInHand):
                                        return face.card.IsInHand()
                                    return face.IsLikeInHand()
                                if found_global_effects:
                                    if check_in_play_and_hand:
                                        found_global_effects = [x for x in found_global_effects if True]
                                    else:
                                        if check_face_up_or_hand:
                                            found_global_effects = [x for x in found_global_effects if True]
                                        else:
                                            if check_only_in_play:
                                                found_global_effects = [x for x in found_global_effects if x.this.IsInPlay(is_same_face=True)]
                        if local_effects:
                            found_local_effects = []
                            for check_effect in local_effects:
                                if (check_effect.ability.priority == priority):
                                    found_local_effects.append(check_effect)
                            if found_local_effects:
                                self.ProcessRuleEffect(message, found_local_effects, priority, undo_handle)
            check_in_play_and_hand = False
            check_face_up_or_hand = True
            check_only_in_play = True
            checked = False
            catogories = ['Rule', 'Forced']
            if has_registered_event:
                if isinstance(message, Message.CheckPlayerCanPayCost):
                    check_in_play_and_hand = True
                    checked = True
                    priorities = [TimingPriority.Constant]
                    catogories = ['Forced']
                else:
                    if isinstance(message, Message.CheckIfAttackMessageHasKeyword):
                        checked = True
                        priorities = [TimingPriority.Constant]
                        catogories = ['Rule']
                    else:
                        if isinstance(message, Message.WhenRecalculateAttackDamage):
                            checked = True
                            priorities = [TimingPriority.Constant, TimingPriority.ForcedInterrupt]
                            catogories = ['Rule', 'Forced']
                        else:
                            if isinstance(message, Message.WhenCalculateEffectCost):
                                checked = True
                                priorities = [TimingPriority.Rule, TimingPriority.Constant]
                                catogories = ['Rule']
                            else:
                                if isinstance(message, Message.CheckIfAllyCountLimit):
                                    checked = True
                                    priorities = [TimingPriority.Constant]
                                    catogories = ['Rule']
                                else:
                                    if isinstance(message, Message.CheckIfFaceIsLikeInHand):
                                        checked = True
                                        priorities = [TimingPriority.Constant]
                                        catogories = ['Rule']
                                    else:
                                        if isinstance(message, (Message.CheckIfUnitCanBeAttackBy, Message.CheckIfSchemeCanBeThwartBy, Message.CheckIfEffectIsIgnoreKeyWord)):
                                            checked = True
                                            priorities = [TimingPriority.Constant]
                                            catogories = ['Rule']
            for priority in priorities:
                if has_registered_event:
                    for category in catogories:
                        found_global_effects = self.FindEffectsList(category, type(message), priority)
                        def check_is_in_hand(face: CardFace):
                            if isinstance(message, Message.CheckIfFaceIsLikeInHand):
                                return face.card.IsInHand()
                            return face.IsLikeInHand()
                        if found_global_effects:
                            if check_in_play_and_hand:
                                found_global_effects = [x for x in found_global_effects if True]
                            else:
                                if check_face_up_or_hand:
                                    found_global_effects = [x for x in found_global_effects if True]
                                else:
                                    if check_only_in_play:
                                        found_global_effects = [x for x in found_global_effects if x.this.IsInPlay(is_same_face=True)]
                if local_effects:
                    found_local_effects = []
                    for check_effect in local_effects:
                        if (check_effect.ability.priority == priority):
                            found_local_effects.append(check_effect)
                    if found_local_effects:
                        self.ProcessRuleEffect(message, found_local_effects, priority, undo_handle)
        if local_effects:
            if has_registered_event:
                self.debug_log_both.AddLog(message.name, f'{has_registered_event} / {len(local_effects)}')
        if local_effects:
            if not (has_registered_event):
                self.debug_log_only_local.AddLog(message.name, {len(local_effects)})
        if not (local_effects):
            if has_registered_event:
                self.debug_log_only_global.AddLog(message.name, {has_registered_event})
        for priority in list(TimingPriority):
            check_effects = {}
            local_effect_priority_forced = []
            local_effect_priority_optional = []
            size = 0
            if has_registered_event:
                for category in EventManager.CATEGORY_LIST:
                    found_effects = self.FindEffectsList(category, type(message), priority)
                    check_effects[category] = found_effects[:]
                    size = (size + len(check_effects[category]))
            if local_effects:
                for check_effect in local_effects:
                    if (check_effect.ability.priority == priority):
                        if not (check_effect.is_forced):
                            if is_playing_res:
                                local_effect_priority_forced.append(check_effect)
                            else:
                                local_effect_priority_optional.append(check_effect)
                        local_effect_priority_forced.append(check_effect)
                    size = (size + len(local_effect_priority_forced))
                    size = (size + len(local_effect_priority_optional))
            if (size == 0):
                pass
            if ('Statistics' in check_effects):
                if check_effects['Statistics']:
                    if self.ProcessRuleEffect(message, check_effects['Statistics'], priority, undo_handle):
                        return
            if ('Rule' in check_effects):
                if check_effects['Rule']:
                    if self.ProcessRuleEffect(message, check_effects['Rule'], priority, undo_handle):
                        return
            if local_effect_priority_forced:
                if is_playing_res:
                    if self.ProcessPayingEffect(message, message.by_effect, priority):
                        return
            if local_effect_priority_forced:
                if is_playing_res:
                    if ('Forced' in check_effects):
                        if check_effects['Forced']:
                            forced_effects = local_effect_priority_forced
                            if ('Forced' in check_effects):
                                forced_effects = (forced_effects + check_effects['Forced'])
                            if local_effect_priority_forced:
                                if self.ProcessForcedEffect(message, local_effect_priority_forced, priority, undo_handle):
                                    return
            if ('Forced' in check_effects):
                if check_effects['Forced']:
                    forced_effects = local_effect_priority_forced
                    if ('Forced' in check_effects):
                        forced_effects = (forced_effects + check_effects['Forced'])
                    if local_effect_priority_forced:
                        if self.ProcessForcedEffect(message, local_effect_priority_forced, priority, undo_handle):
                            return
            if not (local_effect_priority_optional):
                if ('Optional' in check_effects):
                    if check_effects['Optional']:
                        optional_effects = local_effect_priority_optional
                        if ('Optional' in check_effects):
                            optional_effects = (optional_effects + check_effects['Optional'])
                        if optional_effects:
                            if self.ProcessOptionalEffect(message, optional_effects, local_effect_priority_optional, priority):
                                return
            optional_effects = local_effect_priority_optional
            if ('Optional' in check_effects):
                optional_effects = (optional_effects + check_effects['Optional'])
            if optional_effects:
                if self.ProcessOptionalEffect(message, optional_effects, local_effect_priority_optional, priority):
                    return
