# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.message import *
class EventCounter:
    def __init__(self):
        self.event_size = {}
    def Add(self, event):
        if (event not in self.event_size):
            self.event_size[event] = 0
        self.event_size[event] = (self.event_size[event] + 1)
    def GetSize(self, event):
        if (event in self.event_size):
            return self.event_size[event]
        return 0
    def GetAllSize(self):
        size = 0
        for event in self.event_size:
            size = (size + self.event_size[event])
        return size
