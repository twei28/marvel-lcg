# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.scene.replay.operation import OperationDescriptor
from game.scene.replay.operation import CommandDescriptor
Unused(OperationDescriptor, CommandDescriptor)
from game.scene.replay.hero import HeroDescriptor
from game.scene.replay.campaign import CampaignDescriptor
from game.scene.replay.encounter_set import EncounterSetDescriptor
Unused(HeroDescriptor)
Unused(CampaignDescriptor)
Unused(EncounterSetDescriptor)
