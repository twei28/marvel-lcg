# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.scene import *
from game.scene.replay import *
from engine.lib import Json
from engine.lib import Ver
from engine.file import FileManager
CATEGORY_NAME = 'SCENE'
class LoaderHelper:
    @staticmethod
    def CreateScene(seed, campaign, players, rules):
        scene = Scene(version=str(Ver.version), metadata={'seed': seed}, rules=rules, campaign=campaign, players=players, inputs=[])
        scene.UpdateVersion()
        for player in scene.players:
            if not ((player.name != '')):
                raise AssertionError
        return scene
    @staticmethod
    def Loads(file_path):
        scene = Json.LoadAs(file_path, Scene, check_sum='Warn')
        scene.UpdateVersion()
        scene.SetMetadataStr('path', file_path)
        return scene
class SceneLoader:
    @staticmethod
    def NewFromJson(campaign_json, encounter_set_names, hero_jsons, seed, rules, campaign_log):
        players = []
        for hero_text in hero_jsons:
            player = Json.LoadsAs(hero_text, HeroDescriptor)
            player.UpdateVersion()
            players.append(player)
        campaign = Json.LoadsAs(campaign_json, CampaignDescriptor)
        campaign.UpdateVersion()
        if (encounter_set_names != None):
            campaign.encounter_sets = encounter_set_names[:]
        else:
            campaign.encounter_sets = (campaign.encounter_sets + campaign.modular_sets)
        if campaign_log:
            campaign.campaign_log = (campaign.campaign_log | campaign_log)
        scene = LoaderHelper.CreateScene(seed, campaign, players, rules)
        return scene
    @staticmethod
    def NewScene(campaign_name, encounter_set_names, hero_names, seed):
        heroes_text = []
        campaign_text = ''
        if not ((type(campaign_name) is str)):
            raise AssertionError(f'campaign_name={campaign_name!r}')
        for hero_json in hero_names:
            file_path = FileManager.FindJsonPath('Hero', hero_json)
            if not (file_path):
                raise AssertionError(f'file_path={file_path!r}')
            with FileManager.OpenFile(file_path, read=True) as file:
                heroes_text.append(file.Read())
        file_path = FileManager.FindJsonPath('Campaign', campaign_name)
        if not (file_path):
            raise AssertionError(f'file_path={file_path!r}')
        with FileManager.OpenFile(file_path, read=True) as file:
            campaign_text = file.Read()
        scene = SceneLoader.NewFromJson(campaign_text, encounter_set_names, heroes_text, seed, [], {})
        return scene
    @staticmethod
    def Load(replay, nullable = False):
        file_path = FileManager.FindJsonPath('Replay', replay, nullable=nullable)
        if file_path:
            scene = LoaderHelper.Loads(file_path)
            return scene
