# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.scene.scene import Scene
from game.scene.loader import SceneLoader
Unused(Scene)
Unused(SceneLoader)
