# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
@dataclass
class HeroDescriptor:
    __annotations__ = {}
    version: str
    name: str
    hero: List[str]
    hero_deck: List[str]
    obligations: List[str]
    nemesis_set: List[str]
    player_deck = field(default_factory=lambda : [])
    player_deck: List[str]
    def UpdateVersion(self):
        pass
