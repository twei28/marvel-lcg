# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.game_run.game_challenge import GameChallenge
@dataclass
class CampaignDescriptor:
    __annotations__ = {}
    version = field(default='')
    version: str
    name = field(default='')
    name: str
    villain = field(default_factory=lambda : [])
    villain: List[str]
    expert = field(default=False)
    expert: bool
    challenges = field(default_factory=lambda : [])
    challenges: List['GameChallenge.CHALLENGE']
    schemes = field(default_factory=lambda : [])
    schemes: List[str]
    set_aside = field(default_factory=lambda : [])
    set_aside: List[str]
    encounters = field(default_factory=lambda : [])
    encounters: List[str]
    encounter_sets = field(default_factory=lambda : [])
    encounter_sets: List[str]
    modular_sets = field(default_factory=lambda : [])
    modular_sets: List[str]
    campaign_log = field(default_factory=lambda : {})
    campaign_log: Dict[(str, str)]
    def UpdateVersion(self):
        pass
    def SetChallenge(self, *challenges: GameChallenge.CHALLENGE):
        self.challenges = list(sorted(set(challenges)))
