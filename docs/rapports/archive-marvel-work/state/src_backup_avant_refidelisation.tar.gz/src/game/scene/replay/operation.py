# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.effect import *
@dataclass
class CommandDescriptor:
    __annotations__ = {}
    id = field(default='')
    id: str
    targets = field(default_factory=lambda : [])
    targets: List[str]
    resources = field(default_factory=lambda : [])
    resources: List[str]
    def GetDebugCommand(self):
        id = str(self.id)
        if id.startswith('Puzzle.'):
            return self.id
        if id.startswith(':'):
            return self.id[1:]
        return ''
    @staticmethod
    def FindNewEffectId(effect_str, check_effect_list):
        id = CommandDescriptor.FindNewEffectIdInternal(effect_str, check_effect_list)
        if not (id):
            raise AssertionError
        return id[0]
    @staticmethod
    def FindNewEffectIdInternal(effect_str, check_effect_list):
        import re
        found_effects = []
        m = re.match('e(\\d+) (.*) c(\\d+) .*', effect_str)
        if m:
            effect_name = m[2].replace(' ', '_')
            object_id = int(m[3])
        else:
            m = re.match('e(\\d+) c(\\d+) .*', effect_str)
            if not (m):
                raise AssertionError
            effect_name = ''
            object_id = int(m[2])
        for effect in check_effect_list:
            if (effect.this.card.object_id == object_id):
                found_effects.append(effect)
        if (len(found_effects) == 1):
            pass
        else:
            for effect in found_effects[:]:
                if (effect.GetDisplayName(remove_space=True) != effect_name):
                    found_effects.remove(effect)
        return [x.object_id for x in found_effects]
    @staticmethod
    def FromDebugCommand(cmd):
        if cmd.startswith('Puzzle.'):
            pass
        else:
            cmd = f':{cmd}'
        return CommandDescriptor(cmd, [], [])
def CardEffectInt(card_name_id):
    if (card_name_id == ''):
        return 0
    if isinstance(card_name_id, int):
        return card_name_id
    if card_name_id.startswith(':'):
        return 0
    import re
    m = re.match('[ec](\\d+) .+', card_name_id)
    if m:
        return int(m[1])
    m = re.match("{'id': (\\d+),.+", card_name_id)
    if m:
        return int(m[1])
    return int(card_name_id)
@dataclass
class OperationDescriptor:
    __annotations__ = {}
    step = field(default=-1)
    step: int
    event = field(default='')
    event: str
    effect = field(default_factory=lambda : CommandDescriptor())
    effect: CommandDescriptor
    crc = field(default='')
    crc: str
