# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from core.lib import Time
from game.scene.replay import *
from engine.lib import Json
from engine.lib import Ver
from engine.log import Log
from engine.file import FileManager
from engine.config import ConfigVariables
from game import *
CATEGORY_NAME = 'SCENE'
TEST_RULES = ConfigVariables.ListStr('test_rules', [])
METADATA_KEY_LIST = Literal[('step', 'clients')]
METADATA_KEY_BOOL = Literal['is_puzzle']
METADATA_KEY_INT = Literal['seed']
METADATA_KEY_STR = Literal[('time', 'path', 'comment', 'cover', 'report', 'sign')]
METADATA_KEY_FLOAT = Literal['playtime']
METADATA_KEY = ((((METADATA_KEY_LIST | METADATA_KEY_BOOL) | METADATA_KEY_INT) | METADATA_KEY_STR) | METADATA_KEY_FLOAT)
@dataclass
class Scene:
    __annotations__ = {}
    version = field(default='')
    version: str
    metadata = field(default_factory=lambda : {})
    metadata: Dict[(METADATA_KEY, Union[(str, int, bool)])]
    rules = field(default_factory=lambda : [])
    rules: List[str]
    campaign = field(default=CampaignDescriptor())
    campaign: CampaignDescriptor
    players = field(default_factory=lambda : [])
    players: Sequence[HeroDescriptor]
    puzzle = field(default_factory=lambda : [])
    puzzle: List[str]
    inputs = field(default_factory=lambda : [])
    inputs: List[OperationDescriptor]
    def GetSaveFileName(self, use_comment = True):
        return f'[{Ver.version}]-{self.GetName(use_comment)}'
    @property
    def name(self):
        return self.GetName()
    def GetName(self, use_comment = True):
        from engine import Engine
        game = Engine.game
        name = ''
        if self.is_puzzle:
            name = 'puzzle-'
        if use_comment:
            if self.comment:
                name = (name + self.comment)
            else:
                for player in self.players:
                    name = (name + f'{player.name}-')
                name = (name + self.campaign.name)
                if self.campaign.challenges:
                    name = (name + ('-' + '-'.join(self.campaign.challenges)))
                else:
                    if self.campaign.expert:
                        name = (name + '-expert')
                if game.world:
                    if game.world.rule.mode_campaign.val:
                        name = (name + '-campaign')
        else:
            for player in self.players:
                name = (name + f'{player.name}-')
            name = (name + self.campaign.name)
            if self.campaign.challenges:
                name = (name + ('-' + '-'.join(self.campaign.challenges)))
            else:
                if self.campaign.expert:
                    name = (name + '-expert')
            if game.world:
                if game.world.rule.mode_campaign.val:
                    name = (name + '-campaign')
        inputs = game.controller_manager.replay.history_inputs
        name = (name + f'-({len(inputs)})')
        if game.session.world:
            for test_card_id in sorted(game.session.world.cheat.test_cards):
                if (test_card_id not in ('01088', '01089', '01090')):
                    name = (name + f'-{test_card_id}')
        for input in inputs:
            if input.effect.GetDebugCommand():
                name = (name + '-debug')
            else:
                pass
        if (self.seed != 0):
            name = (name + f'-({str(self.seed)})')
        return FileManager.SanitizeFilename(name.lower())
    def UpdateInputs(self, game: 'Game'):
        self.inputs = game.controller_manager.replay.history_inputs
    def PrepareSave(self, game, *, playtime, report = None, clients = None):
        from engine.user.user_info import UserInfo
        self.UpdateInputs(game)
        if (self.sign == ''):
            self.SetMetadataStr('sign', UserInfo.fingerprint)
        if (self.time == ''):
            self.SetMetadataStr('time', Time.Format())
        data = self
        if self.is_puzzle:
            for input in data.inputs:
                delattr(input, 'step')
                delattr(input, 'event')
                delattr(input, 'crc')
        if playtime:
            self.SetMetadataFloat('playtime', playtime)
        for key in ('undo_count', 'goto_count'):
            self.metadata.pop(key, None)
        if report:
            self.SetMetadataStr('report', report)
        if clients:
            self.SetMetadataList('clients', clients)
        ordered_keys = ((['sign'] + [key for key in self.metadata if (key not in ('sign', 'clients', 'report', 'step'))]) + [*('report', 'clients', 'step')])
        sorted_metadata = {key: self.metadata[key] for key in ordered_keys if (key in self.metadata)}
        self.metadata = sorted_metadata
    def Save(self, file_path, game, *, playtime = None):
        if self.is_puzzle:
            return False
        self.PrepareSave(game, playtime=playtime)
        path = FileManager.GetDirName(file_path)
        FileManager.MakeDir(path)
        data = self
        Json.Save(data, file_path, ignore_check_sum=False)
        Log.Info(CATEGORY_NAME, f'Saved: {file_path}')
        return True
    def UpdateVersion(self):
        if ('mode_skirmish' in self.metadata):
            self.rules.append('mode_skirmish')
            self.metadata.pop('mode_skirmish')
        if ('mode_heroic' in self.metadata):
            mode_heroic = self.metadata['mode_heroic']
            self.rules.append(f'mode_heroic_{mode_heroic}')
            self.metadata.pop('mode_heroic')
        if ('rule' in self.metadata):
            rule = self.metadata['rule']
            if (rule == '1.5'):
                self.rules.append('rule_15')
            self.metadata.pop('rule')
        if not (Ver(self.version).IsCreateHeroDeckFirst()):
            self.rules.append('create_player_deck_first')
        if not (Ver(self.version).IsDeadpoolsEncounter()):
            if ('crisis_of_infinite_deadpools' in self.rules):
                self.rules.remove('crisis_of_infinite_deadpools')
            else:
                self.rules.append('no_crisis_of_infinite_deadpools')
                if ('crisis_of_infinite_deadpools' in self.rules):
                    self.rules.remove('crisis_of_infinite_deadpools')
        else:
            if ('crisis_of_infinite_deadpools' in self.rules):
                self.rules.remove('crisis_of_infinite_deadpools')
        if not (Ver(self.version).IsFixSurge()):
            if ('fix_surge' not in self.rules):
                self.rules.append('no_fix_surge')
        if not (Ver(self.version).IsFixTreachery()):
            if ('fix_treachery' not in self.rules):
                self.rules.append('no_fix_treachery')
        if ('encounter_cards_ignore_crisis' in self.rules):
            self.rules.remove('encounter_cards_ignore_crisis')
        del self.campaign.modular_sets
        self.rules = list(sorted(set(self.rules)))
    def HackTestRule(self):
        pass
    def SetMetadataList(self, key, value):
        str_list = Types.ListToStrList(value)
        self.metadata[key] = str_list
    def SetMetadataBool(self, key, value):
        self.metadata[key] = value
    def SetMetadataInt(self, key, value):
        self.metadata[key] = value
    def SetMetadataStr(self, key, value):
        self.metadata[key] = value
    def SetMetadataFloat(self, key, value):
        self.metadata[key] = {'.1f':value}
    def SetSeed(self, value):
        self.SetMetadataInt('seed', value)
    def GetMetadataList(self, key):
        str_list = str(self.metadata.get(key, ''))
        return Types.StrListToList(str_list)
    def GetMetadataBool(self, key):
        return bool(self.metadata.get(key, False))
    def GetMetadataInt(self, key):
        return int(self.metadata.get(key, 0))
    def GetMetadataStr(self, key):
        return str(self.metadata.get(key, ''))
    def GetMetadataFloat(self, key):
        return float(self.metadata.get(key, 0))
    @property
    def time(self):
        return self.GetMetadataStr('time')
    @property
    def path(self):
        return self.GetMetadataStr('path')
    @property
    def seed(self):
        return self.GetMetadataInt('seed')
    @property
    def comment(self):
        return self.GetMetadataStr('comment')
    @property
    def is_puzzle(self):
        return self.GetMetadataBool('is_puzzle')
    @property
    def cover(self):
        return self.GetMetadataStr('cover')
    @property
    def playtime(self):
        return self.GetMetadataFloat('playtime')
    @property
    def step(self):
        return self.GetMetadataList('step')
    @property
    def sign(self):
        return self.GetMetadataStr('sign')
