# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
@dataclass
class EncounterSetDescriptor:
    __annotations__ = {}
    version: str
    name: str
    encounters: List[str]
