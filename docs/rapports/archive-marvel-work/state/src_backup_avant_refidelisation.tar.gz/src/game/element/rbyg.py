# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
class ResRBYG:
    __annotations__ = {}
    RBYG = Literal[('R', 'B', 'Y', 'G')]
    RBYG: TypeAlias
    RBY = Literal[('R', 'B', 'Y')]
    RBY: TypeAlias
    def __init__(self, r, b, y, g):
        from game.element.resources import Resources
        self.r = r
        self.b = b
        self.y = y
        self.g = g
        self.total = (((r + b) + y) + g)
        self.types = sum((1 for color in (self.r, self.b, self.y, self.g) if (color > 0)))
        self.color_text = ''
        self.color_text = (self.color_text + (Resources.RES_TEXT['r'] * self.r))
        self.color_text = (self.color_text + (Resources.RES_TEXT['b'] * self.b))
        self.color_text = (self.color_text + (Resources.RES_TEXT['y'] * self.y))
        self.color_text = (self.color_text + (Resources.RES_TEXT['g'] * self.g))
    def __mul__(self, val):
        return ResRBYG((self.r * val), (self.b * val), (self.y * val), (self.g * val))
    def __add__(self, other: 'ResRBYG|int') -> 'ResRBYG':
        if isinstance(other, int):
            return ResRBYG(self.r, self.b, self.y, self.g)
        return ResRBYG((self.r + other.r), (self.b + other.b), (self.y + other.y), (self.g + other.g))
    def __sub__(self, other: 'ResRBYG|int') -> 'ResRBYG':
        if isinstance(other, int):
            return (self + (-1 * other))
        return ResRBYG((self.r - other.r), (self.b - other.b), (self.y - other.y), (self.g - other.g))
    @staticmethod
    def FromText(rbyg):
        rbyg = rbyg.lower()
        r = (rbyg.count('r'), rbyg.count('b'), rbyg.count('y'), rbyg.count('g'))[0]
        b = (rbyg.count('r'), rbyg.count('b'), rbyg.count('y'), rbyg.count('g'))[1]
        y = (rbyg.count('r'), rbyg.count('b'), rbyg.count('y'), rbyg.count('g'))[2]
        g = (rbyg.count('r'), rbyg.count('b'), rbyg.count('y'), rbyg.count('g'))[3]
        return ResRBYG(r, b, y, g)
    def OnlyHasColor(self, text):
        if (self.total == 0):
            return False
        if (text == 'R'):
            return ((self.r + self.g) == self.total)
        if (text == 'B'):
            return ((self.b + self.g) == self.total)
        if (text == 'Y'):
            return ((self.y + self.g) == self.total)
    def GetColor(self, text, *, convert_green_res = True):
        if ('G' in text):
            if not ((convert_green_res == False)):
                raise AssertionError(f'text={text!r}')
        if convert_green_res:
            g = self.g
        else:
            g = 0
        if (text == 'R'):
            return (self.r + g)
        if (text == 'B'):
            return (self.b + g)
        if (text == 'Y'):
            return (self.y + g)
        if (text == 'G'):
            return self.g
    def GetTypeKindsInternal(self, green_is_a_type):
        types = 0
        if (self.r > 0):
            types = (types + 1)
        if (self.b > 0):
            types = (types + 1)
        if (self.y > 0):
            types = (types + 1)
        if green_is_a_type:
            types = (types + self.g)
            types = min(4, types)
        return types
    def IsSameType(self):
        if (self.r == 0):
            pass
        return (((self.r == 0) and (self.y == 0)) or ((self.b == 0) and (self.y == 0)))
    def IsDifferentType(self):
        types = self.GetTypeKindsInternal(False)
        if self.g:
            types = (types + self.g)
            types = min(3, types)
        return types
    def CanPayThisCost(self, cost):
        if (self.total == 0):
            return False
        if (cost.rbyg.total == 0):
            return True
        if (cost.r > 0):
            pass
        return (((cost.b > 0) and (self.b > 0)) or (((cost.y > 0) and (self.y > 0)) or ((self.g > 0) or (cost.a > 0))))
class ResRBYGA:
    def __init__(self, a, rbyg):
        self.rbyg = rbyg
        self.a = a
        self.true_val = (self.a + self.rbyg.total)
        self.total = max(0, self.true_val)
        self.color_text = self.rbyg.color_text
        if (self.a > 0):
            self.color_text = (self.color_text + str(self.a))
        if (self.color_text == ''):
            self.color_text = '0'
            return
    @property
    def r(self):
        return self.rbyg.r
    @property
    def b(self):
        return self.rbyg.b
    @property
    def y(self):
        return self.rbyg.y
    @property
    def g(self):
        return self.rbyg.g
    def __mul__(self, val):
        return ResRBYGA((self.a * val), self.rbyg)
    def __add__(self, other: 'ResRBYGA|int') -> 'ResRBYGA':
        if isinstance(other, int):
            return ResRBYGA((self.a + other), self.rbyg)
        return ResRBYGA((self.a + other.a), (self.rbyg + other.rbyg))
    def __sub__(self, val):
        return (self + (-1 * val))
    @staticmethod
    def FromText(rbyga):
        rbyga = rbyga.lower()
        rbyga = rbyga.lstrip('RBY')
        if rbyga.isdigit():
            a = int(rbyga)
        else:
            a = 0
        return ResRBYGA(a, ResRBYG.FromText(rbyga))
