# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.render.symbol import Symbol
from game.element.rbyg import ResRBYGA
class CostRule:
    def __init__(self, *, up_to = None, same_type = None, different_type = None, from_hand = None, requirement = None, or_res = None):
        self.up_to = up_to
        self.same_type = same_type
        self.different_type = different_type
        self.from_hand = from_hand
        self.requirement = requirement
        self.or_res = or_res
        self.rule_texts = [rule for rule, condition in {'UpTo': self.up_to, 'FromHand': self.from_hand, 'SameType': self.same_type, 'DifferentType': self.different_type}.items() if condition]
class Cost:
    @staticmethod
    def FromText(text, up_to = None):
        return Cost(Cast(Any, text), up_to=up_to)
    def __init__(self, rbyga, *, rule = None, up_to = None, same_type = None, different_type = None, from_hand = None, or_cost = None):
        if isinstance(rbyga, ResRBYGA):
            self.rbyga = rbyga
        else:
            self.rbyga = ResRBYGA.FromText(rbyga)
        if rule:
            self.rule = rule
        else:
            self.rule = CostRule(up_to=up_to, same_type=same_type, different_type=different_type, from_hand=from_hand, or_res=or_cost)
        self.text_legacy = Symbol.Clean(self.color_text)
    @property
    def color_text(self):
        return self.rbyga.color_text
    @property
    def val(self):
        return self.rbyga.total
    @property
    def true_val(self):
        return self.rbyga.true_val
    def __mul__(self, val):
        return Cost((self.rbyga * val), rule=self.rule)
    def __add__(self, other: 'Cost|int') -> 'Cost':
        if isinstance(other, int):
            return Cost((self.rbyga + other), rule=self.rule)
        return Cost((self.rbyga + other.rbyga), rule=self.rule)
    def __sub__(self, val):
        return (self + (-1 * val))
    def GetRuleText(self):
        return self.rule.rule_texts
    def GetTypeKinds(self):
        return self.rbyga.rbyg.types
    @property
    def r(self):
        return self.rbyga.r
    @property
    def b(self):
        return self.rbyga.b
    @property
    def y(self):
        return self.rbyga.y
    @property
    def g(self):
        return self.rbyga.g
    def GetSpendText(self):
        texts = []
        has_color = False
        if self.rule.up_to:
            texts.append('up to')
        if (((self.y + self.b) + self.r) + self.g):
            has_color = True
            texts.append(f"{('[[energy]]' * self.y)}{('[[mental]]' * self.b)}{('[[physical]]' * self.r)}{('[[wild]]' * self.g)}")
        else:
            if self.val:
                if (self.val > 0):
                    texts.append(f'{self.val} resources')
                else:
                    texts.append(f'{self.val} resource')
        if not (has_color):
            if self.rule.same_type:
                texts.append('of the same type')
            if self.rule.different_type:
                texts.append('of different types')
            else:
                texts.append('of any type')
        if self.rule.from_hand:
            texts.append('from hand')
        return ' '.join(texts)
