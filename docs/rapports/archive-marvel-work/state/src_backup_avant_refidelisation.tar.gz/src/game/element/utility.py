# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face.card_face import CardFace
from game.card.face.base import ClassCard
CARD_CLASS_LIST = Types.LiteralToList(ClassCard.CARD_CLASS)
CARD_CLASS_LIST: List[ClassCard.CARD_CLASS]
ASPECT_CLASS_LIST = Types.LiteralToList(ClassCard.ASPECT_CLASS_TYPE)
ASPECT_CLASS_LIST: List[ClassCard.ASPECT_CLASS_TYPE]
def IsTrait(a):
    return (a in CardFace.TRAITS_LIST)
def IsCounter(a):
    return (a in CardFace.COUNTER_LIST)
def IsCardClass(a):
    return (a in CARD_CLASS_LIST)
def IsAspectClass(a):
    return (a in ASPECT_CLASS_LIST)
