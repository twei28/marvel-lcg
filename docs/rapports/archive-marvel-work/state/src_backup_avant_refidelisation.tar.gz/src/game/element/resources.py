# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.render.symbol import Symbol
from game.element.cost import Cost
from game.element.rbyg import ResRBYG
from game.player import *
class Resources:
    __annotations__ = {}
    RBYG = ResRBYG.RBYG
    RBYG: Final
    RBY = ResRBYG.RBY
    RBY: Final
    RES_TEXT = {'r': Symbol.r_r_physical, 'g': Symbol.r_g_wild, 'b': Symbol.r_b_mental, 'y': Symbol.r_y_energy}
    RES_TEXT: Final
    RBYG_LIST = [*('R', 'B', 'Y', 'G')]
    RBYG_LIST: List[ResRBYG.RBYG]
    def __init__(self, rbyg, *, reduce = None):
        if isinstance(rbyg, ResRBYG):
            self.rbyg = rbyg
        else:
            self.rbyg = ResRBYG.FromText(rbyg)
        if isinstance(rbyg, str):
            text = rbyg.lower()
            if text:
                if (text[0] == '-'):
                    if text[1:].isdigit():
                        if not ((reduce == None)):
                            raise AssertionError
                        reduce = int(text[1:])
        if (reduce != None):
            if not ((reduce >= 0)):
                raise AssertionError
        self.reduce = (reduce if (reduce != None) else 0)
        self.text_legacy = Symbol.Clean(self.color_text)
    def __repr__(self):
        return self.color_text
    @property
    def text(self):
        return self.text_legacy
    @property
    def color_text(self):
        if self.reduce:
            return str((-1 * self.reduce))
        return self.rbyg.color_text
    @property
    def val(self):
        return self.rbyg.total
    def __mul__(self, val):
        return Resources((self.rbyg * val), reduce=(self.reduce * val))
    def __add__(self, other: 'Resources') -> 'Resources':
        return Resources((self.rbyg + other.rbyg), reduce=(self.reduce + other.reduce))
    def __sub__(self, other: 'Resources') -> 'Resources':
        return Resources((self.rbyg - other.rbyg), reduce=(self.reduce - other.reduce))
    @staticmethod
    def FromText(text):
        return Resources(Cast(Any, text))
    def IsMatchCost(self, cost):
        if cost.rule.or_res:
            if self.IsMatchCost(cost.rule.or_res):
                return True
        if (self.reduce != 0):
            cost = (cost - self.reduce)
        if cost.rule.up_to:
            if not ((cost.GetTypeKinds() <= 1)):
                raise AssertionError
            return (self.val <= cost.val)
        if (self.val >= cost.val):
            green = (self.rbyg.g - cost.rbyga.g)
            def check_value(value):
                if (value < 0):
                    green = (green + value)
                    return
            check_value((self.rbyg.r - cost.rbyga.r))
            check_value((self.rbyg.b - cost.rbyga.b))
            check_value((self.rbyg.y - cost.rbyga.y))
            if (green < 0):
                return False
            if cost.rule.same_type:
                return self.rbyg.IsSameType()
            if cost.rule.different_type:
                return (self.rbyg.IsDifferentType() >= cost.val)
            return True
        return False
    def OnlyHasColor(self, text):
        return self.rbyg.OnlyHasColor(text)
    def HasOneOfColor(self, texts, *, convert_green_res = True):
        for text in texts:
            if (self.GetColor(text, convert_green_res=convert_green_res) > 0):
                return True
        return False
    def HasColorPrinted(self, text):
        return (self.GetColor(text, convert_green_res=False) > 0)
    def HasColor(self, text, *, convert_green_res = True):
        if ('G' == text):
            convert_green_res = False
        return (self.GetColor(text, convert_green_res=convert_green_res) > 0)
    def GetColor(self, text, *, convert_green_res = True):
        return self.rbyg.GetColor(text, convert_green_res=convert_green_res)
    def CanPayThisCost(self, cost):
        if cost.rule.or_res:
            return True
        if (self.reduce > 0):
            return True
        if (self.val == 0):
            return False
        return self.rbyg.CanPayThisCost(cost.rbyga)
    def GetResourceIconTypes(self):
        return self.rbyg.GetTypeKindsInternal(True)
    def Copy(self) -> 'Resources':
        from copy import copy
        return copy(self)
    @property
    def r(self):
        return self.rbyg.r
    @property
    def b(self):
        return self.rbyg.b
    @property
    def y(self):
        return self.rbyg.y
    @property
    def g(self):
        return self.rbyg.g
