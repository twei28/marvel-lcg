# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
@dataclass
class DamageProperty:
    __annotations__ = {}
    damage = field(default=0)
    damage: int
    ignore_tough = field(default=False)
    ignore_tough: bool
    is_from_overkill = field(default=False)
    is_from_overkill: bool
    is_indirect_damage = field(default=False)
    is_indirect_damage: bool
    def Copy(self) -> 'DamageProperty':
        return DamageProperty(damage=self.damage, ignore_tough=self.ignore_tough, is_from_overkill=self.is_from_overkill, is_indirect_damage=self.is_indirect_damage)
