# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.game_run.game_challenge import GameChallenge
@dataclass
class NewGameDescriptor:
    __annotations__ = {}
    campaign_json: str
    encounter_set_names: List[str]
    hero_json: List[str]
    seed: int
    timeout: float
    challenges: List['GameChallenge.CHALLENGE']
    rules: List[str]
    campaign_log: Dict[(str, str)]
