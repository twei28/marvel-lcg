# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import TypeAlias
from core import *
from engine.log import Log
from engine.task.condition import Condition
from game.scene import *
from engine.controller import *
CATEGORY_NAME = 'GAME_STATE'
class StartState:
    def __init__(self):
        self.state = ''
    def Set(self, state: 'GameState.START_STATE'):
        self.state = state
    def Reset(self):
        self.state = ''
    @property
    def is_undo(self):
        return (self.state == 'Undo')
    @property
    def is_new(self):
        return (self.state == 'New')
    @property
    def is_load(self):
        return (self.state == 'Load')
    @property
    def is_replay(self):
        return (self.state == 'Replay')
    @property
    def is_in_testing(self):
        return (self.state == 'InTesting')
    @property
    def is_reset(self):
        return (self.state == '')
class ExitState:
    def __init__(self):
        self.state = ''
    def Set(self, state: 'GameState.EXIT_STATE'):
        self.state = state
    def Reset(self):
        self.state = ''
    @property
    def is_normal_exit(self):
        return (self.state == '')
    @property
    def is_undo_exit(self):
        return (self.state == 'Undo')
class RunningState:
    def __init__(self):
        self.is_running = False
    def Set(self, running):
        self.is_running = running
class GameState:
    __annotations__ = {}
    START_STATE = Literal[('', 'New', 'Undo', 'Load', 'Replay', 'InTesting')]
    START_STATE: TypeAlias
    EXIT_STATE = Literal[('', 'Exit', 'Undo')]
    EXIT_STATE: TypeAlias
    StartState = StartState
    def __init__(self):
        self.start_state = StartState()
        self.exit_state = ExitState()
        self.running_state = RunningState()
        self.condition = Condition('State')
    def SetStartState(self, start_state: 'GameState.START_STATE'):
        self.start_state.Set(start_state)
        Log.DebugSilent(CATEGORY_NAME, f'start_state={start_state!r}')
        self.SetRunningState(False)
        if (start_state != ''):
            self.condition.NotifyAll()
            return
    def ResetStartState(self):
        self.start_state.Reset()
    def WaitUntilGameStart(self):
        def check():
            if self.IsRunningNewGame():
                return True
            return False
        self.condition.Wait(check)
    def IsRunningNewGame(self):
        return (not self.start_state.is_reset)
    def SetRunningState(self, running):
        self.running_state.Set(running)
        Log.DebugSilent('NEW', f'self.is_running={self.is_running!r}')
    def SetExitStatus(self, status: 'GameState.EXIT_STATE'):
        self.exit_state.Set(status)
    @property
    def is_running(self):
        return self.running_state.is_running
