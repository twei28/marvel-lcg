# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.card import *
from game.effect.rule import DebugRule
from game.world import *
from game.card.face.card_type import Identity
from game.card.face.base import Unit2
from game.card.face.base import Scheme2
from game.operate.worlds import Worlds
CATEGORY_NAME = 'PUZZLE'
class RunPuzzle:
    def __init__(self, world: World):
        self.world = world
        self.debug_rule = DebugRule(world.object_manager.card_dict[0].face)
    CardName = ((str | Card) | CardFace)
    def FindOrCreateFace(self, card):
        if isinstance(card, CardFace):
            return card.card.face
        if isinstance(card, Card):
            return card.face
        if (type(card) is int):
            return self.world.object_manager.card_dict[card].face
        if (type(card) is str):
            found_card = None
            player = self.world.GetCurrentPlayer()
            if not (found_card):
                found_card = player.player_deck.FindCard(name=card)
            if not (found_card):
                found_card = player.discard_pile.FindCard(name=card)
            if found_card:
                return found_card
            for face in (Worlds.GetEncounterDeckCards(self.world) + Worlds.GetEncounterDiscardPileCards(self.world)):
                if face.IsName(card):
                    face
                    return
            if found_card:
                return found_card
        else:
            raise AssertionError(f'card={card!r}')
        return self.CreateCard(card)
    def CreateCard(self, card_name):
        from game.card.factory import CardFactory
        from game.card.face.base import ClassCard
        card = CardFactory.GenerateCard(card_name, self.world.aside_deck, self.world)
        if ClassCard.IsType(card.face):
            player = self.world.GetCurrentPlayer()
            card.SetOwner(player)
        return card.face
    def FindCommandCards(self, *cards):
        faces = [self.FindOrCreateFace(x) for x in cards]
        return faces
    def CreateEncounterDiscardPile(self, *cards):
        from game.card.factory import CardFactory
        villain = Worlds.GetAllVillains(self.world)[0]
        for card in cards:
            CardFactory.GenerateCard(card, villain.encounter_discard_pile, self.world)
    def CreateEncounterDeck(self, *cards):
        from game.card.factory import CardFactory
        villain = Worlds.GetAllVillains(self.world)[0]
        for card in cards:
            CardFactory.GenerateCard(card, villain.encounter_deck, self.world)
    def CreateHandCards(self, *cards):
        from game.card.factory import CardFactory
        first_player = self.world.GetFirstPlayer()
        for card in cards:
            CardFactory.GenerateCard(card, first_player.hand_cards, self.world)
    def CreatePlayerDiscardPile(self, *cards):
        from game.card.factory import CardFactory
        first_player = self.world.GetFirstPlayer()
        for card in cards:
            CardFactory.GenerateCard(card, first_player.discard_pile, self.world)
    def CreatePlayerDeck(self, *cards):
        from game.card.factory import CardFactory
        first_player = self.world.GetFirstPlayer()
        for card in cards:
            CardFactory.GenerateCard(card, first_player.player_deck, self.world)
    def CreatePlayerAdditionalDeck(self, *cards):
        from game.card.factory import CardFactory
        first_player = self.world.GetFirstPlayer()
        for card in cards:
            CardFactory.GenerateCard(card, first_player.additional_discard_pile, self.world)
    def Gain(self, *cards, call_back = None):
        player = self.world.GetCurrentPlayer()
        for face in self.FindCommandCards(*cards):
            player.GainCard(face, self.debug_rule)
            if call_back:
                call_back(face)
    def Draw(self, num):
        player = self.world.GetCurrentPlayer()
        effect = DebugRule(player.GetIdentity())
        player.DrawUp(num, effect)
    def Ready(self, *cards):
        from game.operate.faces import Faces
        faces = self.FindCommandCards(*cards)
        Faces.ReadyAll(faces, DebugRule(faces[0]))
    def Exhaust(self, *cards):
        from game.operate.faces import Faces
        faces = self.FindCommandCards(*cards)
        Faces.ExhaustAll(faces, DebugRule(faces[0]))
    def Discard(self, *cards):
        from game.operate.faces import Faces
        faces = self.FindCommandCards(*cards)
        Faces.DiscardAll(faces, DebugRule(faces[0]))
    def Remove(self, *cards):
        from game.operate.faces import Faces
        faces = self.FindCommandCards(*cards)
        Faces.RemoveAllFromGame(faces, DebugRule(faces[0]))
    def Flip(self, *cards):
        from game.operate.faces import Faces
        faces = self.FindCommandCards(*cards)
        Faces.FlipAllTo(faces, None, DebugRule(faces[0]))
    def Heal(self, card, val):
        face = self.FindOrCreateFace(card)
        from game.card.face.attribute.can_health import CanHealth
        if CanHealth.IsType(face):
            face.HealHealth(val, self.debug_rule)
            return
    def Damage(self, card, val, source = None):
        face = self.FindOrCreateFace(card)
        from game.card.face.attribute.can_health import CanHealth
        if CanHealth.IsType(face):
            if (source == None):
                source = face
            face.TakeDamage(source, val, self.debug_rule)
            return
    def Confuse(self, card):
        from game.operate.faces import Faces
        unit = self.FindOrCreateFace(card).CastTo(Unit2)
        if unit.IsConfused():
            unit.DiscardConfused(DebugRule(unit), rule=1)
            return
        Faces.GiveStatus([unit], 'Confused', DebugRule(unit))
    def Stun(self, card):
        from game.operate.faces import Faces
        unit = self.FindOrCreateFace(card).CastTo(Unit2)
        if unit.IsStunned():
            unit.DiscardStunned(DebugRule(unit), rule=1)
            return
        Faces.GiveStatus([unit], 'Stunned', DebugRule(unit))
    def Tough(self, card):
        from game.operate.faces import Faces
        unit = self.FindOrCreateFace(card).CastTo(Unit2)
        if unit.IsTough():
            unit.DiscardTough(DebugRule(unit), rule=1)
            return
        Faces.GiveStatus([unit], 'Tough', DebugRule(unit))
    def ChangeForm(self, card, rule = ''):
        face = self.FindOrCreateFace(card)
        if Identity.IsType(face):
            if not ((rule == 'Identity')):
                if (rule == ''):
                    face.ChangeToOtherIdentityForm(self.debug_rule)
            face.ChangeToOtherIdentityForm(self.debug_rule)
            if (rule == 'Hero'):
                face.ChangeToOtherHeroForm(self.debug_rule)
                return
                return
    def PlaceThreat(self, card, val):
        face = self.FindOrCreateFace(card).CastTo(Scheme2)
        if (val > 0):
            face.PlaceThreatInternal(val, self.debug_rule)
            return
        if (val < 0):
            val = (-1 * val)
            face.RemoveThreatFromSchemes([face], val, self.debug_rule)
            return
    def SetThreat(self, card, val):
        face = self.FindOrCreateFace(card).CastTo(Scheme2)
        self.PlaceThreat(face, (val - face.threat))
    def Counter(self, card, name, size = 3):
        from game.card.face.attribute.can_place_counter import CanPlaceCounter
        from game.operate.faces import Faces
        face = self.FindOrCreateFace(card)
        if isinstance(face, CanPlaceCounter):
            if (size > 0):
                Faces.PlaceCountersOn([face], size, name, self.debug_rule)
                return
            Faces.RemoveCountersOn([face], (-1 * size), name, self.debug_rule)
            return
    def Token(self, card, name, size = 3):
        from game.card.face.attribute.can_place_token import CanPlaceToken
        from game.operate.faces import Faces
        face = self.FindOrCreateFace(card)
        if isinstance(face, CanPlaceToken):
            if (size > 0):
                Faces.PlaceTokensOn([face], size, name, self.debug_rule)
                return
            Faces.RemoveTokensOn([face], size, name, self.debug_rule)
            return
    def Reveal(self, card, *, call_back = None):
        face = self.FindOrCreateFace(card)
        player = self.world.GetCurrentPlayer()
        face.Reveal(player, self.debug_rule)
        if call_back:
            call_back(face)
        return face
    def PutIntoPlay(self, card):
        face = self.FindOrCreateFace(card)
        player = self.world.GetCurrentPlayer()
        face.PutIntoPlay(player, self.debug_rule)
        return face
    def Boost(self, card):
        from game.operate.worlds import Worlds
        face = self.FindOrCreateFace(card)
        card = face.card
        player = self.world.GetCurrentPlayer()
        villain = Worlds.FindVillainByGameArea(player.GetIdentity().card.game_area)
        if villain:
            card.MoveToArea(villain.encounter_deck, self.debug_rule)
            card.MoveToTop(card.area, self.debug_rule)
            villain.DoActivate(player, self.debug_rule)
        return face
    def Deal(self, card):
        face = self.FindOrCreateFace(card)
        card = face.card
        player = self.world.GetCurrentPlayer()
        effect = DebugRule(player.GetIdentity())
        player.DealEncounterCard(face, effect)
        return face
    def PutIntoDeck(self, *cards):
        from game.operate.worlds import Worlds
        from game.operate.faces import Faces
        for face in self.FindCommandCards(*cards):
            player = self.world.GetCurrentPlayer()
            if face.IsInDeck():
                if not (face.card.area.flags.is_discards):
                    Faces.MoveAllToDeck([face], face.card.area, 'Top', self.debug_rule)
            if (face.GetOwner() == player):
                Faces.MoveAllTo([face], player.player_deck, self.debug_rule)
            villain = Worlds.FindVillainByGameArea(player.GetIdentity().card.game_area)
            if villain:
                Faces.MoveAllTo([face], villain.encounter_deck, self.debug_rule)
    def End(self, message = ''):
        from engine import Engine
        game = Engine.game
        from engine.log import Notify
        controller_manager = game.controller_manager
        controller_manager.skip.SetIsSkipping(False)
        if message:
            Notify.Game(message)
            return
class PuzzleHelper:
    @staticmethod
    def Exec(commands, world):
        import ast
        Puzzle = RunPuzzle(world)
        Unused(Puzzle)
        class PuzzleCallVisitor(ast.NodeVisitor):
            def visit_Call(self, node):
                if isinstance(node.func, ast.Attribute):
                    if isinstance(node.func.value, ast.Name):
                        if (node.func.value.id != 'Puzzle'):
                            raise ValueError(f"Function call to '{node.func.attr}' is not allowed. Only calls to 'Puzzle' methods are permitted.")
                    else:
                        raise ValueError('Function call to a non-attribute is not allowed.')
                else:
                    raise ValueError('Function call to a non-attribute is not allowed.')
                self.generic_visit(node)
        for command in commands:
            parsed_code = ast.parse(command)
            visitor = PuzzleCallVisitor()
            visitor.visit(parsed_code)
            for c in world.object_manager.card_dict:
                exec(f'c{c} = world.object_manager.card_dict[{c}].face')
            exec(command)
