# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.puzzle.puzzle import RunPuzzle
from game.puzzle.puzzle import PuzzleHelper
Unused(RunPuzzle, PuzzleHelper)
