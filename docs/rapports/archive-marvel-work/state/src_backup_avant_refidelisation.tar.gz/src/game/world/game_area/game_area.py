# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.object import Object
from game.card import *
from game.player import *
from game.world import *
class GameArea(Object):
    def __init__(self, world: 'World'):
        super().__init__('game_area', world)
    def AddPlayer(self, player: 'Player'):
        from game.message import Message
        from game.operate.worlds import Worlds
        game_area = player.GetIdentity().card.game_area
        for face in Worlds.GetSideSchemes(game_area):
            self.AddCard(face.card)
        for face in player.GetControlCharacters():
            self.AddCard(face.card)
        for face in player.supports.Get():
            self.AddCard(face.card)
        for face in player.obligations_area.Get():
            self.AddCard(face.card)
        for face in player.GetEngagedMinions():
            self.AddCard(face.card)
        for face in player.player_deck.Get():
            self.AddCard(face.card)
        for face in player.discard_pile.Get():
            self.AddCard(face.card)
        for face in player.hand_cards.Get():
            self.AddCard(face.card)
        for face in player.dealt_encounter_cards.Get():
            self.AddCard(face.card)
        for face in player.additional_deck.Get():
            self.AddCard(face.card)
        for face in player.additional_discard_pile.Get():
            self.AddCard(face.card)
        message = Message.GameAreaAddPlayer(player)
        message.Send()
    def AddCard(self, card: 'Card'):
        if not ((card.game_area != self)):
            raise AssertionError
        if card.IsOnField():
            card.face.OnLeaveGameArea(card.game_area)
        card.game_area = self
        status = card.components.status
        for face in ((card.face.GetInventoryDeck().Get() + card.face.GetPlacedCardArea().Get()) + status.GetDeck().Get(True)):
            self.AddCard(face.card)
        if card.IsOnField():
            card.face.OnEnterGameArea(self)
            return
    def FindAllPlayers(self):
        players = []
        for player in self.world.const_players:
            if (player.GetGameArea() == self):
                players.append(player)
        return players
    def __repr__(self):
        return str(self.object_id)
