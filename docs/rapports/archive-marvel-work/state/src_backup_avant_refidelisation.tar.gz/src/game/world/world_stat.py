# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.card import *
from game.ability import *
from game.player import *
from game.message import *
class WorldStat:
    def __init__(self):
        self.once_per_round_effects = []
        self.once_per_round_player_effects = {}
        self.once_per_phase_player_effects = {}
        self.once_per_phase_effects = []
        self.this_turn_made_attack = []
        self.this_turn_made_thwart = []
    def OnTurnBegin(self):
        self.this_turn_made_attack = []
        self.this_turn_made_thwart = []
    def OnTurnEnd(self):
        self.this_turn_made_attack = []
        self.this_turn_made_thwart = []
    def OnRoundEnd(self):
        self.once_per_round_effects = []
        self.once_per_round_player_effects = {}
    def OnPhaseEnd(self):
        self.once_per_phase_effects = []
        self.once_per_phase_player_effects = {}
    def RecordEffectWithPlayer(self, effect: Effect, player: Player):
        if (player not in self.once_per_round_player_effects):
            self.once_per_round_player_effects[player] = [effect]
        else:
            self.once_per_round_player_effects[player].append(effect)
        if (player not in self.once_per_phase_player_effects):
            self.once_per_phase_player_effects[player] = [effect]
            return
        self.once_per_phase_player_effects[player].append(effect)
    def RecordEffect(self, effect: Effect):
        self.once_per_round_effects.append(effect)
        self.once_per_phase_effects.append(effect)
    def RecordAttack(self, end_message: Message.AfterUnitAttackEnd):
        self.this_turn_made_attack.append((end_message.attacker, end_message.by_effect, end_message.attacked_targets))
    def RecordThwart(self, end_message: Message.AfterUnitThwartEnd):
        self.this_turn_made_thwart.append((end_message.trigger, end_message.by_effect, end_message.schemes))
    def RecordPlayedCard(self, player: Player, face: CardFace):
        pass
    def IsOncePerRound(self, ability):
        return (ability not in [x.ability for x in self.once_per_round_effects])
    def IsOncePerRoundPerPlayer(self, ability, player):
        if (player not in self.once_per_round_player_effects):
            return True
        return (ability not in [x.ability for x in self.once_per_round_player_effects[player]])
    def IsOncePerPhasePerPlayer(self, ability, player):
        if (player not in self.once_per_phase_player_effects):
            return True
        return (ability not in [x.ability for x in self.once_per_phase_player_effects[player]])
    def IsOncePerPhase(self, ability):
        return (ability not in [x.ability for x in self.once_per_phase_effects])
