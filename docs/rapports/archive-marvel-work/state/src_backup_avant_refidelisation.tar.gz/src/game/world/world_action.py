# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
from game.effect import *
from game.player import *
from game.world import *
from game.world.game_area import *
class WorldAction:
    from game.card.face.card_type import Ally
    from game.card.face.card_type import Minion
    from game.card.face.base import Villain
    Character = ((((AlterEgo | Hero) | Ally) | Villain) | Minion)
    def GetWorld(self) -> 'World':
        from game.world import World
        return Cast(World, self)
    @property
    def const_players(self):
        world = self.GetWorld()
        return world.players[:]
    def GetFirstPlayer(self) -> Player:
        world = self.GetWorld()
        for player in world.players:
            if not (player.is_eliminated):
                player
                return
        raise AssertionError
    def GetCurrentPlayer(self) -> Player:
        world = self.GetWorld()
        if world.asking_player:
            return world.asking_player[-1]
        if world.is_game_started:
            if world.phase.HasCurrentPlayerPhase():
                current_player = world.current_player
                if not (current_player):
                    raise AssertionError(f'self={self!r}')
                return current_player
        if not (world.is_game_over):
            return self.GetFirstPlayer()
        return world.const_seat_order_players[0]
    def GetTurnPlayer(self) -> Player|None:
        from game.world.world import Phase
        world = self.GetWorld()
        if world.is_game_started:
            if (world.phase.state == Phase.State.PlayerTurn):
                return world.current_player
    def GetPlayerNum(self, game_area = None):
        from game.operate.worlds import Worlds
        world = self.GetWorld()
        if game_area:
            return len(Worlds.GetPlayers(game_area))
        return len(world.players)
    def GetPlayerNumIcon(self):
        world = self.GetWorld()
        return world.started_player_num
    def IsThisUniqueInPlay(self, this):
        from game.operate.worlds import Worlds
        if not (this.IsUnique()):
            return False
        faces = Worlds.GetOnFieldCards(this.card.GetGameArea())
        for face in CardFinder(is_unique=True).Checks(faces):
            if face.card.state.is_defeating:
                pass
            if not (this.CanCoexistWith(face)):
                return True
        return False
    def DiscardResourcesArea(self):
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        world = self.GetWorld()
        for player in self.const_players:
            faces = player.area_resources.GetAll(False)
            if faces:
                Faces.DiscardAll(faces, GameRule(world.GetFirstPlayer().GetIdentity()))
    def UpdatePlayersOrder(self, by_effect: Effect):
        from game.message import Message
        from game.effect.rule import GameRule
        world = self.GetWorld()
        identity = self.GetFirstPlayer().GetIdentity()
        identity.SetActive(GameRule(identity))
        message = Message.AfterPlayersOrderChange(world, by_effect)
        message.Send()
    def ProcessTemporary(self, by_effect: Effect):
        from game.operate.faces import Faces
        from game.operate.worlds import Worlds
        faces = Worlds.FindCardsOnField(by_effect, is_temporary=True)
        Faces.DiscardAll(faces, by_effect)
