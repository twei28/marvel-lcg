# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.world.limit_monitor.player_side_scheme_limit import PlayerSideSchemeLimit
Unused(PlayerSideSchemeLimit)
