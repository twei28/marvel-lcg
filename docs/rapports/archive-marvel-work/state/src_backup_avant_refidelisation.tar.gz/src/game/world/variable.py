# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.player import *
from game.card.face import *
class Variable:
    def __init__(self):
        self.dic = {}
    def SetStr(self, name, value):
        self.dic[name] = value
    def GetStr(self, name):
        return self.dic[name]
    def HasKey(self, name):
        return (name in self.dic)
    def SetFace(self, name, value):
        self.dic[name] = value
    def GetFace(self, name):
        return self.dic[name]
    def AddFace(self, name, value):
        if (name not in self.dic):
            self.dic[name] = []
        self.dic[name].append(value)
    def GetFaces(self, name):
        if (name not in self.dic):
            return []
        return self.dic[name]
