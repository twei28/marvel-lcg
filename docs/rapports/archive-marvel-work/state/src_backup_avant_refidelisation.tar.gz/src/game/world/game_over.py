# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from core import *
from game.world import *
from game.effect import *
GAME_OVER_REASON_RULE = Literal[('There were no cards in either the encounter deck or the encounter discard pile', 'All players were eliminated', 'The Final Stage of the Villain was Defeated', 'The Final Stage of the Main Scheme was Completed', 'The Main Scheme was Completed')]
GAME_OVER_REASON_SIMPLE = Literal[('Players Won', 'Players Lost')]
GAME_OVER_REASON_EXIT = Literal[('Exit', 'Undo')]
GAME_OVER_REASON = ((GAME_OVER_REASON_RULE | GAME_OVER_REASON_SIMPLE) | GAME_OVER_REASON_EXIT)
GAME_OVER_REASON_MAP = {'There were no cards in either the encounter deck or the encounter discard pile': False, 'All players were eliminated': False, 'The Final Stage of the Villain was Defeated': True, 'The Final Stage of the Main Scheme was Completed': False, 'The Main Scheme was Completed': False, 'Players Won': True, 'Players Lost': False, 'Exit': None, 'Undo': None}
GAME_OVER_REASON_MAP: Dict[(GAME_OVER_REASON, (bool | None))]
class GameOverReason:
    def __init__(self, world: 'World'):
        self
        self
        self.reason = None
        self.world = world
    def SetGameOver(self, reason: GAME_OVER_REASON, by_effect: Effect|None):
        if not (self.is_game_over):
            from engine import Engine
            game = Engine.game
            from game.message import Message
            players_won = None
            if (reason == 'Exit'):
                game.state.SetExitStatus('Exit')
                Engine.statistics.Reset()
            else:
                if (reason == 'Undo'):
                    game.state.SetExitStatus('Undo')
                else:
                    game.state.SetExitStatus('')
    def SetPlayersWon(self, player_won, by_effect):
        if player_won:
            reason = 'Players Won'
        else:
            reason = 'Players Lost'
        return self.SetGameOver(reason, by_effect)
    def SetGameOverByRule(self, reason: GAME_OVER_REASON_RULE):
        from game.effect.rule import GameRule
        from game.operate.worlds import Worlds
        scheme = Worlds.GetAllMainSchemes(self.world)[0]
        effect = GameRule(scheme, display_name=reason)
        return self.SetGameOver(reason, effect)
    def SetUndo(self):
        return self.SetGameOver('Undo', None)
    def SetExit(self):
        return self.SetGameOver('Exit', None)
    @property
    def is_game_over(self):
        return (self.reason != None)
    @property
    def is_game_exit_or_undo(self):
        return (self.reason in ('Exit', 'Undo'))
    @property
    def is_exit(self):
        return (self.reason == 'Exit')
