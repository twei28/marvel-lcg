# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from core import *
from game.card.face import *
from game.card import *
from engine.lib import TransText
from engine.log import Log
from engine.profile import Profile
from game.world import *
from build import Build
from game.render.descriptor.world import WorldDescriptor
from game.render.to_descriptor import ToDescriptor
from engine.config import ConfigVariables
RENDER_ON_UNDO = ConfigVariables.Str('render_on_undo', 'round')
CATEGORY_NAME = 'RENDER'
class WorldRender:
    def __init__(self, world: 'World'):
        self.world = world
        self.last_active_card_ids = []
        self.prompt = ''
        self.last_prompt = ''
        self.last_render_id = 0
        self.debug_message = ''
        self.descriptor = WorldDescriptor()
        self.last_round_id = 0
    def PresentForceNoWait(self, is_update = True):
        skip = self.world.controller_manager.skip.is_skipping
        if not ((skip == False)):
            raise AssertionError
        return self.PresentInternal(None, is_update=True, skip=False, wait=False)
    def Present(self, origin_info, sound_name, event_name, *faces, code_info):
        skip = self.world.controller_manager.skip.is_skipping
        return self.PresentInternal(*tuple([origin_info, sound_name, event_name, *faces]), **{'is_update': True, 'skip': skip, 'code_info': code_info})
    def ErrorOccurred(self, origin_info):
        from engine import Engine
        game = Engine.game
        if game.state.is_running:
            if self.world:
                return self.PresentInternal(('Error occurred:\n' + origin_info), '', '', is_update=True, skip=False, log_game_info=False)
                return
    def PresentInternal(self, origin_info, sound_name = '', event_name = '', *faces, code_info = '', is_update = True, skip = False, wait = True, log_game_info = True):
        if is_update:
            self.last_render_id = (self.last_render_id + 1)
            self.last_active_card_ids = [x.card.object_id for x in faces]
        Log.DebugSilent('SYNC', f'-------- {self.last_render_id} ---------')
        if skip:
            from game.test import Test
            if Test.IsInTesting():
                return
            if (RENDER_ON_UNDO.value == 'round'):
                if (self.world.round_id == self.last_round_id):
                    return
            else:
                Log.DebugSilent('SYNC', 'Render world skip')
                return
        self.last_round_id = self.world.round_id
        Log.DebugSilent('SYNC', 'Render world start')
        if origin_info:
            if isinstance(origin_info, str):
                text_symbol = origin_info
                self.prompt = text_symbol
            else:
                text_symbol = origin_info.text_symbol
                self.prompt = origin_info.text_no_symbol
            if text_symbol:
                if log_game_info:
                    if not (skip):
                        Log.PrintGameInfo({text_symbol}, sound_name=sound_name, render_id=self.last_render_id, code_info=code_info)
            self.last_prompt = self.prompt
        else:
            self.prompt = ''
        world = self.world
        self.descriptor = ToDescriptor.World(world, event_name, sound_name)
        from engine import Engine
        game = Engine.game
        if not (Build.release):
            self.debug_message = f"<div id='debug-render'>Render: {self.last_render_id}, Step: {game.controller_manager.replay.current_step_id}</div>\n<div id='debug-effect'>{world.event_manager.debug_log_both.GetLog()}</div>\n<div id='debug-effect'>{world.event_manager.debug_log_only_local.GetLog()}</div>\n<div id='debug-effect'>{world.event_manager.debug_log_only_global.GetLog()}</div>\n<div id='debug-effect'>{world.event_manager.debug_log.GetLog()}</div>\n<div id='profile'>{Profile.GetDebugMessage()}</div>\n"
        for player in world.const_seat_order_players:
            player.GetController().Render()
        if not (skip):
            Log.DebugSilent('SYNC', 'Render start')
            game.controller_manager.WaitSync(wait)
        Log.DebugSilent('SYNC', 'Render end')
    def CalculateCRC(self):
        world = self.world
        infosets = [{}, {}, {}]
        for id in world.object_manager.card_dict:
            if (id != 0):
                card = world.object_manager.card_dict[id]
                info = card.GetCRC(recalculate=True)
                if (info != -1):
                    infosets[0] = (infosets[0] | {id: info})
        return [str(x).replace(' ', '') for x in infosets]
