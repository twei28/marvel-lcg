# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import Unused
from game.world.game_area.game_area import GameArea
Unused(GameArea)
