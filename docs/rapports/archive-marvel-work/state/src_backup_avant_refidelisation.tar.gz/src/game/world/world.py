# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from typing import Final
from typing import TypeAlias
from core import *
from game.card.face import *
from game.ability import *
from game.player import *
from game.deck import *
from game.scene import *
from game.message import *
from engine.job import JobManager
from engine.controller import *
from game.world.game_area import *
from engine.lib import Json
from game.world.game_over import GameOverReason
from game.world.world_action import WorldAction
from game.world.world_find import WorldFind
from game.world.phase import Phase
from game.world.phase import PhaseName
from game.world.variable import Variable
from game.world.world_rule import WorldRule
from game.world.world_stat import WorldStat
from game.world.world_render import WorldRender
from game.world.cheat.cheat_cmd import CheatCommand
GAME_OVER = Literal[(True, False)]
GAME_OVER: TypeAlias
class World(WorldAction, WorldFind):
    def __init__(self, scene, controllers):
        from game.deck import Deck2
        from game.deck import DeckType
        from game.card.face.base import SchemeSide2
        from game.card.face.card_type import Environment
        from game.card.face.card_type import MainScheme
        from game.event.manager import EventManager
        from game.buff.manager import BuffManager
        from game.object.manager import ObjectManager
        from game.operate.worlds import Worlds
        from game.world.limit_monitor import PlayerSideSchemeLimit
        self.object_manager = ObjectManager()
        self.rule = WorldRule()
        self.render = WorldRender(self)
        self.scenario = Scenario('Scenario', self)
        scenario = self.GetScenario()
        self.game_areas = [GameArea(self)]
        self.players = []
        self.const_seat_order_players = []
        self.current_player = None
        self.asking_player = []
        self.phase = Phase()
        self.stat = WorldStat()
        self.store = Variable()
        self.area_removed = Deck2(scenario, DeckType.RemovedArea, CardFace)
        self.area_insert = Deck2(scenario, DeckType.RemovedArea, Insert)
        self.area_status_cards = Deck2(scenario, DeckType.RemovedArea, CardFace)
        self.aside_deck = Deck2(scenario, DeckType.AsideDeck, CardFace)
        self.aside_modular = Deck2(scenario, DeckType.AsideDeck, CardFace)
        self.area_boosting = Deck2(scenario, DeckType.BoostingArea, CardFace)
        self.area_environment = Deck2(scenario, DeckType.EnvironmentArea, Environment)
        self.area_evidence = Deck2(scenario, DeckType.EvidenceArea, Evidence)
        self.area_rule = Deck2(scenario, DeckType.RuleArea, CardFace)
        self.area_processing = Deck2(scenario, DeckType.ProcessingArea, CardFace)
        self.area_revealing = Deck2(scenario, DeckType.RevealingArea, CardFace)
        self.victory_display = Deck2(scenario, DeckType.VictoryDisplay, CardFace)
        self.area_schemes_main = Deck2(scenario, DeckType.MainSchemesArea, MainScheme)
        self.area_schemes_side = Deck2(scenario, DeckType.SideSchemesArea, SchemeSide2)
        self.main_schemes_deck = Deck2(scenario, DeckType.MainSchemesDeck, MainScheme)
        self.round_id = 0
        self.phase_id = 0
        self.event_manager = EventManager(self)
        self.buff_manager = BuffManager(self)
        self.scene = scene
        self.game_over = GameOverReason(self)
        player_num = len(scene.players)
        for i in (0, 1, 2, 3)[:player_num]:
            player = Player(scene.players[i].name, controllers[i], i, self)
            self.players.append(player)
            self.const_seat_order_players.append(player)
        self.started_player_num = player_num
        self.additional_decks = []
        self.additional_discard_piles = []
        self.scenario_decks = {}
        for name in Types.LiteralToList(Worlds.ASIDE_DECK_NAME):
            self.scenario_decks[name] = SetAsideDeck()
        self.limit_player_side_scheme = PlayerSideSchemeLimit(self)
        self.controller_manager = controllers[0].manager
        self.cheat = CheatCommand(self)
        from game.operate.campaign_logs import CampaignLog
        for name in scene.campaign.campaign_log:
            value = scene.campaign.campaign_log[name]
            CampaignLog.SetStr(name, value, self)
        self
    def LoadFromJson(self, file_name, controllers):
        from game.render.descriptor.world import WorldDescriptor
        from game.card.factory import CardFactory
        world_descriptor = Json.LoadAs(file_name, WorldDescriptor)
        self.players = []
        for i in (0, 1, 2, 3)[:world_descriptor.players]:
            player = Player(world_descriptor.players[i].area_hero[0].name, controllers[i], i, self)
            self.players.append(player)
            self.const_seat_order_players.append(player)
            player.setup.SelectIdentity(player.name, ([world_descriptor.players[i].area_hero[0].card_id] + world_descriptor.players[i].area_hero[0].down_card_ids), [], [], [], [])
            for card in world_descriptor.players[i].player_deck:
                CardFactory.GenerateCard(card.card_id, self.players[0].player_deck, self)
            for card in world_descriptor.players[i].hand_cards:
                CardFactory.GenerateCard(card.card_id, self.players[0].hand_cards, self)
        for card in world_descriptor.villain_deck:
            CardFactory.GenerateCard(card.card_id, self.scenario.villain_deck, self)
    def GetScenario(self) -> Scenario:
        return self.scenario
    def GetFirstGameArea(self) -> GameArea:
        return self.game_areas[0]
    def CreateGameArea(self) -> GameArea:
        self.game_areas.append(GameArea(self))
        return self.game_areas[-1]
    def SelectScenario(self, villains, schemes):
        from game.card.factory import CardFactory
        from game.effect.rule import GameRule
        main_schemes = CardFactory.GenerateCards(schemes, self.main_schemes_deck, self)
        main_scheme = main_schemes[0].face
        main_scheme.PutIntoPlay(self.GetFirstPlayer(), GameRule(main_scheme))
        self.GetScenario().SelectVillain(villains)
    def Initialize(self):
        from game.card.factory import CardFactory
        from game.message import Message
        from game.effect.rule import GameRule
        from game.operate.worlds import Worlds
        from game.operate.faces import Faces
        self.event_manager.RegisterPlayRule()
        initialize_message = Message.WhenGameInitialize(self)
        initialize_message.Send()
        Message.TextRender('\n--- Select Hero and Villain ---', self)
        for player in self.const_players:
            i = self.const_players.index(player)
            scene_player = self.scene.players[i]
            player.setup.SelectIdentity(scene_player.name, scene_player.hero, scene_player.hero_deck, scene_player.obligations, scene_player.nemesis_set, scene_player.player_deck)
        if self.is_game_over:
            return
        identity = self.const_players[0].GetIdentity()
        identity.SetActive(GameRule(identity))
        campaign = self.scene.campaign
        if self.rule.mode_skirmish:
            villain = [identity.GetControlByPlayer().AskChoosePaper(campaign.villain)]
        else:
            villain = campaign.villain
        self.SelectScenario(villain, campaign.schemes)
        if self.is_game_over:
            return
        game_start_effect = GameRule(Worlds.GetAllMainSchemes(self)[0])
        Message.TextRender('\n--- Set Up ---', self)
        message = Message.WhenGameBeginSetup(campaign, self)
        message.Send()
        scenario = self.GetScenario()
        if not (message.skip_put_villain_into_play):
            if scenario.villain_deck.GetSize():
                villain = scenario.villain_deck.Get()[0]
                player = self.GetFirstPlayer()
                villain.PutIntoPlay(player, game_start_effect)
        if self.is_game_over:
            return
        if not (message.skip_create_encounter_deck):
            encounters = campaign.encounters[:]
            from game.card.factory import CardFactory
            for encounter_set in message.encounter_set_names:
                encounters = (encounters + CardFactory.LoadEncounterSet(encounter_set))
            CardFactory.GenerateCards(encounters, scenario.encounter_deck, self)
            Message.WhenDeckCreated_Text(scenario.encounter_deck)
            if not (message.no_use_obligation):
                for player in self.const_players:
                    Faces.MoveAllToDeck([x.face for x in player.set_aside_obligations], scenario.encounter_deck, 'Top', game_start_effect)
            if self.rule.crisis_of_infinite_deadpools:
                used_pool_aspect = False
                for player in self.const_players:
                    if player.player_deck.FindCardSize(CardFinder(card_class="'Pool")):
                        used_pool_aspect = True
                    else:
                        pass
        if self.is_game_over:
            return
        for player in self.const_players:
            faces = [card.face for card in player.set_aside_obligations if (card.face in player.set_aside_nemesis_sets.Get())]
            Faces.RemoveAllFromGame(faces, game_start_effect)
        if self.is_game_over:
            return
        for scheme in Worlds.GetAllMainSchemes(self):
            scheme.Setup(True)
        decks = ((([x.player_deck for x in self.const_players] + [x.set_aside_nemesis_sets for x in self.const_players]) + [self.GetScenario().encounter_deck]) + self.additional_decks)
        faces = [y for y in decks]
        for face in faces:
            face.ProcessSetup(game_start_effect)
        if self.is_game_over:
            return
        self.phase.SetState(Phase.State.ScenarioSetup)
        for scheme in Worlds.GetAllMainSchemes(self):
            scheme.Setup(False)
            scheme.Advance(None, game_start_effect)
        for villain in Worlds.GetAllVillains(self):
            villain.Setup(False)
            villain.Reveal(None, game_start_effect)
        faces = [y for y in decks]
        for face in faces:
            face.Setup(False)
        if self.is_game_over:
            return
        campaign_message = Message.WhenCampaignSetup(self)
        campaign_message.Send()
        Message.TextRender('\n--- Draw Cards ---', self)
        if not (self.rule.disable_setup_draw_cards):
            for player in self.const_players:
                player.DrawUp('Max', game_start_effect)
        self.phase.SetState(Phase.State.ResolveMulligans)
        Message.TextRender('\n--- Resolve Mulligans ---', self)
        if not (self.rule.disable_resolve_mulligans):
            def process_player(player: Player):
                player.phase.ResolveMulligans(Message.WhenPlayerResolveMulligans(player))
            JobManager.Simultaneous(process_player, self.const_players)
        if self.rule.additional_resolve_mulligans:
            def process_player(player: Player):
                player.phase.ResolveMulligans(Message.WhenPlayerResolveMulligans(player))
            JobManager.Simultaneous(process_player, self.const_players)
        Message.TextRender('\n--- Resolve Character Setup Abilities ---', self)
        for player in self.const_players:
            player.GetIdentity().Setup(False)
        if self.is_game_over:
            return
        if self.rule.ex_start_hand_size:
            for player in self.const_players:
                player.DrawUp(self.rule.ex_start_hand_size, game_start_effect)
        self.phase.SetState(Phase.State.InitFinished)
        begin_message = Message.WhenGameWouldBegin(self)
        begin_message.Send()
    def PlayerPhase(self):
        def turn_begin():
            self.stat.OnTurnBegin()
        def turn_end():
            self.stat.OnTurnEnd()
        self.phase.SetState(Phase.State.PlayerTurn)
        def get_player_phase_order():
            players = self.const_players[:]
            for player in players:
                if player.flag.Get('YOU_TAKE_THE_FIRST_TURN_DURING_THE_PLAYER_PHASE'):
                    players.remove(player)
                    players.insert(0, player)
            return players
        for player in get_player_phase_order():
            self.current_player = player
            turn_begin()
            player.phase.BeginTurn()
            player.phase.PlayerTurn()
            if self.is_game_over:
                return
            player.phase.EndTurn()
            turn_end()
        self.phase.SetState(Phase.State.PlayerTurnEnd)
    def PlayersEndPhase(self):
        def process_player(player: Player):
            player.phase.EndPhase()
        JobManager.Simultaneous(process_player, self.const_players)
    def VillainPhase(self):
        from game.message import Message
        from game.effect.rule import GameRule
        from game.operate.worlds import Worlds
        for player in self.const_players:
            player.stat.this_phase_revealed_cards = []
        def process_villain_phase_step(step, callback, phase):
            self.phase.SetState(phase)
            step_message = Message.WhenVillainPhaseStepStart(step, self)
            step_message.Send()
            callback()
            if self.is_game_over:
                return
            after_step_message = Message.AfterResolveVillainPhaseStep(step, step_message)
            after_step_message.Send()
        def place_threat():
            self.current_player = None
            start_message = Message.WhenMainSchemePhaseStart(self)
            start_message.Send()
            for scheme in Worlds.GetAllMainSchemes(self):
                scheme.Phase()
            end_message = Message.WhenMainSchemePhaseEnd(self)
            end_message.Send()
        def enemy_activation():
            for player in self.const_players:
                self.current_player = player
                effect = GameRule(player.GetIdentity())
                Worlds.Enemies.VillainAndEngagedMinionsActivateAgainstYou(effect, player)
        def deal_encounter_cards():
            Message.TextRender('\n--- Encounter Cards Phase ---', self)
            num = (1 + self.rule.mode_heroic)
            hazards = {}
            for player in self.const_players:
                game_area = player.GetGameArea()
                if (game_area not in hazards):
                    hazards[game_area] = Worlds.GetHazardFaces(game_area)
                self.current_player = player
                player.DealEncounterCards(num, GameRule(player.GetIdentity()))
            for game_area in hazards:
                if hazards[game_area]:
                    for player in game_area.FindAllPlayers():
                        for face in hazards[game_area][:]:
                            player.DealEncounterCards(1, GameRule(face))
                            hazards[game_area].remove(face)
                        if self.is_game_over:
                            return
                    # backward conditional jump to 112: hazards[game_area]
        def reveal_encounter_cards():
            if any(((player.dealt_encounter_cards.GetSize() != 0) for player in self.const_players)):
                for player in self.const_players:
                    self.current_player = player
                    player.RevealEncounterCards()
                    if self.is_game_over:
                        return
                # backward conditional jump to 20: any(((player.dealt_encounter_cards.GetSize() != 0) for player in self.const_players))
        steps_data = {1: (place_threat, Phase.State.PlaceThreat), 2: (enemy_activation, Phase.State.EnemyActivation), 3: (deal_encounter_cards, Phase.State.DealEncounterCards), 4: (reveal_encounter_cards, Phase.State.RevealsEncounterCards)}
        for _item in steps_data.items():
            step_number = UNKNOWN[0]
            action = UNKNOWN[1][0]
            state = UNKNOWN[1][1]
            process_villain_phase_step(step_number, action, state)
            if self.is_game_over:
                return
    def OnGameLoop(self):
        from game.message import Message
        from game.effect.rule import GameRule
        def game_round():
            def start_round():
                self.phase.SetState(Phase.State.StartRound)
                self.current_player = None
                self.round_id = (self.round_id + 1)
                start_message = Message.WhenRoundStart(self.round_id, self)
                start_message.Send()
                for player in self.const_players:
                    player.phase.BeginRound()
                self.controller_manager.OnBeginRound()
            def end_round():
                self.phase.SetState(Phase.State.EndRound)
                self.current_player = None
                round_message = Message.WhenRoundEnd(self)
                round_message.Send()
                self.stat.OnRoundEnd()
                self.buff_manager.OnRoundEnd()
                for player in self.const_players:
                    player.phase.EndRound()
                end_round_effect = GameRule(self.const_players[0].GetIdentity())
                self.players = Types.Rotate(self.players, 1)
                self.UpdatePlayersOrder(end_round_effect)
                self.ProcessTemporary(end_round_effect)
                end_message = Message.AfterRoundEnd(round_message)
                end_message.Send()
            def phase_begin(phase_type):
                self.phase_id = (self.phase_id + 1)
                phase_message = Message.WhenPhaseBegin(phase_type, self)
                phase_message.Send()
                for player in self.const_players:
                    player.phase.BeginPhase()
                self.controller_manager.OnBeginPhase()
                begin_message = Message.AfterPhaseBegin(phase_message)
                begin_message.Send()
            def phase_end(phase_type):
                from game.message import Message
                self.phase.SetState(Phase.State.EndPhase)
                self.current_player = None
                phase_message = Message.WhenPhaseEnd(self.phase_id, phase_type, self)
                phase_message.Send()
                self.stat.OnPhaseEnd()
                end_message = Message.AfterPhaseEnd(self.phase_id, phase_type, phase_message)
                end_message.Send()
            start_round()
            if self.is_game_over:
                return
            phase_begin('Player')
            if self.is_game_over:
                return
            self.PlayerPhase()
            if self.is_game_over:
                return
            self.PlayersEndPhase()
            if self.is_game_over:
                return
            phase_end('Player')
            if self.is_game_over:
                return
            phase_begin('Villain')
            if self.is_game_over:
                return
            self.VillainPhase()
            if self.is_game_over:
                return
            phase_end('Villain')
            if self.is_game_over:
                return
            end_round()
        if not (self.is_game_over):
            game_round()
            # backward conditional jump to 48: self.is_game_over
            return
    def OnGameOver(self, reason: GameOverReason):
        from game.message import Message
        if not ((reason.reason != None)):
            raise AssertionError
        Message.GameOver_Text(reason.players_won, reason.reason, reason.by_effect, self)
    def SetGameOver(self, player_won, by_effect):
        return self.game_over.SetPlayersWon(player_won, by_effect)
    @property
    def is_game_over(self):
        return self.game_over.is_game_over
    @property
    def is_game_started(self):
        return self.phase.IsGameStarted()
    @property
    def is_initializing(self):
        return self.phase.IsGameInitializing()
    def AdvanceMainScheme(self, prev_scheme, to_face, by_effect):
        from game.message import Message
        from game.effect.rule import GameRule
        from game.operate.faces import Faces
        if not (prev_scheme.card.back_faces):
            raise AssertionError(f'prev_scheme.card={prev_scheme.card!r}')
        message = Message.WhenMainSchemeWouldAdvance(prev_scheme, by_effect)
        message.Send()
        if message.is_be_instead:
            return
        if (prev_scheme.card.printed_faces[0] == prev_scheme):
            card = prev_scheme.card
            card.Flip(GameRule(card.face))
        else:
            if (self.main_schemes_deck.GetSize() > 0):
                if (to_face == None):
                    scheme = self.main_schemes_deck.Get()[0]
                else:
                    if (to_face == '2A'):
                        scheme = self.main_schemes_deck.FindCard(CardFinder(stage=2), card_type=MainScheme)
                        if not ((scheme != None)):
                            raise AssertionError
                    else:
                        if (to_face == '3A'):
                            scheme = self.main_schemes_deck.FindCard(CardFinder(stage=3), card_type=MainScheme)
                            if not ((scheme != None)):
                                raise AssertionError
                        else:
                            scheme = to_face
                            if not (MainScheme.IsType(scheme)):
                                raise AssertionError
                acceleration_token = prev_scheme.acceleration_token
                if not (prev_scheme.card.area.flags.is_victory_display):
                    Faces.RemoveAllFromGame([prev_scheme], GameRule(prev_scheme))
                scheme.PlaceAccelerationToken(acceleration_token, GameRule(scheme))
                scheme.Reveal(None, by_effect)
            else:
                if (self.area_schemes_main.GetSize() == 1):
                    self.game_over.SetGameOverByRule('The Final Stage of the Main Scheme was Completed')
        after_message = Message.AfterMainSchemeAdvanced(message)
        after_message.Send()
    def CheckIsAllPlayersEliminated(self):
        for player in self.const_players:
            if not (player.GetIdentity().IsDefeated()):
                if not (player.is_eliminated):
                    return False
        self.game_over.SetGameOverByRule('All players were eliminated')
        return True
    def GetPhaseText(self):
        if (self.phase.state == Phase.State.PlayerTurn):
            if not ((self.current_player != None)):
                raise AssertionError
            return f'Player {(self.const_seat_order_players.index(self.current_player) + 1)} Turn'
        return self.phase.state
