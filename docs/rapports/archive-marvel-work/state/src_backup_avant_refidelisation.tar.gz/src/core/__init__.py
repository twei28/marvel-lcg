# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

def Unused(*_):
    pass
from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Sequence
from typing import Type
from typing import Set
from typing import Tuple
Unused(Any)
Unused(Dict, List, Set, Tuple, Sequence)
Unused(Type[Callable[([], Any)]])
from typing import TypeVar
Unused(TypeVar)
from typing import Literal
Unused(Literal)
from typing import Union
Unused(Union)
from typing import TypeGuard
Unused(TypeGuard)
from typing_extensions import override
Unused(override)
from copy import copy
Unused(copy)
from typing import final
Unused(final)
from dataclasses import dataclass
from dataclasses import field
from dataclasses import asdict
from dataclasses import fields
from dataclasses import is_dataclass
Unused(dataclass, field)
Unused(asdict)
Unused(fields, is_dataclass)
from typing import Generic
from typing import Iterable
Unused(Generic, Iterable)
from typing import Awaitable
Unused(Awaitable)
from typing import ForwardRef
from typing import cast
from typing import get_args
from typing import get_origin
Unused(ForwardRef, cast, get_args, get_origin)
from typing import TypedDict
Unused(TypedDict)
from typing_extensions import Unpack
Unused(Unpack)
from typing import NoReturn
Unused(NoReturn)
from typing import overload
Unused(overload)
from typing_extensions import deprecated
Unused(deprecated)
from core.utility.types import Types
Unused(Types)
from core.utility.system import System
Unused(System)
from core.utility.cast import Cast
Unused(Cast)
from core.utility.utility import Unquote
Unused(Unquote)
from core.utility.debug import Debug
Unused(Debug)
from core.utility.func import GetFuncLines
from core.utility.func import GetFuncName
from core.utility.func import GetCallStack
from core.utility.func import IsAsyncFunction
from core.utility.func import IsNonAsyncFunction
Unused(GetFuncLines, GetFuncName, GetCallStack, IsAsyncFunction, IsNonAsyncFunction)
from core.meta_class import Tracker
from core.meta_class.class_name import ClassNameMeta
Unused(Tracker)
Unused(ClassNameMeta)
from core.lib.math import Math
Unused(Math)
import collections
Unused(collections)
