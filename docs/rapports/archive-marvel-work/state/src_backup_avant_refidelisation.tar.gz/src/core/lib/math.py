# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
T = TypeVar('T')
class Math:
    INT_INF = 65535
    @staticmethod
    def DivideEvenly(num, lst):
        length = len(lst)
        if (length == 0):
            return (0, num)
        value_per_element = (num // length)
        remainder = (num % length)
        return (value_per_element, remainder)
    @staticmethod
    def AllMax(item_list, key):
        if (item_list == []):
            return []
        item = max(item_list, key=key)
        the_key = key(item)
        return [x for x in item_list if (key(x) == the_key)]
    @staticmethod
    def AllMin(item_list, key):
        if (item_list == []):
            return []
        item = min(item_list, key=key)
        the_key = key(item)
        return [x for x in item_list if (key(x) == the_key)]
    @staticmethod
    def MinMax(x, num_min, num_max):
        if (x > num_max):
            x = num_max
        if (x < num_min):
            x = num_min
        return x
    @staticmethod
    def MaxAndIndex(numbers):
        max_number = max(numbers)
        max_index = numbers.index(max_number)
        return (max_number, max_index)
