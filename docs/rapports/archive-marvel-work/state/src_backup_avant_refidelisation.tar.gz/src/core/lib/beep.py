# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
import winsound
class Beep:
    @staticmethod
    def BeepInternal(frequency = 1000, duration = 100):
        winsound.Beep(frequency, duration)
    @staticmethod
    def NotesInternal(notes):
        for _item in notes:
            frequency = UNKNOWN[0]
            duration = UNKNOWN[1]
            Beep.BeepInternal(frequency, duration)
    @staticmethod
    def Success():
        notes = [*((1000, 100), (1500, 100), (2000, 200), (2000, 100), (1500, 100), (1000, 400))]
        Beep.NotesInternal(notes)
    @staticmethod
    def Warning():
        notes = [(700, 200)]
        Beep.NotesInternal(notes)
