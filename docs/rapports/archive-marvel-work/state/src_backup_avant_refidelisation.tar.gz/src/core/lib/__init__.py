# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from core.lib.math import Math
from core.lib.beep import Beep
from core.lib.time import Time
Unused(Math)
Unused(Beep)
Unused(Time)
