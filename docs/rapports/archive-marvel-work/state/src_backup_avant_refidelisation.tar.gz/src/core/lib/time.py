# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

import time
class Time:
    start_time = time.time()
    @staticmethod
    def Format(format = '%Y-%m-%d %H-%M'):
        import datetime
        return {datetime.datetime.now().strftime(format)}
    @staticmethod
    def GetTime():
        return time.time()
    @staticmethod
    def GetElapsedTime():
        return (time.time() - Time.start_time)
