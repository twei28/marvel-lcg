# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core.meta_class.instance_tracker import InstanceTracker
from core.meta_class.call_tracker import CallTracker
class Tracker:
    Meta = InstanceTracker.Meta
    @staticmethod
    def count_calls(method: CallTracker.FuncT) -> CallTracker.FuncT:
        pass
    count_calls = CallTracker.count_calls
    @classmethod
    def PrintStats(cls):
        return (InstanceTracker.PrintStats() + CallTracker.PrintStats())
    @classmethod
    def ResetStats(cls):
        InstanceTracker.ResetStats()
        CallTracker.ResetStats()
