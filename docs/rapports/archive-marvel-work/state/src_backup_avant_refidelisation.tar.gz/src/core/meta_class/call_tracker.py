# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from build import Build
class CallTracker:
    __annotations__ = {}
    method_call_count = {}
    method_call_count: Dict[(str, Dict[(str, int)])]
    FuncT = TypeVar('FuncT', bound=Callable[(Ellipsis, Any)])
    class Meta(type):
        pass
    @staticmethod
    def count_calls(method: 'CallTracker.FuncT') -> 'CallTracker.FuncT':
        return method
    @staticmethod
    def count_calls_debug(method: 'CallTracker.FuncT') -> 'CallTracker.FuncT':
        def wrapper(self, *args, **kwargs):
            caller = GetCallStack(3)
            if (method.__name__ not in CallTracker.method_call_count):
                CallTracker.method_call_count[method.__name__] = {}
            if (caller not in CallTracker.method_call_count[method.__name__]):
                CallTracker.method_call_count[method.__name__][caller] = 1
            else:
                CallTracker.method_call_count[method.__name__][caller] = (CallTracker.method_call_count[method.__name__][caller] + 1)
            return method(*tuple([self, *args]), **{**kwargs})
        return wrapper
    if not (Build.release):
        count_calls = count_calls_debug
    @classmethod
    def PrintStats(cls):
        import json
        method_call_count = json.dumps(CallTracker.method_call_count, indent=4)
        text = f'method_call_count: {method_call_count}\n'
        return text
    @classmethod
    def ResetStats(cls):
        CallTracker.method_call_count = {}
