# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from build import Build
class InstanceTracker:
    __annotations__ = {}
    instance_list = {}
    instance_list: Dict[(str, List[Any])]
    instance_creation_locations = {}
    instance_creation_locations: Dict[(str, Dict[(str, int)])]
    class Meta(type):
        pass
    class MetaDebug(Meta):
        def __init__(cls, name, bases, dct):
            super().__init__(name, bases, dct)
            InstanceTracker.instance_list[name] = []
            InstanceTracker.instance_creation_locations[name] = {}
        def __call__(cls, *args, **kwargs):
            location = GetCallStack(2)
            if (location in InstanceTracker.instance_creation_locations[cls.__name__]):
                InstanceTracker.instance_creation_locations[cls.__name__][location] = (InstanceTracker.instance_creation_locations[cls.__name__][location] + 1)
            else:
                InstanceTracker.instance_creation_locations[cls.__name__][location] = 1
            instance = super().__call__(*args, **{**kwargs})
            InstanceTracker.instance_list[cls.__name__].append(instance)
            return instance
    if not (Build.release):
        Meta = MetaDebug
    @classmethod
    def ResetStats(cls):
        for key in InstanceTracker.instance_list.keys():
            InstanceTracker.instance_list[key] = []
            InstanceTracker.instance_creation_locations[key] = {}
    @classmethod
    def PrintStats(cls):
        import json
        instance_count = {key: len(value) for key, value in InstanceTracker.instance_list.items()}
        locations = json.dumps(InstanceTracker.instance_creation_locations, indent=4)
        text = f'instance_count={instance_count!r}\nlocations: {locations}\n'
        return text
if (__name__ == '__main__'):
    class MyClass(metaclass=InstanceTracker.Meta):
        my_method = Tracker.count_calls(my_method)
    class MyClass2(metaclass=InstanceTracker.Meta):
        my_method_2 = Tracker.count_calls(my_method_2)
    obj1 = MyClass()
    obj2 = MyClass()
    obj3 = MyClass2()
    obj1.my_method()
    obj1.my_method()
    obj3.my_method_2()
    print(Tracker.PrintStats())
    InstanceTracker.ResetStats()
    Tracker.ResetStats()
    print(InstanceTracker.PrintStats())
    print(Tracker.ResetStats())
