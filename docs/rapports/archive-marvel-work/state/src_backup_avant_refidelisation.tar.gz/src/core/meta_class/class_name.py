# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

class ClassNameMeta(type):
    def __str__(cls):
        return cls.__name__
    def __repr__(cls):
        return cls.__name__
