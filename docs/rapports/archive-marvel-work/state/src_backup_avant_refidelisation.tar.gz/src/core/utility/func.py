# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
import inspect
import os
ROOT_DIR = os.path.abspath(os.curdir)
def GetFuncLines(fn, replace_path = False):
    file_path = fn.__code__.co_filename
    if replace_path:
        from engine.file import FileManager
        file_path = FileManager.ReplacePath(file_path, ROOT_DIR)
    return ((file_path + ':') + str(fn.__code__.co_firstlineno))
def GetFuncName(fn, replace_path = False):
    from build import Build
    if Build.release:
        return fn.__name__
    return ((fn.__name__ + ' ') + GetFuncLines(fn, replace_path))
def GetCallStack(deep):
    from build import Build
    frame = inspect.currentframe()
    for _ in range(deep):
        if frame:
            frame = frame.f_back
    if frame:
        if not (Build.release):
            file_path = os.path.relpath(frame.f_code.co_filename, ROOT_DIR)
        else:
            file_path = frame.f_code.co_filename
    text = '(None)'
    return text
T = TypeVar('T')
def IsAsyncFunction(func):
    return (hasattr(func, '__code__') and ((func.__code__.co_flags & 128) != 0))
def IsNonAsyncFunction(func):
    return (not IsAsyncFunction(func))
