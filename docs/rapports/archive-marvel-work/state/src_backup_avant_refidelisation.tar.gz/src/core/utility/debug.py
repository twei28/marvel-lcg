# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

class Debug:
    @staticmethod
    def IsVSDebug():
        import sys
        return (hasattr(sys, 'gettrace') and (sys.gettrace() is not None))
    @staticmethod
    def DebugBreak(pause_skip = True):
        from engine import Engine
        from build import Build
        if not (Build.release):
            if pause_skip:
                if Engine.game.controller_manager.skip.SetIsSkipping(False):
                    if Engine.game.world:
                        Engine.game.world.render.PresentForceNoWait()
            breakpoint()
            return
