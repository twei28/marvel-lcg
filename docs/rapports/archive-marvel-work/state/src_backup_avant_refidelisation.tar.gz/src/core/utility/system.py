# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

import os
class System:
    @staticmethod
    def Run(cmd):
        os.system(cmd)
    @staticmethod
    def SetTitle(title):
        System.Run(f'title {title}')
    @staticmethod
    def Pause():
        System.Run('pause')
    @staticmethod
    def Sleep(secs):
        from time import sleep
        return sleep(secs)
