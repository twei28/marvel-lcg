# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

def Unquote(string):
    from urllib.parse import unquote
    return unquote(string, 'utf-8', 'replace')
