# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from build import Build
T = TypeVar('T')
def Cast(t, v):
    from game.selector.factory import SELECT
    from game.selector.selector_rule import SelectorRule
    from game.selector.selector_target import SelectorTarget
    from game.selector.selector_where import SelectorWhere
    from game.card.card_finder import CardFinderHelper
    Unused(SELECT, SelectorRule, SelectorTarget, CardFinderHelper, SelectorWhere)
    def unpack_aliases(type_alias, globalns = None, localns = None):
        from typing import _eval_type
        args = get_args(type_alias)
        values = []
        for arg in args:
            if isinstance(arg, ForwardRef):
                resolved_arg = _eval_type(arg, globalns, localns)
                values.extend(unpack_aliases(resolved_arg, globalns, localns))
            if isinstance(arg, str):
                values.append(arg)
            values = (values + get_args(arg))
        return values
    if (get_origin(t) == Union):
        if not ((v in unpack_aliases(t, globals(), locals()))):
            raise AssertionError
    else:
        if (get_origin(t) == Literal):
            if not ((v in list(get_args(t)))):
                raise AssertionError(f'v={v!r} t={t!r}')
        else:
            if (get_origin(t) == list):
                pass
            else:
                if (t == Any):
                    pass
                else:
                    from game.card.face.card_face import CardFace
                    if isinstance(v, CardFace):
                        if not (isinstance(v, t)):
                            if not (v.IsConsiderAs(card_type=t)):
                                raise AssertionError
                    else:
                        if not (isinstance(v, t)):
                            raise AssertionError(f'v={v!r} t={t!r}')
    return cast(t, v)
if Build.release:
    Cast = cast
