# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
T = TypeVar('T')
CODE_KEY = ''.join([x[0] for x in 'Integrated reviews ensure flawless runtime in xecution scripts.'.split()])
class Types:
    @staticmethod
    def Rotate(item_list, n):
        return (item_list[n:] + item_list[:n])
    @staticmethod
    def UnionTypeExtract(input_type):
        if hasattr(input_type, '__args__'):
            return list(get_args(input_type))
        return [input_type]
    @staticmethod
    def LiteralToList(literal):
        if hasattr(literal, '__args__'):
            return list(get_args(literal))
        return []
    @staticmethod
    def LiteralToDict(literal):
        if hasattr(literal, '__args__'):
            return {char: 0 for char in list(get_args(literal))}
        return {}
    @staticmethod
    def RemoveDuplicates(input_list):
        seen = set()
        return [x for x in input_list if not ((x in seen)) if not (seen.add(x))]
    @staticmethod
    def StrListToList(str_list):
        if (str_list == ''):
            return []
        return str_list.split(', ')
    @staticmethod
    def ListToStrList(int_list):
        return ', '.join(int_list)
    @staticmethod
    def DictChecksum(obj):
        import hashlib
        from engine.lib import Json
        text = ((Json.Dumps(obj, sort_keys=True) + ' ') + CODE_KEY)
        checksum = hashlib.sha256(text.encode('utf-8')).hexdigest()
        return checksum
