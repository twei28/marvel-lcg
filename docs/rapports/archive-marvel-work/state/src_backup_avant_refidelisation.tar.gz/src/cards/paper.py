# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from core import *
from game.card.face import *
@dataclass
class Paper:
    __annotations__ = {}
    card_id: str
    pic_id: str
    type: str
    is_unique: bool
    name: str
    subtitle = field(default='')
    subtitle: str
    desc = field(default_factory=lambda : {})
    desc: Dict[('CardFace.KEY', str)]
    traits = field(default_factory=lambda : [])
    traits: List['CardFace.TRAITS']
    pack = field(default='')
    pack: str
    set_name = field(default='')
    set_name: 'CardFace.SETNAMES'
    text = field(default='')
    text: str
    @staticmethod
    def GetCardId(card_paper):
        return card_paper['card_id']
    @staticmethod
    def GetFullLink(card_paper):
        if ('full_link' in card_paper):
            return card_paper['full_link']
        return ''
    @staticmethod
    def GetAbilityLink(card_paper):
        if ('ability_link' in card_paper):
            return card_paper['ability_link']
        return ''
    @staticmethod
    def Load(card_paper, pack):
        card_id = card_paper['card_id']
        pic_id = ''
        if ('pic_id' in card_paper):
            pic_id = card_paper['pic_id']
            from engine.file import Cache
            Cache.SetLinkPic(card_id, pic_id)
        type_name = card_paper['type']
        unique = str(card_paper['name']).startswith('* ')
        name = str(card_paper['name']).lstrip('* ')
        if (type_name == 'Challenge'):
            subtitle = ''
            desc = {}
            traits = []
            set_name = ''
            text = card_paper['text']
        else:
            subtitle = card_paper['subtitle']
            desc = card_paper['desc']
            traits = card_paper['traits']
            set_name = card_paper['set_name']
            if ('text' in card_paper):
                text = card_paper['text']
            else:
                text = ''
        return Paper(card_id, pic_id, type_name, unique, name, subtitle, desc, traits, pack, set_name, text)
    def IsFromSet(self, set_name):
        return (self.set_name == set_name)
    def GetType(self):
        from game.card.face.card_type import Insert
        from game.card.face.card_type import Challenge
        from game.card.face.card_type import Minion
        from game.card.face.card_type import EncounterVillain
        from game.card.face.card_type import Leader
        from game.card.face.card_type import EncounterSideScheme
        from game.card.face.card_type import MainScheme
        from game.card.face.card_type import PlayerSideScheme
        from game.card.face.card_type import Upgrade
        from game.card.face.card_type import Support
        from game.card.face.card_type import Attachment
        from game.card.face.card_type import Environment
        from game.card.face.card_type import Obligation
        from game.card.face.card_type import Treachery
        from game.card.face.card_type import Ally
        from game.card.face.card_type import Hero
        from game.card.face.card_type import AlterEgo
        from game.card.face.card_type import Event
        from game.card.face.card_type import Resource
        from game.card.face.card_type import StatusCard
        from game.card.face.card_type import Evidence
        return {'Insert': Insert, 'Challenge': Challenge, 'Hero': Hero, 'AlterEgo': AlterEgo, 'Ally': Ally, 'Minion': Minion, 'Villain': EncounterVillain, 'Leader': Leader, 'MainScheme': MainScheme, 'SideScheme': EncounterSideScheme, 'PlayerSideScheme': PlayerSideScheme, 'Upgrade': Upgrade, 'Support': Support, 'Attachment': Attachment, 'Environment': Environment, 'Event': Event, 'Obligation': Obligation, **{'Treachery': Treachery, 'Resource': Resource, 'Status': StatusCard, 'Evidence': Evidence}}[self.type]
