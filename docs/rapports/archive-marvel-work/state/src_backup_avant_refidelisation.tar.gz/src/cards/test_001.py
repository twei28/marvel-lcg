# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from cards.pack import *
def GetAbilities():
    def remove_2_threat(effect: Effect, message: Message.AfterCardEnterPlay):
        this = effect.this.CastTo(Ally)
        Unused(this)
        this.RemoveThreatFromSchemes(effect.targets, 2, effect)
    def draw_up_cards(effect: Effect, message: Message.AfterCardLeavePlay):
        this = effect.this.CastTo(Ally)
        Unused(this)
        this.GetControlByPlayer().DrawUp(4, effect)
    def deal_damage(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Ally)
        Unused(this)
        this.DealDamage(effect.targets, 4, effect)
    return [AbilityFactory.AfterCardEnterPlay(AbilityType.Response, 'This', remove_2_threat).SetTarget(Scheme2).SetCost(Cost('B')), AbilityFactory.AfterCardLeavePlay(AbilityType.Response, 'This', draw_up_cards).SetCostFunc(CostFunc.Exhaust('YourIdentity')), AbilityFactory.WhenInYourPlayTurn(AbilityType.Action, deal_damage).SetTarget(Enemy).SetCostFunc(CostFunc.Exhaust('This')).SetName('Deal 4 damage')]
