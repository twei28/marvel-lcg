# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def brix_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Minion)
        Unused(this)
        if Worlds.FindCardOnField(effect, CardFinder2('WEB-WARRIOR', Unit2)):
            this.PlaceThreatOnSchemes('MainScheme', 2, effect)
            return
    return [*AbilityFactory.GiveKeywordToInPlayWhenApplyThis(CardFinder2('INHERITOR', Minion), patrol=1), AbilityFactory.WhenThisRevealed(None, brix_revealed)]
