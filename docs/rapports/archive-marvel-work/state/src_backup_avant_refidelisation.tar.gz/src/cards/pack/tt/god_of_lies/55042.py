# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def fenris_wolf(effect: Effect, message: Message.WhenUnitBeDefeated):
        this = effect.this.CastTo(Minion)
        Unused(this)
    return [WhenDefeatedPlaceShatterCountersOnTheAvatarOfLokivillain(3, fenris_wolf)]
