# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def draugr_buddy(effect: Effect, message: Message.WhenUnitBeDefeated):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetDefeatingPlayer()
        face = Worlds.DiscardEncounterTopCard(effect)
        if Treachery.IsType(face):
            player.DealEncounterCard(this, effect)
            return
    return [AbilityFactory.WhenUnitBeDefeated(AbilityType.WhenDefeated, 'This', draugr_buddy)]
