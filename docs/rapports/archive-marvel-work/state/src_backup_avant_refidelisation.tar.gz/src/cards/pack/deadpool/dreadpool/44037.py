# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def crisis_of_infinite_deadpools_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Treachery)
        Unused(this)
        player = message.GetToPlayer()
        faces = Worlds.GetSetAsideAreaCards(effect, CardFinder(set_name='Dreadpool'))
        minion = SetupCards.Reveal(effect, reveal=player, card_type=Minion, set_name='Dreadpool', only_set_aside=True)
        scheme = SetupCards.Reveal(effect, name='Dreadful Deeds', card_type=EncounterSideScheme, reveal=player, only_set_aside=True)
        faces = [x for x in faces if (x != minion) if (x != scheme)]
        Faces.ShuffleAllTo(faces, 'EncounterDeck', effect)
        Faces.RemoveAllFromGame([this], effect)
    return [AbilityFactory.WhenThisRevealed(None, crisis_of_infinite_deadpools_revealed)]
