# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def whirlwind(effect: Effect, message: Message.WhenUnitWouldAttack):
        this = effect.this.CastTo(Ally)
        Unused(this)
        value = this.RemoveThreatFromSchemes(effect.targets, 1, effect)
        if value:
            message.GainATKForThisAttack(value, effect)
            return
    return [*AbilityFactory.ThisNotCountAllyLimit(), AbilityFactory.WhenUnitMakeAttack(AbilityType.Interrupt, 'This', whirlwind).SetTarget(Scheme2, range='All')]
