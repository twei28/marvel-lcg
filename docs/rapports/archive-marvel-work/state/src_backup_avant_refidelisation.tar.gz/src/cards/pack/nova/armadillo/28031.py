# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def tough_and_tumble_alter_ego(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Treachery)
        Unused(this)
        player = message.GetToPlayer()
        def action():
            ThisCardGainSurge(effect)
        Worlds.Enemies.AllEnemySchemeAgainstYou(effect, player, CardFinder(with_tough=True), if_no_activate=action)
    def tough_and_tumble_hero(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Treachery)
        Unused(this)
        player = message.GetToPlayer()
        activated = Worlds.Enemies.AllEnemyAttackYou(effect, player, CardFinder(with_tough=True))
        if not (activated.activated_cnt):
            ThisCardGainSurge(effect)
            return
    return [AbilityFactory.WhenThisRevealed('Alter-Ego', tough_and_tumble_alter_ego), AbilityFactory.WhenThisRevealed('Hero', tough_and_tumble_hero)]
