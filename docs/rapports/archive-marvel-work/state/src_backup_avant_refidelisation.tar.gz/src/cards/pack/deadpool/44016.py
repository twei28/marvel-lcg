# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def lady_deadpool(effect: Effect, message: Message.WhenUnitBeDefeated):
        this = effect.this.CastTo(Ally)
        Unused(this)
        Faces.DefeatUnits(effect.targets, this, effect)
    return [AbilityFactory.WhenUnitBeDefeated(AbilityType.WhenDefeated, 'This', lady_deadpool).SetTarget(Minion, non_trait='ELITE')]
