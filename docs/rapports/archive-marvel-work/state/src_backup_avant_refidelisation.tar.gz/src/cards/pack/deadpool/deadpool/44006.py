# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def yoo_hoo(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        value = effect.cost_func.Get(CostFunc.TakeDamageUpToHealth).return_damage
        this.RemoveThreatFromSchemes(effect.targets, value, effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, yoo_hoo).SetPlay().SetLabel('thwart').SetCostFunc(CostFunc.TakeDamageUpToHealth('YourHero')).SetTarget(Scheme2)]
