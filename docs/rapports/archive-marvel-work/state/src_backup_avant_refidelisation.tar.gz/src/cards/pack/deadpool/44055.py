# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def laser_swords(effect, face, ui):
        this = effect.this.CastTo(Upgrade)
        if not (this.bind_face):
            return 0
        faces = []
        if Hero.IsType(this.GetBindFace()):
            faces = (faces + Worlds.GetCrisisFaces(effect))
            faces = (faces + Worlds.GetAccelerationIconFaces(effect))
            faces = (faces + Worlds.GetAmplifyFaces(effect))
            faces = (faces + Worlds.GetHazardFaces(effect))
            ui.extend(faces)
            value = Worlds.GetIconsNum(effect, [*('Crisis', 'Acceleration', 'Amplify', 'Hazard')])
            return min(4, value)
        return 0
    return [*AbilityFactory.GiveKeywordToAttached(Hero, get_new_value=laser_swords, attack=1, ex_change_on_event=OnEvent.Icons('InPlay'))]
