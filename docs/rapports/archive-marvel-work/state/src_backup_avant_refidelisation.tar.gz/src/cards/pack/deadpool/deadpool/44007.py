# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def montage(effect: Effect, message: Message.CheckPlayerCanPayCost) -> Resources|None:
        this = effect.this.CastTo(Resource)
        Unused(this)
        res = FacesCounter.GetPrintedResources([this])
        scheme = Worlds.FindMainScheme(this)
        if scheme:
            value = min(3, scheme.acceleration_token)
            res = (res + (Resources('G') * value))
        return res
    return [AbilityFactory.CheckThisCanDropPay(montage)]
