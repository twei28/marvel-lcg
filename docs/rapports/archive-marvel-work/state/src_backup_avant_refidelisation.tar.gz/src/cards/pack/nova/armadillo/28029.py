# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def armadillo(effect: Effect, message: Message.AfterEnemyActivationEnd):
        this = effect.this.CastTo(Minion)
        Unused(this)
        Faces.GiveStatus([this], 'Tough', effect)
    return [AbilityFactory.ThisCanHaveAdditionalTough('Any'), AbilityFactory.AfterEnemyActivatesAgainstYou(AbilityType.ForcedResponse, 'This', armadillo)]
