# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def weight_of_the_world(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Obligation)
        Unused(this)
        Faces.RemoveAllFromGame([this], effect)
    return [*AbilityFactory.CardCannotReady(CardFinder(name='Supernova Helmet')), AbilityFactory.WhenInYourPlayTurn(AbilityType.AlterEgoAction, weight_of_the_world).SetCostFunc(CostFunc.Exhaust('YourAlterEgo'))]
