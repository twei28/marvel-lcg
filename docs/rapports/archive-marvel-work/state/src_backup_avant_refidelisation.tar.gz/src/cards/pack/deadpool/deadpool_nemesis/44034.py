# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def involuntary_procedures(effect: Effect, message: Message.AfterUnitTookDamage):
        this = effect.this.CastTo(EncounterSideScheme)
        Unused(this)
        this.PlaceThreatOnSchemes([this], 1, effect)
        if (this.threat >= 10):
            Faces.RemoveAllFromGame([this], effect)
            return
    return [AbilityFactory.AfterUnitTookDamage(AbilityType.ForcedResponse, CardFinder(name='Deadpool'), involuntary_procedures)]
