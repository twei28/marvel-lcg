# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def trance_of_greed_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        player = message.GetToPlayer()
        identity = player.GetIdentity()
        if not (Faces.GiveStatus([identity], 'Confused', effect)):
            identity.TakeDamage(this, 2, effect)
            return
    def trance_of_greed(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        player = message.GetToPlayer()
        identity = player.GetIdentity()
        faces = player.DrawUp(1, effect)
        if not (player.PlayCardsLikeInTurn(faces, effect)):
            identity.TakeDamage(this, 1, effect)
            return
    return [*AbilityFactory.GiveKeywordToAttached('You', trait='ENTHRALLED'), AbilityFactory.WhenThisRevealed(None, trance_of_greed_revealed), AbilityFactory.WhenInYourPlayTurn(AbilityType.ForcedAction, trance_of_greed).SetCostFunc(CostFunc.Exhaust('This'))]
