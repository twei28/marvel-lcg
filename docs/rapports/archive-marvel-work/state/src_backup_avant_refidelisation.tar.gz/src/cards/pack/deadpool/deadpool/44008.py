# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def chimichanga_truck(effect: Effect, message: Message.AfterUnitRecovery):
        this = effect.this.CastTo(Support)
        Unused(this)
        Faces.ReadyAll(effect.targets, effect)
    return [AbilityFactory.AfterUnitMakeRecovery(AbilityType.Response, Identity, chimichanga_truck, is_basic_recovery=True).SetCostFunc(CostFunc.Exhaust('This')).SetTarget('Trigger')]
