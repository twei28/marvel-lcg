# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def prime_real_estate(effect: Effect, message: Message.WhenCardWouldBePlacedCounter):
        this = effect.this.CastTo(MainScheme)
        Unused(this)
        message.SetBeInstead(effect)
        this.PlaceThreatOnSchemes([this], 1, effect)
    return [AbilityFactory.WhenCardWouldBePlacedCounter(AbilityType.ForcedInterrupt, CardFinder(trait='ENCHANTMENT'), 'charm', prime_real_estate, conditions=[lambda effect, message: message.trigger.card.area.GetOwnerPlayer().GetIdentity().HasTrait('ENTHRALLED')])]
