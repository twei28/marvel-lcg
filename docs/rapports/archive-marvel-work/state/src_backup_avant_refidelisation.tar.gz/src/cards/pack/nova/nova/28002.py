# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def ms_marvel(effect: Effect, message: Message.AfterPlayerPlayedCard):
        this = effect.this.CastTo(Ally)
        Unused(this)
        initiator = effect.GetInitiator()
        Faces.ReturnToHand(effect.targets, initiator, effect)
    return [AbilityFactory.AfterPlayerPlayedCard(AbilityType.HeroResponse, 'You', Event, ms_marvel).SetCostFunc(CostFunc.Exhaust('This')).SetCostFunc(CostFunc.DealDamage(1, 'This')).SetTarget('PlayedCard', from_where=['YourDiscardPile'])]
