# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def hypnotic_gaze(effect: Effect, message: Message.AfterCardPlacedCounter):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        Faces.RemoveCountersOn([this], 'All', 'charm', effect)
        this.card.Flip(effect)
    return [*AbilityFactory.GiveKeywordToAttached('You', trait='DEFIANT'), AbilityFactory.IfThereAreAtLeastCounterHere(5, 'charm', hypnotic_gaze)]
