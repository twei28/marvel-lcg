# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def stick_to_itiveness(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        Faces.ReadyAll(effect.targets, effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, stick_to_itiveness).SetCost(Cost('R')).SetCostFunc(CostFunc.Exhaust('This')).SetTarget('YourHero', canbe_ready=True)]
