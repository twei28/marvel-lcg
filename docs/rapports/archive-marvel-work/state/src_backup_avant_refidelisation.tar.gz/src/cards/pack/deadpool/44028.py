# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def git_gud(effect: Effect, message: Message.WhenUnitWouldBeDefeated):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        message.SetBeInstead(effect)
        identity = message.trigger.CastTo(Identity)
        identity.SetHealth(1, effect)
        identity.ChangeToForm(AlterEgo, effect)
        Faces.RemoveAllFromGame([this], effect)
    return [AbilityFactory.WhenUnitWouldBeDefeated(AbilityType.ForcedInterrupt, Identity, git_gud)]
