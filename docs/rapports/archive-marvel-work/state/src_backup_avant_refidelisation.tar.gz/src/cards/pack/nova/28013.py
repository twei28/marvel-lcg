# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def no_quarter(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        initiator = effect.GetInitiator()
        def action(num):
            faces = initiator.DiscardDeckTopCards(num, effect)
            aggression = []
            for face in faces:
                if ClassCard.IsType(face):
                    if face.IsClass('Aggression'):
                        aggression.append(face)
            initiator.GainCard(aggression, effect)
        this.DealDamage(effect.targets, 4, effect, if_this_attack_deal_excess_damage=action)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, no_quarter).SetPlay().SetLabel('attack').SetTarget(Enemy)]
