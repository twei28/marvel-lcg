# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def deadpool_corps_ship(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Support)
        Unused(this)
        initiator = effect.GetInitiator()
        ally = effect.targets[0].CastTo(Ally)
        ally.PutIntoPlay(initiator, effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.Action, deadpool_corps_ship).SetCostFunc(CostFunc.Exhaust('This')).SetCostFunc(CostFunc.DealPlayerEncounterCard(1, 'Initiator')).SetTarget(Ally, card_class="'Pool", from_where=['YourHandCards'])]
