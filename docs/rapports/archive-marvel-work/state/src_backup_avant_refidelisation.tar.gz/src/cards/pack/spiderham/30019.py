# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def overwatch(effect: Effect, message: Message.AfterSchemeRemoveThreat):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        value = message.value
        this.RemoveThreatFromSchemes(effect.targets, value, effect)
    return [AbilityFactory.CanPlayThisUpgradeCard(Scheme2), AbilityFactory.AfterSchemeRemoveThreat(AbilityType.HeroInterrupt, 'AttachedScheme', overwatch, by_thwart=True).SetCostFunc(CostFunc.Discard('This')).SetTarget(Scheme2, check_fn=lambda effect, face: (face != effect.this.GetBindFace()))]
