# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def the_trickster_tango_boost(effect: Effect, message: Message.WhenCardBecomeBoost):
        this = effect.this.CastTo(EncounterSideScheme)
        Unused(this)
        message.would_atk_message.GainOverKill(effect)
    return [*AbilityFactory.GiveKeywordToInPlayWhenApplyThis(Villain, stalwart=1), AbilityFactory.WhenCardBecomeBoost('This', the_trickster_tango_boost, during_attack=True)]
