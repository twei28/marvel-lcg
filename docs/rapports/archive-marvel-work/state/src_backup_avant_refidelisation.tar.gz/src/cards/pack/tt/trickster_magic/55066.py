# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def zzzax(effect: Effect, message: Message.AfterCardEnterPlay):
        this = effect.this.CastTo(Ally)
        Unused(this)
        initiator = effect.GetInitiator()
        face = Search.PlayerDeckTop(effect, initiator, 5, finder=CardFinder(has_printed_res='Y'))
        if face:
            Faces.AddToHand([face], initiator, effect)
            return
    return [*AbilityFactory.ThisNotCountAllyLimit(), AbilityFactory.AfterCardEnterPlay(AbilityType.Response, 'This', zzzax)]
