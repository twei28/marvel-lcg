# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def wade_wilson(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(AlterEgo)
        Unused(this)
        initiator = effect.GetInitiator()
        face = Search.PlayerCard(effect, initiator, include_player_deck=True, card_class='IdentitySpecific', card_type=Event)
        if face:
            initiator.GainCard(face, effect)
            return
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.Action, wade_wilson).SetName('Break the Fourth Wall').SetCostFunc(CostFunc.Discard('YourHandCards')).LimitOncePerRound()]
