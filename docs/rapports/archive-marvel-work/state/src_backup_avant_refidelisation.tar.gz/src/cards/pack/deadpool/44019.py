# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def da_bomb(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        this.DealDamage(effect.targets, 10, effect)
        units = Worlds.GetOnFieldEnemies(effect)
        damage = Worlds.GetIconsNum(effect, [*('Crisis', 'Acceleration', 'Amplify', 'Hazard')])
        this.DealDamage(units, damage, effect)
        for unit in Worlds.GetOnFieldHeroes(effect):
            unit.TakeDamage(this, damage, effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, da_bomb).SetPlay().SetLabel().SetTarget(Villain)]
