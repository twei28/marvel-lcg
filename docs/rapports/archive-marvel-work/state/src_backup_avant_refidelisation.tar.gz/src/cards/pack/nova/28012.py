# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def pitchback(effect: Effect, message: Message.AfterUnitAttackEnd):
        this = effect.this.CastTo(Event)
        Unused(this)
        this.DealDamage(effect.targets, 4, effect)
    return [AbilityFactory.AfterUnitAttackEnd(AbilityType.HeroResponse, 'YourHero', pitchback).SetPlay(only_if_your_identity_has_trait='AERIAL').SetLabel('attack').SetTarget(Enemy)]
