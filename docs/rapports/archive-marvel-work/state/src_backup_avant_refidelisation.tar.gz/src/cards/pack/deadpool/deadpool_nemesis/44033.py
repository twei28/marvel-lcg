# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def butler_boost(effect: Effect, message: Message.WhenCardBecomeBoost):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetToPlayer()
        Faces.GiveStatus([player.GetIdentity()], 'Confused', effect)
    return [AbilityFactory.PlaceThreatOnCardWhenThisScheme(AbilityType.ForcedInterrupt, CardFinder(name='Involuntary Procedures'), if_able=True), AbilityFactory.WhenCardBecomeBoost('This', butler_boost)]
