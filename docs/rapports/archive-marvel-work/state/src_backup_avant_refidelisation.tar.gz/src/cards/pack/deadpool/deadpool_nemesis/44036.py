# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def mutated_soldier_boost(effect: Effect, message: Message.AfterEnemyActivationEnd):
        this = effect.this.CastTo(Minion)
        Unused(this)
        this.HealHealth(this.sustained, effect)
    return [AbilityFactory.AfterEnemyActivationEnd(AbilityType.ForcedResponse, 'This', mutated_soldier_boost)]
