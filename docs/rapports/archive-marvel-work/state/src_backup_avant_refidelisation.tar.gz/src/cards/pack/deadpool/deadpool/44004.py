# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def maximum_effort(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        damage = effect.cost_func.Get(CostFunc.TakeDamageUpToHealth).return_damage
        this.DealDamage(effect.targets, damage, effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, maximum_effort).SetPlay().SetLabel('attack').SetTarget(Enemy).SetCostFunc(CostFunc.TakeDamageUpToHealth('YourHero'))]
