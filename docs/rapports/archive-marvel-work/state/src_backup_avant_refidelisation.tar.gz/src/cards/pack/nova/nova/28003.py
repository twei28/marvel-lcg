# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def forcefield_projection(effect: Effect, message: Message.WhenUnitWouldTakeDamage):
        this = effect.this.CastTo(Event)
        Unused(this)
        initiator = effect.GetInitiator()
        message.PreventDamage(3, effect)
        if effect.GetPaidResources().HasColor('G'):
            initiator.ChooseAbilities(effect, AbilityFactory.ForChoiceAbility('', lambda targets: this.DealDamage(targets, 3, effect)).SetTarget(Enemy))
            return
    return [AbilityFactory.WhenUnitWouldTakeDamage(AbilityType.HeroInterrupt, Friend, forcefield_projection, is_from_attack=True).SetPlay().SetLabel()]
