# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def law_of_attraction_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(EncounterSideScheme)
        Unused(this)
        player = message.GetToPlayer()
        minion = Worlds.DiscardEncounterCardsUntil(effect, trait='ENTHRALLED', card_type=Minion)
        if minion:
            minion.Reveal(player, effect)
            return
    def law_of_attraction_boost(effect: Effect, message: Message.WhenCardBecomeBoost):
        this = effect.this.CastTo(EncounterSideScheme)
        Unused(this)
        player = message.GetToPlayer()
        PlaceCharmCounter(player, 1, effect)
    return [AbilityFactory.WhenThisRevealed(None, law_of_attraction_revealed), AbilityFactory.WhenCardBecomeBoost('This', law_of_attraction_boost)]
