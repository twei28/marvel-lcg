# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def deadpool(effect: Effect, message: Message.WhenUnitWouldBeDefeated):
        this = effect.this.CastTo(Hero)
        Unused(this)
        message.SetBeInstead(effect)
        this.SetHealth(1, effect)
        this.ChangeToForm(AlterEgo, effect)
        scheme = Worlds.FindMainScheme(this)
        if scheme:
            scheme.PlaceAccelerationToken(1, effect)
            return
    return [AbilityFactory.WhenUnitWouldBeDefeated(AbilityType.ForcedInterrupt, 'This', deadpool).SetName("The Regeneratin' Degenerate")]
