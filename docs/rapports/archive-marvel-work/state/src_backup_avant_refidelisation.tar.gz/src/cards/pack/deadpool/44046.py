# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def break_time(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        this.HealthUnits(effect.targets, 'All', effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.AlterEgoAction, break_time).SetPlay().SetLabel().SetTarget(Identity, range='All', canbe_heal=True)]
