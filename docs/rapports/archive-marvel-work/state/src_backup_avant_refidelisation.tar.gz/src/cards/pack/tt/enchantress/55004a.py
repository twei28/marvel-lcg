# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def prime_real_estate(effect: Effect, message: Message.WhenCardSetup):
        this = effect.this.CastTo(MainScheme)
        Unused(this)
        def action(player: Player):
            SetupCards.AttachTo(effect, attach_to=player.GetIdentity(), finder=CardFinder(name='Hypnotic Gaze'), include_in_play=False, choose='Random')
        Players.ForEachPlayer(effect, action)
    return [AbilityFactory.WhenCardSetup('This', prime_real_estate)]
