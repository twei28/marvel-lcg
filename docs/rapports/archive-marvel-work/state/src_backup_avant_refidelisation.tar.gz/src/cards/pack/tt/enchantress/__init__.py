# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from cards.pack import *
def PlaceCharmCounter(player, size, effect):
    faces = Filter.ByFinder(player.GetPlayerAreaCards(), CardFinder(trait='ENCHANTMENT'))
    Faces.PlaceCountersOn(faces, size, 'charm', effect)
def AfterEnchantressAttacksYouPlaceCharmCounter() -> Ability:
    def enchantress(effect: Effect, message: Message.AfterUnitAttackEnd):
        this = effect.this.CastTo(EncounterVillain)
        Unused(this)
        player = message.GetAgainstPlayer()
        if player:
            PlaceCharmCounter(player, 1, effect)
            return
    return AbilityFactory.AfterUnitAttackYou(AbilityType.ForcedResponse, 'This', enchantress)
