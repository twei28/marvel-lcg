# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def solus_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Minion)
        Unused(this)
        if Worlds.FindCardOnField(effect, CardFinder2('WEB-WARRIOR', Unit2)):
            Faces.GiveFacedownBoostCards([this], 1, effect)
            return
    return [*AbilityFactory.GiveKeywordToInPlayWhenApplyThis(CardFinder2('INHERITOR', Minion), villainous=1), AbilityFactory.WhenThisRevealed(None, solus_revealed)]
