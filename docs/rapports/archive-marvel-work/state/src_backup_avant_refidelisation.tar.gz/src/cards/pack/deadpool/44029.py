# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def healing_factor(effect: Effect, message: Message.AfterPhaseBegin):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        this.HealthUnits(effect.targets, 2, effect)
    return [AbilityFactory.AfterPlayerPhaseBegin(AbilityType.Response, healing_factor).SetTarget('YourIdentity', canbe_heal=True).SetCostFunc(CostFunc.Exhaust('This'))]
