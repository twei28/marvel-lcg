# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def barely_a_scratch(effect: Effect, message: Message.WhenUnitWouldTakeDamage):
        this = effect.this.CastTo(Event)
        Unused(this)
        value = Worlds.GetIconsNum(effect, [*('Crisis', 'Acceleration', 'Amplify', 'Hazard')])
        message.PreventDamage(value, effect)
    return [AbilityFactory.WhenUnitWouldTakeDamage(AbilityType.HeroInterrupt, 'You', barely_a_scratch, is_from_attack=True, conditions=[lambda effect, message: (Worlds.GetIconsNum(effect, [*('Crisis', 'Acceleration', 'Amplify', 'Hazard')]) > 0)]).SetPlay().SetLabel('defense')]
