# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def minotaur_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetToPlayer()
        faces = Worlds.GetEncounterDiscardPileCards(effect, CardFinder(card_type=Treachery))
        if (len(faces) >= 5):
            this.DoActivate(player, effect)
            return
    return [AbilityFactory.WhenThisRevealed(None, minotaur_revealed), WhenDefeatedPlaceShatterCountersOnTheAvatarOfLokivillain(2)]
