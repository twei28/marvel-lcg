# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def karn_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetToPlayer()
        if Worlds.FindCardOnField(effect, CardFinder2('WEB-WARRIOR', Unit2)):
            player.DiscardControlCards(effect, upgrade=True, support=True)
            return
    return [AbilityFactory.UnitAttackGainKeyword(CardFinder2('INHERITOR', Minion), overkill=True, piercing=True), AbilityFactory.WhenThisRevealed(None, karn_revealed)]
