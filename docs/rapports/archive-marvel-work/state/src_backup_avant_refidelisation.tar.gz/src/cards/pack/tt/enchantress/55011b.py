# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def trance_of_wrath_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        player = message.GetToPlayer()
        face = Search.EncounterCardTop(effect, player, 5)
        if face:
            face.Reveal(player, effect)
            return
    def trance_of_wrath(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        player = message.GetToPlayer()
        identity = player.GetIdentity()
        identity.TakeIndirectDamage(this, 1, effect)
        this.DealDamage(effect.targets2, 2, effect)
    return [*AbilityFactory.GiveKeywordToAttached('You', trait='ENTHRALLED'), AbilityFactory.WhenThisRevealed(None, trance_of_wrath_revealed), AbilityFactory.WhenInYourPlayTurn(AbilityType.ForcedAction, trance_of_wrath).SetCostFunc(CostFunc.Exhaust('This')).SetTarget('This').SetTarget2(Minion)]
