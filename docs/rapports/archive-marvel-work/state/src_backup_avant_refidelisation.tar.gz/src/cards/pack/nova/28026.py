# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def yaw_and_roll(effect: Effect, message: Message.AfterUnitThwartEnd):
        this = effect.this.CastTo(Event)
        Unused(this)
        this.RemoveThreatFromSchemes(effect.targets, 3, effect)
    return [AbilityFactory.AfterUnitThwartEnd(AbilityType.HeroResponse, 'YourHero', yaw_and_roll).SetPlay(only_if_your_identity_has_trait='AERIAL').SetLabel('thwart').SetTarget(Scheme2)]
