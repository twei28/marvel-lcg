# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def pool_inspection(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        value = Worlds.GetIconsNum(effect, [*('Crisis', 'Acceleration', 'Amplify', 'Hazard')])
        this.RemoveThreatFromSchemes(effect.targets, 5, effect)
        this.RemoveThreatFromSchemes('EachScheme', value, effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, pool_inspection).SetPlay().SetLabel('thwart').SetTarget(MainScheme).SetIgnoreKeyword('Crisis')]
