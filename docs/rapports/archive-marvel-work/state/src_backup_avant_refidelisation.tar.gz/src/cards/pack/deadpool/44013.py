# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def dogpool(effect: Effect, message: Message.WhenUnitBeDefeated):
        this = effect.this.CastTo(Ally)
        Unused(this)
        this.DealDamage(effect.targets, 1, effect)
    return [AbilityFactory.WhenUnitBeDefeated(AbilityType.WhenDefeated, 'This', dogpool).SetTarget(Enemy)]
