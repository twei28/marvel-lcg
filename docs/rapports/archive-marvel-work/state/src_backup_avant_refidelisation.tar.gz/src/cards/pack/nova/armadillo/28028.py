# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    return [*AbilityFactory.GiveKeywordToInPlayWhenApplyThis(CardFinder(card_type=Enemy, with_tough=True), attack=3, change_on_event=OnEvent.Status(Enemy, 'Tough'))]
