# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def self_confidence(effect: Effect, message: Message.CheckPlayerCanPayCost) -> Resources|None:
        this = effect.this.CastTo(Resource)
        Unused(this)
        initiator = effect.GetInitiator()
        res = FacesCounter.GetPrintedResources([this])
        if (initiator.GetIdentity().sustained == 0):
            res = (res * 3)
            return res
        if (initiator.GetIdentity().sustained < 5):
            res = (res * 2)
        return res
    return [AbilityFactory.CheckThisCanDropPay(self_confidence)]
