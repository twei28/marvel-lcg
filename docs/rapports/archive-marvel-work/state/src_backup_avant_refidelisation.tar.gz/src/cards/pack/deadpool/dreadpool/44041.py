# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def pool_ized(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        allies = Worlds.GetOnFieldAllies(effect, CardFinder(not_with_attach=CardFinder(name="'Pool-ized")))
        ally = Filter.One(allies, effect, highest_cost=True)
        if ally:
            this.AttachTo2(ally, effect)
            return
        ThisCardGainSurge(effect)
    return [AbilityFactory.TreatAttachedCardAsMinion(Ally, "'Pool Minion"), AbilityFactory.WhenThisRevealed(None, pool_ized)]
