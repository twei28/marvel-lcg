# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def metaknowledge(effect: Effect, message: Message.WhenPlayerRevealCard):
        this = effect.this.CastTo(Event)
        Unused(this)
        initiator = effect.GetInitiator()
        message.CancelAllEffectsAndDiscardIt(effect)
        face = message.trigger
        damage = (FacesCounter.CountTotalBoostIcons([face]) + FacesCounter.CountTotalBoostStar([face]))
        initiator.GetIdentity().TakeDamage(this, damage, effect)
    return [AbilityFactory.WhenPlayerRevealCard(AbilityType.HeroInterrupt, 'AnyPlayer', EncounterCard, 'All', metaknowledge).SetPlay().SetLabel()]
