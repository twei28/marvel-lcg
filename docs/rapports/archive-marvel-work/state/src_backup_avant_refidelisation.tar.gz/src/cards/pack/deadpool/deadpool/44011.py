# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    return [AbilityFactory.CanPlayThisUpgradeCard(MainScheme), *AbilityFactory.GiveKeywordToAttached(MainScheme, get_new_value=lambda effect, attach, ui: attach.acceleration_token, target_threat=2, ex_change_on_event=OnEvent.AccelerationToken('AttachedScheme'))]
