# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def enchantress_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(EncounterVillain)
        Unused(this)
        if Worlds.IsStandard(effect):
            face = SetupCards.PutIntoPlay(effect, name='Future of Despair', from_where=['SetAside'])
            if face:
                this.PlaceThreatOnSchemes([face], '3*', effect)
                return
                return
    return [AbilityFactory.WhenThisRevealed(None, enchantress_revealed), AfterEnchantressAttacksYouPlaceCharmCounter()]
