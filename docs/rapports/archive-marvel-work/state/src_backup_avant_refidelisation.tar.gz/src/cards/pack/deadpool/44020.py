# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def get_rage_y(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        Faces.ReadyAll(effect.targets, effect)
        for target in effect.targets:
            target.GainUntilPhaseEnd(effect, attack=1)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.Action, get_rage_y).SetPlay().SetLabel().SetTarget(Ally, canbe_ready=True)]
