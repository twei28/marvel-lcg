# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def deadpools_katana(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        initiator = effect.GetInitiator()
        hero = initiator.GetIdentity()
        hero.DealDamage(effect.targets, 2, effect, property=AttackProperty(piercing=True))
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, deadpools_katana).SetLabel('attack').SetTarget(Enemy).SetCostFunc(CostFunc.Exhaust('This')).SetCostFunc(CostFunc.TakeDamage(1, 'YourIdentity'))]
