# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def the_mangog_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Minion)
        Unused(this)
    def the_mangog_boost(effect: Effect, message: Message.WhenCardBecomeBoost):
        this = effect.this.CastTo(Minion)
        Unused(this)
    return [AbilityFactory.WhenThisRevealed(None, the_mangog_revealed), AbilityFactory.WhenCardBecomeBoost('This', the_mangog_boost)]
