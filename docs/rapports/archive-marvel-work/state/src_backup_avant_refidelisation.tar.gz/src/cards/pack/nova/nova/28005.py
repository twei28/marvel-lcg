# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def pot_shot(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        this.DealDamage(effect.targets, 4, effect)
    return [AbilityFactory.UpdateResourcesGeneratedWhilePlayingThis(color='G', update_rule='Double'), AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, pot_shot).SetPlay().SetLabel('attack').SetTarget(Enemy)]
