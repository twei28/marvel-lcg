# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def bazooka(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        damage = Worlds.GetIconsNum(effect, [*('Crisis', 'Acceleration', 'Amplify', 'Hazard')])
        this.DealDamage(effect.targets, damage, effect, property=AttackProperty(ranged=True))
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, bazooka).SetLabel('attack').SetCostFunc(CostFunc.Discard('This')).SetTarget(Enemy)]
