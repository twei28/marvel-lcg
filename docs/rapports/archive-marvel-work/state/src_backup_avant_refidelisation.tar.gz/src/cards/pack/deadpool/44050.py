# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def plot_convenience(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Support)
        Unused(this)
        initiator = effect.GetInitiator()
        for target in effect.targets:
            if target.card.IsInHand():
                this.PlaceCardHere(target, False, effect)
            if (target.card.area == this.GetPlacedCardArea()):
                initiator.GainCard(target, effect)
    def plot_convenience_select(effect):
        faces = effect.this.GetPlacedCardArea().Get()
        if (len(faces) >= 3):
            return faces
        faces = (faces + CardFinder(card_class='Aspect').Checks(effect.GetInitiator().hand_cards.Get()))
        return faces
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.Action, plot_convenience).SetCostFunc(CostFunc.Exhaust('This')).SetTarget(plot_convenience_select).AnyPlayerCanDoThis()]
