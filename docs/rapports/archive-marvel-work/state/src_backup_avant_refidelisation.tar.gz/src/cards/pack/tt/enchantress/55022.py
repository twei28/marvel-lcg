# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def spellbound_defeated(effect: Effect, message: Message.WhenSchemeBeDefeated):
        this = effect.this.CastTo(EncounterSideScheme)
        Unused(this)
        def action(player: Player):
            if player.GetIdentity().HasTrait('DEFIANT'):
                PlaceCharmCounter(player, 1, effect)
            if player.GetIdentity().HasTrait('ENTHRALLED'):
                player.DiscardControlCards(effect)
                return
        Players.ForEachPlayer(effect, action)
    return [AbilityFactory.WhenSchemeBeDefeated(AbilityType.WhenDefeated, 'This', spellbound_defeated)]
