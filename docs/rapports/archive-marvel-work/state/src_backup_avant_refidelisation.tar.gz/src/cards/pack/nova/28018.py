# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def moon_girl(effect: Effect, message: Message.AfterPlayerPlayedCard):
        this = effect.this.CastTo(Ally)
        Unused(this)
        for target in effect.targets:
            player = target.GetControlByPlayer()
            value = message.paid_resources.GetColor('B')
            player.DrawUp(value, effect)
    return [AbilityFactory.CanPlayThisAllyCard().SetPlay(only_if_your_identity_has_one_of_traits=['CHAMPION', 'GENIUS']), AbilityFactory.AfterYouPlayThisFromHand(AbilityType.Response, moon_girl).SetTarget('Initiator')]
