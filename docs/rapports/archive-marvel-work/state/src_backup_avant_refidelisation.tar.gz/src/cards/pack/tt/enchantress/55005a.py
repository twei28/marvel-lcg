# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def sovereign_sorceress_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(MainScheme)
        Unused(this)
        player = message.GetToPlayer()
        face = Worlds.FindCardOnField(effect, name='Crown of the Enchantress', card_type=Attachment)
        if face:
            identities = Worlds.GetPlayersIdentities(effect)
            Faces.GiveStatus(identities, 'Stunned', effect)
            return
        face = Search.EncounterCard(effect, player, include_discard_pile=True, name='Crown of the Enchantress')
        if face:
            face.Reveal(player, effect)
            return
    return [AbilityFactory.WhenThisRevealed(None, sovereign_sorceress_revealed)]
