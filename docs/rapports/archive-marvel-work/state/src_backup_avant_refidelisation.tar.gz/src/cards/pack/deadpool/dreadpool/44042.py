# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def metacidal_tendencies_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Treachery)
        Unused(this)
        faces = Worlds.FindCardsOnField(effect, trait='DEADPOOL CORPS')
        if Worlds.FindCardOnField(effect, name='Dreadpool'):
            value = 3
        else:
            value = 2
        if not (this.DealDamage(faces, value, effect)):
            scheme = Worlds.FindMainScheme(effect)
            if scheme:
                scheme.PlaceAccelerationToken(1, effect)
                return
                return
    return [AbilityFactory.WhenThisRevealed(None, metacidal_tendencies_revealed)]
