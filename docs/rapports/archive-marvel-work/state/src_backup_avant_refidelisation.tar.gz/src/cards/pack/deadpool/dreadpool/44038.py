# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def dreadpool(effect: Effect, message: Message.WhenUnitBeDefeated):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetKillerPlayer()
        if player:
            player.DealEncounterCard(this, effect)
            return
    return [AbilityFactory.ThisMinionEngageFirstPlayer(), AbilityFactory.WhenUnitBeDefeated(AbilityType.WhenDefeated, 'This', dreadpool)]
