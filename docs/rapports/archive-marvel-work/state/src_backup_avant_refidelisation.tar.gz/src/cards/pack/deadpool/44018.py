# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def cutupper(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        this.DealDamage(effect.targets, 5, effect)
        Faces.GiveStatus(effect.targets, 'Stunned', effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, cutupper).SetPlay().SetLabel('attack').SetTarget(Enemy)]
