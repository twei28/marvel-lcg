# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def dreadful_deeds_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(EncounterSideScheme)
        Unused(this)
        value = len([player for player in Worlds.GetPlayers(effect) if player.IsControl(CardFinder(card_class="'Pool"))])
        this.PlaceThreatOnSchemes([this], (2 * value), effect)
    return [AbilityFactory.WhenThisRevealed(None, dreadful_deeds_revealed)]
