# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def nova(effect: Effect, message: Message.AfterUnitUseBasicPower):
        this = effect.this.CastTo(Hero)
        Unused(this)
        Faces.ReadyAll(effect.targets, effect)
    return [AbilityFactory.AfterUnitUseBasicPower(AbilityType.Response, 'This', nova, powers=[*('ATK', 'THW', 'DEF')]).SetTarget(name='Supernova Helmet', canbe_ready=True)]
