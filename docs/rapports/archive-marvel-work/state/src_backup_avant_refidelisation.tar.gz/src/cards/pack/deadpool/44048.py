# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def mulligan(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        initiator = effect.GetInitiator()
        initiator.DiscardAllHands(effect)
        initiator.DrawUp(initiator.hand_size, effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.Action, mulligan).SetPlay(you_have_played_another_card_this_phase=False).SetLabel()]
