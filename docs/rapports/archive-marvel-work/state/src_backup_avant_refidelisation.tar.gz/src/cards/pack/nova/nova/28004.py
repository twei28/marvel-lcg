# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def lightspeed_flight(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Event)
        Unused(this)
        this.RemoveThreatFromSchemes(effect.targets, 3, effect)
    return [AbilityFactory.UpdateResourcesGeneratedWhilePlayingThis(color='G', update_rule='Double'), AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, lightspeed_flight).SetPlay().SetLabel('thwart').SetTarget(Scheme2)]
