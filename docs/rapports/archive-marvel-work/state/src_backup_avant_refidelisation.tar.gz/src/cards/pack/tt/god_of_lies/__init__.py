# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from cards.pack import *
def PlaceShatterCountersOnTheAvatarOfLokivillain(size):
    pass
def WhenDefeatedPlaceShatterCountersOnTheAvatarOfLokivillain(size, action = None):
    def grendell_defeated(effect: Effect, message: Message.WhenUnitBeDefeated):
        this = effect.this.CastTo(Minion)
        Unused(this)
        PlaceShatterCountersOnTheAvatarOfLokivillain(size)
        if action:
            action(effect, message)
            return
    return AbilityFactory.WhenUnitBeDefeated(AbilityType.WhenDefeated, 'This', grendell_defeated)
