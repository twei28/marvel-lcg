# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from cards.pack import *
def ThePlayerWhoDefeatedThisMinionPutsTheSetAsideAllyIntoPlayUnderTheirControl(name):
    def absorbing_man_defeated(effect: Effect, message: Message.WhenUnitBeDefeated):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetDefeatingPlayer()
        faces = Worlds.GetSetAsideAreaCards(effect, CardFinder(name=name, card_type=Ally))
        if faces:
            faces[0].PutIntoPlay(player, effect, under_control=True)
            return
    return AbilityFactory.WhenUnitBeDefeated(AbilityType.WhenDefeated, 'This', absorbing_man_defeated)
