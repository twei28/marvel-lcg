# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def warbringer(effect: Effect, message: Message.WhenUnitWouldAttack):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.property.against_player
        if player:
            damage = player.hand_cards.FindCardSize(CardFinder(has_printed_res='G'))
            this.GainForThisActive(effect, message, attack=damage)
            message.GainOverKill(effect)
            return
    return [AbilityFactory.WhenUnitAttackYou(AbilityType.ForcedInterrupt, 'This', warbringer)]
