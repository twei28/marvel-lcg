# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def magical_restraints_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Treachery)
        Unused(this)
        player = message.GetToPlayer()
        identity = player.GetIdentity()
        if not (identity.HasTrait('DEFIANT')):
            if not (identity.HasTrait('ENTHRALLED')):
                return
        def action(targets, status):
            Faces.GiveStatus(targets, status, effect)
            PlaceCharmCounter(player, 1, effect)
        if identity.HasTrait('ENTHRALLED'):
            pass
        else:
            pass
        UNKNOWN(player.ChooseAbilities, effect, AbilityFactory.ForChoiceAbility('You are stunned.', lambda targets: action(targets, 'Stunned')).SetTarget('YourIdentity', canbe_stunned=True), choose_x_different_options=AbilityFactory.ForChoiceAbility('You are confused.', lambda targets: action(targets, 'Confused')).SetTarget('YourIdentity', canbe_confused=True))
    return [AbilityFactory.WhenThisRevealed(None, magical_restraints_revealed)]
