# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def spell_blast_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Treachery)
        Unused(this)
        player = message.GetToPlayer()
        identity = player.GetIdentity()
        if not (identity.HasTrait('DEFIANT')):
            if not (identity.HasTrait('ENTHRALLED')):
                return
        def action_scheme(targets):
            enchantress = Worlds.FindCardOnField(effect, name='Enchantress', card_type=Enemy)
            if enchantress:
                if Worlds.IsExpert(effect):
                    pass
                else:
                    pass
        def action_attack(targets):
            enchantress = Worlds.FindCardOnField(effect, name='Enchantress', card_type=Enemy)
            if enchantress:
                if Worlds.IsExpert(effect):
                    pass
                else:
                    pass
        if identity.HasTrait('ENTHRALLED'):
            pass
        else:
            pass
        UNKNOWN(player.ChooseAbilities, effect, AbilityFactory.ForChoiceAbility('Enchantress schemes', action_scheme), choose_x_different_options=AbilityFactory.ForChoiceAbility('Enchantress attacks you', action_attack))
    return [AbilityFactory.WhenThisRevealed(None, spell_blast_revealed)]
