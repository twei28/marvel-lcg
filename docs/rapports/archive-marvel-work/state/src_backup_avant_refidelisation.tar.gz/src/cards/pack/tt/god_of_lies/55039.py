# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def malekith(effect: Effect, message: Message.AfterUnitAttackEnd):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetAgainstPlayer()
        face = Worlds.DiscardEncounterTopCard(effect)
        if Treachery.IsType(face):
            if player:
                player.DealEncounterCard(face, effect)
                return
                return
    return [AbilityFactory.AfterUnitAttackYou(AbilityType.ForcedResponse, 'This', malekith), WhenDefeatedPlaceShatterCountersOnTheAvatarOfLokivillain(2)]
