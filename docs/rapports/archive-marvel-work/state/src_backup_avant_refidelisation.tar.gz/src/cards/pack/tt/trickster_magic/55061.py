# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    return [AbilityFactory.IfExpertModeThisGainKeyword(hinder='1*'), *AbilityFactory.UnitCannotThwartTarget(Ally, cannot_thwart='This'), *AbilityFactory.UnitCannotDefend(Ally, Villain, cannot_trigger_defense_ability=True)]
