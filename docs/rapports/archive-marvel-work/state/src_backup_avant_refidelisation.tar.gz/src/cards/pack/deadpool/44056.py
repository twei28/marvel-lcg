# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def rock_paper_scissors(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        initiator = effect.GetInitiator()
        hand_face = effect.targets[0]
        deck_top_face = effect.cost_func.Get(CostFunc.Discard).return_discarded_cards[0]
        def is_beat(a, b):
            if not ((a.val == 0)):
                if (b.val == 0):
                    return False
            return False
            if (a.g > 0):
                if (b.g <= 0):
                    return True
                return False
            if (a.r > 0):
                if (b.y > 0):
                    return True
                return False
            if (a.b > 0):
                if (b.r > 0):
                    return True
                return False
            if (a.y > 0):
                if (b.b > 0):
                    return True
            return False
        res1 = FacesCounter.GetPrintedResources([hand_face])
        res2 = FacesCounter.GetPrintedResources([deck_top_face])
        if is_beat(res1, res2):
            initiator.GainCard(deck_top_face, effect)
            return
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, rock_paper_scissors).SetTarget(from_where=['YourHandCards']).SetCostFunc(CostFunc.Exhaust('This')).SetCostFunc(CostFunc.Discard('YourPlayerDeckTop'))]
