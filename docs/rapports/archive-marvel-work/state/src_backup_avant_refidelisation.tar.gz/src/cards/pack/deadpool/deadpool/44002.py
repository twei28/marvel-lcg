# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def get_acceleration_token(effect, ui):
        this = effect.this.CastTo(Ally)
        schemes = Worlds.GetAllMainSchemes(effect)
        schemes = [x for x in schemes if (x.card.game_area == this.card.game_area)]
        if schemes:
            value = Math.MaxAndIndex([x.acceleration_token for x in schemes])[0]
            index = Math.MaxAndIndex([x.acceleration_token for x in schemes])[1]
            if (value > 0):
                scheme = schemes[index]
                ui.append(scheme)
        else:
            value = 0
        return min(3, value)
    return [AbilityFactory.ThisGainKeyword(get_acceleration_token, thwart=1, attack=1, change_on_event=OnEvent.AccelerationToken(MainScheme))]
