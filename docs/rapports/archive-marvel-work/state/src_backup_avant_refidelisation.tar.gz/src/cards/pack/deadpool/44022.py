# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def not_my_responsibility(effect: Effect, message: Message.WhenSchemeWouldPlaceThreat):
        this = effect.this.CastTo(Event)
        Unused(this)
        message.SetBeInstead(effect)
        value = message.value
        effect.targets[0].CastTo(((Hero | Ally) | AlterEgo)).TakeDamage(this, value, effect)
    return [AbilityFactory.WhenThreatWouldBePlacedOn(AbilityType.Interrupt, None, not_my_responsibility).SetPlay().SetLabel().SetTarget('YouControlUnit', finder=CardFinder(card_type=(Identity | Ally)))]
