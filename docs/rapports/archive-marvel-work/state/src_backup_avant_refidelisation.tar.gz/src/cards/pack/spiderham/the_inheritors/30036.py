# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def morlun_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetToPlayer()
        if Worlds.FindCardOnField(effect, CardFinder2('WEB-WARRIOR', Unit2)):
            player.GetIdentity().TakeDamage(this, 2, effect)
            return
    return [*AbilityFactory.GiveKeywordToInPlayWhenApplyThis(CardFinder2('INHERITOR', Minion), attack=1), AbilityFactory.WhenThisRevealed(None, morlun_revealed)]
