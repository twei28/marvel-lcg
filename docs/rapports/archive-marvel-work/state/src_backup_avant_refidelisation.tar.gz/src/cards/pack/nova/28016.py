# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def fluid_motion(effect: Effect, message: Message.AfterPlayerPlayedCard):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        initiator = effect.GetInitiator()
        hero = initiator.GetHero()
        hero.GainUntilPhaseEnd(effect, attack=1)
    return [AbilityFactory.AfterPlayerPlayedCard(AbilityType.HeroResponse, 'You', CardFinder2('ATTACK', Event), fluid_motion).SetCostFunc(CostFunc.Exhaust('This')).SetTarget('YourHero').LimitOncePerEvent()]
