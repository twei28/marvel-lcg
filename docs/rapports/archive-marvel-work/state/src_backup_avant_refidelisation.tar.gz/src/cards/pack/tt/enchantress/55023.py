# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def do_my_bidding_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Treachery)
        Unused(this)
        player = message.GetToPlayer()
        identity = player.GetIdentity()
        if not (identity.HasTrait('DEFIANT')):
            if not (identity.HasTrait('ENTHRALLED')):
                return
        def action(card_type):
            face = Search.EncounterCard(effect, player, include_discard_pile=True, card_type=card_type)
            if face:
                face.Reveal(player, effect)
                return
        if identity.HasTrait('ENTHRALLED'):
            pass
        else:
            pass
        UNKNOWN(player.ChooseAbilities, effect, AbilityFactory.ForChoiceAbility('Search the encounter deck and discard pile for a minion and reveal it.', lambda targets: action(Minion)), choose_x_different_options=AbilityFactory.ForChoiceAbility('Search the encounter deck and discard pile for a side scheme and reveal it.', lambda targets: action(SchemeSide2)))
    return [AbilityFactory.WhenThisRevealed(None, do_my_bidding_revealed)]
