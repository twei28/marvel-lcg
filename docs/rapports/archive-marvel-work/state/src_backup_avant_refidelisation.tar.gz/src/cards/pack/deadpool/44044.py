# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def negasonic_teenage_warhead(effect: Effect, message: Message.WhenPlayerRevealCard):
        this = effect.this.CastTo(Ally)
        Unused(this)
        message.CancelWhenRevealedEffect(effect)
    return [AbilityFactory.WhenPlayerRevealCard(AbilityType.Interrupt, 'AnyPlayer', Treachery, 'WhenRevealed', negasonic_teenage_warhead).SetCostFunc(CostFunc.DealDamage(2, 'This'))]
