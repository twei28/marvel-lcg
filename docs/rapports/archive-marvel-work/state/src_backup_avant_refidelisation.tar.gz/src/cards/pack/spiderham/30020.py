# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def scarlet_spider(effect: Effect, message: Message.WhenCardWouldReveal):
        this = effect.this.CastTo(Ally)
        Unused(this)
        initiator = effect.GetInitiator()
        card_type = initiator.DeclareCardType()
        face = message.trigger
        if card_type.IsType(face):
            this.DealDamage([this], 1, effect)
            initiator.DrawUp(1, effect)
            return
    return [AbilityFactory.CanPlayThisAllyCard().SetPlay(only_if_you_control_trait='WEB-WARRIOR'), AbilityFactory.WhenCardWouldReveal(AbilityType.Interrupt, 'You', EncounterCard, scarlet_spider)]
