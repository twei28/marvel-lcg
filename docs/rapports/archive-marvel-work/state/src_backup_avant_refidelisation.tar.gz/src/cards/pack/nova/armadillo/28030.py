# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def rollin_rollin(effect: Effect, player: Player):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        armadillo = Search.EncounterCard(effect, player, include_discard_pile=True, name='Armadillo')
        if armadillo:
            armadillo.PutIntoPlay(player, effect)
            this.AttachTo2(armadillo, effect)
            return
    def rollin_rollin_condition(effect, message):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        return message.attacker.IsTough()
    return [AbilityFactory.AttachToFaceWhenPutIntoPlay(CardFinder(name='Armadillo'), if_cannot_operation=rollin_rollin), *AbilityFactory.UnitCannotDefend('Character', 'AttachedEnemy', cannot_trigger_defense_ability=True, conditions=[rollin_rollin_condition])]
