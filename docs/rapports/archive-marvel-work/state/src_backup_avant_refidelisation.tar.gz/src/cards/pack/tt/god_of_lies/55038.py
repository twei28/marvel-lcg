# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def grendell(effect: Effect, message: Message.WhenUnitWouldAttack):
        this = effect.this.CastTo(Minion)
        Unused(this)
        faces = Worlds.DiscardEncounterCards(3, effect)
        faces = Filter.ByType(faces, Treachery)
        this.GainForThisActive(effect, message, attack=len(faces))
    return [AbilityFactory.WhenUnitMakeAttack(AbilityType.ForcedInterrupt, 'This', grendell), WhenDefeatedPlaceShatterCountersOnTheAvatarOfLokivillain(3)]
