# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def sam_alexander(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(AlterEgo)
        Unused(this)
        initiator = effect.GetInitiator()
        face = Search.PlayerCard(effect, initiator, include_player_deck=True, include_discard_pile=True, name='Supernova Helmet', card_type=Upgrade)
        if face:
            if effect.GetPaidResources().HasColor('G'):
                face.PutIntoPlay(initiator, effect)
                return
            initiator.GainCard(face, effect)
            return
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.AlterEgoAction, sam_alexander).SetCost(Cost('1'))]
