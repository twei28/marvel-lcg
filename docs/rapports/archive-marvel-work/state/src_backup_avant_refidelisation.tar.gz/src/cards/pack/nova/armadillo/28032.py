# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def tough_it_out_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Treachery)
        Unused(this)
        units = []
        villain = Worlds.FindVillain(effect)
        if villain:
            units.append(villain)
        units = (units + Worlds.FindCardsOnField(effect, name='Armadillo'))
        if (Faces.GiveStatus(units, 'Tough', effect) <= 1):
            ThisCardGainSurge(effect)
            return
    return [AbilityFactory.WhenThisRevealed(None, tough_it_out_revealed)]
