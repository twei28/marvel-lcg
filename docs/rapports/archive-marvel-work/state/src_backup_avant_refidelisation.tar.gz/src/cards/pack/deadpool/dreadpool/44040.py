# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def anti_regeneration_ray(effect: Effect, message: Message.WhenUnitWouldAttackUnit):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        target = message.target
        target.TreatAsIfBlank(effect, message)
    def anti_regeneration_ray_action(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Attachment)
        Unused(this)
        player = message.GetToPlayer()
        identity = player.GetIdentity()
        this.AttachTo2(identity, effect)
    return [AbilityFactory.AttachToFaceWhenPutIntoPlay(CardFinder(name='Dreadpool'), if_cannot_attach_to=Villain), AbilityFactory.WhenUnitWouldAttackUnit(AbilityType.ForcedInterrupt, 'AttachedCharacter', CardFinder(non_card_type=Villain), anti_regeneration_ray), AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, anti_regeneration_ray_action).SetCost(Cost('YBR'))]
