# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def whirlwind(effect: Effect, message: Message.AfterUnitAttackEnd):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetAgainstPlayer()
        if player:
            identity = player.GetIdentity()
            faces = Worlds.GetSideSchemes(effect)
            identity.TakeIndirectDamage(this, len(faces), effect)
            return
    return [AbilityFactory.AfterUnitAttackYou(AbilityType.ForcedResponse, 'This', whirlwind), ThePlayerWhoDefeatedThisMinionPutsTheSetAsideAllyIntoPlayUnderTheirControl('Whirlwind')]
