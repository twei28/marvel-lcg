# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def the_wars_been_brought_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Treachery)
        Unused(this)
        player = message.GetToPlayer()
        value = 0
        value = (value + player.hand_cards.FindCardSize(CardFinder(has_printed_res='G')))
        value = (value + Faces.FindCardSize(player.GetControlCards(), CardFinder(has_printed_res='G')))
        value = (value + player.discard_pile.FindCardSize(CardFinder(has_printed_res='G')))
        Worlds.DiscardEncounterCards(value, effect)
    return [AbilityFactory.WhenThisRevealed(None, the_wars_been_brought_revealed)]
