# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    return [*AbilityFactory.GiveKeywordToAttached(Hero, trait='AERIAL'), AbilityFactory.CanGenerateResources(AbilityType.HeroResource, Resources('G')).SetCostFunc(CostFunc.Exhaust('This'))]
