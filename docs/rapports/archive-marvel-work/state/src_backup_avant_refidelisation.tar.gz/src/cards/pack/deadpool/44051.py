# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def ambush(effect: Effect, message: Message.WhenSchemeBeDefeated):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        Faces.DiscardAll(effect.targets, effect)
    return [AbilityFactory.CanPlayThisUpgradeCard(SchemeSide2), AbilityFactory.WhenSchemeBeDefeated(AbilityType.Interrupt, 'AttachedSideScheme', ambush).SetTarget(Minion, non_trait='ELITE')]
