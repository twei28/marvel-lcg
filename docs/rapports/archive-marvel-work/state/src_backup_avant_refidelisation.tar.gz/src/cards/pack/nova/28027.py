# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def height_advantage(effect: Effect, message: Message.WhenPlayerTurnBegin):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        Faces.DiscardAll([this], effect)
    return [AbilityFactory.WhenUnitWouldTakeDamage(AbilityType.NonKeyword, 'You', lambda effect, message: message.ReduceDamage(1, effect), is_from_attack=True, who_deal_damage=Enemy), AbilityFactory.WhenPlayerTurnBegin(AbilityType.ForcedInterrupt, 'You', height_advantage)]
