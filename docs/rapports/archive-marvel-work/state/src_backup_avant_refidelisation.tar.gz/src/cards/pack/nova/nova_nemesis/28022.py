# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def bring_the_war_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(EncounterSideScheme)
        Unused(this)
        def action(player):
            face = player.DiscardControlCards(effect, control=True, finder=CardFinder(has_printed_res='G'))
            if face:
                return [face]
            return []
        faces = Players.ForEachPlayer(effect, action, [])
        this.PlaceThreatOnSchemes([this], len(faces), effect)
    return [AbilityFactory.WhenThisRevealed(None, bring_the_war_revealed)]
