# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def headpool(effect: Effect, message: Message.AfterUnitAttackUnit):
        this = effect.this.CastTo(Ally)
        Unused(this)
        minion = message.attacked.CastTo(Minion)
        for target in effect.targets:
            enemy = target.CastTo(Enemy)
            minion.BasicAttack([enemy], effect)
    return [AbilityFactory.AfterUnitAttackAndDamageUnit(AbilityType.Response, 'This', Minion, headpool, target_in_play=True).SetTarget(Enemy, check_fn=lambda effect, face: (face != effect.GetBindMessage(Message.AfterUnitAttackUnit).attacked))]
