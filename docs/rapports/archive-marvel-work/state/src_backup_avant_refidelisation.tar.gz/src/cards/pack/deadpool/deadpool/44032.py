# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def the_merc_with_the_mouth(effect: Effect, message: Message.WhenObligationGiveToPlayer):
        this = effect.this.CastTo(Obligation)
        Unused(this)
        player = message.GetGaveToPlayer()
        Faces.ExhaustAll(player.GetControlAllies(), effect)
    def you_have_not_talked_this_phase(effect, message):
        return True
    return [AbilityFactory.WhenThisObligationGiveToYou(the_merc_with_the_mouth), AbilityFactory.WhenCardWouldReady(AbilityType.NonKeyword, Ally, lambda effect, message: message.SetBeInstead(effect), control_by='You'), AbilityFactory.PlayersCannotTriggerAbility('Other', None, on_which_card=PlayerCard, during='YourTurn'), AbilityFactory.WhenPlayerPhaseEnd(AbilityType.ForcedResponse, DiscardThisCard, conditions=[you_have_not_talked_this_phase])]
