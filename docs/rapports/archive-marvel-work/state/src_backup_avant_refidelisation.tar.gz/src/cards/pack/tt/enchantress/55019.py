# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def sindr_revealed(effect: Effect, message: Message.WhenCardRevealed):
        this = effect.this.CastTo(Minion)
        Unused(this)
        player = message.GetToPlayer()
        identity = player.GetIdentity()
        if identity.HasTrait('DEFIANT'):
            this.DoActivate(player, effect)
        if identity.HasTrait('ENTHRALLED'):
            Faces.GiveStatus([this], 'Tough', effect)
            return
    return [AbilityFactory.UnitAttackGainKeyword('This', indirect_damage=True), AbilityFactory.WhenThisRevealed(None, sindr_revealed)]
