# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def everyday_hero(effect: Effect, message: Message.AfterCardsBeSpendAsResource):
        this = effect.this.CastTo(Resource)
        Unused(this)
        this.HealthUnits(effect.targets, 1, effect)
    return [AbilityFactory.AfterYouSpendThisCard(AbilityType.Response, everyday_hero, conditions=[lambda effect, message: effect.this.GetOwnerPlayer().GetIdentity().HasTrait('CIVILIAN')]).SetTarget('ToPlayer', canbe_heal=True), AbilityFactory.CheckThisCanDropPay().AnyPlayerCanDoThis(owner_has_trait='CIVILIAN')]
