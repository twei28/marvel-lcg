# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    return [AbilityFactory.CanPlayThisUpgradeCard(NonEliteMinion), AbilityFactory.EnemyCannotActivate(AbilityType.NonKeyword, 'AttachedMinion')]
