# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def absorbing_man(effect: Effect, message: Message.WhenUnitWouldAttack|Message.WhenUnitWouldThwart):
        this = effect.this.CastTo(Ally)
        Unused(this)
        initiator = effect.GetInitiator()
        def action(targets):
            Faces.ExhaustAll(targets, effect)
            face = targets[0]
            if HasCost.IsType(face):
                value = min(3, face.printed_cost.val)
            else:
                value = 0
            if isinstance(message, Message.WhenUnitWouldAttack):
                message.GainATKForThisAttack(value, effect)
                return
            message.GainTHWForThisThwart(value, effect)
        initiator.ChooseAbilities(effect, AbilityFactory.ForChoiceAbility('', action).SetTarget('Upgrade|Support', canbe_exhaust=True))
    return [*AbilityFactory.ThisNotCountAllyLimit(), AbilityFactory.WhenUnitWouldAttackOrThwart(AbilityType.Interrupt, 'This', absorbing_man)]
