# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def sp_dr(effect: Effect, message: Message.WhenUnitBeDefeated):
        this = effect.this.CastTo(Ally)
        Unused(this)
        initiator = effect.GetInitiator()
        initiator.GainCard(this, effect)
    return [AbilityFactory.CanPlayThisAllyCard().SetPlay(only_if_you_control_trait='WEB-WARRIOR'), AbilityFactory.WhenUnitBeDefeated(AbilityType.WhenDefeated, 'This', sp_dr, by_consequential=True, took_excess_damage=True)]
