# Recovered automatically from Python 3.10 bytecode.
# Comments and original formatting were not present in the compiled file.

from . import *
def GetAbilities():
    def war(effect: Effect, message: Message.WhenPlayerInTurn):
        this = effect.this.CastTo(Upgrade)
        Unused(this)
        initiator = effect.GetInitiator()
        hero = initiator.GetHero()
        face = Worlds.DiscardEncounterTopCard(effect)
        if face:
            value = 0
            value = (value + FacesCounter.CountTotalBoostIcons([face]))
            value = (value + FacesCounter.CountTotalBoostStar([face]))
            hero.TakeDamage(face, value, effect)
        face = initiator.DiscardDeckTopCard(effect)
        damage = FacesCounter.GetTotalCost([face])
        this.DealDamage(effect.targets, damage, effect)
    return [AbilityFactory.WhenInYourPlayTurn(AbilityType.HeroAction, war).SetCostFunc(CostFunc.Exhaust('This')).SetTarget(Enemy)]
